/* © 2026 mdulac86. Tous droits réservés. Reproduction, modification et publication interdites sans permission (voir LICENSE). */
/* Menu de la semaine — Utilitaires, état des données, sauvegarde et protection.
   Les fichiers de js/ partagent les mêmes variables globales; ils sont chargés dans l'ordre de index.html. */
/* ---------- utilitaires ---------- */
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/œ/g,'oe');
const keyOf = (name,u) => norm(name).replace(/\([^)]*\)/g,'').replace(/\b([a-z']{3,}?)s\b/g,'$1').replace(/\s+(rapee?|romaine)\b/g,'').replace(/\s+/g,' ').trim().replace(/^lait (2|1|3\.25|entier|ecreme|partiellement ecreme) ?%?$/,'lait')+'|'+u;
function fq(q,u){
  const dec = x => String(+x.toFixed(2)).replace('.', ',');
  if(u==='g') return q>=1000 ? dec(q/1000)+' kg' : Math.round(q)+' g';
  if(u==='ml') return q>=1000 ? dec(q/1000)+' L' : Math.round(q)+' ml';
  return '× '+String(Math.round(q*10)/10).replace('.', ',');
}
const RAYONS = ['fruits et légumes','boulangerie','viandes','poissonnerie','produits laitiers','épicerie','garde-manger','collations','boissons','surgelés'];
const GENERIC = ['fromage','pates','pain','riz','nouilles','pizza','sauce','tomate'];
const PACKS = [
  [/\boeuf/,12,'un'],[/^beurre/,454,'g'],[/^bacon/,400,'g'],[/^lait/,2000,'ml'],
  [/^creme/,500,'ml'],[/ricotta/,475,'g'],[/^sauce tomate/,680,'ml'],[/^farine/,2500,'g'],
  [/^(spaghetti|macaroni|fettuccine|rotini|penne|nouilles)/,450,'g'],[/^riz/,900,'g'],
  [/mozzarella|cheddar|fromage mexicain|fromage rape/,320,'g'],[/^parmesan/,200,'g'],[/^pommes? de terre$/,2270,'g'],
  [/^mayonnaise/,445,'ml'],[/^yogourt/,1,'un']
];
const packOf = (name,u) => { const A = art(name); if(A.pk && A.pk.u===u && A.pk.q > 0) return A.pk.q; const n = norm(name).replace(/\([^)]*\)/g,'').trim(); for(const [re,s,uu] of PACKS) if(uu===u && re.test(n)) return s; return 0; };
/* Un même ingrédient écrit en unités différentes est ramené à une seule unité, pour une seule ligne dans la liste. */
const CONV = [['pomme de terre','g',{un:200}],['tomate','un',{g:1/120}],['carotte','un',{g:1/75}],['oignon','un',{g:1/150}],
  ['chapelure','g',{ml:.45}],['chapelure panko','g',{ml:.25}],['farine','g',{ml:.53}],['fecule de mai','g',{ml:.55}],['cassonade','g',{ml:.85}],['sucre','g',{ml:.85}],
  ['sauce bbq','ml',{un:455}],["moutarde a l'ancienne",'ml',{un:250}],['cuisse de poulet desossee','g',{un:120}],['saucisse italienne','g',{un:100}],
  ['poitrine de poulet','g',{un:225}],['beurre','g',{ml:.96}],['saucisse','g',{un:100}],['patate douce','un',{g:1/300}],['haut de cuisse de poulet desosse','g',{un:120}],
  ['cotelette de porc desossee','g',{un:180}],['sauce aux prune','ml',{un:350}]];
const baseOf = name => keyOf(name,'').slice(0,-1);
function normQU(name, q, u){ const c = CONV.find(x => x[0]===baseOf(name)); return c && c[1]!==u && c[2][u] ? [q*c[2][u], c[1]] : [q, u]; }

/* ---------- état et mémoire ---------- */
const ESS_START = () => ([
    {name:'Oeufs (déjeuners)', q:12, u:'un', r:'produits laitiers', c:'Déjeuners'},
    {name:'Bacon (déjeuners)', q:400, u:'g', r:'viandes', c:'Déjeuners'},
    {name:'Céréales (boîte)', q:3, u:'un', r:'épicerie', c:'Déjeuners'},
    {name:'Gruau instantané (boîte)', q:1, u:'un', r:'épicerie', c:'Déjeuners'},
    {name:'Bagels ou muffins anglais', q:1, u:'un', r:'boulangerie', c:'Déjeuners'},
    {name:"Beurre d'arachide", q:1, u:'un', r:'épicerie', c:'Déjeuners'},
    {name:'Confiture', q:1, u:'un', r:'épicerie', c:'Déjeuners'},
    {name:'Yogourt (déjeuners)', q:8, u:'un', r:'produits laitiers', c:'Déjeuners'},
    {name:'Café', q:1, u:'un', r:'épicerie', c:'Déjeuners'},
    {name:'Pain tranché (lunchs et rôties)', q:3, u:'un', r:'boulangerie', c:'Lunchs'},
    {name:'Jambon tranché (lunchs)', q:300, u:'g', r:'viandes', c:'Lunchs'},
    {name:'Fromage tranché (paquet)', q:1, u:'un', r:'produits laitiers', c:'Lunchs'},
    {name:'Compotes de pommes (emballage)', q:1, u:'un', r:'épicerie', c:'Lunchs'},
    {name:'Boîtes de jus (lunchs)', q:1, u:'un', r:'épicerie', c:'Lunchs'},
    {name:'Pommes (sac)', q:1, u:'un', r:'fruits et légumes', c:'Fruits et légumes'},
    {name:'Bananes (régime)', q:1, u:'un', r:'fruits et légumes', c:'Fruits et légumes'},
    {name:'Clémentines ou oranges (sac)', q:1, u:'un', r:'fruits et légumes', c:'Fruits et légumes'},
    {name:'Raisins', q:1, u:'un', r:'fruits et légumes', c:'Fruits et légumes'},
    {name:'Carottes mini (collation)', q:1, u:'un', r:'fruits et légumes', c:'Fruits et légumes'},
    {name:'Concombres (collation)', q:2, u:'un', r:'fruits et légumes', c:'Fruits et légumes'},
    {name:'Croustilles (gros sac)', q:3, u:'un', r:'épicerie', c:'Collations famille'},
    {name:'Barres tendres (boîte)', q:2, u:'un', r:'épicerie', c:'Collations famille'},
    {name:'Biscuits', q:2, u:'un', r:'épicerie', c:'Collations famille'},
    {name:'Maïs soufflé', q:1, u:'un', r:'épicerie', c:'Collations famille'},
    {name:'Craquelins', q:1, u:'un', r:'épicerie', c:'Collations famille'},
    {name:'Fromage ficelle (sac)', q:1, u:'un', r:'produits laitiers', c:'Collations famille'},
    {name:'Mélange de noix (famille)', q:1, u:'un', r:'épicerie', c:'Collations famille'},
    {name:'Lait 2%', q:6000, u:'ml', r:'produits laitiers', c:'Boissons'},
    {name:'Boisson gazeuse (caisse de 12)', q:2, u:'un', r:'épicerie', c:'Boissons'},
    {name:'Jus (2 L)', q:2, u:'un', r:'épicerie', c:'Boissons'},
    {name:'Eau pétillante (caisse)', q:1, u:'un', r:'épicerie', c:'Boissons'}
]);
const DEFAULT = () => ({
  v:3, appv:'', lastExport:'', maj:0, help:false, cp:'', relay:'', dates:{plan:'', shop:''}, auto:null,
  stock:{}, hist:[], custom:[], varx:{},
  menu:{date:'', items:[], chk:{}, extra:{}, achete:false, snap:null, useup:{}},
  spec:[],
  p:{n:6, cool:4, varMode:'alt', jours:5, souper:5, restes:2, maxTm:35, nLong:1, nEnt:0, nDes:2, nDej:2, nDin:5, pDej:0, pDin:0, dinRestes:true, pp:'spec', off:[0,6], main:'', grp:'rayon', budget:0, reste:true}, sidesx:[], tmx:{}, tpx:{}, fav:{},
  maison:'sel, poivre, huile d\'olive, huile végétale, cannelle, clou de girofle, poudre de chili, ketchup, moutarde, sauce soya',
  snacks:[], ess:[],
  dis:{}, vared:{}, vardel:{}, redit:{}, stores:[], setup:false, rate:{}, art:{}, ph:{}
});
let S = DEFAULT();

const isObj = x => !!x && typeof x==='object' && !Array.isArray(x);
function mergeState(o){ if(!isObj(o)) throw new Error('données invalides'); const d = DEFAULT(); const m = Object.assign(d, o);
  /* chaque champ doit avoir le bon type, sinon on reprend la valeur par défaut (sauvegarde ancienne ou abîmée) */
  const D = DEFAULT(); Object.keys(D).forEach(k => { const v = D[k]; if(Array.isArray(v) && !Array.isArray(m[k])) m[k] = v; else if(isObj(v) && !isObj(m[k])) m[k] = v; });
  ['storesx','skip','report'].forEach(k => { if(m[k] != null && !Array.isArray(m[k])) delete m[k]; });
  ['prices','tmx','tpx','fav','dis','rate','art','ph','redit','vared','vardel','varx','bx','pmaj','pe'].forEach(k => { if(!isObj(m[k])) m[k] = {}; });
  m.menu = Object.assign(DEFAULT().menu, isObj(o.menu) ? o.menu : {});
  ['items','dej','din','ent','sou','des','sn'].forEach(k => { if(m.menu[k] != null && !Array.isArray(m.menu[k])) m.menu[k] = []; if(Array.isArray(m.menu[k])) m.menu[k] = m.menu[k].filter(x => isObj(x) && typeof x.r==='string' || (k==='sn' && isObj(x))); });
  ['chk','extra','useup','dinCook','dinNo','dsel'].forEach(k => { if(!isObj(m.menu[k])) m.menu[k] = {}; });
  m.custom = m.custom.filter(r => isObj(r) && typeof r.n==='string' && Array.isArray(r.i)).map(r => Object.assign(r, {m: Array.isArray(r.m) ? r.m.map(String) : [], i: r.i.filter(g => Array.isArray(g) && +g[0] >= 0 && typeof g[2]==='string'), e: typeof r.e==='string' ? r.e : '', s: typeof r.s==='string' ? r.s : ''}));
  m.hist = m.hist.filter(isObj).map(w => Object.assign(w, {items: Array.isArray(w.items) ? w.items : []}));
  if(m.auto && !(isObj(m.auto) && Array.isArray(m.auto.items))) m.auto = null; if((o.v||1) < 2){ m.ess = d.ess; } m.v = 4; m.p = Object.assign(DEFAULT().p, isObj(o.p) ? o.p : {});   /* nouveaux réglages : valeurs par défaut */ m.menu.useup = m.menu.useup||{}; if(m.menu.date && !m.menu.dej && !m.menu.achete) m.menu.fillNew = true; m.menu.dej = m.menu.dej||[]; m.menu.din = m.menu.din||[]; m.menu.dinCook = m.menu.dinCook||{}; m.menu.dinNo = m.menu.dinNo||{}; m.menu.dsel = m.menu.dsel||{}; m.art = m.art||{}; m.ph = m.ph||{};
  try{ Object.keys(m.ph).forEach(k => { m.ph[k] = (m.ph[k]||[]).filter(e => isFood(e.t)); if(!m.ph[k].length) delete m.ph[k]; }); if(m.auto && m.auto.items) m.auto.items = m.auto.items.filter(i => isFood(i.t)); }catch(e){} m.menu.ent = m.menu.ent||[]; m.menu.sou = m.menu.sou||[]; m.menu.des = m.menu.des||[]; if(!m.dates) m.dates = {plan:'', shop:''}; m.storesx = m.storesx||[]; m.stores = (m.stores||[]).filter(s => !['Loblaws','Food Basics','No Frills'].includes(s)); m.stores.forEach(s => { if(!STORES.includes(s) && !m.storesx.includes(s)) m.storesx.push(s); });
  m.p.budget = Math.max(0, +m.p.budget || 0);
  const st = {}; Object.values(m.stock).forEach(x => { if(!isObj(x) || typeof x.name!=='string' || !(+x.q > 0)) return; const [q,u] = normQU(x.name,+x.q,x.u); const k = keyOf(x.name,u); if(st[k]) st[k].q += q; else st[k] = Object.assign({}, x, {q,u}); }); m.stock = st;
  return m; }
/* ---------- protection des données ----------
   Les données vivent sur le téléphone, sous la clé KEY. Une mise à jour de l'application ne remplace que le code.
   1. Si les données ne peuvent pas être lues, elles sont mises de côté (RESCUE) avant tout enregistrement.
   2. Une copie est gardée avant chaque nouvelle version et une fois par jour (COPIES, 5 au maximum).
   3. Une copie peut être enregistrée dans Fichiers et restaurée. */
const APPV = self.APP_VERSION || 'dev', TEST = !!self.APP_TEST, PFX = TEST ? 'menu_test_' : 'menu_epicerie_';
const TEST_PAGE = TEST && /test\.html$/.test(location.pathname);   /* version de test publiée comme fichiers « test… » à la racine */
const KEY = PFX + 'v1', COPIES = PFX + 'copies', RESCUE = PFX + 'secours', REAL_KEY = 'menu_epicerie_v1';
let loadFailed = false, rescued = false, bkBar = true;   /* bkBar : bandeau de sauvegarde, une fois par ouverture */
function readCopies(){ try{ const a = JSON.parse(localStorage.getItem(COPIES) || '[]'); return Array.isArray(a) ? a.filter(x => isObj(x) && typeof x.data==='string') : []; }catch(e){ return []; } }
function snapshot(label, raw){
  try{ const o = JSON.parse(raw); delete o.auto; raw = JSON.stringify(o); }catch(e){}
  const L = readCopies(); L.unshift({d: new Date().toISOString(), day: isoToday(), label, data: raw});
  for(let n = Math.min(L.length, 5); n >= 1; n--){ try{ localStorage.setItem(COPIES, JSON.stringify(L.slice(0, n))); return true; }catch(e){} }
  return false;
}
function loadLocal(){
  let j = null;
  try{ j = localStorage.getItem(KEY); }catch(e){}
  if(j){
    try{ S = mergeState(JSON.parse(j)); }
    catch(e){ loadFailed = true; try{ if(!localStorage.getItem(RESCUE)) localStorage.setItem(RESCUE, j); rescued = true; }catch(_){} }
    if(!loadFailed && S.appv !== APPV){ snapshot('Avant la mise à jour', j); S.appv = APPV; try{ localStorage.setItem(KEY, JSON.stringify(S)); }catch(e){} }
    if(loadFailed) S.flash = "Tes données n'ont pas pu être lues par cette version. Elles sont gardées de côté, rien n'est effacé : Profil → Compte → « Essayer de les restaurer ».";
  } else S.appv = APPV;
}
/* nombre saisi : « 1 200 », « 150 $ », « 2,5 » ; jamais négatif ni NaN */
const numIn = v => Math.max(0, parseFloat(String(v ?? '').replace(/[\s\u00a0$]/g,'').replace(',','.')) || 0);
var _FAV = new Map(), _GK = new Map();
function resetCaches(){ _FAV = new Map(); _GK = new Map(); _DO = new WeakMap(); _AR = _ND = _BL = _CAT = _PN = null; _DF = new Map(); _AS = null; _ASA = null; _ECO = new Map(); _CMP = new Map(); if(typeof peReset === 'function') peReset(); }
function save(){
  resetCaches(); S.maj = Date.now(); S.bkDirty = true;
  if(loadFailed){ setSync("Données illisibles : rien n'est enregistré pour ne rien écraser (voir Profil)"); return; }
  const raw = JSON.stringify(S);
  const put = () => { localStorage.setItem(KEY, raw); setSync('Enregistré sur cet appareil'); };
  try{ put(); }
  catch(e){   /* stockage plein : garder seulement la copie la plus récente, puis réessayer */
    try{ localStorage.setItem(COPIES, JSON.stringify(readCopies().slice(0, 1))); put(); }
    catch(e2){ try{ localStorage.removeItem(COPIES); put(); }catch(e3){ setSync("Enregistrement impossible : mode privé ou stockage plein"); return; } }
  }
  try{ const L = readCopies(); if(!L.some(c => c.label==='Copie du jour' && c.day===isoToday())) snapshot('Copie du jour', raw); }catch(e){}
}
function setSync(t){ const e = $('#sync'); if(e) e.textContent = t; }

/* Menu de la semaine — Recettes : variantes, accompagnements, portions, mode Cuisiner, textes, importation.
   Les fichiers de js/ partagent les mêmes variables globales; ils sont chargés dans l'ordre de index.html. */
/* ---------- recettes : variantes et ingrédients ---------- */
let _AR = null, _ND = null, _BL = null, _CAT = null, _DF = new Map();  /* caches vidés à chaque enregistrement ou rendu */
/* recettes de base + banque commune de la famille (robot des reels), avec tes modifications, puis les tiennes */
function allRecipes(){ if(!_AR){ if(FAMREC === null) famLoad(); const own = new Set(RECIPES.map(r => r.n).concat(S.custom.map(r => r.n)));
  _AR = RECIPES.concat(FAMREC.filter(r => !own.has(r.n))).map(r => S.redit && S.redit[r.n] ? Object.assign({}, r, S.redit[r.n]) : r).concat(S.custom); } return _AR; }
let FAMREC = null;
const baseRecipe = n => RECIPES.find(x => x.n===n) || (FAMREC || []).find(x => x.n===n);
/* Index rebuilt only when the recipe array changes; duplicate-name precedence is preserved. */
let recipeIndexSource = null, recipeIndex = new Map();
const byName = n => {
  const recipes = allRecipes();
  if(recipeIndexSource !== recipes){
    recipeIndexSource = recipes; recipeIndex = new Map();
    recipes.forEach(r => { if(!recipeIndex.has(r.n)) recipeIndex.set(r.n, r); });
  }
  return recipeIndex.get(n);
};
function varRows(r){
  const rows = [], del = (S.vardel||{})[r.n]||[], ed = (S.vared||{})[r.n]||{};
  (r.v||[]).forEach((v,i) => { if(del.includes(i)) return; rows.push({src:'b', i, v:ed[i]||v, edited:!!ed[i]}); });
  ((S.varx||{})[r.n]||[]).forEach((v,j) => rows.push({src:'x', i:j, v}));
  return rows;
}
const vars = r => varRows(r).map(x => x.v);
const KINDS = {souper:'Soupers et dîners', dejeuner:'Déjeuners', entree:'Entrées', soupe:'Soupes et potages', dessert:'Desserts', sauce:'Sauces'};
const KIND1 = {souper:'Souper ou dîner', dejeuner:'Déjeuner', entree:'Entrée', soupe:'Soupe ou potage', dessert:'Dessert', sauce:'Sauce (complément)'};
/* Les dîners (din) utilisent les mêmes recettes que les soupers (items). */
const LISTS = ['items','din','dej','ent','sou','des'];
const ML = {items:'souper', din:'souper', dej:'dejeuner', ent:'entree', sou:'soupe', des:'dessert'};
const LOFK = {souper:'items', dejeuner:'dej', entree:'ent', soupe:'sou', dessert:'des'};
const LBL = {items:'Soupers', din:'Dîners', dej:'Déjeuners', ent:'Entrées', sou:'Soupes et potages', des:'Desserts'};
const kindOf = r => r.k || 'souper';
const PRS = {poulet:'Poulet et volaille', boeuf:'Boeuf', porc:'Porc et charcuterie', poisson:'Poissons et fruits de mer', vege:'Végétarien et oeufs', mixte:'Autres viandes'};
const STYS = {fumoir:'Fumoir', plancha:'Plancha', pub:'Pub, sport et tailgate', poutine:'Poutines', pates:'Pâtes', riz:'Riz et nouilles', sandwich:'Sandwichs et burgers', mex:'Mexicain', asia:'Asiatique', mijote:'Mijoté et mijoteuse', bbq:'Grillé et BBQ', four:'Au four', poele:'À la poêle', soupe:'Soupes', salade:'Salades', bouchee:'Bouchées et trempettes', biscuit:'Biscuits et carrés', gateau:'Gâteaux, tartes et muffins', fruit:'Fruits et croustades', froid:'Poudings et desserts froids', crepe:'Crêpes', prepare:'Plats préparés', sauce:'Sauces'};
function prOf(r){
  if(r.pr) return r.pr;
  if(kindOf(r)==='dessert' || kindOf(r)==='dejeuner') return '';
  const meat = r.i.filter(g => g[3]==='viandes' || g[3]==='poissonnerie').map(g => g[2]).join(' ');
  const t = norm(r.n+' '+meat);
  if(/poulet|dinde|volaille/.test(t)) return 'poulet';
  if(/poisson|saumon|crevette|morue|aiglefin|thon|truite|petoncle|fruits de mer/.test(t)) return 'poisson';
  if(/boeuf|steak|bavette|tournedos|rosbif|veau/.test(t)) return 'boeuf';
  if(/porc|jambon|bacon|saucisse|bologne|lardon|cotes levees|pepperoni|cotelette/.test(t)) return 'porc';
  return meat ? 'mixte' : 'vege';
}
function styOf(r){
  if(r.st && r.st.length) return r.st;
  const s = new Set(), t = norm(r.n+' '+(r.s||'')), byT = {pates:'pates', riz:'riz', sandwich:'sandwich', mex:'mex'};
  if(byT[r.t]) s.add(byT[r.t]);
  if(/soya|teriyaki|tao|chinois|ramen|egg roll|wok|sesame/.test(t)) s.add('asia');
  if(/mijot|braise|chili|ragout|stroganov|coq au/.test(norm(r.n)) || /mijoteuse|1 h 30/.test(t)) s.add('mijote');
  if(/bbq|grill|brochette|steak|bavette|cotes levees|tournedos/.test(t)) s.add('bbq');
  if(/soupe/.test(t)) s.add('soupe');
  if(/salade/.test(norm(r.n))) s.add('salade');
  if(/four|plaque|gratin|lasagne|pate a la viande|pizza|°f/.test(t)) s.add('four');
  if(!s.size) s.add('poele');
  return [...s];
}
/* ---------- goûts de chaque membre de la famille ----------
   Une note de 1 à 5 par protéine, sorte de plat ou aliment : 5 J'adore, 4 J'aime, 3 Je tolère, 2 Je n'aime pas, 1 Refuse d'en manger.
   Le menu favorise ce que chacun aime et répartit les coups de cœur dans la semaine. Un plat que personne ne mange n'est jamais
   proposé; si seulement certains refusent la protéine principale, une 2e protéine est prévue pour eux (selon le choix de la semaine). */
let QW = null;   /* réponses du questionnaire pendant qu'on bâtit l'ébauche */
const weekQ = () => QW || (S.menu && S.menu.q) || {};
const NOTES = [[5,"J'adore"],[4,"J'aime"],[3,'Je tolère'],[2,"Je n'aime pas"],[1,"Refuse d'en manger"]];
const NOTE_PTS = {5:1.6, 4:.8, 3:0, 2:-1.3};
const GOUTS = [
  ['Protéines', [['poulet','Poulet'],['boeuf','Boeuf'],['porc','Porc'],['poisson','Poisson'],['mer','Fruits de mer'],['vege','Végé (tofu, légumineuses)']]],
  ['Sortes de plats', [['pates','Pâtes'],['riz','Riz et nouilles'],['mex','Mexicain'],['asia','Asiatique'],['sandwich','Sandwichs et burgers'],['pub','Pub'],['poutine','Poutine'],['bbq','BBQ et grillades'],['fumoir','Fumoir'],['mijote','Mijotés'],['soupe','Soupes'],['salade','Salades'],['piquant','Épicé (piquant)']]],
  ['Aliments', [['champi','Champignons'],['poivron','Poivrons'],['oignon','Oignons'],['tomate','Tomates'],['olive','Olives'],['brocoli','Brocoli'],['epinard','Épinards'],['coriandre','Coriandre'],['fromage','Fromage']]]];
const GOUT_L = Object.fromEntries(GOUTS.flatMap(g => g[1]));
const GOUT_PROT = ['poulet','boeuf','porc','poisson','mer','vege'];
const GOUT_RE = {poulet:/poulet|dinde|volaille/, boeuf:/boeuf|steak|bavette|surlonge|entrecote|filet mignon|contre-filet|faux-filet|rosbif|tournedos|veau|brisket/,
  porc:/porc|jambon|bacon|saucisse|chorizo|pancetta|prosciutto|lardon|pepperoni|salami|bologne|cotes levees|cretons|capicollo/,
  poisson:/saumon|truite|tilapia|morue|aiglefin|goberge|\bsole\b|fletan|thon|maquereau|sardine|poisson|\bdore\b|perchaude|vivaneau|mahi|espadon|anchois/,
  mer:/crevette|petoncle|homard|crabe|moule|palourde|calmar|pieuvre|huitre|langoustine|fruits de mer|surimi/,
  piquant:/piment|jalapeno|sriracha|chipotle|cayenne|harissa|gochujang|buffalo|piquant|sambal|tabasco|habanero|chili broye/,
  champi:/champignon/, poivron:/poivron/, oignon:/oignon(?!s? verts?)|echalote/, tomate:/tomate/, olive:/\bolives?\b/, brocoli:/brocoli/, epinard:/epinard/, coriandre:/coriandre/,
  fromage:/fromage|cheddar|mozzarella|parmesan|feta|gruyere|\bbrie\b|chevre|ricotta|monterey|emmental|bocconcini|halloumi|mascarpone|provolone/};
/* texte d'un plat pour reconnaître les goûts : sans le bouillon, l'huile d'olive ni les sauces de poisson */
const goutTxt = (r, v) => (norm(r.n) + ' | ' + effective(r, v||0).map(g => norm(g.name)).join(' | ')).replace(/huile d.olive/g, ' ')
  .replace(/(bouillon|fond|base|cubes?|consomme) (de |d.|au |aux )?(poulet|boeuf|legumes|poisson|veau|fruits de mer)/g, ' ').replace(/sauce (de |au |aux )?(poisson|huitres?)/g, ' ');
function goutKeys(r, v){
  const key = r.n + '|' + (v||0); let K = _GK.get(key); if(K) return K;
  const T = goutTxt(r, v), out = new Set();
  ['poulet','boeuf','porc','poisson','mer'].forEach(k => { if(GOUT_RE[k].test(T)) out.add(k); });
  const pr = prOf(r);
  if(![...out].length && ['poulet','boeuf','porc','poisson'].includes(pr)) out.add(pr);
  if(pr==='vege' && ['souper','soupe'].includes(kindOf(r)) && !GOUT_PROT.some(k => out.has(k))) out.add('vege');
  styOf(r).forEach(x => { if(GOUT_L[x]) out.add(x); });
  ['piquant','champi','poivron','oignon','tomate','olive','brocoli','epinard','coriandre','fromage'].forEach(k => { if(GOUT_RE[k].test(T)) out.add(k); });
  K = [...out]; _GK.set(key, K); return K;
}
/* protéines principales : celles qui pèsent dans le plat (pas quelques tranches de bacon sur le dessus) */
function mainProts(r, v){
  const W = {};
  effective(r, v||0).forEach(g => { const n = norm(g.name); if(/bouillon|fond de|sauce|consomme/.test(n)) return;
    const gr = g.u==='g' ? g.q : g.u==='un' ? g.q * 150 : g.u==='ml' ? g.q : 0;
    ['poulet','boeuf','porc','poisson','mer'].forEach(k => { if(GOUT_RE[k].test(n)) W[k] = (W[k]||0) + gr; }); });
  const mx = Math.max(0, ...Object.values(W)), L = Object.keys(W).filter(k => W[k] >= 200 && W[k] >= .4 * mx);
  if(!L.length){ const pr = prOf(r); if(['poulet','boeuf','porc','poisson'].includes(pr) && kindOf(r)==='souper') L.push(pr); }
  return L;
}
const membresG = () => profil().membres;
const goutsActifs = () => membresG().some(m => (m.g && Object.keys(m.g).length) || String(m.rx||'').trim());
const motsRefus = m => String(m.rx||'').split(/[,;\n]/).map(w => norm(w).trim()).filter(w => w.length >= 3);
function avisMembre(m, r, v){
  const K = goutKeys(r, v), g = m.g || {}, refus = K.filter(k => g[k] === 1);
  const W = motsRefus(m); if(W.length){ const T = goutTxt(r, v); W.forEach(w => { if(T.includes(w)) refus.push('mot:' + w); }); }
  const vals = K.map(k => g[k]).filter(x => x >= 2 && x <= 5);
  return {refus, pts: vals.length ? vals.reduce((t, x) => t + NOTE_PTS[x], 0) / Math.sqrt(vals.length) : 0};
}
/* avis de toute la famille sur un plat : qui refuse quoi, et la note moyenne (pondérée par les portions) */
function famAvis(r, v){
  const key = r.n + '|' + (v||0); let A = _FAV.get(key); if(A) return A;
  const mains = mainProts(r, v), L = membresG().map((m, i) => Object.assign({i, w:portionDe(m), lunch:!!m.l}, avisMembre(m, r, v)));
  L.forEach(x => { x.prot = x.refus.filter(k => mains.includes(k)); x.autre = x.refus.filter(k => !mains.includes(k)); });
  const W = L.reduce((t, x) => t + x.w, 0) || 1;
  A = {L, mains, pts: L.reduce((t, x) => t + x.w * (x.refus.length ? 0 : x.pts), 0) / W, tous: L.length > 0 && L.every(x => x.refus.length),
    refProt: L.filter(x => x.prot.length), refAutre: L.filter(x => x.autre.length && !x.prot.length)};
  _FAV.set(key, A); return A;
}
const mixW = () => weekQ().mix || 'p2';
/* écarté cette semaine : personne n'en mange, ou on évite les plats à 2 protéines, ou une protéine mise de côté */
function famBad(r){
  const pas = weekQ().pas || [];
  if(pas.length && kindOf(r)==='souper' && (pas.includes(prOf(r)) || mainProts(r, 0).some(k => pas.includes(k === 'mer' ? 'poisson' : k)))) return true;
  if(!goutsActifs()) return false;
  const A = famAvis(r, 0); if(A.tous) return true;
  return mixW()==='eviter' && A.refProt.length > 0 && kindOf(r)==='souper';
}
function famBonus(r){
  let b = 0; const env = weekQ().env || [];
  if(env.length){ const K = new Set([prOf(r), ...styOf(r)]); if(env.some(k => K.has(k))) b += 1.4; }
  if(!goutsActifs()) return b;
  const A = famAvis(r, 0);
  /* une entrée, une soupe ou un dessert n'a pas de 2e protéine : chaque personne qui refuse compte */
  if(kindOf(r) !== 'souper') return b + 1.1 * A.pts - 1.2 * A.L.filter(x => x.refus.length).length;
  return b + 1.1 * A.pts - (A.refProt.length ? (mixW()==='pareil' ? 1.5 : .4) : 0) - .9 * A.refAutre.length;
}
/* « Papa n'en mange pas » : pour une entrée, une soupe ou un dessert */
function pasPour(it){
  const r = it && byName(it.r); if(!r || !goutsActifs()) return '';
  const L = famAvis(r, it.v).L.filter(x => x.refus.length); if(!L.length) return '';
  return `${nomsDe(L)} ${L.length > 1 ? 'n\'en mangent' : 'n\'en mange'} pas (${refusTxt(L.flatMap(x => x.refus))})`;
}
/* un accompagnement que quelqu'un n'aime pas (brocoli, champignons…) passe après les autres */
function goutSidePen(sd){
  if(!sd || !goutsActifs()) return 0;
  const T = norm(sd.n + ' ' + (sd.i||[]).map(g => g[2]).join(' ')); let p = 0;
  membresG().forEach(m => { const g = m.g || {}; Object.keys(g).forEach(k => { const re = GOUT_RE[k]; if(re && g[k] <= 2 && re.test(T)) p += g[k] === 1 ? 2 : .8; });
    motsRefus(m).forEach(w => { if(T.includes(w)) p += 2; }); });
  return p;
}
const nomDe = i => { const M = membresG(), m = M[i]; if(!m) return ''; if(m.nom && String(m.nom).trim()) return String(m.nom).trim();
  const ad = m.a==='adulte'; return (ad ? 'Adulte ' : 'Enfant ') + M.slice(0, i+1).filter(x => (x.a==='adulte')===ad).length; };
const etListe = L => L.length > 1 ? L.slice(0, -1).join(', ') + ' et ' + L[L.length-1] : (L[0] || '');
const nomsDe = L => etListe(L.map(x => nomDe(x.i)));
const refusTxt = keys => etListe([...new Set(keys)].map(k => k.startsWith('mot:') ? k.slice(4) : (GOUT_L[k] || k).toLowerCase()));
/* 2e protéine : pour ceux qui refusent la protéine principale, cuite à part avec le même assaisonnement */
const P2 = {poulet:{lbl:'Poulet', n:'poitrines de poulet', g:170, ray:'viandes', s:"Poêler les poitrines de poulet à feu moyen 6 à 7 min par côté (ou 20 à 25 min au four à 400 °F), avec le même assaisonnement ou la même sauce que le plat, jusqu'à 74 °C au centre."},
  porc:{lbl:'Porc', n:'côtelettes de porc désossées', g:170, ray:'viandes', s:'Poêler les côtelettes 4 à 5 min par côté, avec le même assaisonnement que le plat, jusqu\'à 63 °C au centre.'},
  boeuf:{lbl:'Steak de boeuf', n:'steaks de surlonge', g:180, ray:'viandes', s:'Saisir les steaks à feu vif 3 à 4 min par côté (mi-saignant), avec le même assaisonnement que le plat. Laisser reposer 5 min.'},
  vege:{lbl:'Tofu', n:'tofu ferme', g:150, ray:'fruits et légumes', s:"Couper le tofu en cubes, bien l'éponger et le dorer 8 à 10 min à la poêle avec un filet d'huile et le même assaisonnement ou la même sauce que le plat."},
  poisson:{lbl:'Saumon', n:'filets de saumon', g:150, ray:'poissonnerie', s:'Cuire les filets de saumon 12 à 15 min au four à 400 °F, avec le même assaisonnement que le plat.'}};
function p2Def(qui, mains){
  const M = membresG(); let best = '', bs = -9;
  ['poulet','porc','boeuf','vege','poisson'].forEach((k, j) => { if(mains.includes(k) || (k==='poisson' && mains.includes('mer'))) return;
    const notes = qui.map(x => ((M[x.i]||{}).g||{})[k === 'poisson' ? 'poisson' : k] || 3); if(notes.some(n => n === 1)) return;
    const sc = notes.reduce((t, n) => t + n, 0) / notes.length - j * .05; if(sc > bs){ bs = sc; best = k; } });
  return best;
}
/* les membres qui refusent la protéine principale d'un plat du menu (les lunchs : seulement ceux qui apportent un lunch) */
function refusDe(it, l){
  if(!goutsActifs() || !it) return null;
  const r = byName(it.r); if(!r || !(kindOf(r)==='souper' || it.sr)) return null;
  const A = famAvis(r, it.v), din = l==='din' || it.din, pool = din ? A.L.filter(x => x.lunch) : A.L;
  return {A, pool, prot: pool.filter(x => x.prot.length), autre: pool.filter(x => x.autre.length)};
}
function p2Info(it, l){
  const R = refusDe(it, l); if(!R || !R.prot.length || R.prot.length === R.pool.length) return null;
  if(it.p2 === 'non' || (mixW()==='pareil' && !it.p2)) return null;
  const alt = it.p2 && P2[it.p2] && !R.A.mains.includes(it.p2) ? it.p2 : p2Def(R.prot, R.A.mains); if(!alt) return null;
  const W = R.pool.reduce((t, x) => t + x.w, 0) || 1, share = R.prot.reduce((t, x) => t + x.w, 0) / W;
  return {alt, qui:R.prot, share, mains:R.A.mains, re:new RegExp(R.A.mains.map(k => GOUT_RE[k].source).join('|'))};
}
const p2Grams = (it, p) => Math.max(100, Math.round(portionsOf(it) * p.share * P2[p.alt].g / 10) * 10);
const p2Fac = (p, name) => p && p.re.test(norm(name)) ? Math.max(0, 1 - p.share) : 1;
function p2Sel(it, l, i){
  const R = refusDe(it, l); if(!R || !R.prot.length || R.prot.length === R.pool.length) return '';
  const info = p2Info(it, l), cur = info ? info.alt : 'non';
  const opts = ['poulet','porc','boeuf','vege','poisson'].filter(k => !R.A.mains.includes(k) && !(k==='poisson' && R.A.mains.includes('mer')))
    .map(k => `<option value="${k}" ${cur===k?'selected':''}>${esc(P2[k].lbl)} pour ${esc(nomsDe(R.prot))}</option>`).join('') + `<option value="non" ${cur==='non'?'selected':''}>Aucune : même plat pour tous</option>`;
  return `<select data-a="p2sel" data-ml="${l}" data-i="${i}" aria-label="2e protéine">${opts}</select>`;
}
/* la phrase « Papa ne mange pas de poisson : 340 g de poitrines de poulet à part » */
function p2Txt(it, l){
  const R = refusDe(it, l); if(!R || !R.prot.length) return '';
  const qui = nomsDe(R.prot), pl = R.prot.length > 1, info = p2Info(it, l), ref = refusTxt(R.prot.flatMap(x => x.prot));
  if(R.prot.length === R.pool.length) return `${qui} ${pl ? 'ne mangent' : 'ne mange'} pas : ${ref}.`;
  return info ? `${qui} ${pl ? 'ne mangent' : 'ne mange'} pas : ${ref}. 2e protéine : ${fq(p2Grams(it, info), 'g')} de ${P2[info.alt].n}, cuits à part.` : `${qui} ${pl ? 'ne mangent' : 'ne mange'} pas : ${ref}. Pas de 2e protéine prévue.`;
}
const autreTxt = (it, l) => { const R = refusDe(it, l); if(!R || !R.autre.length) return ''; return R.autre.map(x => `${nomDe(x.i)} refuse : ${refusTxt(x.autre)}`).join('. ') + '. À retirer de sa portion, ou change le plat.'; };
/* Profil → Famille : les goûts d'une personne */
function goutsBlock(m, i){
  const g = m.g || {}, ks = Object.keys(g), ref = ks.filter(k => g[k]===1).concat(motsRefus(m).map(w => 'mot:'+w)), ad = ks.filter(k => g[k]===5), pk = 'gouts|' + i;
  const sum = [ad.length ? 'adore : ' + refusTxt(ad) : '', ref.length ? 'refuse : ' + refusTxt(ref) : ''].filter(Boolean).join(' · ') || (ks.length ? `${ks.length} note${ks.length>1?'s':''}` : 'pas encore notés');
  return `<details class="panel gouts" data-pan="${pk}" ${openPan.has(pk)?'open':''}><summary>Goûts de ${esc(nomDe(i))} <small>${esc(sum)}</small></summary>
    <p class="small">Laisse « — » quand c'est égal. Avec « Refuse d'en manger », le plat n'est jamais servi tel quel à cette personne : une 2e protéine est prévue, ou le plat est évité.</p>
    ${GOUTS.map(([t, L]) => `<p class="gt-h">${esc(t)}</p><div class="gt-grid">${L.map(([k, lab]) => `<label class="gt"><span>${esc(lab)}</span><select class="mini${g[k] ? ' n'+g[k] : ''}" data-pg="${k}" data-i="${i}" aria-label="${esc(lab)} pour ${esc(nomDe(i))}"><option value="">—</option>${NOTES.map(([v, nn]) => `<option value="${v}" ${g[k]===v?'selected':''}>${esc(nn)}</option>`).join('')}</select></label>`).join('')}</div>`).join('')}
    <label class="f">Refuse aussi (autres aliments, séparés par des virgules)<input type="text" data-pf="rx" data-i="${i}" value="${esc(m.rx||'')}" placeholder="ex. betteraves, câpres" autocomplete="off"></label></details>`;
}
const PRS_S = {poulet:'Poulet', boeuf:'Boeuf', porc:'Porc', poisson:'Poisson', vege:'Végé', mixte:'Viande'};
const STYS_S = {fumoir:'Fumoir', plancha:'Plancha', pub:'Pub', poutine:'Poutine', pates:'Pâtes', riz:'Riz', sandwich:'Sandwich', mex:'Mexicain', asia:'Asiatique', mijote:'Mijoté', bbq:'Grillé', four:'Four', poele:'Poêle', soupe:'Soupe', salade:'Salade', bouchee:'Bouchée', biscuit:'Biscuits', gateau:'Gâteau', fruit:'Fruits', froid:'Froid', crepe:'Crêpes'};
function metaTags(r, souper){
  const t = [PRS_S[prOf(r)], ...styOf(r).map(s => STYS_S[s])].filter(Boolean).map(x => `<span>${esc(x)}</span>`);
  if(r.nw) t.push('<span class="new">Nouveau</span>');
  if(r.fam) t.push('<span class="liked">Famille</span>');
  if(r.oc) t.push('<span class="long">À l\'occasion</span>');
  if(estTiktok(r)) t.push('<span class="new">TikTok</span>');
  if(S.fav[r.n]) t.push('<span class="fav">Favori</span>');
  if(souper && isLong(r)) t.push('<span class="long">Fin de semaine</span>');
  methods(r).slice(1).forEach(m => t.push(`<span class="cmt">${esc(m.l)}</span>`));
  if(r.pp) t.push('<span class="pp">Prêt à servir</span>');
  if(r.sp) t.push(`<span>${kindOf(r)==='dejeuner' ? 'Déjeuner de semaine' : 'Simple'}</span>`);
  if(r.pp && dealsOf(r).length) t.push('<span class="spec">En spécial</span>');
  const rt = S.rate[r.n]; if(rt && rt.up > rt.down) t.push('<span class="liked">Aimé</span>'); else if(rt && rt.down > rt.up) t.push('<span class="long">Peu aimé</span>');
  return `<div class="meta">${t.join('')}</div>`;
}
const tagHtml = s => `<span class="tag"><span class="nm">${esc(s.t)}</span>${s.p ? `<b>${esc(s.p)}</b>` : ''}<small>${esc(s.s)}</small></span>`;
const tagLine = r => [kindOf(r)==='souper' ? '' : KIND1[kindOf(r)], PRS[prOf(r)]||'', ...styOf(r).map(s => STYS[s]||'')].filter(Boolean).join(' · ');
const mlist = l => (S.menu[l] = S.menu[l] || []);
const nOf = l => l==='items' ? S.p.n : l==='ent' ? (S.p.nEnt||0) : l==='sou' ? (S.p.nSou||0) : l==='dej' ? (S.p.nDej||0) : l==='din' ? dinNeed().length : (S.p.nDes||0);
const allItems = () => LISTS.flatMap(l => S.menu[l]||[]);
const histItems = w => (w.items||[]).concat(w.din||[], w.dej||[], w.ent||[], w.sou||[], w.des||[]);
function deltaItems(delta){
  const out = {add:[], rem:[]};
  String(delta||'').split(';').map(s => s.trim()).filter(Boolean).forEach(tok => {
    const m = tok.match(/^@([fv])=(\S+)$/); if(m){ out[m[1]] = m[2]; return; }
    if(tok[0]==='+'){ const x = tok.match(/^\+\s*([\d.,]+)\s+(g|ml|un)\s+(.*?)(?:\|(.*))?$/); if(x) out.add.push({q:parseFloat(x[1].replace(',','.')), u:x[2], name:x[3].trim(), ray:(x[4]||'').trim()}); }
    else if(tok[0]==='-'){ const x = tok.match(/^-\s*([\d.,]+)\s+(g|ml|un)\s+(.*)$/); out.rem.push(x ? {q:parseFloat(x[1].replace(',','.')), u:x[2], name:x[3].trim()} : {name:tok.slice(1).trim()}); }
  });
  return out;
}
const unitTxt = (q,u) => `${+q} ${u==='un' ? '' : u+' '}`;
function varDetail(v){
  const d = deltaItems(v[1]), L = [];
  const sn = id => id==='aucun' ? 'aucun' : ((sideById(id)||{}).n || id);
  d.add.forEach(a => L.push('Ajoute : '+qt(a.q,a.u)+' '+a.name));
  d.rem.forEach(x => L.push('Retire : '+(x.q ? qt(x.q,x.u)+' ' : '')+x.name));
  if(d.f!==undefined) L.push('Féculent : '+sn(d.f));
  if(d.v!==undefined) L.push('Légume ou salade : '+sn(d.v));
  const desc = vdesc(v[0]);
  return `<div class="var">${desc?`<p style="margin:0">${esc(desc)}</p>`:''}${L.length?`<ul class="small" style="margin:4px 0 0;padding-left:18px">${L.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}${v[2]?`<p class="small" style="margin:4px 0 0"><b>Préparation :</b> ${esc(v[2])}</p>`:''}${!desc && !L.length && !v[2] ? '<p class="small" style="margin:0">Aucun changement d\'ingrédient.</p>' : ''}</div>`;
}
function resetV(n){ allItems().forEach(x => { if(x.r===n){ x.v = 0; x.ovr = {}; } }); }
/* après un changement de versions : chaque plat garde la même version (retrouvée par son contenu), sinon revient à la base */
function remapV(n, before, a){
  const r = byName(n), after = r ? varRows(r).map(x => x.v) : [];
  allItems().concat((S.occ && S.occ.items) || []).forEach(x => { if(x.r!==n || !x.v) return; const old = before[x.v-1], j = after.indexOf(old);
    if(j >= 0) x.v = j+1; else if(a==='vsave' && after[x.v-1]) {} else { x.v = 0; x.ovr = {}; } });
}
function addToMenu(r){ const l = LOFK[kindOf(r)]; const L = mlist(l); L.push(l==='items' ? mkItem(r, usedSides(L), pickVar(r)) : {r:r.n, v:pickVar(r)}); if(l==='items'){ linkFollow(L[L.length-1]); assignDays(false); } }
const vname = t => { const i = t.indexOf(':'); const n = (i>0 ? t.slice(0,i) : t).trim(); return n.length>34 ? n.slice(0,32)+'…' : n; };
const vdesc = t => { const i = t.indexOf(':'); return i>0 ? t.slice(i+1).trim() : ''; };
function effective(r, idx){
  const map = new Map();
  const add = (q,u,name,rayon) => { const k = keyOf(name,u); const o = map.get(k); if(o) o.q += q; else map.set(k,{q,u,name,rayon:rayon||'épicerie'}); };
  r.i.forEach(([q,u,name,rayon]) => add(q,u,name,rayon));
  const d = idx>0 && vars(r)[idx-1] ? vars(r)[idx-1][1] : '';
  d.split(';').map(x => x.trim()).filter(Boolean).forEach(tok => {
    if(tok[0]==='+'){
      const m = tok.match(/^\+\s*([\d.,]+)\s+(g|ml|un)\s+(.*?)(?:\|(.*))?$/);
      if(m) add(parseFloat(m[1].replace(',','.')), m[2], m[3].trim(), (m[4]||'').trim());
    } else if(tok[0]==='-'){
      const m = tok.match(/^-\s*([\d.,]+)\s+(g|ml|un)\s+(.*)$/);
      if(m){ const k = keyOf(m[3].trim(), m[2]); const o = map.get(k); if(o){ o.q -= parseFloat(m[1].replace(',','.')); if(o.q<=0) map.delete(k); } }
      else { const nm = tok.slice(1).trim(), w = norm(nm), b = baseOf(nm), ex = [...map].filter(([k,o]) => baseOf(o.name)===b);
        const re = new RegExp('(^|[^a-z])' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '($|[^a-z])');
        (ex.length ? ex : [...map].filter(([k,o]) => re.test(norm(o.name)))).forEach(([k]) => map.delete(k)); }
    }
  });
  return [...map.entries()].map(([k,o]) => ({k,...o}));
}


/* ---------- accompagnements, portions, stock ---------- */
const TYPES = {viande:'Viande',pates:'Pâtes',riz:'Riz et nouilles',sandwich:'Sandwich et burger',mex:'Mexicain',complet:'Repas complet'};
const ALLS = () => SIDES.concat(S.sidesx||[], stockSides());
const sideById = id => id ? ALLS().find(s => s.id===id) : null;
const sidesOf = sl => ALLS().filter(s => s.sl===sl);
const compat = (s, r) => s.ty.includes('all') || s.ty.includes(r.t||(kindOf(r)==='soupe' ? 'soupe' : 'viande'));
/* une soupe servie comme repas : on lui choisit ses accompagnements comme pour un plat de type « soupe » */
const soupR = r => ({n:r.n, i:r.i, k:'soupe', t:'soupe', sf:'auto', sv:'auto'});
function mkSoupe(r, used){
  const rs = soupR(r), it = {r:r.n, v:0, sr:1, fm:1, vm:1, ovr:{f:false, v:false}};
  it.sf = chooseSide(rs, 'f', used); if(it.sf) used.add(it.sf); it.sv = chooseSide(rs, 'v', used);
  return it;
}
/* repas plaisir : un plat « à l'occasion » (soir de match, tailgate) ou de style pub */
const plaisirOk = r => kindOf(r)==='souper' && (r.oc || styOf(r).includes('pub') || styOf(r).includes('poutine'));
function repasPlaisir(items, k, banned){
  const taken = new Set(items.map(x => x.r));
  const C = allRecipes().filter(r => plaisirOk(r) && !S.dis[r.n] && !softBad(r) && ppOk(r) && !taken.has(r.n))
    .map(r => ({r, s:score(r) + (r.oc ? 1 : 0) - (banned && banned.has(r.n) ? 6 : 0)})).sort((a, b) => b.s - a.s);
  C.slice(0, k).forEach(({r}) => { const it = mkItem(r, usedSides(items), pickVar(r)); it.cm = 1; items.push(it); });
}
/* une soupe nourrissante (viande, légumineuses, pâtes, riz, pommes de terre) passe en premier comme repas */
const copieux = r => mainProts(r, 0).length > 0 || /lentille|pois chiche|haricot|feve|pates|nouille|riz|orge|pois casses|pommes? de terre|tortellini|gnocchi/.test(goutTxt(r, 0));
function soupesRepas(items, k, banned){
  const taken = new Set(items.map(x => x.r));
  const C = allRecipes().filter(r => kindOf(r)==='soupe' && !r.oc && !S.dis[r.n] && !softBad(r) && !taken.has(r.n))
    .map(r => ({r, s:score(r) + (copieux(r) ? 1.2 : 0) - (banned && banned.has(r.n) ? 6 : 0)})).sort((a, b) => b.s - a.s);
  C.slice(0, k).forEach(({r}) => items.push(mkSoupe(r, usedSides(items))));
}
const totalPortions = () => (S.p.souper||4) + (S.p.restes||0);
const pDej = () => S.p.pDej || S.p.souper || 4;
const pDin = () => S.p.pDin || (S.p.restes > 0 ? S.p.restes : S.p.souper) || 2;
const portionsOf = it => it.pt || (it.din ? pDin() : totalPortions());
/* portions habituelles d'un plat selon sa section du menu */
const ptDef = (it, l) => l==='items' ? totalPortions() : (l==='din' || it.din) ? pDin() : l==='dej' ? pDej() : 6;
function variantSides(r, idx){
  const o = {}; const d = idx>0 && vars(r)[idx-1] ? vars(r)[idx-1][1] : '';
  d.split(';').forEach(tok => { const m = tok.trim().match(/^@([fv])=(\S+)$/); if(m) o[m[1]] = m[2]==='aucun' ? '' : m[2]; });
  return o;
}
const recentSides = () => new Set(S.hist.slice(-2).flatMap(w => w.items.flatMap(x => [x.sf,x.sv])).filter(Boolean));
const usedSides = items => new Set(items.flatMap(x => [x.sf,x.sv]).filter(Boolean));
const sigWords = name => norm(name).replace(/\([^)]*\)/g,'').split(/[^a-z]+/).filter(w => w.length>=4 && !['fromage','sauce','pate','pates','pain','tranche','portion','individuel','boite','paquet','emballage','hache','moulu','rape','frais','fume','cuit','gros','grand','mini'].includes(w)).map(w => w.replace(/s$/,''));
/* « Fromage cheddar » couvre « cheddar râpé », « Poulet » couvre « poitrines de poulet », mais « Pommes » ne couvre pas « pommes de terre ». */
const CUTS = ['poitrine','cuisse','haut','filet','pilon','laniere','cube','tranche','desosse','desossee','surgele','surgelee','fort','doux','moyen','maigre','extra','entier','entiere','petit','petite','bebe','jeune','fraiche','frai'];
function sameFood(a, b){
  if(!a.length || !b.length) return false;
  const extra = (x, y) => x.filter(w => !y.includes(w));
  return (a.every(w => b.includes(w)) && extra(b,a).every(w => CUTS.includes(w))) || (b.every(w => a.includes(w)) && extra(a,b).every(w => CUTS.includes(w)));
}
function stockKey(n){
  if(S.stock[n.k]) return n.k;
  const nw = sigWords(n.name); if(!nw.length) return null;
  for(const [k,o] of Object.entries(S.stock)){ if(o.u===n.u && sameFood(sigWords(o.name), nw)) return k; }
  return null;
}
function stockSideBonus(s){ return s.i.some(([q,u,n]) => { if(isMaison(n)) return false; const u2 = normQU(n,q,u)[1]; return !!stockKey({k:keyOf(n,u2),name:n,u:u2}); }) ? .5 : 0; }
/* Genre de féculent. Un plat qui contient déjà des pâtes, du riz ou des patates ne reçoit que du pain;
   un plat dans du pain (burger, tacos) peut avoir des frites ou du riz, mais pas un autre pain. */
const STARCH = [['pates',/spaghetti|\bpates\b|macaroni|penne|fusilli|rotini|linguine|fettuccine|tortellini|ravioli|lasagne|gnocchi|nouilles|vermicelle|orzo|ramen|udon|coquilles/],
  ['riz',/\briz\b|risotto|quinoa|couscous/],['patate',/pommes? de terre|patates?|frites|grelots|pilees|rissolees|wedges|pelures|dauphinois/],
  ['pain',/\bpains?\b|baguette|naan|\bpitas?\b|tortillas?|brioche|ciabatta|kaiser/]];
const HEAVY = ['pates','riz','patate'];
const starchOf = txt => { const t = norm(txt).replace(/pates? a pizza|coquilles a tacos/g, 'pain').replace(/pates? (au poulet|a la viande)|pates? a tarte|pate de /g, ' ').replace(/pate chinois|hachis|cottage pie/g, 'patate'); return STARCH.filter(([,re]) => re.test(t)).map(([k]) => k); };
const _MST = new WeakMap(), _SST = new WeakMap();
function mainStarch(r){ let s = _MST.get(r); if(!s){ s = new Set(); (r.i||[]).forEach(g => starchOf(g[2]).forEach(k => s.add(k))); _MST.set(r, s); } return s; }
function sideStarch(sd){ let k = _SST.get(sd); if(!k){ k = [...new Set(starchOf(sd.n).concat((sd.i||[]).flatMap(g => starchOf(g[2]))))]; _SST.set(sd, k); } return k; }
function clash(sd, r){
  if(!sd || !r) return false; const m = mainStarch(r), k = sideStarch(sd); if(!k.length || !m.size) return false;
  if(k.some(x => m.has(x))) return true;
  return HEAVY.some(x => m.has(x)) && k.some(x => HEAVY.includes(x));
}
function chooseSide(r, slot, used){
  const def = (slot==='f' ? r.sf : r.sv) ?? '';
  if(def==='') return '';
  if(r.fx && r.fx[slot] && sideById(def)) return def;   /* accompagnement choisi pour toujours */
  const rec = recentSides();
  const c = sidesOf(slot).filter(s => !(S.sdis||{})[s.id] && (s.id===def || (compat(s,r) && !(slot==='f' && clash(s,r))))); if(!c.length) return '';
  let best='', bs=-9;
  c.forEach(s => { const sc = Math.random() + (s.id===def?.5:0) + (s.id.startsWith('st:')?.9:(s.id[0]==='x'?.3:0)) - (used.has(s.id)?1.5:0) - (rec.has(s.id)?.6:0) + stockSideBonus(s) - goutSidePen(s); if(sc>bs){ bs=sc; best=s.id; } });
  return best;
}
function mkItem(r, used, v){
  const ov = variantSides(r, v);
  const it = {r:r.n, v, ovr:{f:'f' in ov, v:'v' in ov}, fm:1, vm:1};
  it.sf = 'f' in ov ? ov.f : chooseSide(r,'f',used);
  it.sv = 'v' in ov ? ov.v : chooseSide(r,'v',used);
  return it;
}
function scaleQ(q,u,f){
  if(Math.abs(f-1)<1e-9) return q;
  const x = q*f;
  if(u==='un') return x>=3 ? Math.ceil(x-1e-9) : Math.ceil(x*2-1e-9)/2;
  return x>=100 ? Math.round(x/10)*10 : x>=20 ? Math.round(x/5)*5 : Math.max(.5, Math.round(x*2)/2);
}
function fullIngs(it, all){
  const r = byName(it.r); if(!r) return [];
  const f = kindOf(r)==='souper' || it.sr ? portionsOf(it)/6 : kindOf(r)==='dejeuner' ? (it.pt || pDej())/6 : (it.pt ? it.pt/6 : 1), ex = it.ex||[];
  const map = new Map();
  const put = (g, fac) => { if(fac<=0) return; const q = scaleQ(g.q,g.u,fac); const o = map.get(g.k); if(o) o.q += q; else map.set(g.k,{k:g.k,q,u:g.u,name:g.name,rayon:g.rayon}); };
  const prim = r.ur ? primOf(it) : null, p2 = p2Info(it, it.din ? 'din' : 'items');
  effective(r,it.v).forEach(g => { if(prim && urMatch(r.ur, g.name)){ if(all) map.set('r'+g.k,{k:g.k,q:scaleQ(g.q,g.u,f),u:g.u,name:g.name,rayon:g.rayon,rest:prim.r}); return; } const out = ex.includes(g.k); if(out && !all) return; if(out){ map.set('x'+g.k,{k:g.k,q:scaleQ(g.q,g.u,f),u:g.u,name:g.name,rayon:g.rayon,x:true}); return; } put(g, f * p2Fac(p2, g.name)); });
  if(p2){ const P = P2[p2.alt]; put({k:keyOf(P.n,'g'), q:p2Grams(it, p2), u:'g', name:P.n, rayon:P.ray}, 1); }
  if(r.rs && follOf(it)) r.rs.x.forEach(([q,u,n,ra]) => put({k:keyOf(n,u),q,u,name:n,rayon:ra}, 1));
  const sr = it.sc ? byName(it.sc) : null;   /* sauce ajoutée au plat */
  if(sr) sr.i.forEach(([q,u,n,ra]) => { const g = {k:keyOf(n,u),q,u,name:n,rayon:ra}; const out = ex.includes(g.k); if(out && !all) return; if(out){ map.set('x'+g.k,{...g,q:scaleQ(q,u,f),x:true}); return; } put(g, f); });
  [['sf','fm'],['sv','vm']].forEach(([key,mk]) => { const s = sideById(it[key]); if(!s) return;
    s.i.forEach(([q,u,n,ra]) => { const g = {k:keyOf(n,u),q,u,name:n,rayon:ra}; const out = ex.includes(g.k); if(out && !all) return; if(out){ map.set('x'+g.k,{...g,q:scaleQ(q,u,f),x:true}); return; } put(g, f*(it[mk]??1)); }); });
  return [...map.values()];
}
/* clé de stock d'un ingrédient, avec la même conversion d'unités que la liste (4 pommes de terre ↔ 800 g) */
const skOf = g => { const [q,u] = normQU(g.name, g.q, g.u); return stockKey({k:keyOf(g.name,u), name:g.name, u, q}); };
function stockOf(it){ const out = []; fullIngs(it).forEach(g => { if(isMaison(g.name)) return; const sk = skOf(g); if(sk){ const nm = S.stock[sk].name; if(!out.includes(nm)) out.push(nm); } }); return out.slice(0,3); }
function aUtiliser(){
  if(!Object.keys(S.stock).length) return [];
  const used = new Set(); needs().forEach(n => { if(n.src.includes('Restes à manger')) return; const sk = stockKey(n); if(sk) used.add(sk); });
  return Object.entries(S.stock).filter(([k,o]) => !isMaison(o.name) && !used.has(k)).map(([k,o]) => ({k,o,eat:!!S.menu.useup[k]}));
}
function ideesPour(o){
  const w = sigWords(o.name); if(!w.length) return [];
  const rec = recentSet(), inM = new Set(allItems().map(x => x.r));
  return allRecipes().filter(r => !S.dis[r.n] && !rec.has(r.n) && !inM.has(r.n) && effective(r,0).some(g => g.u===o.u && sigWords(g.name).some(x => w.includes(x)))).slice(0,3);
}
function sidesLabel(r){ const nm = id => id==='auto' ? 'varié' : (sideById(id)||{}).n; return `${TYPES[r.t||'viande']||''} · Par défaut : ${[nm(r.sf||''),nm(r.sv||'')].filter(Boolean).join(' + ') || 'aucun accompagnement'} (change chaque semaine)`; }
const qt = (q,u) => fq(q,u).replace('× ','');
function sideBlock(it,i,l){
  l = l || 'items'; const r = byName(it.r), dis = '';
  const QO = [[0,'Aucun'],[0.5,'Moins'],[1,'Normal'],[1.5,'Plus'],[2,'Double']];
  const rr = it.sr && r ? soupR(r) : r;
  const col = slot => { const key = slot==='f'?'sf':'sv', mk = slot==='f'?'fm':'vm', all = sidesOf(slot);
    const fit = s => compat(s,rr) && !(slot==='f' && clash(s,rr)), ok = all.filter(fit), other = all.filter(s => !fit(s)); const cur = it[key]||'';
    const op = s => `<option value="${esc(s.id)}" ${cur===s.id?'selected':''}>${esc(s.n)}</option>`;
    return `<div><label class="f">${slot==='f' ? (it.sr ? 'Avec la soupe' : 'Féculent') : 'Légume / salade'}<select data-a="sidesel" data-ml="${l}" data-i="${i}" data-s="${slot}" ${dis}><option value="">Aucun</option><optgroup label="Recommandés">${ok.map(op).join('')}</optgroup><optgroup label="Autres">${other.map(op).join('')}</optgroup></select></label>
      <label class="f">Quantité<select data-a="sideq" data-ml="${l}" data-i="${i}" data-s="${slot}" ${dis}>${QO.map(([v,n]) => `<option value="${v}" ${(it[mk]??1)===v?'selected':''}>${n}</option>`).join('')}</select></label></div>`; };
  return `<div class="grid2">${col('f')}${col('v')}</div>`;
}
function renderUtiliser(){
  const L = aUtiliser(); if(!L.length) return '';
  return `<div class="card"><h3>À utiliser cette semaine</h3><p class="small">Ce qui est à la maison et que le menu n'utilise pas encore. « Je le mange » le compte comme collation ou lunch; il sera retiré de la maison à la fin de la semaine.</p>`
   + L.map(x => { const id = ideesPour(x.o); return `<div class="item" style="flex-wrap:wrap"><span class="t"><b>${esc(x.o.name)}</b><small>${fq(x.o.q,x.o.u)} en stock</small></span><button class="btn s ${x.eat?'p':''}" data-a="eat" data-k="${esc(x.k)}">${x.eat?'Au menu ✓':'Je le mange'}</button>${id.length?`<div class="chips" style="width:100%">${id.map(r => `<button class="btn s" data-a="addrec" data-r="${esc(r.n)}">+ ${esc(r.n)}</button>`).join('')}</div>`:''}</div>`; }).join('') + `</div>`;
}

/* ---------- iPhone ou Android : l'aide, la sauvegarde et l'installation en dépendent ---------- */
const UA = navigator.userAgent || '';
const ANDROID = /Android/i.test(UA);
const IOS = !ANDROID && (/iPhone|iPad|iPod/i.test(UA) || (navigator.platform==='MacIntel' && navigator.maxTouchPoints > 1));
const FICH = IOS ? 'Fichiers' : 'Téléchargements';            /* où va une copie enregistrée */
const NAVI = IOS ? 'Safari' : ANDROID ? 'Chrome' : 'le navigateur';
const isInstalled = () => { try{ return navigator.standalone===true || matchMedia('(display-mode: standalone)').matches; }catch(e){ return false; } };
/* Android (Chrome) : l'invitation à installer est gardée pour un bouton « Installer l'application » */
let instEvt = null;
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); instEvt = e; try{ render(); }catch(_){} });
window.addEventListener('appinstalled', () => { instEvt = null; try{ render(); }catch(_){} });
async function installApp(){
  if(!instEvt) return; const ev = instEvt;
  try{ ev.prompt(); const c = await ev.userChoice; if(c && c.outcome==='accepted') instEvt = null; }catch(e){ instEvt = null; }
  render();
}
const instBtn = () => instEvt && !isInstalled() ? `<button class="btn s p" data-a="inst_go">Installer l'application</button>` : '';
/* bouton Retour d'Android (et glisser vers la gauche) : ferme Cuisiner, quitte le mode magasin, revient à Ma semaine.
   Seulement ensuite, il quitte l'application. Une seule entrée d'historique, sans changer l'adresse. */
const navDeep = () => !!cook || !!plusK || storeMode || tab!=='semaine';
let navBack = false;
function navSync(){
  try{
    const g = !!(history.state && history.state.mds);
    if(navDeep() && !g) history.pushState({mds:1}, '');
    else if(!navDeep() && g && !navBack){ navBack = true; history.back(); setTimeout(() => { navBack = false; }, 800); }
  }catch(e){}
}
try{ history.scrollRestoration = 'manual'; }catch(e){}
window.addEventListener('popstate', () => {
  if(navBack){ navBack = false; navSync(); return; }
  if(cook){ cook = null; wakeOff(); renderCook(); }
  else if(plusK){ plusK = ''; render(); }
  else if(storeMode){ storeMode = false; lockScreen(false); render(); window.scrollTo(0, 0); }
  else if(tab!=='semaine'){ tab = 'semaine'; render(); window.scrollTo(0, 0); }
  navSync();
});

/* ---------- mode Cuisiner : ingrédients et étapes à cocher ---------- */
let cook = null, wl = null;
const CK = PFX + 'cuisine';   /* cases cochées, à part des données (pas de sauvegarde pour ça) */
const ckRead = () => { try{ return JSON.parse(localStorage.getItem(CK) || '{}') || {}; }catch(e){ return {}; } };
const ckWrite = o => { try{ const lim = Date.now() - 8*864e5; Object.keys(o).forEach(k => { if(!o[k] || (o[k].ts||0) < lim) delete o[k]; }); localStorage.setItem(CK, JSON.stringify(o)); }catch(e){} };
async function wakeOn(){ try{ if(cook && !wl && navigator.wakeLock){ wl = await navigator.wakeLock.request('screen'); wl.addEventListener('release', () => { wl = null; }); } }catch(e){ wl = null; } }
function wakeOff(){ try{ if(wl) wl.release(); }catch(e){} wl = null; }
/* une étape par phrase; « 400°F 40 min. » ou « 2,5 » ne coupent pas */
function splitSteps(s){
  const parts = String(s||'').replace(/\s+/g, ' ').replace(/(^|[.!?]\s+)\d{1,2}[.)]\s+/g, '$1').trim().split(/([.!?])\s+/), out = []; let cur = '';
  for(let i = 0; i < parts.length; i += 2){ cur += parts[i] + (parts[i+1] || ''); const nx = parts[i+2];
    if(nx === undefined || /^[A-ZÀ-ÖØ-Þ0-9«(]/.test(nx)){ if(cur.trim()) out.push(cur.trim()); cur = ''; } else cur += ' '; }
  return out;
}
function cookItem(){
  if(!cook) return null;
  if(cook.r){ const r = byName(cook.r); if(!r) return null; const kd = kindOf(r);
    const it = {r:r.n, v:cook.v||0, cm:cook.cm||'', pt: cook.pt || (kd==='souper' ? totalPortions() : kd==='dejeuner' ? pDej() : 0), sf:r.sf && r.sf!=='auto' ? r.sf : '', sv:r.sv && r.sv!=='auto' ? r.sv : ''};
    if(cook.ms && kd==='souper'){ const left = stockLeft(); Object.entries(fitStock(r, it.pt, left).use).forEach(([k,q]) => { left[k] = Math.max(0, left[k] - q); }); maisonSides(it, r, it.pt, left); }
    return {r, it, l:''}; }
  const it = mlist(cook.l)[cook.i]; if(!it) return null; const r = byName(it.r); return r ? {r, it, l:cook.l} : null;
}
function cookHtml(){
  const c = cookItem(); if(!c) return '';
  const {r, it, l} = c, kd = kindOf(r), vs = vars(r), cur = it.v>0 ? vs[it.v-1] : null;
  const k = cmEff(it, r), M = methods(r); cook.ck = cook.key + (k ? '|'+k : '');
  const f = kd==='souper' || it.sr ? portionsOf(it)/6 : kd==='dejeuner' ? (it.pt || pDej())/6 : (it.pt ? it.pt/6 : 1);
  const np = kd==='souper' || it.sr ? portionsOf(it) : kd==='dejeuner' ? (it.pt || pDej()) : (it.pt || 0);
  const qx = (q, u) => u==='un' ? String(Math.round(q*10)/10).replace('.', ',') : fq(q, u);
  const prim = l==='items' && r.ur ? primOf(it) : null, fo = l==='items' ? follOf(it) : null, ex = it.ex || [];
  const groups = [], steps = [];
  const p2 = l==='items' || l==='din' ? p2Info(it, l) : null;
  const main = effective(r, it.v||0).map(g => ({n:g.name, q:qx(scaleQ(g.q,g.u,f*p2Fac(p2, g.name)), g.u), note: prim && urMatch(r.ur, g.name) ? 'restes de '+prim.r : ex.includes(g.k) ? 'retiré de la liste d\'épicerie' : ''}));
  if(r.rs && fo) r.rs.x.forEach(([q,u,n]) => main.push({n, q:qx(q,u), note:'en plus, pour '+fo.r}));
  groups.push({t: kd==='souper' || it.sr ? 'Le plat' : '', rows:main});
  if(p2) groups.push({t:'2e protéine pour '+nomsDe(p2.qui), rows:[{n:P2[p2.alt].n, q:qx(p2Grams(it, p2), 'g'), note:''}]});
  const sr = it.sc ? byName(it.sc) : null;
  if(sr) groups.push({t:'Sauce : '+sr.n, rows:sr.i.map(([q,u,n]) => ({n, q:qx(scaleQ(q,u,f), u), note:''}))});
  const sides = [['sf','fm'],['sv','vm']].map(([k,m]) => ({s:sideById(it[k]), m:it[m]??1})).filter(x => x.s && x.m > 0);
  sides.forEach(({s, m}) => groups.push({t:'Avec : '+s.n, rows:s.i.map(([q,u,n]) => ({n, q:qx(scaleQ(q,u,f*m), u), note:''}))}));
  splitSteps(stepsM(r, k)).forEach(t => steps.push({t}));
  /* une version « au four » ne va pas avec une autre façon de cuire */
  if(cur && cur[2] && !(k && /four|frit|mijot|air|bbq|grill|plancha|fumoir|poele/.test(norm(cur[0])))) splitSteps(cur[2]).forEach(t => steps.push({t, g:'Pour la version '+vname(cur[0]).toLowerCase()}));
  if(p2) steps.push({t:P2[p2.alt].s, g:'2e protéine pour '+nomsDe(p2.qui)});
  if(sr && sr.s) splitSteps(sr.s).forEach(t => steps.push({t, g:'Sauce : '+sr.n}));
  sides.filter(x => x.s.s).forEach(({s}) => splitSteps(s.s).forEach(t => steps.push({t, g:'Avec : '+s.n})));
  const sans = sides.filter(x => !x.s.s); if(sans.length) steps.push({t:'Préparer '+sans.map(x => lowFirst(x.s.n)).join(' et ')+'.', g:'Accompagnements'});
  const st = (ckRead()[cook.ck] || {}).c || {};
  let ni = 0; const total = groups.reduce((t,g) => t + g.rows.length, 0) + steps.length, done = Object.keys(st).filter(k => st[k] && (/^s(\d+)$/.test(k) ? +k.slice(1) < steps.length : /^i(\d+)$/.test(k) && +k.slice(1) < total - steps.length)).length;
  const ingH = groups.map(g => `${g.t ? `<p class="ck-g">${esc(g.t)}</p>` : ''}<div class="ck-list">${g.rows.map(x => { const id = 'i'+(ni++);
    return `<label class="ck-row"><input type="checkbox" data-ck="${id}" ${st[id]?'checked':''}><span class="ck-tx"><span>${esc(x.n)}${x.note ? `<em>${esc(x.note)}</em>` : ''}</span><span class="ck-q">${esc(x.q)}</span></span></label>`; }).join('')}</div>`).join('');
  let lastG = null, sn = 0;
  const stepH = steps.map((x, j) => { const id = 's'+j, head = x.g !== lastG && x.g ? `</div><p class="ck-g">${esc(x.g)}</p><div class="ck-list">` : ''; lastG = x.g; sn++;
    return `${head}<label class="ck-row ck-step"><input type="checkbox" data-ck="${id}" ${st[id]?'checked':''}><span class="ck-num">${sn}</span><span class="ck-tx">${esc(x.t)}</span></label>`; }).join('');
  const when = it.d ? (l==='dej' ? 'Déjeuner' : l==='din' ? 'Dîner' : 'Souper')+', '+dayLbl(it.d).toLowerCase() : KIND1[kd] || '';
  const mt = l==='items' ? mjTxt(it, r) : '';
  return `<div class="ck-in"><div class="ck-top"><button class="btn s" data-a="ck_close">Fermer</button><span class="ck-prog" id="ck_prog">${done} sur ${total} cochés</span></div>
    <div class="ck-bar" aria-hidden="true"><i id="ck_bar" style="width:${total ? Math.round(done/total*100) : 0}%"></i></div>
    ${recipePhoto(r, 'cook-photo')}<p class="td-k">${esc(when)}</p><h2 class="ck-t">${esc(r.n)}</h2>
    <p class="small">${np ? `Pour ${np} portions` : 'Environ 6 à 8 portions'} · ${esc(tmTxtM(r, k))}${cur ? ' · version '+esc(vname(cur[0]).toLowerCase()) : ''}</p>
    ${M.length ? `<div class="seg ck-cm" role="group" aria-label="Façon de cuire">${M.map(m => `<button class="${m.k===k?'on':''}" data-a="ck_cm" data-k="${m.k||'b'}">${esc(m.l)} <small>${esc(fmtMin(m.tm))}</small></button>`).join('')}</div>${cmAuto(it, r) ? `<p class="small">${esc(CM_L[k])} : choisi parce que c'est un soir de semaine.</p>` : ''}` : ''}
    ${mt ? `<p class="rest">${esc(mt)}</p>` : ''}${l==='items' && extrasDe(it.d).length ? `<p class="rest">Aussi ce soir : ${esc(extrasDe(it.d).join(' · '))}.</p>` : ''}${prim ? `<p class="rest">Avec les restes de ${esc(prim.r)}.</p>` : ''}${fo ? `<p class="rest">Garde le surplus pour ${esc(fo.r)}.</p>` : ''}
    ${navigator.wakeLock ? '<p class="small">L\'écran reste allumé pendant que tu cuisines.</p>' : ''}
    <h3 class="ck-h">Ingrédients</h3>${ingH}
    <h3 class="ck-h">Étapes</h3><div class="ck-list">${stepH}</div>
    <div class="acts"><button class="btn s" data-a="ck_reset">Tout décocher</button><button class="btn s p" data-a="ck_close">Terminé</button></div></div>`;
}
function renderCook(){
  const el = $('#cook'); if(!el) return;
  const html = cook ? cookHtml() : '';
  if(!html){ if(cook){ cook = null; wakeOff(); } el.hidden = true; el.innerHTML = ''; document.documentElement.classList.remove('ckopen'); return; }
  el.innerHTML = html; el.hidden = false; document.documentElement.classList.add('ckopen');
}
function openCook(o){
  if(o.r) cook = {r:o.r, v:o.v||0, pt:o.pt||0, ms:!!o.ms, cm:o.cm||'', key:'r|'+o.r+(o.pt ? '|'+o.pt : '')};
  else { const it = mlist(o.l)[o.i]; if(!it) return; cook = {l:o.l, i:o.i, key:o.l+'|'+it.r+'|'+(it.d||S.menu.date||'')}; }
  renderCook(); const el = $('#cook'); if(el) el.scrollTop = 0;
  wakeOn(); navSync();
}
function closeCook(){ cook = null; wakeOff(); renderCook(); navSync(); }
function ckProgress(){
  const el = $('#cook'); if(!el) return; const all = el.querySelectorAll('input[data-ck]'), done = el.querySelectorAll('input[data-ck]:checked').length;
  const pg = $('#ck_prog'), br = $('#ck_bar'); if(pg) pg.textContent = `${done} sur ${all.length} cochés`; if(br) br.style.width = (all.length ? Math.round(done/all.length*100) : 0)+'%';
}
document.addEventListener('visibilitychange', () => { if(cook && document.visibilityState==='visible') wakeOn(); });
document.addEventListener('keydown', e => { if(cook && e.key==='Escape') closeCook(); });

/* ---------- textes à envoyer ---------- */
function ligneSouper(it,i){
  const r = byName(it.r); if(!r) return null;
  const vs = vars(r), v = it.v>0 && vs[it.v-1] ? vname(vs[it.v-1][0]) : '';
  const ac = avecTxt(it), k = cmEff(it, r);
  return {r, v, ac, k, titre:`${i+1}. ${r.n}${v ? ' - '+v : ''}${k ? ' ('+CM_L[k].toLowerCase()+')' : ''}`};
}
function texteMenu(){
  const m = S.menu; if(!m.date) return '';
  const L = [`MENU DE LA SEMAINE - ${m.date}`];
  LISTS.forEach(l => {
    if(l==='din'){ const P = dinPlan().filter(p => p.it || p.rest); if(!P.length) return; L.push('', 'DÎNERS');
      P.forEach(p => { if(p.rest){ L.push(`${dayLbl(p.d)} : restes de ${p.rest.r}`); return; }
        const x = ligneSouper(p.it, 0); if(!x) return;
        L.push((p.d ? dayLbl(p.d)+' : ' : '')+x.titre.replace(/^\d+\. /,''));
        if(x.ac) L.push('   Avec : '+x.ac);
        L.push(`   ${portionsOf(p.it)} portions`); });
      return; }
    const X = mlist(l).slice(); if(!X.length) return; L.push('', LBL[l].toUpperCase());
    if(l==='items' || l==='dej') X.sort((a,b) => (a.d||'9').localeCompare(b.d||'9'));
    X.forEach((it,i) => { const x = ligneSouper(it,i); if(!x) return;
      L.push(it.d && (l==='items' || l==='dej') ? `${dayLbl(it.d)} : ${x.titre.replace(/^\d+\. /,'')}${it.sr ? ' (soupe-repas)' : it.cm ? ' (repas plaisir)' : ''}` : x.titre);
      if((l==='ent' || l==='sou') && it.ro) L.push('   ' + roleTxt(it, l));
      if(x.ac) L.push('   Avec : '+x.ac);
      if(it.sc) L.push('   Sauce : '+it.sc);
      if(l==='items'){ const p2 = p2Info(it, l); if(p2) L.push(`   2e protéine pour ${nomsDe(p2.qui)} : ${fq(p2Grams(it, p2), 'g')} de ${P2[p2.alt].n}`); }
      if(l==='items') L.push(`   ${portionsOf(it)} portions`);
      if(l==='dej') L.push(`   ${it.pt || pDej()} portions`);
      const p = primOf(it); if(p && x.r.ur) L.push(`   Avec les restes de : ${p.r}`);
      const fo = follOf(it); if(fo && x.r.rs) L.push(`   Garder des restes pour : ${fo.r}`);
      itemDeals(it, x.r).slice(0,2).forEach(d => L.push(`   Spécial : ${specTxt(d.hit)}`)); }); });
  return L.join('\n');
}
function texteRecette(it, i, withCode){
  const x = ligneSouper(it, i||0); if(!x) return ''; const r = x.r, kd = kindOf(r);
  const np = kd==='souper' ? portionsOf(it) : kd==='dejeuner' ? (it.pt || pDej()) : (it.pt || 0);
  const L = [x.titre.replace(/^\d+\. /,''), `${kd==='souper' && !it.din && !it.pt ? `Pour ${np} portions (souper + restes du dîner)` : np ? `Pour ${np} portions` : 'Environ 6 à 8 portions'} · ${tmTxtM(r, x.k)}`];
  const cur = it.v>0 ? vars(r)[it.v-1] : null;
  if(cur) L.push('Version : '+vname(cur[0])+(vdesc(cur[0]) ? ' - '+vdesc(cur[0]) : ''));
  if(x.ac) L.push('Accompagnements : '+x.ac);
  L.push('', 'INGRÉDIENTS');
  fullIngs(it).sort((a,b) => a.name.localeCompare(b.name,'fr')).forEach(g => L.push(`- ${g.name} : ${qt(g.q,g.u)}`));
  if(stepsM(r, x.k)) L.push('', x.k ? 'PRÉPARATION ('+CM_L[x.k].toUpperCase()+')' : 'PRÉPARATION', stepsM(r, x.k));
  if(cur && cur[2]) L.push('', 'POUR CETTE VERSION', cur[2]);
  if(withCode) L.push('', "Pour l'ajouter à ta banque (Recettes, Importer une recette copiée), copie tout ce message :", recCode(r));
  return L.join('\n');
}
function texteDetail(){
  const m = S.menu; if(!m.date) return '';
  const parts = []; LISTS.forEach(l => mlist(l).forEach((it,i) => { const t = texteRecette(it,i); if(t) parts.push(t); }));
  return `MENU DÉTAILLÉ - semaine du ${m.date}\n\n` + parts.join('\n\n------------------------------\n\n');
}
function texteListe(){
  const m = S.menu; if(!m.date) return '';
  const {rows, verify} = buyList();
  const L = [`LISTE D'ÉPICERIE - ${m.date}`];
  groupsOf(rows).forEach(g => { L.push('', g.title.toUpperCase()); g.sub.forEach(s => { if(s.ray) L.push('- '+cap(s.ray)); s.rows.forEach(r => { const d = dealFor(r.name); L.push(`[ ] ${cap(r.name)} : ${qt(r.buy,r.u)}${d ? '   (spécial '+d.s+(d.p ? ' '+d.p : '')+')' : ''}`); }); }); });
  if(verify.length) L.push('', 'À VÉRIFIER À LA MAISON', verify.map(v => v.name).sort().join(', '));
  return L.join('\n');
}

/* ---------- importer une recette copiée ---------- */
function recCode(r){
  const o = {n:r.n, k:kindOf(r), pr:r.pr||'', st:r.st||[], t:r.t||'', tm:tmOf(r), sf:r.sf||'', sv:r.sv||'', m:r.m||[], i:r.i, s:r.s||'', v:vars(r)};
  if(tpOf(r) < tmOf(r)) o.tp = tpOf(r); if(mjOf(r)) o.mj = mjOf(r);
  if(r.pp) o.pp = true; if(r.ur) o.ur = r.ur; if(r.rs) o.rs = r.rs; if(hasCm(r)) o.cm = r.cm; if(Array.isArray(r.al)) o.al = r.al;
  let bin = ''; new TextEncoder().encode(JSON.stringify(o)).forEach(x => { bin += String.fromCharCode(x); });
  return 'MDS1.'+btoa(bin)+'.FIN';
}
function decodeCode(c){ const bin = atob(c.replace(/\s+/g,'')); return JSON.parse(new TextDecoder().decode(Uint8Array.from(bin, ch => ch.charCodeAt(0)))); }
function uniqueName(n){ let x = n, k = 2; while(allRecipes().some(r => norm(r.n)===norm(x))) x = `${n} (${k++})`; return x; }
function parseRecetteTexte(txt){
  const lines = txt.split(/\r?\n/).map(l => l.trim());
  const title = lines.find(l => l && !/^(pour |environ |version|accompagnements|ingr)/i.test(l)); if(!title) return null;
  const pm = txt.match(/Pour (\d+) portions/), fac = pm ? 6/(+pm[1]) : 1;
  const i0 = lines.findIndex(l => /^INGR[ÉE]DIENTS$/i.test(l)); if(i0<0) return null;
  const ing = [];
  for(let k = i0+1; k < lines.length && lines[k]; k++){
    const m = lines[k].match(/^-\s*(.+?)\s*:\s*([\d.,]+)\s*(kg|g|ml|L)?$/); if(!m) continue;
    let q = parseFloat(m[2].replace(',','.')), u = m[3] || 'un'; [q,u] = toBase(q,u);
    q = u==='un' ? Math.max(1, Math.round(q*fac*2)/2) : Math.round(q*fac);
    ing.push([q, u, m[1], (catFind(m[1])||{}).ray || guessRayon(m[1])]);
  }
  if(!ing.length) return null;
  const p0 = lines.findIndex(l => /^PR[ÉE]PARATION$/i.test(l));
  const s = p0>=0 ? lines.slice(p0+1).filter(Boolean).filter(l => !/^POUR CETTE VERSION|^Pour l'ajouter/.test(l))[0] || '' : '';
  return {n:title.replace(/\s+-\s+.*$/,''), k:'souper', m:[], i:ing, s, v:[], tm:30, sf:'auto', sv:'auto', t:'viande'};
}

/* ---------- lire une recette copiée d'un site Internet ---------- */
const FRACS = {'½':.5,'¼':.25,'¾':.75,'⅓':1/3,'⅔':2/3,'⅛':.125,'⅜':.375,'⅝':.625,'⅞':.875,'⅕':.2};
/* Mesures : [expression, facteur, unité de base]. Les cuillères et tasses canadiennes : 15 ml, 5 ml, 250 ml. */
const MESURES = [
  [/^(?:c\.?\s*(?:à|a)\s*(?:soupe|table|s\.?)|cuill[eè]res?\s*(?:à|a)\s*(?:soupe|table)|cuil\.?\s*(?:à|a)\s*soupe|c\.\s*s\.|c-à-s|cas|tbsp|tbs|tb)(?![a-zà-ÿ])\.?/i, 15, 'ml'],
  [/^(?:c\.?\s*(?:à|a)\s*(?:th[ée]|caf[ée]|t\.?)|cuill[eè]res?\s*(?:à|a)\s*(?:th[ée]|caf[ée])|cuil\.?\s*(?:à|a)\s*th[ée]|c\.\s*t\.|c-à-t|cat|tsp)(?![a-zà-ÿ])\.?/i, 5, 'ml'],
  [/^(?:tasses?|cups?)(?![a-zà-ÿ])/i, 250, 'ml'],
  [/^(?:millilitres?|ml)(?![a-zà-ÿ])\.?/i, 1, 'ml'],
  [/^(?:centilitres?|cl)(?![a-zà-ÿ])/i, 10, 'ml'],
  [/^(?:décilitres?|dl)(?![a-zà-ÿ])/i, 100, 'ml'],
  [/^(?:litres?|l)(?![a-zà-ÿ])\.?/i, 1000, 'ml'],
  [/^(?:kilogrammes?|kilos?|kg)(?![a-zà-ÿ])\.?/i, 1000, 'g'],
  [/^(?:grammes?|gr|g)(?![a-zà-ÿ])\.?/i, 1, 'g'],
  [/^(?:livres?|lbs?)(?![a-zà-ÿ])\.?/i, 454, 'g'],
  [/^(?:onces?|oz)(?![a-zà-ÿ])\.?/i, 28, 'g'],
  [/^(?:pinc[ée]es?|soupçons?|traits?)(?![a-zà-ÿ])/i, 1, 'ml']
];
/* Contenants et pièces : on garde le mot dans le nom et on compte à l'unité, sauf si leur format est donné (boîte de 796 ml). */
const PIECES = /^(gousses?|bo[iî]tes?|conserves?|paquets?|sacs?|sachets?|enveloppes?|tranches?|bottes?|branches?|feuilles?|brins?|tiges?|morceaux?|poign[ée]es?|pots?|bouteilles?|rouleaux?|abaisses?|contenants?|barquettes?|casseaux?|noix|noisettes?|cubes?|filets?|pi[eè]ces?|t[eê]tes?|grappes?|bouquets?)(?![a-zà-ÿ])/i;
const PREPS = ['finement','grossièrement','grossierement','au goût','au gout','facultatif','facultative','environ','bien tassée','bien tassé','tassée','tassé','légèrement battu','légèrement battus','à la température ambiante','à température ambiante','pour la cuisson','pour badigeonner','pour servir','pour garnir','en garniture','(facultatif)'];
const ADJS = /^(petite?s?|grosses?|gros|grande?s?|moyenne?s?|large|beaux?|belles?|bonne?s?|environ)\s+/i;
const STAPLES = /^(sel|poivre|sel et poivre|eau|eau froide|eau chaude|eau bouillante|glaçons?|huile pour la friture)$/;
const SYN = [[/\bsauce soja\b/,'sauce soya'],[/\bpatates?\b(?! douces?)/,'pommes de terre'],[/\b[ée]chalotes? vertes?\b/,'oignons verts'],[/\bcr[èe]me (\d\d) ?%/,'crème $1%']];
/* Mots qu'on peut laisser tomber pour retrouver l'aliment connu (« boeuf haché maigre » → « boeuf haché »). */
const DESC = new Set(['hache','hachee','haches','hachees','emince','emincee','eminces','emincees','tranche','tranchee','tranches','tranchees','rape','rapee','rapes','rapees','pele','pelee','peles','pelees','maigre','mi-maigre','extra-maigre','frais','fraiche','fraiches','russet','yukon','gold','moyen','moyenne','moyens','moyennes','gros','grosse','grosses','petit','petite','petits','petites','coupe','coupee','coupes','coupees','finement','desosse','desossee','desosses','desossees','sans','peau','os','pare','paree','nature','ordinaire','espagnol','espagnols','italien','italienne','tout','usage','tout-usage','non','sale','salee','doux','douce','et']);

function readNum(s){
  const m = s.match(/^(\d+)\s+(\d+)\/(\d+)|^(\d+)\s*([½¼¾⅓⅔⅛⅜⅝⅞⅕])|^(\d+)\/(\d+)|^([½¼¾⅓⅔⅛⅜⅝⅞⅕])|^(\d+(?:[.,]\d+)?)/);
  if(!m) return null;
  let v = m[1] ? +m[1] + m[2]/m[3] : m[4] ? +m[4] + FRACS[m[5]] : m[6] ? m[6]/m[7] : m[8] ? FRACS[m[8]] : parseFloat(m[9].replace(',','.'));
  let rest = s.slice(m[0].length);
  const r = rest.match(/^\s*(?:à|a|-|–|ou)\s*(?=[\d½¼¾⅓⅔⅛⅜⅝⅞⅕])/);   /* 2 à 3, 1/2 à 3/4, 1 à 1 1/2 : on garde la moyenne */
  if(r){ const w = readNum(rest.slice(r[0].length)); if(w){ v = (v + w.v)/2; rest = w.rest; } }
  return {v, rest};
}
function readMeasure(s){
  s = s.trim().replace(/^d(?:e\s+|['’]\s*)(?=(?:tasses?|cups?|c\.|cuil|cuill|lb|livres?|kg|g\b|ml|l\b|oz|onces?))/i, '');
  for(const [re, f, u] of MESURES){ const m = s.match(re); if(m) return {f, u, rest:s.slice(m[0].length)}; }
  return null;
}
/* « 2 tasses (500 ml) » : on préfère la mesure métrique entre parenthèses. */
function metricIn(par){
  const n = readNum(par.trim()); if(!n) return null;
  const me = readMeasure(n.rest); if(!me || (me.u==='ml' && me.f===15) || me.f===5 || me.f===250 || me.f===454 || me.f===28) return null;
  return {q:n.v*me.f, u:me.u};
}
function cleanName(raw){
  let n = ' '+raw.replace(/\s+/g,' ').trim()+' ';
  n = n.replace(/\([^)]*\)/g,' ');
  const cut = n.indexOf(','); if(cut>0) n = n.slice(0, cut);
  n = n.replace(/\s+ou\s+.*$/i, ' ');                               /* « beurre ou margarine » : le premier choix */
  PREPS.forEach(w => { n = n.replace(new RegExp('\\s'+w.replace(/[()]/g,'\\$&')+'(?=\\s|$)','gi'), ' '); });
  n = n.trim().replace(/^(de |d'|d’|du |des |de la |de l'|de l’)/i, '').replace(ADJS, '').replace(/^(de |d'|d’|du |des )/i, '').trim();
  let nn = norm(n); SYN.forEach(([re, to]) => { if(re.test(nn)) { n = n.replace(new RegExp(re.source.replace(/\\b/g,''),'i'), to); nn = norm(n); } });
  return n.replace(/\s+/g,' ').replace(/[.;:]+$/,'').trim();
}
/* Relier au catalogue : on raccourcit le nom jusqu'à trouver un aliment connu (« oignon haché » → « oignon »). */
function matchCatalog(name){
  const w = name.split(' ');
  for(let k = w.length; k >= 1; k--){ const c = catFind(w.slice(0,k).join(' ')); if(c) return {c, k, full: k===w.length}; }
  return null;
}
function parseIngLine(line){
  let s = line.replace(/^[\s\-–•·*▢□☐◻✓✔○●]+/, '').replace(/\u00a0/g,' ').trim();
  if(!s) return null;
  let q = 0, u = 'un', piece = '', can = false;
  const n = readNum(s);
  if(n){
    s = n.rest.trim();
    const me = readMeasure(s);
    if(me){ q = n.v*me.f; u = me.u; s = me.rest.trim();
      const par = s.match(/^\(([^)]*)\)/); if(par){ const mi = metricIn(par[1]); if(mi && me.f!==1){ q = mi.q; u = mi.u; } s = s.slice(par[0].length).trim(); } }
    else {
      const par = s.match(/^\(([^)]*)\)/);                          /* « 1 (796 ml) boîte » ou « 2 (env. 400 g) poitrines » */
      const pm = s.match(PIECES);
      if(pm){ piece = pm[0]; s = s.slice(pm[0].length).trim(); }
      const pMetric = pm && /bo[iî]te|conserve|paquet|sac|sachet|pot|bouteille|contenant|barquette|casseau|enveloppe/i.test(pm[0]) ? (() => { const p2 = s.match(/^(?:de\s+)?\(([^)]*)\)/); const mm = p2 && p2[1].match(/(\d+(?:[.,]\d+)?)\s*(ml|l|g|kg)\b/i); if(mm){ s = s.slice(p2[0].length).trim(); return mm; } return null; })() : null;
      const sz = pMetric || s.match(/^(?:de\s+)?\(?\s*(\d+(?:[.,]\d+)?)\s*(ml|l|g|kg|oz|lb)\b\.?\s*\)?/i)
             || (par ? par[1].match(/(\d+(?:[.,]\d+)?)\s*(ml|l|g|kg|lb)\b/i) : null);
      if(sz && piece && /bo[iî]te|conserve|paquet|sac|sachet|pot|bouteille|contenant|barquette|casseau|enveloppe/i.test(piece)){
        const me2 = readMeasure(sz[2]); const size = parseFloat(String(sz[1]).replace(',','.'))*me2.f;
        q = n.v*size; u = me2.u; can = /bo[iî]te|conserve/i.test(piece); piece = ''; if(!pMetric && s.match(/^(?:de\s+)?\(?\s*\d/)) s = s.slice(sz[0].length).trim();
      } else { q = n.v; u = 'un'; if(par && !pm) s = s.slice(par[0].length).trim();
        const wt = (s+' '+(par ? par[0] : '')).match(/(?:\bde\s+|\(\s*(?:env(?:iron|\.)?\s*)?)(\d+(?:[.,]\d+)?)\s*(kg|g|lb|ml|l)\b\.?(\s*(?:chacune?s?|ch\.|par morceau))?(?:\s*(?:au total|en tout))?\s*\)?/i);
        if(wt && !piece){ const me3 = readMeasure(wt[2]); const size = parseFloat(wt[1].replace(',','.'))*me3.f; q = wt[3] ? n.v*size : (/^\s*de\b/i.test(wt[0]) ? n.v*size : size); u = me3.u; s = s.replace(wt[0].trim(), ' ').replace(/\(\s*(au total|en tout)?\s*\)/i,' ').replace(/\s+(au total|en tout)\b/i,' ').trim(); } }
    }
  }
  s = s.replace(/^\([^)]*\)\s*/, '');
  const name = cleanName((piece ? piece+' ' : '') + s);
  if(!name || name.length < 2) return null;
  return {q, u, name, noq: !n, can};
}
const name0 = n => n.split(' ');
const H_ING = /^(ingr[ée]dients?|ce qu'il (vous )?faut|liste d'?ingr[ée]dients)\s*:?$/i;
const H_STEP = /^(pr[ée]paration|[ée]tapes?|instructions?|m[ée]thode|mode de pr[ée]paration|directions|marche à suivre)\s*:?$/i;
const H_END = /^(notes?|conseils?|astuces?|valeurs? nutritives?|nutrition|par portion|informations? nutritionnelles?|à propos|commentaires?|vous aimerez aussi|imprimer|partager)\b/i;
const T_LINE = /^(temps|pr[ée]paration|cuisson|temps total|total|marinade|repos|r[ée]frig[ée]ration|congélation|portions?|rendement|donne|pour)\b/i;
function minutesOf(s){ const n = norm(s); let t = 0; const hh = n.match(/(\d+)\s*h(?:eures?)?\s*(\d+)?/); if(hh) t += (+hh[1])*60 + (+(hh[2]||0)); const mm = !hh && n.match(/(\d+)\s*min/); if(mm) t += +mm[1]; return t; }
function parseWebRecipe(txt){
  const lines = txt.replace(/\r/g,'').split('\n').map(l => l.replace(/\u00a0/g,' ').trim());
  const isIngLine = l => /^[\-–•·*▢□☐◻]?\s*(\d|[½¼¾⅓⅔⅛])/.test(l) && !/^\d+\s*(min|minutes?|h|heures?|portions?|personnes|parts)\b/i.test(l);
  let i0 = lines.findIndex(l => H_ING.test(l));
  /* sans titre « Ingrédients » : le premier bloc de lignes qui commencent par une quantité */
  let i1 = -1;
  if(i0 < 0){ const k = lines.findIndex(isIngLine); if(k < 0) return null; i0 = k-1; let z = k; while(z < lines.length && (isIngLine(lines[z]) || !lines[z])) z++; i1 = z; }
  else i1 = lines.findIndex((l,k) => k>i0 && (H_STEP.test(l) || /^(1[.)]\s|[ée]tape 1\b)/i.test(l)));
  if(i1 < 0) i1 = lines.length;
  /* temps et portions : n'importe où avant les étapes */
  let prep = 0, cook = 0, total = 0, portions = 0;
  for(let k = 0; k < i1; k++){
    const l = lines[k], nx = lines[k+1]||''; const both = T_LINE.test(l) && !/\d/.test(l) ? l+' '+nx : l;
    const n = norm(both).replace(/^temps (de |d')?(?=preparation|cuisson)/,'');
    /* une ligne peut contenir plusieurs temps : « Préparation 20 min Cuisson 1 h » */
    n.split(/(?=\b(?:preparation|cuisson|(?:temps )?total|portions?|rendement)\b)/).forEach(sg => { sg = sg.trim();
      if(/^preparation\b/.test(sg) && /\d/.test(sg)) prep = prep || minutesOf(sg.replace(/^preparation\s*:?/,''));
      else if(/^cuisson\b/.test(sg) && /\d/.test(sg)) cook = cook || minutesOf(sg.replace(/^cuisson\s*:?/,''));
      else if(/^(temps )?total\b/.test(sg) && /\d/.test(sg)) total = total || minutesOf(sg); });
    const pm = n.match(/^(?:portions?|rendement|donne|pour)\s*:?\s*(\d+)/) || n.match(/^(\d+)\s*(?:portions?|personnes|parts|services)\b/);
    if(pm && !portions) portions = +pm[1];
  }
  /* titre : première ligne qui n'est ni un titre de section, ni un temps, ni une quantité */
  const title = lines.slice(0, Math.max(i0,1)).find(l => l && l.length>2 && l.length<90 && !T_LINE.test(l) && !H_ING.test(l) && !/^\d/.test(l) && !/^(recette|accueil|menu|imprimer|partager|enregistrer|par |photo|\d+ (avis|commentaires?))/i.test(l))
    || lines.find(l => l && !isIngLine(l)) || 'Recette importée';
  const ing = [], unsure = [];
  for(let k = i0+1; k < i1; k++){
    const l = lines[k]; if(!l) continue;
    if(H_END.test(l)) break;
    if(T_LINE.test(l) && !isIngLine(l)) continue;
    const g = parseIngLine(l); if(!g) continue;
    const nn = norm(g.name);
    if(/^(portions?|personnes|parts|min|minutes|h|heures)\b/.test(nn) || STAPLES.test(nn)) continue;
    if(g.noq){
      if(STAPLES.test(nn) || /^(sel|poivre)\b/.test(nn) && nn.split(' ').length<=4) continue;
      if(/:$/.test(l) || (l.split(' ').length<=3 && !matchCatalog(g.name) && !/\bau go[uû]t\b/i.test(l))) continue;   /* sous-titre : « Sauce », « Garniture : » */
    }
    ing.push(g);
  }
  if(!ing.length) return null;
  /* étapes */
  const steps = [];
  for(let k = i1 < lines.length && H_STEP.test(lines[i1]) ? i1+1 : i1; k < lines.length; k++){
    const l = lines[k]; if(!l) continue; if(H_END.test(l)) break;
    if(T_LINE.test(l) && /\d/.test(l) && l.length < 40) continue;
    steps.push(l.replace(/^(?:[ée]tape\s*)?\d+\s*[.)\-–:]?\s+/i,'').trim());
  }
  const tn = norm(title);
  const k = /gateau|tarte|biscuit|muffin|carre|brownie|pouding|croustade|mousse|sucre a la creme|beigne|cupcake|bagatelle|tiramisu|cheesecake|gateau au fromage|pain aux bananes|crumble|clafoutis|fudge|sorbet|creme glacee|tartelette|galette/.test(tn) ? 'dessert'
    : /^(soupe|potage|creme de|veloute|chaudree|bouillon)\b/.test(tn) ? 'soupe'
    : /^(sauce|vinaigrette|pesto|mayonnaise|tzatziki|marinade|coulis)\b/.test(tn) ? 'sauce'
    : /trempette|bouchee|bruschetta|rouleaux de printemps|ailes de poulet|nachos|tapenade|hummus|houmous|verrine|canape|salade (verte|cesar)/.test(tn) ? 'entree' : 'souper';
  const fac = k==='souper' && portions > 0 ? 6/portions : 1;
  const rows = ing.map(g => {
    let q = g.noq ? 1 : g.q*fac, u = g.u;
    const hit = matchCatalog(g.name), c = hit && hit.c;
    const useCat = c && (hit.full || name0(g.name).slice(hit.k).every(x => DESC.has(norm(x).replace(/[^a-z-]/g,''))));
    let name = useCat ? c.n : cap(g.name);
    if(c && u==='un' && c.u!=='un' && g.noq){ u = c.u; q = c.u==='g' ? 100 : 15; }
    q = u==='un' ? Math.max(.5, Math.round(q*2)/2) : q < 20 ? Math.round(q*10)/10 : Math.round(q);
    if(g.noq) unsure.push(name);
    const [qq,uu] = niceUnit(q,u);
    /* à vérifier : quantité absente, unité différente de celle du catalogue (ex. riz en tasses), ou aliment inconnu */
    const doute = g.noq ? 'quantité absente' : (c && c.u !== u && !(c.u==='g' && u==='un' && gpuOf(norm(name)))) ? `d'habitude en ${c.u==='un' ? 'unités' : c.u}` : !c ? 'aliment nouveau' : '';
    return {n:name, q:String(+(+qq).toFixed(2)), u:uu, ray: c ? c.ray : g.can ? 'épicerie' : guessRayon(g.name), doute};
  });
  const tm = total || (prep + cook) || 30;
  return {n:title.replace(/\s*[-–|].*$/, '').trim(), k, tm, tp:prep && cook ? prep : 0, portions, fac, rows, s:steps.join(' ').replace(/\s+/g,' ').trim(), unsure};
}
const TM_OPTS = [10,15,20,25,30,35,40,45,50,60,75,90,120,150];
function webToDraft(w){
  const tm = TM_L.find(v => v >= w.tm) || Math.max(10, Math.round(+w.tm || 30));
  drafts.new = {n:w.n, k:w.k, pr:'', st:[], t:'viande', tm:String(tm), tp:String(w.tp ? Math.min(TP_L.find(v => v >= w.tp) || 90, tm) : tm), mj:/mijoteuse|slow cooker/i.test(w.s||''), sf:'auto', sv:'auto', fam:false, m:'', s:w.s, rows:w.rows.length ? w.rows : emptyRows(4)};
}

/* Mots de circulaire par défaut : la viande ou le poisson de la recette, sinon le premier mot du nom. */
function autoMots(ing, name){
  const mots = [];
  ing.filter(x => x[3]==='viandes' || x[3]==='poissonnerie').forEach(x => { const nm = plain(x[2]).toLowerCase(), kw = ['poulet','boeuf','porc','dinde','jambon','saumon','crevette','saucisse','bacon','veau','agneau','tilapia','morue','aiglefin','thon'].find(w => norm(nm).includes(w)); [nm, kw].forEach(w => { if(w && !mots.includes(w)) mots.push(w); }); });
  return mots.length ? mots : [String(name).split(/[ ,]+/)[0].toLowerCase()];
}
function importRecipes(txt){
  const found = []; const re = /MDS1\.([A-Za-z0-9+\/=\s]+?)\.FIN/g; let m;
  while((m = re.exec(txt))){ try{ const o = decodeCode(m[1]); if(o && o.n && Array.isArray(o.i)) found.push(o); }catch(e){} }
  if(!found.length){ const o = parseRecetteTexte(txt); if(o) found.push(o); }
  const names = []; let skipped = 0;
  found.forEach(o => {
    /* recette partagée : on ne garde que des champs du bon type (un code abîmé ne doit pas casser l'onglet Recettes) */
    if(!o || typeof o.n!=='string' || !o.n.trim()) return;
    o.n = o.n.trim().slice(0, 120);
    o.i = (Array.isArray(o.i) ? o.i : []).filter(g => Array.isArray(g) && isFinite(+g[0]) && +g[0] >= 0 && ['g','ml','un'].includes(g[1]) && typeof g[2]==='string' && g[2].trim())
      .map(g => [+g[0], g[1], g[2].trim().slice(0, 120), RAYONS.includes(g[3]) ? g[3] : guessRayon(g[2])]);
    if(!o.i.length) return;
    o.m = Array.isArray(o.m) ? o.m.filter(x => typeof x==='string') : [];
    o.s = typeof o.s==='string' ? o.s : ''; o.e = typeof o.e==='string' ? o.e : '';
    o.v = Array.isArray(o.v) ? o.v.filter(v => Array.isArray(v) && typeof v[0]==='string').map(v => [v[0], typeof v[1]==='string' ? v[1] : '', typeof v[2]==='string' ? v[2] : undefined].filter(x => x !== undefined)) : [];
    ['tm','tp','mj'].forEach(k => { if(o[k] != null && !isFinite(+o[k])) delete o[k]; });
    { const c = {}; if(o.cm && typeof o.cm==='object'){ if(typeof o.cm.b==='string') c.b = o.cm.b.slice(0, 40);
        Object.keys(CM_L).forEach(k => { const x = o.cm[k]; if(x && typeof x.s==='string' && isFinite(+x.tp) && isFinite(+x.tm)) c[k] = {tp:+x.tp, tm:+x.tm, s:x.s}; }); }
      if(Object.keys(c).some(k => k!=='b')) o.cm = c; else delete o.cm; }
    if(Array.isArray(o.al)) o.al = o.al.filter(x => typeof x==='string').slice(0, 10); else delete o.al;
    if(o.k && !KINDS[o.k]) delete o.k;
    const same = allRecipes().find(r => norm(r.n)===norm(o.n));
    if(same && JSON.stringify(same.i)===JSON.stringify(o.i)){ skipped++; return; }
    o.n = same ? uniqueName(o.n) : o.n; Object.assign(o, {c:true, nw:true, e:o.e||'', v:o.v||[]}); if(!o.m || !o.m.length) o.m = autoMots(o.i, o.n);
    S.custom.push(o); _AR = null; names.push(o.n);
  });
  return {added:names.length, names, skipped};
}

const CATS = [['','Sans catégorie'],['f','Féculent'],['v','Légume ou salade'],['p','Protéine'],['c','Collation'],['o','Autre']];
function stockSides(){
  const TYK = {pates:['viande'], riz:['viande','riz','mex'], patate:['viande','sandwich','complet'], pain:['viande','pates','complet']};
  const tyOf = o => { if(o.cat!=='f') return ['all']; const k = starchOf(o.name); return k.length ? [...new Set(k.flatMap(x => TYK[x]))] : ['viande','complet']; };
  return Object.entries(S.stock).filter(([k,o]) => o.cat==='f' || o.cat==='v').map(([k,o]) => ({id:'st:'+k, n:o.name+' (à la maison)', sl:o.cat, ty:tyOf(o), i:[[Math.max(.5, Math.round(o.q/Math.max(.5,totalPortions()/6)*10)/10), o.u, o.name, o.rayon||'épicerie']]}));
}
const tmOf = r => (S.tmx||{})[r.n] ?? r.tm ?? 30;
/* préparation : le temps où il faut être aux fourneaux. Le four sans surveillance et la mijoteuse ne comptent pas. */
const tpOf = r => Math.min(tmOf(r), (S.tpx||{})[r.n] ?? r.tp ?? tmOf(r));
const mjOf = r => +(r && r.mj) || 0;   /* 1 : recette à la mijoteuse; 2 : braisé qui peut y aller */
const MAX_FOUR = 90;                    /* cuisson sans surveillance acceptable un soir de semaine */
const fmtMin = m => { m = Math.round(+m||0); return m < 60 ? m+'\u00a0min' : Math.floor(m/60)+'\u00a0h'+(m%60 ? '\u00a0'+String(m%60).padStart(2,'0') : ''); };
/* le temps de préparation permis un soir de semaine, selon la réponse de la semaine */
const maxTmW = () => { const t = weekQ().temps, b = S.p.maxTm||35; return t==='vite' ? Math.min(b, 25) : t==='temps' ? Math.max(b, 45) : b; };
const nLongW = () => { const t = weekQ().temps, b = S.p.nLong ?? 1; return t==='vite' ? 0 : t==='temps' ? Math.max(2, b + 1) : b; };
const weekOk = r => tpOf(r) <= maxTmW() && (tmOf(r) <= MAX_FOUR || mjOf(r) > 0);
const isLong = r => !weekOk(r);
const tmTxt = r => { const a = tpOf(r), t = tmOf(r); return t > a + 5 ? `${fmtMin(a)} de préparation, ${fmtMin(t)} au total${mjOf(r)===1 ? ' (mijoteuse)' : ''}` : fmtMin(t); };
const tmShort = r => fmtMin(tpOf(r));
const tmList = r => tmOf(r) > tpOf(r) + 5 ? `${fmtMin(tpOf(r))} + cuisson` : fmtMin(tmOf(r));
const TP_L = [5,10,15,20,25,30,35,40,45,60,75,90], TM_L = [10,15,20,25,30,35,40,45,50,55,60,70,75,90,120,150,180,240,300,360,480,600,720];
const optMin = (list, cur) => list.concat([+cur]).filter((v,j,a) => v && a.indexOf(v)===j).sort((a,b) => a-b).map(v => `<option value="${v}" ${+cur===v?'selected':''}>${fmtMin(v)}</option>`).join('');
/* ---------- façons de cuire : air fryer, mijoteuse, four (champ cm des recettes) ---------- */
const CM_L = {af:'Air fryer', mj:'Mijoteuse', four:'Four'};
const cmOf = (r, k) => k && r && r.cm && CM_L[k] && r.cm[k] && typeof r.cm[k].s==='string' ? r.cm[k] : null;
const hasCm = r => !!(r && r.cm && Object.keys(CM_L).some(k => cmOf(r, k)));
const tpM = (r, k) => { const c = cmOf(r, k); return c ? Math.min(+c.tp||0, +c.tm||0) : tpOf(r); };
const tmM = (r, k) => { const c = cmOf(r, k); return c ? +c.tm||0 : tmOf(r); };
const tmTxtM = (r, k) => { if(!cmOf(r, k)) return tmTxt(r); const a = tpM(r, k), t = tmM(r, k);
  return k==='mj' ? `${fmtMin(a)} de préparation, puis ${fmtMin(t - a)} à la mijoteuse` : t > a + 5 ? `${fmtMin(a)} de préparation, ${fmtMin(t)} au total` : fmtMin(t); };
const stepsM = (r, k) => (cmOf(r, k) || r).s || '';
/* la recette de base d'abord, puis les autres façons. Vide si le plat n'a qu'une façon. */
function methods(r){
  if(!hasCm(r)) return [];
  return [{k:'', l:(typeof r.cm.b==='string' && r.cm.b) || 'Recette de base', tp:tpOf(r), tm:tmOf(r)}]
    .concat(Object.keys(CM_L).filter(k => cmOf(r, k)).map(k => ({k, l:CM_L[k], tp:tpM(r, k), tm:tmM(r, k)})));
}
/* le plus rapide ce soir : la mijoteuse ne compte pas, elle part le matin */
const fastM = r => { const M = methods(r).filter(m => m.k!=='mj'); return M.length ? M.reduce((a, b) => b.tm < a.tm ? b : a) : null; };
const cmWeek = m => m.tp <= maxTmW() && (m.tm <= MAX_FOUR || m.k==='mj');
/* la façon de cuire d'un plat du menu : celle choisie (b = la recette de base), sinon, un soir de semaine,
   celle qui rend possible un plat trop long (ex. côtes levées à la mijoteuse) */
function cmEff(it, r){
  if(!it || !hasCm(r)) return '';
  if(it.cm) return it.cm!=='b' && cmOf(r, it.cm) ? it.cm : '';
  if(it.d && !isOff(it.d) && (!weekOk(r) || (mjOf(r)===2 && tmOf(r) > MAX_FOUR))){
    const M = methods(r).filter(m => m.k && cmWeek(m)).sort((a, b) => (a.k==='mj') - (b.k==='mj') || a.tp - b.tp);
    if(mjOf(r)===2 && cmOf(r, 'mj')) return 'mj';
    if(M.length) return M[0].k; }
  return '';
}
const cmAuto = (it, r) => !!(it && !it.cm && cmEff(it, r));
function mjTxt(it, r){
  const k = cmEff(it, r);
  if(k==='mj') return it.d && !isOff(it.d) ? 'Mijoteuse : prépare les ingrédients la veille au soir, pars la mijoteuse le matin.' : 'Mijoteuse : pars-la le matin.';
  if(k) return '';
  const mj = mjOf(r); if(!mj || !it.d) return '';
  const wk = !isOff(it.d);
  if(mj===1) return wk ? 'Mijoteuse : prépare les ingrédients la veille au soir, pars la mijoteuse le matin.' : 'Mijoteuse : pars-la le matin.';
  if(tmOf(r) <= MAX_FOUR) return '';
  return wk ? `Soir de semaine : prépare-le la veille, puis 8 h à faible intensité à la mijoteuse pendant la journée (au lieu de ${fmtMin(tmOf(r))} au four ou sur le feu).` : 'Aussi possible à la mijoteuse : 8 h à faible intensité.';
}

/* Menu de la semaine — Variété, jours de la semaine, dîners et restes.
   Les fichiers de js/ partagent les mêmes variables globales; ils sont chargés dans l'ordre de index.html. */
/* ---------- variété : familles de plats ---------- */
const FAMS = [['fajitas',/fajita/],['tacos',/\btacos?\b/],['quesadillas',/quesadilla/],['burritos',/burrito|enchilada/],['nachos',/nachos/],
  ['pizza',/pizza|calzone/],['burger',/burger|sloppy/],['rotisserie',/poulets? (bbq|roti|entier)|tourne-broche|crapaudine/],['jambon',/^jambon|epaule de jambon/],['hotdog',/hot-?dogs?|michigan|bratwurst|guedille/],['saucisses',/\bsaucisses\b/],['sandwich',/sous-marin|sandwich|panini|croque-|club|cheesesteak|hot chicken/],['teriyaki',/teriyaki/],
  ['wrap',/wrap|\bpitas?\b|souvlaki|shawarma|gyro/],['poutine',/poutine/],['spaghetti',/spaghetti/],['lasagne',/lasagne/],['mac',/mac (n|and) cheese|macaroni/],
  ['chili',/chili/],['pate',/pate chinois|cottage pie|hachis/],['tourte',/tourtiere|pate a la viande|pates? au poulet (maison|surgele)|^pate au poulet/],['saute',/saute|\bwok\b|general tao|chow mein|chop suey|riz frit/],['curry',/curry|tikka|poulet au beurre/],['cotelettes',/cotelettes/],
  ['nouilles',/ramen|nouilles|pad thai|lo mein/],['soupe',/\bsoupes?\b|chaudree|potage/],['bol',/\bbols?\b|poke/],['effiloche',/effiloch/],['ailes',/\bailes\b/],
  ['cotes',/cotes levees/],['brochettes',/brochette/],['boulettes',/boulette/],['painviande',/pains? de viande/],['oeufs',/quiche|omelette|frittata/],
  ['pane',/croquette|\bpanes?\b|parmesan/],['steak',/steak|bavette|contre-filet|cote de boeuf|picanha|surlonge|filet mignon|tournedos|entrecote/],
  ['salade',/salade/],['ragout',/ragout|braise|bourguignon/]];
const famOf = r => { if(!r || !r.n) return ''; const t = norm(r.n); const f = FAMS.find(([,re]) => re.test(t)); return f ? f[0] : ''; };
const TY_MAX = {mex:2, sandwich:2, riz:2, pates:2};
/* ressemblance de deux soupers : deux soirs de suite (et le dîner du lendemain, qui mange les restes) */
function simR(a, b){
  if(!a || !b) return 0; let s = 0; const fa = famOf(a);
  if(fa && fa===famOf(b)) s += 5;
  const ta = a.t||'viande'; if(ta!=='viande' && ta!=='complet' && ta===(b.t||'viande')) s += 3;
  const pa = protein(a); if(pa!=='autre' && pa===protein(b)) s += 2;
  return s;
}
const gapDays = (a, b) => Math.round((new Date(b+'T12:00:00') - new Date(a+'T12:00:00'))/864e5);
/* Échange les jours des soupers pour éviter deux soirs de suite qui se ressemblent.
   Les plats longs restent aux jours de congé; les restes planifiés viennent 2 ou 3 jours après la grosse pièce. */
function spreadDays(){
  const L = mlist('items').filter(x => x.d), at = new Map(L.map(x => [x.d, x])), R = x => byName(x.r);
  const cost = () => { let c = 0;
    at.forEach((x, d) => { const y = at.get(addDays(d, 1)); if(y) c += simR(R(x), R(y)) + (x.cm && y.cm ? 8 : 0); });
    { const w0 = weekStart(); L.forEach(x => { c += .5 * perishOf(R(x)) * Math.max(0, gapDays(w0, x.d)); }); }
    L.forEach(x => { if(!x.after) return; const pa = L.find(y => y.r===x.after); if(!pa) return; const g = gapDays(pa.d, x.d); c += g < 1 ? 99 : g===1 ? 3 : g===4 ? 1 : g >= 5 ? 6 : 0; });
    return c; };
  const mov = L.filter(x => !x.dfix && !x.cm), okAt = (x, d) => { const r = R(x); return !(r && isLong(r) && !isOff(d)); };   /* les repas plaisir gardent leur soir */
  const sw = (a, b) => { const t = a.d; a.d = b.d; b.d = t; at.set(a.d, a); at.set(b.d, b); };
  for(let k = 0; k < 40; k++){
    const c0 = cost(); let best = 0, bp = null;
    for(let i = 0; i < mov.length; i++) for(let j = i+1; j < mov.length; j++){
      const a = mov[i], b = mov[j]; if(!okAt(a, b.d) || !okAt(b, a.d)) continue;
      sw(a, b); const g = c0 - cost(); sw(a, b); if(g > best){ best = g; bp = [a, b]; } }
    if(!bp) break; sw(bp[0], bp[1]);
  }
}

/* ---------- jours de la semaine ---------- */
const addDays = (iso, n) => { const d = new Date(iso+'T12:00:00'); d.setDate(d.getDate()+n); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); };
const weekDates = () => Array.from({length:7}, (_,k) => addDays(weekStart(), k));
const isOff = iso => (S.p.off||[0,6]).includes(new Date(iso+'T12:00:00').getDay());
const dayLbl = iso => { try{ return cap(new Date(iso+'T12:00:00').toLocaleDateString('fr-CA',{weekday:'long', day:'numeric'})); }catch(e){ return iso; } };
const JOURS = ['dimanche','lundi','mardi','mercredi','jeudi','vendredi','samedi'];
/* Chaque souper reçoit un jour : les plats longs vont aux jours de congé, les restes après la grosse pièce. */
function assignDays(force){
  const L = mlist('items'), dates = weekDates(), seen = new Set();
  if(force) L.forEach(x => { if(!x.dfix) delete x.d; });
  L.forEach(x => { if(!x.d || !dates.includes(x.d) || seen.has(x.d)) delete x.d; else seen.add(x.d); });
  const todo = L.filter(x => !x.d); if(!todo.length) return;
  const free = dates.filter(d => !seen.has(d));
  /* repas plaisir d'abord, parmi tous les jours libres : vendredi ou samedi (congé pour une longue cuisson), jamais deux soirs de suite */
  { const dw = d => new Date(d+'T12:00:00').getDay(), cmDays = L.filter(x => x.cm && x.d).map(x => x.d);
    todo.filter(x => x.cm && !(x.after && L.some(y => y.r===x.after))).forEach(x => { const r = byName(x.r), lg = r && isLong(r);
      const C = free.filter(d => lg ? isOff(d) : [5,6].includes(dw(d))).concat(free.filter(d => isOff(d) || [5,6].includes(dw(d))));
      const d = C.find(d => !cmDays.some(c => Math.abs(gapDays(c, d)) === 1)) || C[0];
      if(d){ free.splice(free.indexOf(d), 1); x.d = d; cmDays.push(d); } }); }
  const rest = todo.filter(x => !x.d); if(!rest.length) return;
  const pick = free.slice(0, rest.length);
  const isFol = x => x.after && L.some(y => y.r===x.after);
  const main = rest.filter(x => !isFol(x)).sort((a,b) => ((byName(b.r)||{}).rs?1:0) - ((byName(a.r)||{}).rs?1:0)), fol = rest.filter(isFol);
  const take = off => { const i = pick.findIndex(d => isOff(d)===off); return i>=0 ? pick.splice(i,1)[0] : pick.shift(); };
  main.filter(x => { const r = byName(x.r); return !x.d && r && isLong(r); }).forEach(x => { x.d = take(true); });
  main.filter(x => !x.d).forEach(x => { x.d = take(false); });
  fol.forEach(x => { const p = L.find(y => y.r===x.after); let i = -1;
    if(p && p.d){ for(const k of [2,3,1,4]){ i = pick.indexOf(addDays(p.d, k)); if(i >= 0) break; } if(i < 0) i = pick.findIndex(d => d > p.d); }
    x.d = i>=0 ? pick.splice(i,1)[0] : pick.shift(); });
  /* les restes planifiés viennent toujours après le plat qui les produit */
  fol.forEach(x => { const p = L.find(y => y.r===x.after); if(p && p.d && x.d && x.d < p.d && !p.dfix && !x.dfix && !(isLong(byName(p.r)||{}) && !isOff(x.d))){ const t = p.d; p.d = x.d; x.d = t; } });
  L.forEach(x => { if(!x.d) delete x.d; });
  if(force) spreadDays();
}
/* Entrées et soupes à côté : chacune avec le souper d'un jour. Les entrées la fin de semaine d'abord, les soupes
   les soirs de semaine (jamais avec une soupe-repas), en les espaçant. Sans rôle (« pour les lunchs », « au choix ») : pas de jour. */
function assignExtras(force){
  const I = mlist('items').filter(x => x.d), days = [...new Set(I.map(x => x.d))].sort();
  [['ent', true], ['sou', false]].forEach(([l, off]) => {
    const L = mlist(l), seen = new Set(), ok = d => days.includes(d) && !(l==='sou' && I.some(x => x.d===d && x.sr));
    L.forEach(x => { if(!x.ro || x.ro==='lunch' || x.ro==='libre'){ delete x.d; return; } if(force && !x.dfix) delete x.d; if(x.d && (!ok(x.d) || seen.has(x.d))) delete x.d; if(x.d) seen.add(x.d); });
    const todo = L.filter(x => (x.ro==='entree' || x.ro==='avec') && !x.d); if(!todo.length) return;
    const free = days.filter(d => ok(d) && !seen.has(d)), pref = free.filter(d => isOff(d)===off), rest = free.filter(d => isOff(d)!==off);
    const spread = (D, k) => { if(k >= D.length) return D.slice(); return Array.from({length:k}, (_, j) => D[Math.floor(j * D.length / k)]); };
    const pick = spread(pref, Math.min(todo.length, pref.length)).concat(spread(rest, Math.max(0, todo.length - pref.length)));
    todo.forEach((x, j) => { if(pick[j]) x.d = pick[j]; });
  });
}
/* ce qui accompagne le souper d'un jour : « entrée : bruschettas », « soupe : crème de brocoli » */
const extrasDe = d => d ? mlist('ent').filter(x => x.d===d && (x.ro==='entree' || x.ro==='avec')).map(x => (x.ro==='entree' ? 'entrée : ' : 'avec : ') + lowFirst(x.r))
  .concat(mlist('sou').filter(x => x.d===d && x.ro==='avec').map(x => 'soupe : ' + lowFirst(x.r))) : [];
const roleTxt = (it, l) => { const s = it.d ? dayLbl(it.d).toLowerCase() : '';
  if(l==='sou') return it.ro==='avec' ? (s ? `Avec le souper de ${s}` : 'Avec un souper') : 'Pour les lunchs ou au choix';
  return it.ro==='entree' ? (s ? `En entrée, ${s}` : 'En entrée') : it.ro==='avec' ? (s ? `Avec le repas de ${s}` : 'Avec le repas') : 'Au choix'; };
/* rôle d'une entrée ou d'une soupe dans la semaine */
function extraCtl(it, i, l){
  const days = mlist('items').filter(x => x.d).sort((a, b) => a.d.localeCompare(b.d));
  const ro = it.ro || (l==='sou' ? 'lunch' : 'libre');
  const dl = l==='sou' ? days.filter(x => !x.sr) : days;
  return `<div class="grid2"><label class="f">Servie${roSel(it, i, l)}</label>
    ${ro==='avec' || ro==='entree' ? `<label class="f">Avec le souper de<select data-a="xday" data-ml="${l}" data-i="${i}"><option value="">Choisir un jour</option>${dl.map(x => `<option value="${x.d}" ${it.d===x.d?'selected':''}>${esc(dayLbl(x.d))} : ${esc(x.r)}</option>`).join('')}</select></label>` : ''}</div>`;
}
/* Déjeuners : les plus longs (crêpes, pain doré…) vont aux jours de congé. */
const dejDays = () => { const ds = weekDates(), n = Math.min(7, S.p.nDej||0); return ds.filter(isOff).concat(ds.filter(d => !isOff(d))).slice(0, n).sort(); };
function assignDej(force){
  const L = mlist('dej'), ds = weekDates(), seen = new Set();
  if(force) L.forEach(x => { if(!x.dfix) delete x.d; });
  L.forEach(x => { if(!x.d || !ds.includes(x.d) || seen.has(x.d)) delete x.d; else seen.add(x.d); });
  const todo = L.filter(x => !x.d); if(!todo.length) return;
  const pref = dejDays().filter(d => !seen.has(d)), pick = pref.concat(ds.filter(d => !seen.has(d) && !pref.includes(d)));
  const take = () => { const i = pick.findIndex(d => isOff(d)); return i>=0 ? pick.splice(i,1)[0] : pick.shift(); };
  const R = x => byName(x.r)||{}, tk = off => { const i = pick.findIndex(d => isOff(d)===off); return i>=0 ? pick.splice(i,1)[0] : pick.shift(); };
  todo.filter(x => !isSimple(R(x))).sort((a,b) => tmOf(R(b)) - tmOf(R(a))).forEach(x => { const d = tk(true); if(d) x.d = d; });
  todo.filter(x => isSimple(R(x))).forEach(x => { const d = tk(false); if(d) x.d = d; });
}
/* ---------- dîners : les restes du souper de la veille d'abord ----------
   Chaque souper est cuisiné pour le souper + les restes (Profil). Le midi suivant, on mange ces restes.
   Les jours de dîner sans restes reçoivent une recette de la banque des soupers (pas déjà au menu). */
const dinDays = () => { const ds = weekDates(), n = Math.min(7, S.p.nDin||0), no = S.menu.dinNo||{}; return ds.filter(d => !isOff(d)).concat(ds.filter(isOff)).slice(0, n).filter(d => !no[d]).sort(); };
function restesAvail(d){
  if(S.p.dinRestes===false || !(S.p.restes > 0) || !d) return null;
  const it = mlist('items').find(x => x.d===addDays(d, -1));
  return it && (!it.pt || it.pt > (S.p.souper||4)) ? it : null;
}
const restesFor = d => (S.menu.dinCook||{})[d] ? null : restesAvail(d);
const dinNeed = () => dinDays().filter(d => !restesFor(d));
function dinPlan(){
  const L = mlist('din'), days = new Set(dinDays()); L.forEach(x => { if(x.d) days.add(x.d); });
  return [...days].sort().map(d => { const i = L.findIndex(x => x.d===d); return i>=0 ? {d, it:L[i], i} : restesFor(d) ? {d, rest:restesFor(d)} : {d}; })
    .concat(L.map((it,i) => ({d:'', it, i})).filter(x => !x.it.d));
}
function fillDin(n, keep, ban){
  const items = keep.slice(), taken = new Set(items.map(x => x.r)), banned = new Set([...recentSet(), ...taken, ...(ban||[])]);
  const ok = r => kindOf(r)==='souper' && !r.oc && !S.dis[r.n] && !softBad(r) && !r.ur && !r.rs && !r.pp && tpOf(r) <= Math.max(30, S.p.maxTm||35) && tmOf(r) <= 60;
  let pool = allRecipes().filter(r => ok(r) && !banned.has(r.n));
  if(pool.length < n - items.length) pool = allRecipes().filter(r => ok(r) && !taken.has(r.n) && !(ban||new Set()).has(r.n));
  const prot = {}, fams = new Set(), typs = {};
  const note = r => { const p = protein(r); prot[p] = (prot[p]||0)+1; const f = famOf(r); if(f) fams.add(f); const t = r.t||'viande'; typs[t] = (typs[t]||0)+1; };
  items.concat(mlist('items')).forEach(x => { const r = byName(x.r); if(r) note(r); });
  const add = r => { const it = mkItem(r, usedSides(items), pickVar(r)); it.din = true; items.push(it); taken.add(r.n); note(r); };
  const bad = (r, lvl) => { const f = famOf(r), t = r.t||'viande'; if(f && fams.has(f)) return true;
    if(lvl===0){ const p = protein(r); if(p!=='autre' && (prot[p]||0) >= 3) return true; if(TY_MAX[t]!==undefined && (typs[t]||0) >= TY_MAX[t]) return true; }
    return false; };
  const C = pool.map(r => ({r, s:score(r)})).sort((a,b) => b.s-a.s).map(x => x.r);
  [0,1].forEach(lvl => C.forEach(r => { if(items.length >= n || taken.has(r.n) || bad(r, lvl)) return; add(r); }));
  C.forEach(r => { if(items.length < n && !taken.has(r.n)) add(r); });
  return items;
}
function syncDin(force){
  const m = S.menu; if(!m.date) return;
  m.din = m.din || []; m.dinCook = m.dinCook || {}; m.dinNo = m.dinNo || {};
  const ds = weekDates(); ['dinCook','dinNo'].forEach(k => Object.keys(m[k]).forEach(d => { if(!ds.includes(d)) delete m[k][d]; }));
  const L = m.din, need = dinNeed(), seen = new Set();
  if(force) L.forEach(x => { if(!x.dfix) delete x.d; });
  L.forEach(x => { x.din = true; if(x.d && ds.includes(x.d) && (need.includes(x.d) || x.dfix) && !seen.has(x.d)) seen.add(x.d); else delete x.d; });
  const free = need.filter(d => !seen.has(d));
  L.filter(x => !x.d).forEach(x => { if(free.length) x.d = free.shift(); });
  if(m.achete) return;
  m.din = L.filter(x => x.d || x.lock);
  if(free.length && !m.maison){
    const nl = fillDin(m.din.length + free.length, m.din, new Set(mlist('items').map(x => x.r)));
    nl.forEach(x => { if(!x.d && !x.lock && free.length) x.d = free.shift(); });
    m.din = nl.filter(x => x.d || x.lock);
  }
}
/* appelé à chaque affichage : jours, déjeuners ajoutés après une mise à jour, dîners selon les restes */
function syncMeals(){
  const m = S.menu; if(!m.date) return false;
  const key = () => JSON.stringify([m.items, m.din, m.dej, m.des, m.ent, m.sou, m.dinCook]), before = key();
  m.dej = m.dej || []; m.din = m.din || [];
  if(m.fillNew){ delete m.fillNew; if(!m.achete) m.dej = fill(nOf('dej'), m.dej, 'dej'); }
  if(!m.achete) ['dej','des'].forEach(l => { const L = m[l]||[], bad = L.filter(x => { const r = byName(x.r); return !x.lock && r && (l==='dej' ? isSimple(r) && x.d && isOff(x.d) : !simpleOk(r)); });
    if(!bad.length) return; const keep = L.filter(x => !bad.includes(x)), nl = fill(L.length, keep, l, new Set(bad.map(x => x.r)));
    if(nl.length < L.length) return; nl.slice(keep.length).forEach((x, j) => { const b = bad[j]; if(b && b.d && !nl.some(y => y!==x && y.d===b.d)) x.d = b.d; }); m[l] = nl; });
  if(!m.achete) ['items','din'].forEach(l => (m[l]||[]).forEach((it, i, L) => { const r = byName(it.r), sd = sideById(it.sf);
    if(!r || !sd || it.sr || sd.id===r.sf || (it.man||{}).f || (it.ovr||{}).f || !clash(sd, r)) return;
    const nf = chooseSide(r, 'f', usedSides(L.filter((_,j) => j!==i))); if(nf !== it.sf && !clash(sideById(nf), r)) it.sf = nf; }));
  assignDays(false); assignDej(false); syncDin(false); assignExtras(false);
  return key() !== before;
}
/* ---------- cuisiner une fois, manger deux fois ---------- */
const urMatch = (phrases, name) => (phrases||[]).some(ph => norm(ph).split(' ').every(w => norm(name).includes(w)));
const pairs = (rp, rf) => !!(rp && rf && rp.rs && rf.ur && rf.ur.some(u => rp.rs.w.includes(u)));
const primOf = it => it.after && S.p.reste!==false ? mlist('items').find(x => x.r===it.after) || null : null;
const follOf = it => S.p.reste!==false ? mlist('items').find(x => x.after===it.r) || null : null;
function pickFollow(rp, taken, avoid){
  const fp = famOf(rp), pen = r => { const f = famOf(r); return (f && (f===fp || (avoid && avoid.has(f))) ? 3 : 0) + ((r.t||'viande')!=='viande' && r.t===rp.t ? 1.5 : 0); };
  const c = allRecipes().filter(r => kindOf(r)==='souper' && !r.oc && !taken.has(r.n) && !S.dis[r.n] && !softBad(r) && ppOk(r) && simpleOk(r) && !r.pp && pairs(rp, r)).map(r => ({r, s:score(r) - pen(r)})).sort((a,b) => b.s-a.s);
  return c.length ? c[0].r : null;
}
function linkFollow(it){
  const r = byName(it.r); if(!r || !r.ur || it.after || S.p.reste===false) return;
  const p = mlist('items').find(x => x!==it && pairs(byName(x.r), r) && !mlist('items').some(y => y.after===x.r));
  if(p) it.after = p.r;
}
/* ---------- plats préparés, notes, prix ---------- */
const ppOk = r => !r.pp || S.p.pp==='all' || (S.p.pp==='spec' && dealsOf(r).length>0);
/* déjeuners et desserts simples : seulement si permis dans Profil */
const isSimple = r => !!(r && (r.sp || (kindOf(r)==='dessert' && r.pp)));
const simpleOk = r => !isSimple(r) || kindOf(r)!=='dessert' || !!S.p.desSimple;
const softBad = r => { const rt = S.rate[r.n]; return (!!rt && rt.down>=2 && rt.down>rt.up) || famBad(r); };
const priceOf = s => { const m = String(s && s.p || '').replace(',', '.').match(/\d+(?:\.\d+)?/); return m ? parseFloat(m[0]) : Infinity; };
const money = v => v.toFixed(2).replace('.', ',')+' $';

/* Menu de la semaine — Liste d'épicerie, prix, barème et association des spéciaux.
   Les fichiers de js/ partagent les mêmes variables globales; ils sont chargés dans l'ordre de index.html. */
/* ---------- besoins, stock, achats ---------- */
const maisonList = () => S.maison.split(',').map(x => norm(x).trim()).filter(Boolean);
const MAISON_OK = new Set(['noir','noire','moulu','moulue','concasse','fin','fine','gros','jaune','vierge','extra','casher','mer','table','iode','neutre','canola','reguliere','regulier','doux','douce','grains','fraichement','moulin','pincee','legere','leger','sodium','reduit','faible']);
function isMaison(name){
  const parts = norm(name).replace(/\([^)]*\)/g,' ').split(/,| et /).map(s => s.trim()).filter(Boolean);
  const one = n => maisonList().some(m => { if(n===m) return true; if(!n.startsWith(m+' ')) return false;
    return n.slice(m.length).split(/[^a-z0-9]+/).filter(w => w && !STOPW.has(w)).every(w => MAISON_OK.has(w)); });
  return parts.length > 0 && parts.every(one);
}

function needs(){
  if(_ND) return _ND;
  const map = new Map();
  const add = (q,u,name,rayon,src) => { [q,u] = normQU(name,q,u); const k = keyOf(name,u); const o = map.get(k); if(o){ o.q += q; if(src && !o.src.includes(src)) o.src.push(src); } else map.set(k,{k,q,u,name,rayon:classer(name, rayon),src:src?[src]:[]}); };
  allItems().forEach(it => { fullIngs(it).forEach(g => add(g.q,g.u,g.name,g.rayon,it.r)); });
  Object.keys(S.menu.useup||{}).forEach(k => { const st = S.stock[k]; if(st) add(st.q, st.u, st.name, st.rayon, 'Restes à manger'); });
  if(S.menu.date){
    S.snacks.forEach(s => add(s.q*S.p.jours, s.u, s.name, s.r, 'Collations'));
    S.ess.forEach(s => add(s.q, s.u, s.name, s.r, s.c || 'Essentiels'));
    (S.menu.sn||[]).forEach(s => add(s.q, s.u, s.name, s.r, s.src || 'Collations en spécial'));
  }
  return (_ND = [...map.values()]);
}
function buyList(){
  if(_BL) return _BL;
  const rows = [], covered = [], verify = [];
  const avail = {}; Object.entries(S.stock).forEach(([k,o]) => avail[k] = o.q);
  for(const n of needs()){
    const ex = S.menu.extra[n.k];
    if(isMaison(n.name)){ verify.push({...n, manque: !!ex}); if(!ex) continue; }
    const sk = ex ? null : stockKey(n); const st = sk ? avail[sk] : 0;
    if(sk) avail[sk] = Math.max(0, avail[sk] - n.q);
    let def = ex ? n.q : n.q - st;
    if(def <= 0.001){ covered.push({...n, st}); continue; }
    const plan = planBuy(n.name, n.u, def), p = plan ? 0 : packOf(n.name,n.u);
    const buy = plan ? plan.buy : p ? Math.ceil(def/p - 1e-9)*p : n.u==='un' ? Math.max(1, Math.ceil(def - 0.05)) : def;
    rows.push({...n, st, buy, def, plan});
  }
  return (_BL = {rows, covered, verify});
}
const isoToday = () => { const d = new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); };
/* début de la semaine du menu : la date d'épicerie choisie, sinon le jour où le menu a été créé (les jours ne glissent plus chaque jour) */
/* date d'épicerie (ramassage) : choisie à la main, sinon celle du menu en cours, sinon le prochain jour de ramassage du profil */
const shopISO = () => S.dates.shop || (S.menu && S.menu.date && S.menu.shop) || (isObj(S.profil) ? nextPickup() : isoToday());
/* premier jour du menu : fixé à sa création (les jours ne glissent pas), sinon le premier jour de cuisine après le ramassage */
const weekStart = () => (S.menu && S.menu.date && S.menu.start) || startFrom(shopISO());
const fmtDate = iso => { try{ return new Date(iso+'T12:00:00').toLocaleDateString('fr-CA',{weekday:'long',day:'numeric',month:'long'}); }catch(e){ return iso; } };
const nice = t => { t = String(t).trim(); return t.charAt(0).toUpperCase()+t.slice(1).toLowerCase(); };
const cap = t => { t = String(t); return t.charAt(0).toUpperCase()+t.slice(1); };
/* Épiceries de la semaine : les favorites (Profil) moins celles décochées sur la carte de la semaine. */
const goStores = () => S.stores.filter(s => !(S.skip||[]).includes(s));
/* produits de pharmacie et d'entretien qui partagent un mot avec un aliment (« crème », « savon au lait »…) */
const NONFOOD = /\b(eucerin|nivea|aveeno|cetaphil|cerave|neutrogena|olay|vaseline|gillette|colgate|crest|oral-?b|listerine|sensodyne|tampax|kotex|pampers|huggies|kleenex|cottonelle|charmin|scotties|purex|tide|downy|bounce|sunlight|cascade|lysol|clorox|javex|febreze|glad|ziploc|duracell|energizer|garnier|pantene|aussie|tresemme|old spice|speed stick|tylenol|advil|motrin|reactine|centrum|jamieson|polysporin|vicks|benadryl|gaviscon|lubriderm|jergens|bioderma|vichy|la roche-posay|marcelle|lise watier|revlon|maybelline|covergirl|l.oreal)\b|creme (pour les |a )?mains|creme (hydratante|pour le corps|pour le visage|solaire|a raser|de nuit|de jour|antirides|corporelle)|ecran solaire|\blotions?\b|shampo|revitalisant|deodorant|antisudorifique|dentifrice|brosse a dents|rince-bouche|\bsavons?\b|gel douche|nettoyant|detergent|assouplissant|papier hygienique|essuie-tout|mouchoirs|couches(-culottes| pour| jetables)|lingettes|serviettes hygieniques|protege-dessous|rasoirs?\b|maquillage|mascara|vernis|eau de (toilette|parfum)|vitamines?\b|multivitamine|analgesique|comprimes|sirop contre la toux|\bpiles?\b|ampoules?\b|litiere|nourriture pour (chien|chat)|sacs a ordures|sacs poubelle|papier d.aluminium|pellicule plastique|soins? (de la peau|capillaires?)|\bbaume\b|cosmetique|teinture|coloration capillaire/;
const isFood = t => !NONFOOD.test(norm(t||''));
function autoItems(){ if(!S.auto) return []; const d = shopISO(), go = goStores(); return S.auto.items.filter(i => isFood(i.t) && (S.auto.anyDate || ((!i.vt || i.vt >= d) && (!i.vf || i.vf <= d))) && (!S.stores.length || go.includes(i.s))); }
let _AS = null;
const allSpec = () => _AS || (_AS = S.spec.filter(s => !s.s || !(S.skip||[]).includes(s.s)).map(s => ({s:s.s, t:s.t, p:''})).concat(autoItems().map(i => ({s:i.s, t:nice(i.t), p:i.p||'', d:i.d||0, per:i.per||''}))));
const specTxt = s => s.t+(s.p ? ' à '+s.p : '')+' ('+s.s+')';
/* Mots composés qui changent d'aliment : « Pommes » ne doit pas prendre le spécial « Pommes de terre ». */
const COMPOUNDS = ['pomme de terre','beurre d\'arachide','creme glacee','creme sure','lait de coco','noix de coco','fromage a la creme','pain de viande','sucre a glacer','pate a tarte'];

/* Prix de référence : voir prix-maxi.js (PRIX, PRIX_DEF, BASE, BAREME, PRIX_MAJ). */
const PRIX_MAJ_TXT = () => { try{ return 'mis à jour le ' + new Date(prixDate()+'T12:00:00').toLocaleDateString('fr-CA', {day:'numeric', month:'long', year:'numeric'}); }catch(e){ return PRIX_MAJ; } };
const prixVieux = () => { try{ return gapDays(prixDate(), isoToday()) > 120; }catch(e){ return false; } };
/* rappel mensuel de mise à jour des prix (désactivable, « dans une semaine » possible) */
const prixRappel = () => { try{ const p = pmaj(); return S.setup && !peFrais() && p.rappel !== false && gapDays(prixDate(), isoToday()) >= 30 && !(p.snooze && p.snooze > isoToday()); }catch(e){ return false; } };
const _BMC = new Map();
function baremeRaw(name){
  const n = norm(name); if(_BMC.has(n)) return _BMC.get(n);
  const b = BAREME.find(x => x[0].test(n)) || null; _BMC.set(n, b); return b;
}
/* Mise à jour des prix : un prix inscrit (S.bx, par entrée du barème) remplace celui du fichier;
   les autres prix suivent l'ajustement global en % (S.pmaj.pct), pour suivre l'inflation. */
const pmaj = () => (S.pmaj = isObj(S.pmaj) ? S.pmaj : {});
const pctF = () => 1 + (Math.max(-50, Math.min(100, +pmaj().pct || 0)) / 100);
const bxKey = b => b[0].source;
function baremeOf(name){ const b = baremeRaw(name); return b ? mergeBx(b) : null; }
function mergeBx(b){
  const o = b[1], ov = (S.bx || {})[bxKey(b)] || {}, k = pctF();
  const m = Object.assign({}, o);
  if(o.f) m.f = o.f.map(([s, p], i) => [s, ov.f && ov.f[i] > 0 ? ov.f[i] : Math.round(p * k * 100) / 100]);
  if(o.kg) m.kg = ov.kg > 0 ? ov.kg : Math.round(o.kg * k * 100) / 100;
  return [b[0], m];
}
/* date de la dernière mise à jour des prix : celle du fichier ou celle faite dans l'application */
const prixDate = () => { const d = pmaj().d || ''; return d > PRIX_MAJ ? d : PRIX_MAJ; };
/* meilleure façon d'acheter q avec les formats F : un format, ou un gros format complété par un plus petit */
function bestFormats(q, F){
  const tol = 0.03;
  const best = (rest, G) => {   /* un format seul, ou n gros formats complétés par les plus petits */
    let B = null; const keep = o => { if(!B || o.cost < B.cost - 1e-9 || (Math.abs(o.cost - B.cost) < 1e-9 && o.fmt.length < B.fmt.length)) B = o; };
    G.forEach(([s,p]) => { const c = Math.max(1, Math.ceil(rest/s - tol)); keep({cost:c*p, fmt:[[s, c]]}); });
    G.forEach(([s,p]) => { const n = Math.floor(rest/s + tol), r = rest - n*s; if(n < 1 || r <= s*tol) return;
      const H = G.filter(x => x[0] < s); if(!H.length) return; const o = best(r, H); keep({cost:n*p + o.cost, fmt:[[s, n]].concat(o.fmt)}); });
    return B;
  };
  const b = best(q, F); return {cost:b.cost, fmt:b.fmt, buy:b.fmt.reduce((t,[s,c]) => t + s*c, 0)};
}
/* les formats à acheter pour une ligne (null si l'article se vend au poids ou n'est pas au barème) */
function planBuy(name, u, q){
  const A = art(name); if(A.pk && A.pk.q > 0) return null;
  const b = baremeOf(name); if(!b || !b[1].f || b[1].u!==u || q <= 0) return null;
  if(u==='un' && PKG_RE.test(norm(name))) return null;
  return bestFormats(q, b[1].f);
}
/* prix régulier d'une ligne d'après le barème (null si absent) */
function baremeCost(r){
  const b = baremeOf(r.name); if(!b) return null; const o = b[1], n = norm(r.name);
  if(o.kg){ const g = r.u==='g' ? r.buy : r.u==='un' ? r.buy * (gpuOf(n) || o.gpu || 0) : 0; return g ? g/1000*o.kg : null; }
  if(r.u===o.u) return bestFormats(r.buy, o.f).cost;
  if(r.u==='un' && o.u==='g' && gpuOf(n)) return bestFormats(r.buy*gpuOf(n), o.f).cost;
  if(r.u==='un') return r.buy * o.f[0][1];   /* un « un » = un format */
  return null;
}
const baremeTxt = name => { const b = baremeOf(name); if(!b) return ''; const o = b[1];
  return (o.kg ? `${money(o.kg)} / kg` : o.f.map(([s,p]) => `${o.u==='un' ? (s===1 ? "l'unité" : 'paquet de '+s) : fq(s, o.u)} : ${money(p)}`).join(' · ')) + (o.e ? ' (estimé)' : ''); };
/* prix par unité de base (par g, par ml ou à l'unité) */
function prixBase(name, u, ray){
  const n = norm(name), hit = PRIX.find(([re]) => re.test(n)), [b, f] = BASE[u] || ['un',1];
  if(hit && hit[1][b] !== undefined) return hit[1][b]/f * pctF();
  const d = PRIX_DEF[ray] || PRIX_DEF['épicerie'];
  return (d[b] !== undefined ? d[b] : (d.un || 4))/f * pctF();
}
let _ECO = new Map(), _ASA = null, _CMP = new Map(), prEdit = '';
/* Articles comptés à l'unité mais vendus en paquet : le prix d'une circulaire est celui du paquet (douzaine d'oeufs, 8 pains…). */
const PKG_RE = /\((sac|boite|paquet|emballage|regime|caisse|gros sac|pot|bouteille|contenant)|\b(sac|sachet|boite|paquet|caisse|pot|bouteille|emballage|contenant|botte|barquette|plateau)(s|x)? (de|d')|ou muffins anglais/;
const PACK_UN = [[/\boeufs?\b/,12],[/tranches? de pain/,20],[/tranches? de (fromage|cheddar)|fromage tranche/,16],[/pains? (a hamburger|a hot-dog|kaiser)|petits pains|sliders/,8],[/pains? sous-marin/,6],
  [/tortillas?/,10],[/coquilles a tacos/,12],[/saucisses? a hot-dog/,12],[/pitas?/,6],[/naan/,4],[/bagels|muffins anglais/,6],[/croissants?/,6],[/fromage ficelle|batonnets de fromage/,12],
  [/compotes? de pommes/,6],[/feuilles de laitue/,15],[/coeurs de romaine/,3],[/abaisses?/,2],[/croquettes|pogo/,8]];
/* poids moyen d'une unité (g), pour les formats au poids et les prix à la livre */
const GPU = [[/poitrines? de poulet/,225],[/hauts? de cuisses?|cuisses? de poulet/,120],[/pilons?/,110],[/cotelettes?/,200],[/steaks?/,250],[/saucisses? a hot-dog/,45],[/saucisses?/,100],
  [/filets? de (saumon|poisson|morue|aiglefin|tilapia|truite|sole)/,150],[/oignons?/,150],[/carottes?/,75],[/tomates?/,120],[/patates? douces?/,300],[/pommes de terre|patates/,200],[/poivrons?/,170],
  [/pommes/,180],[/poires/,180],[/oranges/,150],[/clementines/,80],[/citrons?/,100],[/limes?/,70],[/avocats?/,170],[/bananes?/,120],[/concombres?/,300],[/courgettes?/,250],[/brocoli/,450],[/chou-fleur/,800],[/mangues?/,300]];
const gpuOf = n => (GPU.find(([re]) => re.test(n)) || [])[1] || 0;
function countIn(t){
  let m = t.match(/(\d+)\s*x\s*\d/); if(m) return +m[1];
  m = t.match(/(\d+)\s*(un|unites|mcx|morceaux|tranches|oeufs|saucisses|tortillas|pitas|pains|bagels|croissants|muffins|portions|sachets|canettes|bouteilles|boites|emb|pqt|ct)\b/); if(m) return +m[1];
  if(/douzaine/.test(t)) return 12;
  m = t.match(/(?:^|\s)(\d{1,2})\s*$/); if(m && +m[1] >= 2 && +m[1] <= 60) return +m[1];
  return 0;
}
/* unités par paquet : lues dans le nom du spécial, déduites de son poids, sinon le format courant */
function unitsPer(row, t){
  const n = norm(row.name); const c = t ? countIn(t) : 0; if(c) return c;
  const A = art(row.name); if(A.pk && A.pk.u==='un' && A.pk.q > 0) return A.pk.q;
  const gpu = gpuOf(n), sz = t && t.match(/(\d+(?:[.,]\d+)?)\s*(kg|g|lb)\b/);
  if(gpu && sz) return Math.max(1, Math.round(parseFloat(sz[1].replace(',','.')) * ({kg:1000, g:1, lb:454})[sz[2]] / gpu));
  const d = PACK_UN.find(([re]) => re.test(n)); return d ? d[1] : 0;
}
/* coût d'un spécial pour la quantité de la ligne : format lu dans le nom, format courant, sinon à la livre pour la viande et le poisson */
function dealCost(s, row){
  const pr = priceOf(s); if(!isFinite(pr)) return null;
  const t = norm(s.t), sz = t.match(/(\d+(?:[.,]\d+)?)\s*(kg|g|lb|l|ml)\b/);
  /* prix au poids (« 3,88 /lb ») : coût = poids nécessaire × prix */
  if(s.per==='lb' || s.per==='kg'){ const g = row.u==='g' ? row.buy : row.u==='un' ? row.buy * (gpuOf(norm(row.name)) || 0) : 0; if(g) return pr * g / (s.per==='lb' ? 453.6 : 1000); }
  const mult = (() => { const m = t.match(/(\d+)\s*[x×]\s*\d/); return m && +m[1] > 1 && +m[1] <= 48 ? +m[1] : 1; })();
  if(row.u==='un'){
    const n = norm(row.name);
    if(PKG_RE.test(n)) return pr * row.buy;
    const per = unitsPer(row, t); if(per) return pr * Math.max(1, Math.ceil(row.buy/per - 0.05));
    const gpu = gpuOf(n);
    if(gpu && /viandes|poissonnerie/.test(row.rayon||'')) return pr * row.buy * gpu / 454;
    const ue = prixBase(row.name, 'un', row.rayon);
    if(gpu && pr > 2.2*ue) return pr * row.buy * gpu / 454;
    if(ue > 0 && pr >= 3*ue) return pr * Math.max(1, Math.ceil(row.buy / Math.max(2, Math.round(pr/ue)) - 0.05));
    return pr * row.buy;
  }
  if(sz){
    let size = parseFloat(sz[1].replace(',','.')) * ({kg:1000, g:1, lb:454, l:1000, ml:1})[sz[2]] * mult;
    if((sz[2]==='l' || sz[2]==='ml') !== (row.u==='ml')) size = 0;
    if(size) return pr * Math.max(1, Math.ceil(row.buy/size - 0.05));
  }
  const pk = packOf(row.name, row.u); if(pk) return pr * Math.max(1, Math.ceil(row.buy/pk - 0.05));
  if(row.u==='g' && /viandes|poissonnerie/.test(row.rayon||'')) return pr * row.buy/454;
  /* format absent du nom : on suppose le format courant du barème */
  const bf = baremeOf(row.name); if(bf && bf[1].u===row.u && bf[1].f && bf[1].f[0][0] > 0) return pr * Math.max(1, Math.ceil(row.buy/bf[1].f[0][0] - 0.05));
  return pr;
}
/* « 4 douzaines », « 2 paquets de 8 », « ≈ 6 paquets de 375 g » sous l'article */
function packInfo(r){
  const d = dealFor(r.name), t = d ? norm(d.t) : '', n = norm(r.name);
  if(r.plan && !d){ const F = r.plan.fmt; if(r.u==='un'){ if(F.every(([s]) => s===1)) return ''; if(F.length===1 && F[0][0]===12 && /\boeuf/.test(n)) return F[0][1]===1 ? '1 douzaine' : `${F[0][1]} douzaines`; }
    return F.map(([s,c]) => r.u==='un' ? `${c} paquet${c>1?'s':''} de ${s}` : `${c} × ${fq(s, r.u)}`).join(' + '); }
  if(r.u==='un'){
    if(PKG_RE.test(n)) return '';
    const per = unitsPer(r, t); if(per < 2 || r.buy < 2) return '';
    const np = Math.max(1, Math.ceil(r.buy/per - 0.05));
    if(per===12 && /\boeuf/.test(n)) return np===1 ? '1 douzaine' : `${np} douzaines`;
    return `${np} paquet${np>1?'s':''} de ${per}`;
  }
  const sz = t.match(/(\d+(?:[.,]\d+)?)\s*(kg|g|lb|l|ml)\b/); let size = 0;
  if(sz){ size = parseFloat(sz[1].replace(',','.')) * ({kg:1000, g:1, lb:454, l:1000, ml:1})[sz[2]]; if((sz[2]==='l' || sz[2]==='ml') !== (r.u==='ml')) size = 0; }
  if(!size) size = packOf(r.name, r.u);
  if(!size && r.u==='g' && /viandes|poissonnerie/.test(r.rayon||'') && r.buy >= 200) return `≈ ${String(Math.round(r.buy/453.6*10)/10).replace('.', ',')} lb`;
  if(!size || r.buy < size*1.5) return '';
  const np = Math.max(1, Math.ceil(r.buy/size - 0.05));
  return `≈ ${np} paquets de ${fq(size, r.u)}`;
}
/* prix habituel de la ligne : ton prix noté, sinon l'estimation */
function costEst(r){ const L = (S.prices||{})[r.k], mine = L && !L.sp;
  if(!mine){ if(r.plan) return r.plan.cost; const bc = baremeCost(r); if(bc != null) return bc; }
  let q = r.buy; if(r.u==='un' && !mine){ const n = norm(r.name), A = art(r.name); if(!PKG_RE.test(n)){ const d = A.pk && A.pk.u==='un' && A.pk.q > 0 ? [0, A.pk.q] : PACK_UN.find(([re]) => re.test(n)); if(d) q = Math.max(1, Math.ceil(r.buy/d[1] - 0.05)) * d[1]; } }   /* vendu au paquet */
  return (mine ? L.pu : prixBase(r.name, r.u, r.rayon)) * q; }
/* coût d'une ligne à l'épicerie où elle va (voir epiceries.js : tes prix, le relevé, l'estimation, les spéciaux) */
function rowEco(r){
  if(_ECO.has(r.k)) return _ECO.get(r.k);
  const s = storeOf(r), c = costAt(r, s);
  /* rabais annoncé par la circulaire : le prix régulier qu'elle indique, s'il est plus haut */
  const reg = c.deal && c.deal.d > 0 && c.deal.d < 95 ? Math.max(c.reg, c.cost/(1 - c.deal.d/100)) : c.reg;
  const o = {cost:c.cost, reg, save:Math.max(0, reg - c.cost), mine: c.src==='mine', deal:c.deal, rsp:c.rsp, src:c.src, store:s};
  _ECO.set(r.k, o); return o;
}
function listTotals(rows){ let cost = 0, save = 0; rows.forEach(r => { const e = rowEco(r); cost += e.cost; save += e.save; }); return {cost: cost * calF(), save, raw: cost}; }
/* toutes les circulaires de tes épiceries, même celles où tu ne vas pas cette semaine (pour comparer) */
const allSpecAll = () => _ASA || (_ASA = S.spec.map(s => ({s:s.s, t:s.t, p:'', d:0})).concat(S.auto ? S.auto.items.filter(i => { const d = shopISO(); return isFood(i.t) && (S.auto.anyDate || ((!i.vt || i.vt >= d) && (!i.vf || i.vf <= d))) && (!S.stores.length || S.stores.includes(i.s)); }).map(i => ({s:i.s, t:nice(i.t), p:i.p||'', d:i.d||0, per:i.per||'', o:i.o||''})) : []));
/* ---------- association d'un article à un spécial ----------
   On compare des mots entiers (« lait » ne prend pas « laitue », « oeuf » ne prend pas « boeuf »).
   Tous les mots importants de l'article doivent être dans le spécial. Un spécial qui annonce une autre forme du produit
   (pané, haché, sauce, soupe, jus, chips…) est écarté si l'article ne la nomme pas, sauf dans « X ou Y ».
   L'onglet Articles permet de choisir le bon spécial, d'en retenir un produit, de changer les mots ou d'en exclure. */
const STOPW = new Set(['de','du','des','la','le','les','a','au','aux','et','en','d','l','pour','avec','sur','un','une','x','g','kg','ml','lb','oz','ou','par','sans','dans','ch','chacun','prix','special']);
const OPTW = new Set(['endes','cru','crue','decortique','decortiquee','deveine','deveinee','frais','fraiche','gros','grosse','moyen','moyenne','petit','petite','nature','regulier','reguliere','classique','original','originale','extra','desosse','peau','maigre','mi','surgele','rape','tranche','bio','biologique','familial','format','choix','filet','mur','mure','blanc','blanche','jaune','rouge','vert','verte','emince','coupe','piece','tout','usage','lave','bebe','mini','jumbo','paquet','boite','sac','emballage','regime','caisse','pot','bouteille','contenant','barquette','unite','portion','individuel','individuelle','lunch','lunchs','dejeuner','dejeuners','collation','famille','roties','rotie','cuit','cuite','congele']);
const FORMW = new Set(['hache','roti','steak','cotelette','cote','poitrine','cuisse','haut','pilon','aile','epaule','longe','saucisse','bacon','cube','laniere','pane','croquette','burger','boulette','bouillon','soupe','sauce','assaisonnement','marinade','marine','chip','croustille','biscuit','barre','jus','boisson','yogourt','creme','glace','gateau','muffin','tarte','pizza','lasagne','repas','sandwich','vinaigrette','trempette','tartinade','poudre','sirop','nourriture','chien','chat','compote','puree','broye','pain','hamburger','dog','baguette','bagel','croissant','tortilla','pita','naan','brioche','salade','chocolat','the','cafe','cereale','granola','nouille','sec','seche','bbq','kit','melange','gelee','confiture','dinde','latte','cappuccino','frappuccino','capsule','tartiner','teriyaki','aigre','carbonara','frit','frite','tao','shawarma','plat','simili','stroganov','mein','pastrami','garni','farci','fume','endes','conserve','collation','fouette','vegetale','vegetal','patissiere','evapore','concentre','condense','aromatise','sucre','croquant','enrobe','glacage','fondant','friandise','bonbon','gomme','jujube','guimauve','surprise','kinder']);
const sing = w => w.length > 3 && /[sx]$/.test(w) && !/(ss|is|us|ais|ois|oix|as)$/.test(w) && !/^(gros|dos|repos|frais|sans|sous|endes)$/.test(w) ? w.slice(0,-1) : w;
/* corrections avant la normalisation (les accents distinguent pâté et pâtes) */
const rawFix = s => String(s||'').toLowerCase().replace(/(?<![a-zà-ÿ])p[âa]t[ée]s?(?![a-zà-ÿ])/g, m => /é/.test(m) ? 'terrine' : m).replace(/\ben d[ée]s\b/g, 'endes').replace(/\bpommes? terre\b/g, 'pomme de terre');
const toks = (s, keepParen) => { let t = norm(rawFix(s)); if(!keepParen) t = t.replace(/\([^)]*\)/g,' ');
  return t.replace(/['’]/g,' ').split(/[^a-z0-9%]+/).filter(w => w && !STOPW.has(w) && !/^\d/.test(w)).map(w => { w = sing(w); return w.length > 4 && w.endsWith('ee') ? w.slice(0,-1) : w; }); };
const reqToks = name => { const t = toks(name), r = t.filter(w => !OPTW.has(w)); return r.length ? r : t; };
const spId = s => s.s+'|'+norm(s.t);
const _PREP = new WeakMap();
/* ---------- association spécial ↔ article ----------
   Un nom de circulaire est découpé en « segments » : la partie anglaise (après « | ») et les tailles entre
   parenthèses sont retirées, puis le nom est coupé aux « ou » (« Carottes ou oignons jaunes » = 2 produits).
   Un article correspond à un segment seulement si son mot principal y est le produit lui-même :
   « Oeufs blancs » oui, mais pas « Nouilles aux oeufs », « Casserole d'oeufs » ni « Oeufs Kinder Surprise ». */
const CONNW = new Set(['de','d','du','des','a','au','aux','avec','en','sur','pour','et','farci','farcie','farcis','barde','bardee','bardes','enrobe','enrobee','fourre','fourree','saveur','style','facon','sauce']);
const ARTW = new Set(['la','le','les','l','un','une']);
/* mots de catégorie qui peuvent précéder le produit : « Fromage feta », « Riz basmati », « Huile d'olive » */
const CLASSW = new Set(['fromage','viande','poisson','legume','fruit','pate','nouille','riz','farine','huile','vinaigre','sucre','the','epice','fine','herbe','sauce','lait','creme','bouillon']);
/* compléments normaux après le produit : l'animal (« Saucisses de porc »), le liquide (« Thon à l'huile ») */
const POSTOK = new Set(['poulet','boeuf','porc','dinde','veau','agneau','canard','poisson','saumon','thon','morue','crevette','huile','eau','saumure','dos','surlonge','longe','epaule','cuisse','poitrine','lait','grain']);
/* produits souvent aromatisés : « Yogourt aux fraises », « Ketchup aux tomates » restent ces produits */
const FREEPOST = new Set(['yogourt','yogurt','ketchup','jus','the','cafe','tisane','compote','confiture','gruau','cereale','craquelin','biscuit','muffin','barre','vinaigrette','moutarde','soupe','bouillon','saucisse','pain','bagel','fromage','pouding','gelee','sirop','tartinade','trempette','salsa','mayonnaise']);
/* coupes et formats : « Poitrines de poulet », « Sac de carottes » restent du poulet et des carottes */
const CUTW = new Set(['poitrine','cuisse','haut','pilon','aile','filet','cube','laniere','epaule','longe','cotelette','cote','steak','roti','bavette','surlonge','tranche','morceau','jarret','contre','intérieur','interieur','exterieur','ronde','croupe','palette','flanc','cuisseau','gigot','carre','demi','quartier','tournedo','medaillon','escalope','brochette',
  'sac','paquet','paq','emb','bifteck','produit','preparation','entier','entiere','duo','assortiment','canette','minicanette','boite','caisse','emballage','barquette','format','tube','pot','bouteille','contenant','plateau','bloc','rouleau','douzaine','botte','regime','couronne','tete','pied','coeur','bouquet','grappe','casseau','livre','lb','kg','g','ml','l','economique','familial','gros','grosse','petit','petite']);
/* friandises et produits non alimentaires qui partagent des mots avec les aliments */
const CANDY_RE = /\b(kinder|surprise|friandises?|bonbons?|cadbury|lindt|ferrero|hershey|reese|smarties|m ?& ?m|mars|twix|kit ?kat|aero|caramilk|coffee crisp|toblerone|guimauves?|reglisses?|halloween|paques|jujubes?|gommes?)\b/;
const SMOKED = new Set(['bacon','jambon','saucisse','saucisson','kielbasa']);
const VARIETY = {
  fromage: {all:new Set(['chevre','feta','brie','camembert','oka','bocconcini','parmesan','mozzarella','mozzarellissima','gouda','suisse','havarti','ricotta','mascarpone','halloumi','cottage','raclette','bleu','emmental','kashkaval','tuma','provolone','gruyere','cheddar','colby','monterey','jack','tresse','grec','paneer','asiago','romano','fontina','swiss','cracker','vache','babybel','ficelle','quark']), def:new Set(['cheddar','mozzarella','mozzarellissima','colby','monterey','jack'])},
  lait: {all:new Set(['coco','amande','soya','soja','avoine','chocolat','riz','cajou','evapore','condense','beurre','frappe']), def:new Set()},
  riz: {all:new Set(['lait','croustillant','souffle','galette','cereale']), def:new Set()}
};
/* conserves : un article en boîte prend un spécial en boîte, pas le saumon frais */
const CANNED_RE = /\bboites?\b|conserve|\bcans?\b|canned|endes|\bpelee|\bpolpa\b|mutti|unico|aylmer|rio ?mare|clover|gold seal|cedar|fillo|clark|primo|del monte|green giant|pastene|\b(1[0-9]{2}|[2-9][0-9]{2}) ?ml\b|\b(8[5-9]|9[0-9]|1[0-9]{2}|2[01][0-9]) ?g\b/;
const CANNABLE = new Set(['tomate','saumon','thon','mais','pois','haricot','ananas','peche','poire','champignon','pomme','lentille','feve']);
const NAMEFIX = [[/\bou\s*\/\s*or\b/g, ' ou '], [/\b(\d+)\s*%/g, '$1pc']];
function nameSegs(t){
  let n = norm(rawFix(t)).split('|')[0]; NAMEFIX.forEach(([re, r]) => n = n.replace(re, r));
  n = n.replace(/\([^)]*\)/g, ' ').replace(/\b\d+(?:[.,]\d+)?\s*(?:x|×)\s*\d+(?:[.,]\d+)?\s*(?:g|kg|ml|l|lb|oz)\b/g, ' ').replace(/\b\d+(?:[.,]\d+)?(?:\s*[-à\/]\s*\d+(?:[.,]\d+)?)?\s*(?:g|kg|ml|l|lb|oz|un|unites?)\b\.?/g, ' ');
  const tok = seg => seg.replace(/['’]/g, ' ').split(/[^a-z0-9]+/).filter(Boolean).map(w => { if(/^\d+pc$/.test(w)) return w; w = sing(w); return w.length > 4 && w.endsWith('ee') ? w.slice(0,-1) : w; }).filter(w => w==='et' || !/^\d/.test(w) || /pc$/.test(w));
  const out = [];
  /* les « ou » partagent souvent un mot : « Poitrines ou cuisses de poulet », « Lait 1 % ou 2 % », « Huile de canola ou végétale » */
  n.split(/;|\s-\s|,(?!\d)/).forEach(part => {
    const S = part.split(/\bou\b|\bor\b/).map(tok).filter(W => W.length); if(!S.length) return;
    const first = S[0][0], last = S[S.length-1], tail = last.slice(1);
    S.forEach((W, i) => { out.push(W);
      if(S.length > 1){ if(i > 0 && !W.includes(first)) out.push([first].concat(W)); if(i < S.length-1 && tail.length) out.push(W.concat(tail)); } });
  });
  return out;
}
let _PN = null;
/* noms de produits connus : un tel mot devant l'article (« Poulet au beurre » pour Beurre) change le produit */
function prodNouns(){
  if(_PN) return _PN;
  _PN = new Set([...FORMW].filter(w => !CUTW.has(w)).concat(['casserole','tartelette','chou','brownie','macaroni','beigne','nouille','pappardelle','linguine','spaghetti','penne','raviolis','ravioli','tortellini','gnocchi','roule','pate','pogo','quiche','tourtiere','pate','mousse','pouding','galette','crepe','gaufre','omelette','fondue','pizza','poutine','burrito','taco','nacho','wrap','hummus','houmous','tzatziki','charqui','minicroissant','croquant','poulet','boeuf','porc','dinde','veau','agneau','saumon','thon','crevette','fromage','beurre','lait','oeuf','riz','yogourt','legume','fruit','pomme','tomate','patate','oignon']));
  try{ catalog().forEach(c => { const r = reqToks(c.n); if(r[0] && r[0].length > 2) _PN.add(r[0]); }); }catch(e){}
  return _PN;
}
/* l'article (mots requis R, mot principal R[0]) est-il le produit de ce segment ? */
function segFits(R, mine, W){
  const PN = prodNouns(), head = R[0];
  if(!R.every(w => W.includes(w))) return false;
  const i = W.indexOf(head), pre = W.slice(0, i).filter(w => !ARTW.has(w));
  const j = pre.length && CONNW.has(pre[pre.length-1]) ? pre.length-1 : -1;   /* connecteur juste avant le produit */
  if(j >= 0){ const bef = pre.slice(0, j); if(!bef.length || !bef.every(w => CUTW.has(w) || CONNW.has(w))) return false; }
  else if(pre.some(w => PN.has(w) && !CONNW.has(w) && !mine.has(w) && !CUTW.has(w) && !OPTW.has(w) && !CLASSW.has(w))) return false;
  /* après le mot principal : « Beurre aux pois chiches », « Riz au lait » sont d'autres produits */
  const post = FREEPOST.has(head) ? [] : W.slice(i + 1);
  for(let k = 0; k < post.length; k++){
    if(!CONNW.has(post[k])) continue;
    let w = post[k+1]; let m = k+1; while(w && ARTW.has(w)){ m++; w = post[m]; }
    if(w && PN.has(w) && !mine.has(w) && !OPTW.has(w) && !CUTW.has(w) && !POSTOK.has(w)) return false;
  }
  /* forme ou préparation qui n'est pas dans le nom de l'article (pané, haché, en sauce…) */
  if(W.some(w => FORMW.has(w) && !mine.has(w) && !(w==='fume' && SMOKED.has(head)))) return false;
  /* variétés : « Fromage râpé » prend le cheddar ou la mozzarella, pas le chèvre ni le brie */
  const V = VARIETY[head];
  if(V){ const own = [...mine].some(w => V.all.has(w)), other = W.filter(w => V.all.has(w) && !mine.has(w));
    if(other.length && (own || !other.every(w => V.def.has(w)))) return false; }
  /* pourcentages : Crème 35 % ne prend pas la crème 10 %, Lait 2 % pas le lait 1 % */
  const pm = [...mine].filter(w => /pc$/.test(w)), pw = W.filter(w => /pc$/.test(w));
  if(pm.length && pw.length && !pm.some(w => pw.includes(w))) return false;
  return true;
}
function prep(list){
  let P = _PREP.get(list);
  if(!P){ P = list.map(s => { const tk = toks(s.t, true), sg = nameSegs(s.t), nt = norm(rawFix(s.t)); return {s, nt, tk:new Set(tk.concat(sg.flat())), segs:sg, f:tk.filter(w => FORMW.has(w)), b:baseOf(rawFix(s.t)), candy:CANDY_RE.test(nt), can:CANNED_RE.test(nt), canMark:/endes|\bpelee|\bpolpa\b|conserve|\bboites?\b/.test(nt), alt:/ ou /.test(nt)}; }); P.memo = new Map();
    /* index mot → spéciaux : on n'examine que les spéciaux qui contiennent le premier mot cherché */
    P.idx = new Map(); P.forEach(x => x.tk.forEach(w => { let a = P.idx.get(w); if(!a) P.idx.set(w, a = []); a.push(x); }));
    _PREP.set(list, P); }
  return P;
}
/* réglages d'un article (onglet Articles) */
const artB = name => baseOf(plain(name));
const art = name => (S.art||{})[artB(name)] || {};
const pcToks = name => (norm(name).match(/\b\d+\s*%/g) || []).map(x => x.replace(/\s*%/, 'pc'));
function dealCands(name, P){
  if(P.memo && P.memo.has(name)) return P.memo.get(name);
  const res = dealCands0(name, P); if(P.memo) P.memo.set(name, res); return res;
}
function dealCands0(name, P){
  const A = art(name), nb = baseOf(name), alts = [];
  if(A.kw) A.kw.split(',').forEach(x => { const t = toks(x); if(t.length) alts.push({t, free:false, kw:true}); });
  else { const parts = / ou /.test(norm(name)) ? plain(name).split(/\s+ou\s+/i) : [name]; parts.forEach(p => { const r = reqToks(p); if(r.length) alts.push({t:r, free:false}); }); }
  (A.learn||[]).forEach(t => { if(t.length) alts.push({t, free:true}); });
  if(!alts.length) return [];
  const no = A.no ? A.no.split(',').flatMap(x => toks(x)) : [];
  const mine = new Set(toks(name).concat(alts.flatMap(a => a.t), pcToks(name)));
  if(/\bboites?\b|conserve|en d[ée]s/i.test(name)) ['conserve','endes','boite'].forEach(w => mine.add(w));
  const candyOk = CANDY_RE.test(norm(name)) || /chocolat|bonbon|friandise/.test(norm(name));
  let pool = P;
  if(P.idx){ const set = new Set(); alts.forEach(a => (P.idx.get(a.t[0]) || []).forEach(x => set.add(x))); pool = P.filter(x => set.has(x)); }
  const head = reqToks(name)[0], canned = CANNABLE.has(head) && (/\bboites?\b|conserve/.test(norm(name)) || /endes/.test(norm(rawFix(name)))) && !/\bboites? (de|d)( |')?(oeufs?|cereales?|biscuits?|craquelins?|the|cafe|mouchoirs?|chocolats?)/.test(norm(name)), ex = new Set(A.ex || []);
  return pool.filter(x => {
    if(no.some(w => x.tk.has(w)) || ex.has(norm(x.s.t))) return false;
    if(alts.some(a => a.free && a.t.every(w => x.tk.has(w)))) return true;
    if(x.candy && !candyOk) return false;
    if(canned ? !x.can : (CANNABLE.has(head) && x.canMark)) return false;
    if(COMPOUNDS.some(c => x.b.includes(c) && !nb.includes(c) && nb.split(' ').includes(c.split(' ')[0]))) return false;
    /* mots choisis à la main (Articles) : tous présents dans un même segment, sans autre contrôle de forme */
    return alts.some(a => !a.free && x.segs.some(W => a.kw ? a.t.every(w => W.includes(w)) : segFits(a.t, mine, W)));
  }).map(x => x.s);
}
const matchesFor = (name, list) => dealCands(name, prep(list));
/* moins cher dans une autre de tes épiceries ? */
/* nettement moins cher dans une autre de tes épiceries ? (seulement d'après un vrai prix : spécial, relevé ou ton prix) */
function cheaper(r){
  if(_CMP.has(r.k)) return _CMP.get(r.k);
  let out = null;
  const A = storeOf(r), cA = costAt(r, A); let best = null;
  S.stores.filter(s => s !== A).forEach(s => { const c = costAt(r, s); if(c.src === 'est' && !c.deal && !c.rsp) return; if(!best || c.cost < best.c.cost) best = {s, c}; });
  if(best && best.c.cost < cA.cost*0.9 && cA.cost - best.c.cost >= 0.5) out = {store:best.s, cost:best.c.cost, costA:cA.cost, A, aDeal: !!(cA.deal || cA.rsp), save: cA.cost - best.c.cost, sp: !!(best.c.deal || best.c.rsp)};
  _CMP.set(r.k, out); return out;
}
/* vraies aubaines : rabais d'au moins 35 % sur un produit qui se garde ou se congèle */
function stockTip(n, ray){
  if(ray==='viandes' || ray==='poissonnerie') return 'À congeler en portions dans des sacs hermétiques : environ 3 mois pour la viande hachée et le poisson, 6 mois pour les pièces.';
  if(ray==='surgelés') return 'Se garde plusieurs mois au congélateur.';
  if(/beurre|fromage/.test(n)) return 'Le beurre et le fromage râpé se congèlent bien.';
  if(/garde-manger|épicerie/.test(ray) && !/pain|jus|lait|yogourt|creme|sushi|salade/.test(n)) return 'Se garde longtemps au garde-manger.';
  return '';
}
function aubaines(){
  const seen = new Set(), out = [];
  allSpec().forEach(s => {
    const pr = priceOf(s); if(!isFinite(pr)) return;
    const n = norm(s.t), ray = guessRayon(s.t), tip = stockTip(n, ray); if(!tip) return;
    let disc = s.d || 0;
    if(!disc && (ray==='viandes' || ray==='poissonnerie')){
      const hit = PRIX.find(([re]) => re.test(n)); const kg = hit && hit[1].kg;
      const sz = n.match(/(\d+(?:[.,]\d+)?)\s*(kg|g|lb)\b/);
      const perKg = s.per==='lb' ? pr*2.2046 : s.per==='kg' ? pr : sz ? pr / (parseFloat(sz[1].replace(',','.')) * ({kg:1, g:0.001, lb:0.454})[sz[2]]) : null;
      if(kg && perKg) disc = Math.round((1 - perKg/kg)*100);
    }
    if(disc >= 35 && disc < 90 && !seen.has(n)){ seen.add(n); out.push({s, disc, tip}); }
  });
  return out.sort((a,b) => b.disc - a.disc).slice(0, 6);
}
function renderAubaines(){
  const L = aubaines(); if(!L.length) return '';
  const added = new Set((S.menu.sn||[]).map(x => x.t)), dis = '';
  return `<div class="card aub"><h3>Vraies aubaines : fais des réserves</h3><p class="small">Ces rabais sont rares : au moins 35 % sous le prix habituel. Bon moment pour en acheter plus et les garder.</p><div class="list">${L.map(x => `<div class="item"><span class="t"><span class="tags">${tagHtml(x.s)}<span class="flag w">−${x.disc} %</span></span><small>${esc(x.tip)}${goStores().includes(x.s.s) ? '' : ` Chez ${esc(x.s.s)}, où tu ne vas pas cette semaine.`}</small></span>${added.has(x.s.t) ? '<span class="small">Dans la liste</span>' : `<button class="btn s p" data-a="aubadd" data-t="${esc(x.s.t)}" ${dis}>En ajouter</button>`}</div>`).join('')}</div></div>`;
}

/* Historique : à chaque recherche, le meilleur spécial trouvé pour chaque article connu (8 dernières semaines). */
function noterPrix(){
  const d = shopISO(), L = (S.auto && S.auto.items || []).map(i => ({s:i.s, t:nice(i.t), p:i.p||'', d:i.d||0, per:i.per||''})).filter(s => isFinite(priceOf(s)));
  if(!L.length) return;
  const P = prep(L), arts = new Map(); S.ph = S.ph || {};
  const add = n => { if(n && !isMaison(n)) arts.set(artB(n), n); };
  if(S.menu.date) needs().forEach(n => add(n.name));
  Object.values(S.stock||{}).forEach(o => add(o.name)); (S.ess||[]).concat(S.snacks||[]).forEach(o => add(o.name));
  Object.keys(S.ph).forEach(b => { if(!arts.has(b)){ const c = catalog().find(x => x.b===b); if(c) arts.set(b, c.n); } });
  arts.forEach((name, b) => {
    const C = dealCands(name, P); if(!C.length) return;
    const s = C.reduce((a, x) => priceOf(x) < priceOf(a) ? x : a), pr = priceOf(s);
    const H = (S.ph[b] || []).filter(e => e.d !== d);
    const e = {d, s:s.s, p:pr, t:String(s.t).slice(0,48)}; if(s.d > 0 && s.d < 95) e.r = Math.round(pr/(1 - s.d/100)*100)/100;
    H.unshift(e); S.ph[b] = H.sort((x,y) => y.d.localeCompare(x.d)).slice(0, 6);
  });
}
const dShort = iso => { try{ return new Date(iso+'T12:00:00').toLocaleDateString('fr-CA', {day:'numeric', month:'short'}); }catch(e){ return iso; } };
/* « Souvent en spécial à … » pour un article sans spécial cette semaine */
function histLine(name){
  const H = ((S.ph||{})[artB(name)] || []).filter(e => e.d !== shopISO()); if(!H.length) return '';
  if(H.length===1){ const e = H[0]; return `Dernier spécial : ${money(e.p)} chez ${e.s} le ${dShort(e.d)} (${e.t}). Pas en spécial cette semaine.`; }
  const ps = H.map(e => e.p).sort((a,b) => a-b), lo = ps[0], hi = ps[ps.length-1];
  return `Souvent en spécial ${lo===hi ? 'à '+money(lo) : 'de '+money(lo)+' à '+money(hi)} (${H.length} fois depuis le ${dShort(H[H.length-1].d)}, dernier chez ${H[0].s}). Pas en spécial cette semaine.`;
}
/* le spécial d'un article cette semaine : celui choisi dans Articles, sinon le moins cher pour la quantité de la liste */
function dealFor(name){
  if(_DF.has(name)) return _DF.get(name);
  const man = (S.menu.dsel||{})[artB(name)]; let best = null;
  if(man !== 'none'){
    if(man) best = allSpec().find(s => spId(s)===man) || null;
    if(!best){
      const row = _BL ? _BL.rows.find(r => r.name===name) : null; let bc = Infinity;
      dealCands(name, prep(allSpec())).forEach(s => { const pr = priceOf(s), c = isFinite(pr) ? (row ? dealCost(s, row) : pr) : Infinity;
        if(!best || c < bc){ best = s; bc = c; } });
    }
  }
  _DF.set(name, best); return best;
}

/* Menu de la semaine — Génération du menu, budget, recherche des circulaires (Flipp).
   Les fichiers de js/ partagent les mêmes variables globales; ils sont chargés dans l'ordre de index.html. */
/* ---------- génération du menu ---------- */
const protein = r => { const t = norm(r.n+' '+r.m.join(' ')); for(const p of ['poulet','boeuf','porc','saucisse','jambon','bacon','poisson','bologne']) if(t.includes(p)) return p;
  return /saumon|truite|crevette|morue|tilapia|aiglefin|thon|petoncle|homard|crabe|moules|fruits de mer/.test(t) ? 'poisson' : 'autre'; };
const isPasta = r => /spaghetti|pates|lasagne|tortellini|mac n|gnocchi|carbonara|nouilles|ramen/.test(norm(r.n));
const uses = n => S.hist.reduce((c,w) => c + histItems(w).filter(x => x.r===n).length, 0);
function recentSet(){ return new Set(S.hist.slice(-S.p.cool).flatMap(w => histItems(w).map(x => x.r))); }
function pickVar(r){
  const nv = vars(r).length;
  if(S.p.varMode==='base' || !nv) return 0;
  const u = uses(r.n);
  return S.p.varMode==='var' ? 1 + (u % nv) : u % (nv+1);
}
/* un plat fait avec des restes ne profite pas du spécial de l'ingrédient qu'il récupère */
const itemDeals = (it, r) => { const ds = dealsOf(r); return r.ur && primOf(it) ? ds.filter(d => !urMatch(r.ur, d.mot) && !urMatch(r.ur, d.hit.t)) : ds; };
/* Coupe ou forme précise dans un spécial : elle doit aussi se trouver dans la recette (pas de boeuf haché pour un rôti). */
const SHAPES = ['hache','roti','steak','cotelette','cote','poitrine','cuisse','pilon','aile','epaule','longe','filet','saucisse','bacon','tranche','cube','laniere','surlonge','bavette','palette','croquette','pane','pizza','lasagne','tourtiere','pogo','burrito','soupe','sauce','croustille','biscuit','yogourt','glacee','gateau','muffin','barre','jus','boisson','vinaigrette','trempette','repas','salade','sandwich','fromage a la creme','poulet','boeuf','porc','dinde','jambon','saumon','crevette','veau','agneau','tilapia','morue','aiglefin','thon','poisson'];
const SHAPE_RE = SHAPES.map(w => [w, new RegExp('\\b'+w)]);
let _DO = new WeakMap();
function dealsOf(r){
  if(_DO.has(r)) return _DO.get(r); const res = dealsOf0(r); _DO.set(r, res); return res;
}
function dealsOf0(r){
  const out = [], ing = norm(r.n+' '+r.i.map(g => g[2]).join(' '));
  const fits = s => { const t = norm(s.t); return SHAPE_RE.every(([w,re]) => !re.test(t) || ing.includes(w)); };
  const P = prep(allSpec());
  for(const mot of (r.m||[])){ if(!toks(mot).length) continue; const hit = dealCands(mot, P).find(fits); if(hit && !out.some(y => y.hit===hit)) out.push({mot,hit}); }
  return out;
}
function score(r){
  let pts = 0;
  dealsOf(r).forEach(d => pts += GENERIC.includes(norm(d.mot)) ? .3 : 1.2);
  pts += .35 * [...r.e].filter(c => c!==' ' && c!=='️').length / 2;
  let hit = 0; effective(r,0).forEach(g => { if(isMaison(g.name)) return; const sk = skOf(g); if(sk) hit += Math.min(1, S.stock[sk].q/Math.max(normQU(g.name,g.q,g.u)[0],1)); });
  pts += Math.min(hit,5)*.4;
  if(S.fav[r.n]) pts += .8;
  if(tpOf(r)<=20) pts += .25;
  if(r.pp && dealsOf(r).length) pts += 2.5;
  if(r.rs && S.p.reste!==false && dealsOf(r).length) pts += .6;
  const rt = S.rate[r.n]; if(rt) pts += Math.max(-2, Math.min(1.5, .5*rt.up - .7*rt.down));
  pts += famBonus(r);
  return pts + Math.random()*.9;
}

function fillDej(n, keep, ban){
  const items = keep.slice(), taken = new Set(items.map(x => x.r)), banned = new Set([...recentSet(), ...taken, ...(ban||[])]);
  const base = allRecipes().filter(r => kindOf(r)==='dejeuner' && !r.oc && !S.dis[r.n] && !softBad(r) && ppOk(r) && !(ban && ban.has(r.n)));
  const best = semaine => { const ok = r => (STK ? stkOk(r, pDej()) : isSimple(r)===semaine) && !taken.has(r.n);
    let c = base.filter(r => ok(r) && !banned.has(r.n)); if(!c.length) c = base.filter(ok); if(!c.length) c = base.filter(r => !taken.has(r.n));
    if(STK) c = c.filter(r => stkOk(r, pDej()));
    let b = null, bs = -1e9; c.forEach(r => { const s = score(r); if(s > bs){ bs = s; b = r; } }); if(b) stkUse(b, pDej()); return b; };
  const used = new Set(items.map(x => x.d).filter(Boolean)), free = dejDays().filter(d => !used.has(d));
  free.slice(0, Math.max(0, n - items.length)).forEach(d => { const r = best(!isOff(d)); if(!r) return; items.push({r:r.n, v:pickVar(r), d}); taken.add(r.n); });
  while(items.length < n){ const r = best(false); if(!r) break; items.push({r:r.n, v:pickVar(r)}); taken.add(r.n); }
  return items;
}
function fill(n, keep, l, ban){
  l = l || 'items'; const kind = ML[l];
  if(l==='dej') return fillDej(n, keep, ban);
  if(l==='din') return fillDin(n, keep, new Set([...(ban||[]), ...mlist('items').map(x => x.r)]));
  const items = keep.slice();
  const banned = new Set([...recentSet(), ...items.map(x => x.r), ...(ban||[])]);
  const ptL = l==='items' ? totalPortions() : 0;
  const pool = allRecipes().filter(r => kindOf(r)===kind && !r.oc && !S.dis[r.n] && !softBad(r) && (STK ? true : ppOk(r)) && simpleOk(r) && !(ban && ban.has(r.n)) && (!STK || (!r.ur && stkOk(r, ptL))));
  let cands = pool.filter(r => !banned.has(r.n));
  /* pas assez de plats « frais » : on complète avec des plats récents, mais toujours après les nouveaux */
  if(cands.length < n - items.length) cands = pool.filter(r => !items.some(x => x.r===r.n));
  cands = cands.map(r => ({r, s:score(r) - (banned.has(r.n) ? 10 : 0)})).sort((a,b) => b.s-a.s);
  const taken = new Set(items.map(x => x.r));
  let pps = items.filter(x => (byName(x.r)||{}).pp).length;
  if(kind!=='souper'){
    for(const {r} of cands){ if(items.length>=n) break; if(taken.has(r.n) || (r.pp && pps>=1) || !stkOk(r, ptL)) continue; items.push(Object.assign({r:r.n, v:STK ? 0 : pickVar(r)}, l==='ent' ? {ro:'entree'} : l==='sou' ? {ro:'avec'} : {})); taken.add(r.n); if(r.pp) pps++; stkUse(r, ptL); }
    return items;
  }
  const nsr = l==='items' && !STK ? Math.min(S.p.nSr||0, n) : 0, srMiss = Math.max(0, nsr - items.filter(x => x.sr).length);
  const ncm = l==='items' && !STK ? Math.min(S.p.nCm||0, Math.max(0, n - nsr)) : 0, cmMiss = Math.max(0, ncm - items.filter(x => x.cm).length), nN = n - srMiss - cmMiss;
  const prot = {}, fams = {}, typs = {}; let pastas = 0, longs = 0, duos = items.filter(x => x.after).length; const maxLong = nLongW(), maxDuo = n>=6 ? 2 : 1;
  const note = r => { const p = protein(r); prot[p] = (prot[p]||0)+1; pastas += isPasta(r)?1:0; longs += isLong(r)?1:0;
    const f = famOf(r); if(f) fams[f] = (fams[f]||0)+1; const ty = r.t||'viande'; typs[ty] = (typs[ty]||0)+1; };
  items.forEach(it => { const r = byName(it.r); if(r) note(r); });
  const push = (r, after) => { const it = mkItem(r, usedSides(items), STK ? 0 : pickVar(r)); if(after) it.after = after; items.push(it); taken.add(r.n); note(r); if(r.pp) pps++; stkUse(r, ptL); };
  /* chacun ses coups de cœur : un plat aimé de celui qui a été le moins gâté jusqu'ici passe devant */
  const fair = goutsActifs() && !STK, joie = {};
  const joieAdd = r => { if(fair) famAvis(r, 0).L.forEach(x => { joie[x.i] = (joie[x.i]||0) + (x.refus.length ? -.5 : x.pts); }); };
  items.forEach(it => { const r = byName(it.r); if(r) joieAdd(r); });
  const fairB = r => { const L = famAvis(r, 0).L; if(L.length < 2) return 0; const J = L.map(x => joie[x.i]||0), avg = J.reduce((t, x) => t + x, 0) / J.length;
    return L.reduce((t, x, j) => t + Math.max(0, avg - J[j] + .5) * .45 * (x.refus.length ? -1 : x.pts), 0); };
  const okLvl = (r, lvl) => {
    if(taken.has(r.n) || (r.pp && pps>=1) || (STK && !stkOk(r, ptL))) return false;
    const p = protein(r);
    if(lvl===0){ if(p!=='autre' && (prot[p]||0)>=2) return false; if(isPasta(r) && pastas>=2) return false; }
    if(lvl<2){ const f = famOf(r), ty = r.t||'viande'; if(f && fams[f]) return false; if(TY_MAX[ty]!==undefined && (typs[ty]||0) >= TY_MAX[ty]) return false; }
    if(lvl<2 && isLong(r) && longs>=maxLong) return false;
    if(lvl===0 && r.rs && duos>=maxDuo) return false;
    return true; };
  const pass = lvl => { while(items.length < nN){
    let best = null, bs = -1e9;
    for(const c of cands){ if(!okLvl(c.r, lvl)) continue; const sc = c.s + (fair ? fairB(c.r) : 0); if(sc > bs){ bs = sc; best = c.r; } if(!fair) break; }
    if(!best) break; const r = best;
    push(r); joieAdd(r);
    if(!STK && r.rs && S.p.reste!==false && duos<maxDuo && items.length < nN){ const av = new Set(Object.keys(fams)), fu = pickFollow(r, new Set([...taken, ...banned]), av) || pickFollow(r, taken, av); if(fu){ push(fu, r.n); joieAdd(fu); duos++; } }
  } };
  pass(0); if(items.length<nN) pass(1); if(items.length<nN) pass(2);
  if(srMiss) soupesRepas(items, srMiss, banned);
  if(cmMiss) repasPlaisir(items, cmMiss, banned);
  return items;
}
function today(){ return fmtDate(shopISO()); }
function genMenu(){
  const m = S.menu, shop = shopISO(), start = startFrom(shop), nm = {date:fmtDate(start), start, shop, chk:{}, extra:{}, achete:false, snap:null, useup:m.useup||{}, sn:m.date ? (m.sn||[]) : [], dinCook:{}, dinNo:{}, dsel:m.dsel||{}};
  nm.q = QW ? Object.assign({}, QW) : (m.date && m.start === start && m.q ? m.q : null); if(m.eb && m.start === start) nm.eb = true;
  const q0 = QW; QW = nm.q || {};   /* les réponses de la semaine guident le choix des plats */
  ['items','dej','ent','sou','des'].forEach(l => { nm[l] = fill(nOf(l), (m[l]||[]).filter(x => x.lock), l, l==='sou' ? new Set((nm.items||[]).map(x => x.r)) : undefined); });
  QW = q0; if(!nm.q) delete nm.q;
  nm.din = (m.din||[]).filter(x => x.lock);
  S.menu = nm; assignDays(true); assignDej(true); syncDin(true); assignExtras(true); resetCaches();
  const nb = budgetFit(); if(nb) S.flash = `Budget : ${nb} souper${nb>1?'s':''} remplacé${nb>1?'s':''} par ${nb>1?'des plats moins chers':'un plat moins cher'}.`;
  save(); render();
}
/* coût approximatif d'un plat (au prorata, spéciaux compris) : sert seulement à comparer les plats entre eux */
function dishCost(it){
  let c = 0;
  fullIngs(it).forEach(g => { if(isMaison(g.name) || g.rest || g.x) return; let x = prixBase(g.name, g.u, g.rayon) * g.q; const d = dealFor(g.name);
    if(d){ const dc = dealCost(d, {name:g.name, u:g.u, buy:g.q, rayon:g.rayon, k:g.k}); if(dc != null && isFinite(dc)) x = Math.min(x, dc); }
    if(isFinite(x)) c += x; });
  return c;
}
/* Budget : tant que la liste dépasse, le souper le plus cher (non verrouillé) est remplacé par un plat bien noté
   qui coûte au moins 20 % de moins. Au plus 6 remplacements; renvoie le nombre de plats changés. */
function budgetFit(){
  const b = +S.p.budget || 0; if(!b || !S.menu.date || S.menu.achete) return 0;
  let changed = 0; const recent = recentSet(), tried = new Set();
  /* candidats évalués une seule fois (note et coût), pas à chaque tour */
  const pool = allRecipes().filter(r => kindOf(r)==='souper' && !r.oc && !S.dis[r.n] && !softBad(r) && ppOk(r) && simpleOk(r) && !recent.has(r.n))
    .map(r => { const it = mkItem(r, new Set(), pickVar(r)); return {r, s: score(r), c: dishCost(it)}; });
  for(let k = 0; k < 6; k++){
    resetCaches();
    if(listTotals(buyList().rows).cost <= b) break;
    const L = mlist('items'), used = new Set(allItems().map(x => x.r));
    const cand = L.map((it, i) => ({it, i, c: dishCost(it)})).filter(o => !o.it.lock && !o.it.sr && !o.it.cm && !o.it.dfix && !o.it.after && !follOf(o.it) && !tried.has(o.it.r) && byName(o.it.r)).sort((a, c) => c.c - a.c)[0];
    if(!cand) break;
    tried.add(cand.it.r);
    const longOk = isLong(byName(cand.it.r));
    const others = L.filter((_, j) => j !== cand.i);
    let best = null;
    pool.forEach(o => { if(used.has(o.r.n) || (isLong(o.r) && !longOk) || !(o.c < cand.c * 0.8)) return;
      const s = o.s - 2 * o.c / Math.max(1, cand.c); if(!best || s > best.s) best = {r:o.r, s}; });
    if(!best) continue;
    const it = mkItem(best.r, usedSides(others), pickVar(best.r)); if(cand.it.d) it.d = cand.it.d;
    L[cand.i] = it; changed++;
  }
  resetCaches(); return changed;
}
/* une soupe à côté devient le souper d'un jour (le souper prévu ce jour-là est retiré) */
function soupeEnRepas(l, i){
  const L = mlist(l), it = L[i], I = mlist('items'); if(!it) return '';
  const r = byName(it.r); if(!r) return '';
  const j = I.findIndex(x => x.d===it.d && !x.sr), k = j >= 0 ? j : I.findIndex(x => x.d && !x.sr && !x.lock && !isOff(x.d)), old = k >= 0 ? I[k] : null;
  const ni = mkSoupe(r, usedSides(I)); if(old && old.d){ ni.d = old.d; ni.dfix = true; }
  L.splice(i, 1); if(k >= 0) I[k] = ni; else I.push(ni);
  S.p.nSr = Math.min(2, (S.p.nSr||0) + 1); S.p.nSou = Math.max(0, (S.p.nSou||0) - 1);
  assignDays(false); assignExtras(false);
  return `${r.n} : soupe-repas${ni.d ? ' ' + dayLbl(ni.d).toLowerCase() : ''}${old ? `, à la place de ${old.r}` : ''}.`;
}
/* une soupe-repas redevient une soupe à côté; le jour reçoit un autre souper */
function soupeACote(i){
  const I = mlist('items'), it = I[i]; if(!it || !it.sr) return '';
  const d = it.d; I.splice(i, 1); mlist('sou').push({r:it.r, v:0, ro:'avec', d, dfix:true});
  S.p.nSr = Math.max(0, (S.p.nSr||0) - 1); S.p.nSou = Math.min(3, (S.p.nSou||0) + 1);
  if(!S.menu.achete){ S.menu.items = fill(nOf('items'), I, 'items', new Set([it.r])); const nw = S.menu.items.find(x => !x.d); if(nw && d) nw.d = d; }
  assignDays(false); assignExtras(false);
  const nw = mlist('items').find(x => x.d===d);
  return `${it.r} : soupe à côté du souper${nw ? ` (${nw.r})` : ''}.`;
}
function ajuster(){
  const m = S.menu; if(!m.date) return;
  { const I = mlist('items'), want = Math.min(S.p.nSr||0, nOf('items')), have = I.filter(x => x.sr);
    if(have.length > want) have.filter(x => !x.lock).slice(0, have.length - want).forEach(x => I.splice(I.indexOf(x), 1));
    else if(have.length < want && I.length >= nOf('items')) I.filter(x => !x.sr && !x.lock && !x.dfix).slice(-(want - have.length)).forEach(x => I.splice(I.indexOf(x), 1)); }
  { const I = mlist('items'), want = Math.min(S.p.nCm||0, Math.max(0, nOf('items') - Math.min(S.p.nSr||0, nOf('items')))), have = I.filter(x => x.cm);
    if(have.length > want) have.filter(x => !x.lock).slice(0, have.length - want).forEach(x => I.splice(I.indexOf(x), 1));
    else if(have.length < want && I.length >= nOf('items')) I.filter(x => !x.sr && !x.cm && !x.lock && !x.dfix).slice(-(want - have.length)).forEach(x => I.splice(I.indexOf(x), 1)); }
  ['items','dej','ent','sou','des'].forEach(l => {
    const n = nOf(l), cur = mlist(l);
    if(cur.length > n){ const locked = cur.filter(x => x.lock), rest = cur.filter(x => !x.lock).slice(0, Math.max(0, n-locked.length)); m[l] = cur.filter(x => x.lock || rest.includes(x)); }
    else if(cur.length < n) m[l] = fill(n, cur, l);
  });
  assignDays(false); assignDej(false); syncDin(false); assignExtras(false);
}


/* ---------- code de la famille : les spéciaux et les prix du robot sont chiffrés ----------
   Le robot (GitHub) lit les circulaires une fois par semaine et chiffre le résultat avec le code de la famille
   (secret MENU_CLE). Le téléphone le déchiffre avec le même code : AES-GCM, clé tirée du code par PBKDF2-SHA256.
   Le code n'est écrit nulle part dans le code de l'application; il reste sur ce téléphone, hors des sauvegardes. */
const CODE_KEY = PFX + 'code', SP_ENC = 'speciaux.enc.json', PE_ENC = 'prix-epiceries.enc.json';
const familleCode = () => { try{ return localStorage.getItem(CODE_KEY) || ''; }catch(e){ return ''; } };
const b64u8 = t => Uint8Array.from(atob(t), c => c.charCodeAt(0));
/* le code tel qu'on le dit : sans majuscules, sans accents, espaces simples (comme robot/chiffre.mjs) */
const codeNorm = c => String(c || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
const _CLES = new Map();
async function cleDe(code, salt, it){
  const k = salt + '|' + it + '|' + code; if(_CLES.has(k)) return _CLES.get(k);
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(codeNorm(code)), 'PBKDF2', false, ['deriveKey']);
  const cle = await crypto.subtle.deriveKey({name:'PBKDF2', salt:b64u8(salt), iterations:it, hash:'SHA-256'}, base, {name:'AES-GCM', length:256}, false, ['decrypt']);
  _CLES.set(k, cle); return cle;
}
async function dechiffrer(env, code){
  if(!env || env.v !== 1 || !env.ct || !env.salt || !env.iv || !(env.it > 0)) throw Object.assign(new Error('fichier illisible'), {code:'format'});
  if(!(self.crypto && crypto.subtle)) throw Object.assign(new Error('navigateur trop ancien'), {code:'vieux'});
  let data;
  try{ data = new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM', iv:b64u8(env.iv)}, await cleDe(code, env.salt, env.it), b64u8(env.ct))); }
  catch(e){ throw Object.assign(new Error('code incorrect'), {code:'cle'}); }
  if(env.z === 'gzip') data = await gunzip(data);
  return JSON.parse(new TextDecoder().decode(data));
}
/* un fichier du robot : null s'il n'existe pas (robot pas encore lancé) */
async function lireChiffre(url, code){
  const ctl = new AbortController(), tm = setTimeout(() => ctl.abort(), 15000);
  let r; try{ r = await fetch(url, {cache:'no-store', signal:ctl.signal}); } finally { clearTimeout(tm); }
  if(r.status === 404) return null; if(!r.ok) throw new Error('HTTP ' + r.status);
  return dechiffrer(await r.json(), code);
}
async function gunzip(u8){
  if(typeof DecompressionStream === 'function'){ try{ return new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer()); }catch(e){} }
  return inflateGzip(u8);
}
/* gzip pour les vieux téléphones (iOS 15 et moins n'ont pas DecompressionStream) : inflate minimal, d'après tinf */
function inflateGzip(d){
  if(d[0] !== 31 || d[1] !== 139 || d[2] !== 8) throw new Error('gzip');
  const fl = d[3]; let p = 10;
  if(fl & 4) p += 2 + (d[10] | d[11] << 8);
  if(fl & 8) while(d[p++]);
  if(fl & 16) while(d[p++]);
  if(fl & 2) p += 2;
  return inflateRaw(d.subarray(p));
}
function inflateRaw(src){
  let out = new Uint8Array(Math.max(1024, src.length * 6)), op = 0, bp = 0, bb = 0, bn = 0;
  const need = n => { if(op + n > out.length){ const o = new Uint8Array(Math.max(out.length * 2, op + n)); o.set(out); out = o; } };
  const bits = n => { while(bn < n){ if(bp >= src.length) throw new Error('inflate : fin'); bb |= src[bp++] << bn; bn += 8; } const v = bb & ((1 << n) - 1); bb >>>= n; bn -= n; return v; };
  const table = (L, n) => { const c = new Uint16Array(16), sy = new Uint16Array(n), off = new Uint16Array(16);
    for(let i = 0; i < n; i++) c[L[i]]++; c[0] = 0;
    for(let i = 0, t = 0; i < 16; i++){ off[i] = t; t += c[i]; }
    for(let i = 0; i < n; i++) if(L[i]) sy[off[L[i]]++] = i;
    return {c, sy}; };
  const sym = t => { let sum = 0, cur = 0, len = 0;
    do{ cur = 2 * cur + bits(1); if(++len > 15) throw new Error('inflate : code'); sum += t.c[len]; cur -= t.c[len]; } while(cur >= 0);
    return t.sy[sum + cur]; };
  const LB = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258], LE = [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
  const DB = [1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577], DE = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
  let fixe = null;
  for(let fin = 0; !fin;){
    fin = bits(1); const type = bits(2);
    if(type === 0){ bb = 0; bn = 0; const n = src[bp] | src[bp+1] << 8; bp += 4; if(bp + n > src.length) throw new Error('inflate : bloc'); need(n); out.set(src.subarray(bp, bp + n), op); op += n; bp += n; continue; }
    let lt, dt;
    if(type === 1){
      if(!fixe){ const L = new Uint8Array(288); L.fill(8, 0, 144); L.fill(9, 144, 256); L.fill(7, 256, 280); L.fill(8, 280, 288); fixe = [table(L, 288), table(new Uint8Array(30).fill(5), 30)]; }
      [lt, dt] = fixe;
    } else if(type === 2){
      const hl = bits(5) + 257, hd = bits(5) + 1, hc = bits(4) + 4, O = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15], cl = new Uint8Array(19);
      for(let i = 0; i < hc; i++) cl[O[i]] = bits(3);
      const ct = table(cl, 19), L = new Uint8Array(hl + hd);
      for(let i = 0; i < hl + hd;){
        const v = sym(ct);
        if(v < 16) L[i++] = v;
        else { let r, x = 0; if(v === 16){ if(!i) throw new Error('inflate : répétition'); x = L[i-1]; r = 3 + bits(2); } else if(v === 17) r = 3 + bits(3); else r = 11 + bits(7);
          if(i + r > hl + hd) throw new Error('inflate : longueurs'); L.fill(x, i, i + r); i += r; }
      }
      lt = table(L.subarray(0, hl), hl); dt = table(L.subarray(hl), hd);
    } else throw new Error('inflate : bloc inconnu');
    for(;;){
      const v = sym(lt);
      if(v < 256){ need(1); out[op++] = v; continue; }
      if(v === 256) break;
      const li = v - 257; if(li >= 29) throw new Error('inflate : longueur');
      const len = LB[li] + bits(LE[li]), di = sym(dt); if(di >= 30) throw new Error('inflate : distance');
      const dist = DB[di] + bits(DE[di]); if(dist > op) throw new Error('inflate : distance');
      need(len); for(let k = 0; k < len; k++, op++) out[op] = out[op - dist];
    }
  }
  return out.subarray(0, op);
}
/* spéciaux du robot (gardés 10 min en mémoire) et la zone la plus proche du code postal */
let _SPR = null;
async function robotSpeciaux(code){
  if(_SPR && _SPR.code === code && Date.now() - _SPR.t < 6e5) return _SPR.d;
  const d = await lireChiffre(SP_ENC, code); _SPR = {d, code, t: Date.now()}; return d;
}
const zoneDe = (d, cp) => { const Z = d && Array.isArray(d.zones) ? d.zones.filter(z => z && Array.isArray(z.flyers) && isObj(z.items)) : []; if(!Z.length) return null;
  const c = String(cp||'').replace(/\s/g,'').toUpperCase();
  return Z.find(z => z.cp === c) || (c ? Z.find(z => z.cp && z.cp.slice(0,3) === c.slice(0,3)) : null) || Z.find(z => z.cp && c && z.cp[0] === c[0]) || Z[0]; };
/* prix régulier d'un article de circulaire : indiqué (« rég. 5,99 $ », « économisez 2 $ »), sinon déduit du rabais en % */
function regOf(it, pr){
  const num = v => { const m = String(v ?? '').replace(',', '.').match(/\d+(?:\.\d+)?/); return m ? parseFloat(m[0]) : NaN; };
  if(!(pr > 0)) return 0;
  let r = num(it.original_price);
  const txt = norm([it.sale_story, it.pre_price_text, it.post_price_text, it.price_text].filter(Boolean).join(' '));
  if(!(r > pr)){ const m = txt.match(/\b(?:prix\s+)?reg(?:ulier)?\b\.?\s*:?\s*(\d+(?:[.,]\d{1,2})?)\s*\$/); if(m) r = num(m[1]); }
  if(!(r > pr)){ const m = txt.match(/\b(?:economisez|epargnez|save)\s+(\d+(?:[.,]\d{1,2})?)\s*\$/); if(m) r = pr + num(m[1]); }
  if(!(r > pr)){ const d = +it.discount; if(d > 0 && d < 95) r = pr / (1 - d/100); }
  return r > pr * 1.01 && r < pr * 4 ? Math.round(r * 100) / 100 : 0;
}

/* ---------- dépôt privé de la famille (banque commune) et lecture des reels et des photos du frigo ----------
   La clé du dépôt privé est dans boite.enc.json, chiffrée avec le code de la famille. Elle n'ouvre que ce dépôt.
   Les reels et les photos sont lus par Gemini avec la clé de chaque personne (plus bas). */
const BOITE_ENC = 'boite.enc.json', FAM_FILE = 'recettes-famille.json', FAM_KEY = PFX + 'famrec', JOBS_KEY = PFX + 'robot';
let _BOITE = null;
const errC = (msg, code) => Object.assign(new Error(msg), {code});
async function boite(){
  const code = familleCode(); if(!code) throw errC('Entre d\'abord le code de la famille (Profil → Compte).', 'nocode');
  if(_BOITE && _BOITE.code === code) return _BOITE;
  let d; try{ d = await lireChiffre(BOITE_ENC, code); }catch(e){ throw e.code === 'cle' ? errC('Le code de la famille a changé : entre le nouveau dans Profil → Compte.', 'cle') : e; }
  if(!d || !d.token || !d.depot) throw errC('Le robot de la famille n\'est pas encore installé.', 'absente');
  return (_BOITE = {token:d.token, depot:d.depot, code});
}
async function gh(chemin, opt){
  const b = await boite(); opt = opt || {};
  const r = await fetch('https://api.github.com/repos/' + b.depot + chemin, Object.assign({cache:'no-store'}, opt, {headers: Object.assign({Authorization:'Bearer ' + b.token, Accept:'application/vnd.github+json', 'X-GitHub-Api-Version':'2022-11-28'}, opt.headers || {})}));
  if(r.status === 401) _BOITE = null;
  return r;
}
const b64utf8 = t => { const u = new TextEncoder().encode(t); let bin = ''; for(let i = 0; i < u.length; i += 0x8000) bin += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(bin); };
/* un fichier JSON du dépôt privé : {data, sha}, ou null s'il n'existe pas */
async function ghLire(chemin){
  const r = await gh('/contents/' + chemin); if(r.status === 404) return null; if(!r.ok) throw errC('HTTP ' + r.status, 'http');
  const m = await r.json(); let txt = m.content ? new TextDecoder().decode(b64u8(m.content.replace(/\s/g, ''))) : '';
  if(!txt && m.size > 0){ const r2 = await gh('/contents/' + chemin, {headers:{Accept:'application/vnd.github.raw+json'}}); txt = await r2.text(); }
  return {data: JSON.parse(txt || 'null'), sha: m.sha};
}
async function ghEcrire(chemin, obj, msg, sha){
  const body = {message: msg, content: b64utf8(JSON.stringify(obj))}; if(sha) body.sha = sha;
  const r = await gh('/contents/' + chemin, {method:'PUT', body: JSON.stringify(body), headers:{'Content-Type':'application/json'}});
  if(!r.ok) throw Object.assign(errC('HTTP ' + r.status, 'http'), {status: r.status});
  return r.json();
}
/* image réduite (JPEG) : assez nette pour lire une description, assez légère pour le robot */
async function imageReduite(file, max, q){
  const url = URL.createObjectURL(file);
  try{
    const img = await new Promise((ok, ko) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => ko(errC('Une des images est illisible.', 'img')); i.src = url; });
    const f = Math.min(1, max / Math.max(img.naturalWidth || 1, img.naturalHeight || 1)), c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(img.naturalWidth * f)); c.height = Math.max(1, Math.round(img.naturalHeight * f));
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', q);
  } finally { URL.revokeObjectURL(url); }
}
let robotJobs = (() => { try{ return JSON.parse(localStorage.getItem(JOBS_KEY) || '{}') || {}; }catch(e){ return {}; } })();
const jobsSave = () => { try{ localStorage.setItem(JOBS_KEY, JSON.stringify(robotJobs)); }catch(e){} };
/* lit les images avec la clé Gemini de la personne; une seule lecture à la fois par sorte (recette, inventaire) */
async function robotEnvoyer(type, files, extra){
  const L = [...(files || [])].filter(f => /^image\//.test(f.type || 'image/'));
  if(!L.length) throw errC(type === 'recette' ? 'Choisis au moins une capture d\'écran.' : 'Choisis au moins une photo.', 'vide');
  const nmax = type === 'recette' ? 4 : 6;
  let images = [];
  for(const [max, q] of [[1600, .72], [1280, .62], [1024, .55]]){
    images = []; for(const f of L.slice(0, nmax)) images.push(await imageReduite(f, type === 'recette' ? max : Math.min(max, 1280), q));
    if(images.reduce((t, x) => t + x.length, 0) < 3.2e6) break;
  }
  const cle = geminiCle(); if(!cle) throw errC('Ajoute d\'abord ta clé Gemini gratuite (Profil → Compte).', 'nocle');
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  const j = {id, t:Date.now(), etat:'attente', direct:true, extra: extra || {}}; robotJobs[type] = j; jobsSave(); render();
  try{
    const rep = await gemLire(type, images, extra, cle);
    if(robotJobs[type] === j){ j.etat = rep.ok ? 'pret' : 'erreur'; j.rep = rep; jobsSave(); }
  }catch(e){
    if(robotJobs[type] !== j) return id;
    j.etat = 'erreur'; j.rep = {erreur: e.status === 0 ? 'Pas de connexion Internet. Réessaie quand le téléphone est en ligne.'
      : e.cle ? 'Google refuse ta clé Gemini : vérifie-la dans Profil → Compte.'
      : e.status === 429 ? 'Ta limite gratuite de Gemini est atteinte pour l\'instant. Réessaie plus tard, ou demain.'
      : 'Gemini n\'a pas pu lire les images (' + String(e.message || '').slice(0, 80) + '). Réessaie dans quelques minutes.'};
    jobsSave();
  }
  return id;
}
/* attend la réponse du robot (environ 1 minute), en redessinant le compteur */
const robotWait = {};
async function robotAttendre(type, tick){
  const j = robotJobs[type]; if(!j || j.etat !== 'attente' || j.direct || robotWait[type]) return null;
  robotWait[type] = true;
  try{
    while(robotJobs[type] === j && Date.now() - j.t < 8 * 60e3){
      let r = null; try{ r = await ghLire('reponses/' + j.id + '.json'); }catch(e){}
      if(r && r.data){ j.etat = r.data.ok ? 'pret' : 'erreur'; j.rep = r.data; jobsSave(); return r.data; }
      if(tick) tick(Math.round((Date.now() - j.t) / 1000));
      await new Promise(ok => setTimeout(ok, 6000));
    }
    if(robotJobs[type] === j && j.etat === 'attente'){ j.etat = 'long'; jobsSave(); }
    return null;
  } finally { robotWait[type] = false; }
}
const mmss = n => Math.floor(n / 60) + ':' + String(n % 60).padStart(2, '0');
function robotStatut(type, el){
  const j = robotJobs[type]; if(!j) return '';
  if(j.etat === 'attente' && j.direct) return `<p class="note" id="${el}_st">Ton Gemini lit tes images… (quelques secondes)</p>`;
  if(j.etat === 'attente') return `<p class="note" id="${el}_st">Lecture en cours… (environ 1 minute)</p>`;
  if(j.etat === 'long') return `<p class="note">Le robot n'a pas encore répondu. <button class="btn s" data-a="rb_check" data-t="${type}">Vérifier</button> <button class="btn s" data-a="rb_drop" data-t="${type}">Abandonner</button></p>`;
  if(j.etat === 'erreur') return `<p class="note">${esc((j.rep && j.rep.erreur) || 'Les images n\'ont pas pu être lues.')} <button class="btn s" data-a="rb_drop" data-t="${type}">Recommencer</button></p>`;
  return '';
}
/* une réponse arrivée : la recette va dans « Nouvelle recette » pour être vérifiée; l'inventaire, dans Maison */
function robotFini(type){
  const j = robotJobs[type]; if(!j || j.etat !== 'pret') return false;
  const rep = j.rep || {};
  if(type === 'recette'){
    const w = parseWebRecipe(rep.texte || '');
    if(!w){ j.etat = 'erreur'; j.rep = {erreur:'La recette du robot est illisible. Réessaie avec d\'autres captures.'}; jobsSave(); return false; }
    webToDraft(w); const d = drafts.new, lien = (j.extra && j.extra.lien) || '';
    if(rep.genre && KINDS[rep.genre]) d.k = rep.genre;
    if(rep.proteine && PRS[rep.proteine]) d.pr = rep.proteine;
    if(Array.isArray(rep.style)) d.st = rep.style.filter(x => STYS[x]).slice(0, 3);
    if(rep.titre && rep.titre.length < 90) d.n = rep.titre;
    d.s = (d.s ? d.s + ' ' : '') + `Inspiré d'un reel${rep.createur ? ' de ' + rep.createur : ''}${lien ? ' (' + lien + ')' : ''}.`;
    d.src = lien; d.partage = !!familleCode();
    d.note = `Recette écrite par le robot à partir du reel : ${w.rows.length} ingrédient${w.rows.length>1?'s':''}${w.portions && w.k==='souper' ? `, ajustés de ${w.portions} à 6 portions` : ''}${w.unsure.length ? `. Quantité à vérifier : ${w.unsure.join(', ')}` : ''}${rep.remarque ? '. ' + rep.remarque : ''}. Vérifie les quantités et les étapes, puis touche « Enregistrer la recette » en bas.`;
    plusK = 'nouvelle'; plusFromMenu = false;
  } else {
    invRes = (rep.articles || []).map(a => { const raw = cleanName(a.nom) || a.nom, hit = matchCatalog(raw), c = hit && hit.full ? hit.c : catFind(raw);
      const name = c ? c.n : raw; let [q, u] = toBase(+a.quantite || 1, a.unite === 'L' ? 'L' : a.unite || 'un'); [q, u] = normQU(name, q, u);
      return {name, q:Math.round(q * 10) / 10, u, rayon: c ? c.ray : guessRayon(name), on: a.certitude !== 'basse', lieu: a.lieu || ''}; });
    openPan.add('inv'); if(tab!=='maison'){ plusK = 'frigo'; plusFromMenu = false; }
  }
  delete robotJobs[type]; jobsSave(); return true;
}
async function robotSuivre(type, elId){
  const j0 = robotJobs[type];
  const rep = j0 && j0.etat === 'pret' ? j0.rep : await robotAttendre(type, sec => { const el = $('#' + elId + '_st'); if(el) el.textContent = `Lecture en cours… ${mmss(sec)} (environ 1 minute)`; });
  if(rep && rep.ok && robotFini(type)){ render(); const box = document.querySelector(type === 'recette' ? 'details[data-rec="__new"]' : '#inv_card'); if(box) box.scrollIntoView({block:'start'}); }
  else render();
}
/* ---------- Gemini personnel : la clé de la personne, gardée sur ce téléphone seulement ----------
   Le téléphone parle directement à Gemini (Google accepte les appels venant du site) : chacun utilise sa propre
   limite gratuite, et aucune clé n'est partagée.
   Les consignes et le nettoyage sont les mêmes que ceux du robot (robot/demandes.mjs du dépôt privé). */
const GEM_KEY = PFX + 'gemini', GEM_API = 'https://generativelanguage.googleapis.com/v1beta';
const GEM_DEF = ['gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-3.5-flash-lite', 'gemini-flash-latest', 'gemini-flash-lite-latest'];
const geminiCle = () => { try{ return localStorage.getItem(GEM_KEY) || ''; }catch(e){ return ''; } };
const RB_KINDS = ['souper', 'dejeuner', 'entree', 'soupe', 'dessert', 'sauce'], RB_PRS = ['poulet', 'boeuf', 'porc', 'poisson', 'vege', 'mixte'];
const RB_PROMPTS = {
  recette: `Tu es le robot de cuisine d'une famille québécoise. Tu reçois des captures d'écran d'une vidéo de recette (Instagram, TikTok, Facebook) : la description, les ingrédients ou les étapes montrés à l'écran.
Écris la recette pour l'application de la famille. Réponds seulement avec un objet JSON :
{"ok": true, "titre": "…", "createur": "@compte s'il est visible, sinon \"\"", "genre": "${RB_KINDS.join('|')}", "proteine": "${RB_PRS.join('|')}", "style": ["…"], "portions": 4, "preparation_min": 15, "cuisson_min": 30, "texte": "…", "remarque": "ce qui manquait ou a été estimé, sinon \"\""}
Si aucune recette n'est lisible : {"ok": false, "raison": "…"}.
Le champ "style" contient 0 à 3 valeurs parmi : ${Object.keys(STYS).join(', ')}.
Le champ "texte" est la recette complète, en français, exactement dans ce format :
<Titre>
Portions : <nombre>
Préparation : <nombre> min
Cuisson : <nombre> min

Ingrédients
<quantité> <unité> <aliment>
…

Préparation
1. <étape>
2. <étape>
Règles :
- Une ligne par ingrédient, qui commence par la quantité. Mesures canadiennes : tasse, c. à soupe, c. à thé, g, kg, ml, L, lb, oz, ou un nombre d'unités (« 3 gousses d'ail », « 2 oignons »). Exemple : « 1 lb de boeuf haché », « 2 tasses de farine ».
- N'invente pas d'ingrédient absent des images. Si une quantité n'est pas lisible, estime une quantité raisonnable et ajoute « environ » après l'aliment.
- Le sel, le poivre et l'eau peuvent être omis de la liste.
- Étapes réécrites dans tes mots, en phrases complètes, avec les températures en °F et les temps de cuisson.
- Pas d'emoji, pas de mot-clic, pas de publicité.`,
  inventaire: `Tu reçois des photos du frigo, du congélateur ou du garde-manger d'une famille québécoise. Fais l'inventaire des aliments que tu reconnais.
Réponds seulement avec un objet JSON :
{"ok": true, "articles": [{"nom": "lait 2 %", "quantite": 2, "unite": "L", "lieu": "frigo|congelateur|garde-manger", "certitude": "haute|moyenne|basse"}], "remarque": "…"}
Si aucun aliment n'est visible : {"ok": false, "raison": "…"}.
Règles :
- Noms simples et courants en français, au singulier si possible (« poitrines de poulet », « fromage cheddar », « ketchup »), sans la marque sauf si elle définit le produit.
- Quantité estimée de ce qui reste. Unités : g, kg, ml, L ou un (unités). Contenants entiers : compte-les (« 3 un yogourts »). Viande et fromage : poids estimé.
- Un même aliment vu plusieurs fois : une seule ligne avec le total.
- Ignore ce qui n'est pas de la nourriture. Au plus 60 articles.`
};
/* JSON de la réponse, même entouré de ``` ou de texte */
function rbJson(txt){
  const s = String(txt || '').replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '').trim();
  try{ return JSON.parse(s); }catch(e){}
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if(a >= 0 && b > a){ try{ return JSON.parse(s.slice(a, b + 1)); }catch(e){} }
  return null;
}
const rbTxt = (v, n) => typeof v === 'string' ? v.replace(/[\u0000-\u001f]+/g, ' ').trim().slice(0, n || 200) : '';
/* seulement des champs connus, du bon type (même nettoyage que le robot) */
function rbNettoyer(type, o){
  if(!o || typeof o !== 'object') return {ok:false, erreur:'Réponse illisible.'};
  if(o.ok === false) return {ok:false, erreur:rbTxt(o.raison, 300) || 'Rien de lisible dans les images.'};
  if(type === 'recette'){
    const texte = typeof o.texte === 'string' ? o.texte.replace(/\r/g, '').slice(0, 8000).trim() : '';
    if(!/\n/.test(texte) || !/ingr[ée]dients/i.test(texte)) return {ok:false, erreur:'Aucune liste d\'ingrédients trouvée dans les images.'};
    const n = v => Number.isFinite(+v) && +v >= 0 && +v < 1000 ? Math.round(+v) : 0;
    return {ok:true, titre:rbTxt(o.titre, 120), createur:rbTxt(o.createur, 60), genre:RB_KINDS.includes(o.genre) ? o.genre : '', proteine:RB_PRS.includes(o.proteine) ? o.proteine : '',
      style:(Array.isArray(o.style) ? o.style : []).filter(x => STYS[x]).slice(0, 3), portions:n(o.portions), preparation_min:n(o.preparation_min), cuisson_min:n(o.cuisson_min), texte, remarque:rbTxt(o.remarque, 300)};
  }
  const U = {g:'g', kg:'kg', ml:'ml', l:'L', un:'un', unite:'un', u:'un'};
  const articles = (Array.isArray(o.articles) ? o.articles : []).map(a => {
    const nom = rbTxt(a && a.nom, 80), q = +(a && a.quantite), u = U[norm(String(a && a.unite || 'un')).replace(/s$/, '')] || 'un';
    return nom && q > 0 && q < 100000 ? {nom, quantite:Math.round(q * 100) / 100, unite:u, lieu:rbTxt(a.lieu, 20), certitude:['haute', 'moyenne', 'basse'].includes(a.certitude) ? a.certitude : 'moyenne'} : null;
  }).filter(Boolean).slice(0, 80);
  if(!articles.length) return {ok:false, erreur:'Aucun aliment reconnu dans les photos.'};
  return {ok:true, articles, remarque:rbTxt(o.remarque, 300)};
}
/* appel à Gemini avec la clé dans l'en-tête (jamais dans l'adresse); erreur avec .status (0 : pas de réseau) */
async function gemFetch(chemin, cle, corps, delai){
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), delai || 90000);
  try{
    const r = await fetch(GEM_API + chemin, {method: corps ? 'POST' : 'GET', signal: ac.signal, cache:'no-store',
      headers: Object.assign({'x-goog-api-key': cle}, corps ? {'Content-Type':'application/json'} : {}), body: corps ? JSON.stringify(corps) : undefined});
    const txt = await r.text(); let j = null; try{ j = JSON.parse(txt); }catch(e){}
    if(!r.ok) throw Object.assign(new Error((j && j.error && (j.error.message || j.error.status)) || 'HTTP ' + r.status), {status:r.status});
    if(!j) throw Object.assign(new Error('Réponse inattendue de Gemini.'), {status:502});
    return j;
  } catch(e){
    if(e.name === 'AbortError') throw Object.assign(new Error('Gemini ne répond pas.'), {status:504});
    if(e.status === undefined) e.status = 0;
    throw e;
  } finally { clearTimeout(t); }
}
const gemRefus = e => e.status === 401 || e.status === 403 || /API key not valid|API_KEY_INVALID|API key expired|PERMISSION_DENIED/i.test(e.message || '');
/* les modèles Flash offerts à cette clé, du plus récent au plus léger (les noms changent souvent) */
function gemChoisir(noms){
  const c = noms.map(n => String(n).replace(/^models\//, '')).map(n => { const m = /^gemini-(\d+(?:\.\d+)?)-flash(-lite)?$/.exec(n); return m ? {n, v:+m[1], lite:!!m[2]} : null; }).filter(Boolean);
  const par = lite => c.filter(x => x.lite === lite).sort((a, b) => b.v - a.v).slice(0, 2).map(x => x.n);
  const alias = ['gemini-flash-latest', 'gemini-flash-lite-latest'].filter(a => noms.some(n => String(n).replace(/^models\//, '') === a));
  const L = [...par(false), ...par(true), ...alias];
  return L.length ? L : GEM_DEF;
}
let _GEMM = null;
async function gemModeles(cle){
  if(_GEMM && _GEMM.cle === cle && Date.now() - _GEMM.t < 6 * 3600e3) return _GEMM.L;
  const j = await gemFetch('/models?pageSize=1000', cle, null, 20000);
  const L = gemChoisir((j.models || []).filter(m => (m.supportedGenerationMethods || []).includes('generateContent')).map(m => m.name));
  _GEMM = {cle, L, t:Date.now()}; return L;
}
const gemNom = m => String(m || '').replace(/^gemini-/, 'Gemini ').replace(/-flash-lite/, ' Flash-Lite').replace(/-flash/, ' Flash').replace(/-latest/, '');
/* lit les images avec la clé personnelle : {ok, …, modele}; lance une erreur si Gemini refuse (e.cle : clé refusée) */
async function gemLire(type, images, extra, cle){
  extra = extra || {};
  const consigne = type === 'recette'
    ? 'Voici les captures d\'écran du reel.' + (extra.lien ? ` Lien : ${rbTxt(extra.lien, 300)}.` : '') + (extra.note ? ` Précision de la famille : ${rbTxt(extra.note, 300)}.` : '')
    : 'Voici les photos.' + (extra.note ? ` Précision de la famille : ${rbTxt(extra.note, 300)}.` : '');
  let modeles = GEM_DEF;
  try{ modeles = await gemModeles(cle); }catch(e){ if(gemRefus(e)) throw Object.assign(e, {cle:true}); if(e.status === 0) throw e; }
  const parts = images.map(u => { const m = /^data:([^;]+);base64,(.*)$/.exec(u); return {inline_data:{mime_type:m[1], data:m[2]}}; }).concat([{text:consigne}]);
  const corps = strict => ({systemInstruction:{parts:[{text:RB_PROMPTS[type]}]}, contents:[{role:'user', parts}],
    generationConfig:Object.assign({maxOutputTokens:8192}, strict ? {temperature:.2, responseMimeType:'application/json'} : {})});
  let der = null;
  for(const m of modeles){
    try{
      const ch = '/models/' + encodeURIComponent(m) + ':generateContent';
      let j; try{ j = await gemFetch(ch, cle, corps(true)); }catch(e){ if(e.status !== 400 || gemRefus(e)) throw e; j = await gemFetch(ch, cle, corps(false)); }
      const c = j.candidates && j.candidates[0], t = c && c.content ? (c.content.parts || []).filter(x => x && x.text && !x.thought).map(x => x.text).join('') : '';
      if(!t) throw Object.assign(new Error('Pas de réponse (' + ((c && c.finishReason) || (j.promptFeedback && j.promptFeedback.blockReason) || 'vide') + ')'), {status:502});
      return Object.assign(rbNettoyer(type, rbJson(t)), {modele:m});
    }catch(e){
      der = e;
      if(gemRefus(e)){ e.cle = true; throw e; }
      if(e.status === 0) throw e;
      if(![400, 404, 408, 409, 413, 429, 500, 502, 503, 504].includes(e.status)) break;
    }
  }
  throw der || Object.assign(new Error('Gemini n\'a pas répondu.'), {status:502});
}
/* Profil → Épiceries : la clé Gemini de la personne */
let gemMsg = '';
function geminiCard(){
  const c = geminiCle();
  return `<div class="card" id="gem_card"><h3>Ta clé Gemini</h3>
    <p class="small">Elle sert à lire les reels et les photos du frigo avec ton propre Gemini gratuit. La clé reste sur ce téléphone : elle n'est ni dans les sauvegardes ni partagée avec la famille.</p>
    ${c ? `<p class="note">Ce téléphone a ta clé Gemini.</p>
      <div class="acts"><button class="btn s" data-a="gm_test">Vérifier</button><button class="btn s d" data-a="gm_forget" data-armed="0">Oublier la clé</button></div>`
    : `<details class="panel"><summary>Obtenir ta clé (2 minutes, gratuit)</summary><ol class="small steps-l">
        <li>Ouvre <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">aistudio.google.com</a> et connecte-toi avec ton compte Google (18 ans et plus).</li>
        <li>Touche <b>Create API key</b> (ou « Créer une clé API »), puis copie la clé.</li>
        <li>Reviens ici, colle-la et touche <b>Valider</b>.</li></ol>
        <p class="small">Avec la version gratuite, Google peut se servir des images pour améliorer ses produits.</p></details>
      <div class="grid2" style="grid-template-columns:1fr auto;align-items:end"><label class="f">Clé<input type="password" id="gm_in" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Colle ta clé ici"></label><button class="btn s p" data-a="gm_save">Valider</button></div>`}
    <div class="small" id="gm_msg" ${gemMsg ? '' : 'hidden'}>${esc(gemMsg)}</div></div>`;
}
async function geminiSave(test){
  const inp = $('#gm_in'), cle = test ? geminiCle() : String(inp ? inp.value : '').replace(/\s+/g, ''), m = () => $('#gm_msg');
  if(!cle){ say(m(), 'Colle d\'abord ta clé Gemini.'); return; }
  say(m(), 'Vérification de la clé…');
  let L;
  try{ _GEMM = null; L = await gemModeles(cle); }
  catch(e){ say(m(), gemRefus(e) ? (test ? 'Google refuse cette clé maintenant. Oublie-la et colles-en une nouvelle.' : 'Google refuse cette clé. Vérifie que tu l\'as copiée au complet.') : e.status === 0 ? 'Pas de connexion pour vérifier la clé. Réessaie plus tard.' : 'Google ne répond pas pour l\'instant (' + e.message + '). Réessaie plus tard.'); return; }
  if(!test){ try{ localStorage.setItem(GEM_KEY, cle); }catch(e){ say(m(), 'Impossible de garder la clé sur ce téléphone.'); return; } }
  gemMsg = `Clé acceptée. Modèle utilisé : ${gemNom(L[0])}.`; render(); gemMsg = '';
}
/* banque commune : recettes ajoutées par la famille, gardées sur le téléphone et relues de temps en temps */
const famSan = o => { if(!isObj(o) || typeof o.n !== 'string' || !o.n.trim() || !Array.isArray(o.i)) return null;
  const i = o.i.filter(g => Array.isArray(g) && isFinite(+g[0]) && ['g','ml','un'].includes(g[1]) && typeof g[2]==='string').map(g => [+g[0], g[1], g[2].slice(0, 120), RAYONS.includes(g[3]) ? g[3] : guessRayon(g[2])]);
  if(!i.length) return null;
  const str = (v, n) => typeof v === 'string' ? v.slice(0, n) : '';
  return {n:o.n.trim().slice(0, 120), e:'', m:(Array.isArray(o.m) ? o.m : []).filter(x => typeof x==='string').slice(0, 12), k:KINDS[o.k] ? o.k : 'souper', pr:PRS[o.pr] ? o.pr : '', st:(Array.isArray(o.st) ? o.st : []).filter(x => STYS[x]),
    t:TYPES[o.t] ? o.t : 'viande', tm:isFinite(+o.tm) && +o.tm > 0 ? +o.tm : 30, tp:isFinite(+o.tp) && +o.tp > 0 ? +o.tp : undefined, mj:+o.mj ? 1 : 0, sf:str(o.sf, 40), sv:str(o.sv, 40),
    i, s:str(o.s, 6000), v:[], src:str(o.src, 300), ajout:str(o.ajout, 10), oc:+o.oc ? 1 : 0, fam:true, nw: !!o.ajout && gapDays(o.ajout, isoToday()) <= 21}; };
function famLoad(){ try{ const o = JSON.parse(localStorage.getItem(FAM_KEY) || 'null'); FAMREC = o && Array.isArray(o.recettes) ? o.recettes.map(famSan).filter(Boolean) : []; }catch(e){ FAMREC = []; } }
function famSet(L, t){ FAMREC = L.map(famSan).filter(Boolean); try{ localStorage.setItem(FAM_KEY, JSON.stringify({recettes:L, t:t || Date.now()})); }catch(e){} _AR = null; resetCaches(); }
async function famFetch(force){
  if(!familleCode()) return false;
  let t = 0; try{ t = (JSON.parse(localStorage.getItem(FAM_KEY) || 'null') || {}).t || 0; }catch(e){}
  if(!force && Date.now() - t < 6 * 3600e3) return false;
  const r = await ghLire(FAM_FILE); const L = r && r.data && Array.isArray(r.data.recettes) ? r.data.recettes : [];
  const avant = JSON.stringify((FAMREC || []).map(x => x.n)); famSet(L); return avant !== JSON.stringify(FAMREC.map(x => x.n));
}
/* ajoute (ou remplace) une recette dans la banque commune; réessaie si quelqu'un d'autre écrit en même temps */
async function famModifier(fn, msg){
  for(let essai = 0; essai < 3; essai++){
    const r = await ghLire(FAM_FILE), L = r && r.data && Array.isArray(r.data.recettes) ? r.data.recettes : [];
    const N = fn(L.slice());
    try{ await ghEcrire(FAM_FILE, {v:1, recettes:N}, msg, r && r.sha); famSet(N); return true; }
    catch(e){ if(e.status !== 409 && e.status !== 422) throw e; }
  }
  throw errC('La banque commune est occupée : réessaie dans un moment.', 'conflit');
}
const famObj = r => ({n:r.n, m:r.m || [], k:kindOf(r), pr:r.pr || '', st:r.st || [], t:r.t || 'viande', tm:tmOf(r), tp:tpOf(r), mj:mjOf(r) ? 1 : 0, sf:r.sf || '', sv:r.sv || '', i:r.i, s:r.s || '', src:r.src || '', oc:r.oc ? 1 : 0, ajout:isoToday()});
const famPublier = r => famModifier(L => L.filter(x => norm(x.n) !== norm(r.n)).concat([famObj(r)]), 'Recette ajoutée : ' + r.n);
const famRetirer = n => famModifier(L => L.filter(x => norm(x.n) !== norm(n)), 'Recette retirée : ' + n);
const famHas = n => (FAMREC || []).some(x => norm(x.n) === norm(n));
let recFlash = '', invRes = null;

/* ---------- recherche des spéciaux (Flipp) ---------- */
const FLIPP = 'https://backflipp.wishabi.com/flipp';
/* Épiceries du Québec, regroupées. Le nom affiché est reconnu dans le nom du marchand des circulaires. */
const STORE_GROUPS = [
  ['Supermarchés', [['IGA',/\biga\b/],['Metro',/\bmetro\b/],['Provigo',/provigo/],['Inter-Marché',/inter-?\s?march/],['Marché Ami',/marche ami\b/],['Marché Richelieu',/richelieu/],['Marchés Tradition',/tradition/],['Bonichoix',/bonichoix/],['Axep',/axep/]]],
  ['À escompte', [['Maxi',/\bmaxi\b/],['Super C',/super ?c\b/],['Tigre Géant',/tigre geant|giant tiger/]]],
  ['Grandes surfaces et entrepôts', [['Walmart',/walmart/],['Costco',/costco/],['Mayrand',/mayrand/]]],
  ['Santé, vrac et spécialités', [['Adonis',/adonis/],['Avril',/\bavril\b/],['Rachelle-Béry',/rachelle.?bery/],['Bulk Barn',/bulk barn/]]],
  ['Pharmacies (quelques aliments en spécial)', [['Jean Coutu',/jean coutu/],['Familiprix',/familiprix/],['Pharmaprix',/pharmaprix|shoppers/],['Uniprix',/uniprix/],['Brunet',/\bbrunet\b/]]]
];
const MARCHANDS = STORE_GROUPS.flatMap(g => g[1].map(([n,re]) => [re,n]));
const STORES = MARCHANDS.map(x => x[1]);
const allStores = () => STORES.concat((S.storesx||[]).filter(s => !STORES.includes(s)));
const marchand = n => { const t = norm(n||'').trim(); if(!t) return ''; const m = MARCHANDS.find(x => x[0].test(t)); if(m) return m[1];
  return (S.storesx||[]).find(s => { const c = norm(s).trim(); return c.length>2 && (t.includes(c) || c.includes(t)); }) || ''; };
const GROCERY_CAT = f => { const c = norm([].concat(f.categories||[]).join(' ')+' '+(f.categories_csv||'')); return !c.trim() || (/grocer|epicer|aliment|food|pharm/.test(c) && !/restaurant/.test(c)); };
let stFound = null;
async function trouverEpiceries(){
  const msg = $('#st_msg'), cp = (S.cp||'').replace(/\s/g,'').toUpperCase();
  if(!cp){ say(msg, "Entre d'abord ton code postal."); return; }
  if(!cpOk(cp)){ say(msg, 'Code postal invalide (exemple : G6V 6Z3).'); return; }
  say(msg, 'Recherche des épiceries près de chez toi…');
  try{
    let fl = null; const code = familleCode();
    if(code){ try{ const z = zoneDe(await robotSpeciaux(code), cp); if(z) fl = z.flyers; }catch(e){} }
    if(!fl) fl = flyersOf(await jget(`${FLIPP}/flyers?locale=fr-ca&postal_code=${encodeURIComponent(cp)}`));
    const names = new Map();
    fl.forEach(f => {
      const c = norm([].concat(f.categories||[]).join(' ')+' '+(f.categories_csv||''));
      if(!/grocer|epicer|aliment|food/.test(c) || /restaurant/.test(c)) return;
      const raw = String(f.merchant||'').trim(); if(!raw) return;
      const k = marchand(raw) || raw; if(!names.has(k)) names.set(k, !!marchand(raw));
    });
    stFound = [...names.entries()].map(([n,known]) => ({n, known})).sort((a,b) => a.n.localeCompare(b.n,'fr'));
    render();
    say($('#st_msg'), stFound.length ? `${stFound.length} épicerie${stFound.length>1?'s':''} trouvée${stFound.length>1?'s':''} avec une circulaire pour ${cp}. Coche celles où tu vas.` : `Aucune circulaire d'épicerie trouvée pour ${cp}. Vérifie le code postal.`);
  }catch(e){ say($('#st_msg') || msg, e.net ? "La recherche est bloquée par le navigateur ou tu es hors ligne. Coche tes épiceries dans la liste, ou ajoute celles qui manquent à la main." : 'La recherche a échoué ('+(e.message||'erreur')+'). Coche tes épiceries dans la liste.'); }
}
const storeChip = n => `<label class="chip"><input type="checkbox" data-store="${esc(n)}" ${S.stores.includes(n)?'checked':''}>${esc(n)}</label>`;
function storePicker(){
  const own = (S.storesx||[]).filter(s => !STORES.includes(s));
  return `<div class="acts"><button class="btn s" id="st_find">Trouver les épiceries de mon code postal</button></div><div class="note" id="st_msg" hidden></div>
    ${stFound && stFound.length ? `<p class="sgrp">Près de chez toi</p><div class="chips">${stFound.map(x => storeChip(x.n)).join('')}</div>` : ''}
    ${STORE_GROUPS.map(([g, L]) => `<p class="sgrp">${esc(g)}</p><div class="chips">${L.map(([n]) => storeChip(n)).join('')}</div>`).join('')}
    <p class="sgrp">Autres épiceries de ta région</p>
    ${own.length ? `<div class="chips">${own.map(storeChip).join('')}</div><p class="small">Retirer : ${own.map(s => `<a href="#" data-a="stx_rm" data-s="${esc(s)}">${esc(s)}</a>`).join(', ')}</p>` : ''}
    <div class="grid2" style="grid-template-columns:1fr auto;align-items:end"><label class="f">Une épicerie manque ?<input type="text" id="stx_n" placeholder="Nom de l'épicerie" autocomplete="off"></label><button class="btn s" id="stx_add">Ajouter</button></div>`;
}
/* requête vers les circulaires : délai maximal, erreurs réseau étiquetées, réponse vérifiée */
async function jget(u, ms){
  const relay = /^https:\/\//.test(S.relay||'') ? S.relay : '';
  const url = relay ? relay + encodeURIComponent(u) : u;
  const ac = new AbortController(), to = setTimeout(() => ac.abort(), ms || 15000);
  let r;
  try{ r = await fetch(url, {signal: ac.signal}); }
  catch(e){ throw Object.assign(new Error(e.name==='AbortError' ? 'délai dépassé' : 'réseau'), {net:true}); }
  finally{ clearTimeout(to); }
  if(!r.ok) throw Object.assign(new Error('HTTP '+r.status), {net:true});
  let d; try{ d = await r.json(); }catch(e){ throw new Error('réponse illisible'); }
  if(d && typeof d.contents==='string'){ try{ d = JSON.parse(d.contents); }catch(e){} }   /* relais de type allorigins */
  return d;
}
const flyersOf = fl => { const a = Array.isArray(fl) ? fl : fl && Array.isArray(fl.flyers) ? fl.flyers : null; if(!a) throw new Error('format des circulaires inattendu'); return a; };
const itemsOf = d => { const a = Array.isArray(d) ? d : d && Array.isArray(d.items) ? d.items : null; if(!a) throw new Error('format'); return a; };
/* jour local (Québec) d'une date de circulaire : « 2026-10-21T23:59:59-04:00 » → 2026-10-21 */
/* la date d'une circulaire est celle écrite dans le texte (heure du magasin), peu importe le fuseau du téléphone */
const dayOf = v => { if(!v) return ''; const s = String(v); if(/^\d{4}-\d\d-\d\d/.test(s)) return s.slice(0, 10); const d = new Date(s); return isNaN(d) ? s.slice(0,10) : d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); };
const covers = (f, day) => (!f.valid_from || dayOf(f.valid_from) <= day) && (!f.valid_to || dayOf(f.valid_to) >= day);
const cpOk = cp => /^[A-Z]\d[A-Z]\d[A-Z]\d$/.test(cp);
let spBusy = false;
function motsCles(){
  const set = new Set();
  allRecipes().forEach(r => r.m.forEach(m => { const n = norm(m); if(n.length>=4 && !GENERIC.includes(n)) set.add(n); }));
  ['lait','oeuf','pain','cereale','jus','croustille','gazeuse','yogourt','beurre','fromage','pates','pizza','bacon','banane','pomme','clementine','biscuit','cafe','jambon','creme','farine','riz','raisin','carotte','concombre','tomate','oignon','laitue','poulet','boeuf','porc','saucisse','frite','poisson','saumon','tortilla','sauce'].concat(SNACK_WORDS).forEach(x => set.add(norm(x)));
  return [...set];
}
async function chercherSpeciaux(ignorerDate){
  /* le bouton et le message sont relus à chaque étape : l'écran peut être redessiné pendant la recherche */
  const say = t => { const st = $('#sp_status'); if(st) st.textContent = t; };
  if(spBusy) return;
  const cp = (S.cp||'').replace(/\s/g,'').toUpperCase(), code = familleCode();
  if(!code){ say('Les spéciaux sont réservés à la famille et aux amis : entre le code de la famille dans Profil → Compte.'); return; }
  if(!S.stores.length){ say('Choisis d\'abord tes épiceries dans Profil.'); return; }
  spBusy = true; { const b = $('#sp_go'); if(b) b.disabled = true; }
  const shop = shopISO();
  try{
    say('Lecture des spéciaux de la semaine…');
    /* d'abord le fichier du robot; Flipp seulement s'il manque ou ne couvre pas le jour de l'épicerie */
    const mine = f => { const s = marchand(f.merchant); return s && S.stores.includes(s); };
    let src = null, all = [];
    try{ const z = zoneDe(await robotSpeciaux(code), cp); if(z){ src = {robot:true, items: async f => z.items[f.id] || []}; all = z.flyers.filter(mine); } }
    catch(e){ if(e.code === 'cle'){ say('Le code de la famille ne correspond plus aux spéciaux du robot : vérifie-le dans Profil → Compte.'); return; } }
    if(!src || !all.some(f => covers(f, shop))){
      if(cpOk(cp)){ try{ const fl = flyersOf(await jget(`${FLIPP}/flyers?locale=fr-ca&postal_code=${encodeURIComponent(cp)}`)).filter(mine);
          if(fl.length && (!src || fl.some(f => covers(f, shop)))){ src = {robot:false, items: async f => itemsOf(await jget(`${FLIPP}/flyers/${f.id}?locale=fr-ca&postal_code=${encodeURIComponent(cp)}`))}; all = fl; } }
        catch(e){ if(!src) throw e; } }
      else if(!src){ say(cp ? 'Code postal invalide dans Profil (exemple : G6V 6Z3).' : 'Entre d\'abord ton code postal dans Profil.'); return; }
    }
    if(!all.length){ say("Aucune circulaire de tes épiceries trouvée pour ce code postal."); return; }
    let flyers = all.filter(f => covers(f, shop));
    let note = '', anyDate = false;
    if(!flyers.length){
      if(!ignorerDate){
        const later = all.filter(f => dayOf(f.valid_from) > shop).map(f => dayOf(f.valid_from)).sort()[0];
        const fin = all.map(f => dayOf(f.valid_to)).sort().pop();
        say(later ? `Les circulaires qui couvrent le ${fmtDate(shop)} commencent le ${fmtDate(later)} : relance la recherche à ce moment. `
          : `Aucune circulaire ne couvre le ${fmtDate(shop)} pour l'instant (les circulaires actuelles finissent le ${fmtDate(fin)}). Les nouvelles sortent le jeudi : relance la recherche plus tard. `);
        const st = $('#sp_status');
        if(st){ const a = document.createElement('button'); a.className = 'btn s'; a.textContent = 'Utiliser les circulaires actuelles quand même'; a.onclick = () => chercherSpeciaux(true); st.appendChild(a); }
        return;
      }
      flyers = all.filter(f => covers(f, isoToday()));
      if(!flyers.length) flyers = all;
      note = ' (circulaires actuelles, possiblement expirées à la date de l\'épicerie)'; anyDate = true;
    }
    const isGro = f => /grocer|epicer/.test(norm(String(f.categories_csv||f.categories||'')));
    flyers = flyers.filter(GROCERY_CAT).sort((a,b) => (isGro(b)?1:0) - (isGro(a)?1:0));
    /* au moins une circulaire par épicerie choisie, puis les autres, jusqu'à 24 */
    { const seen = new Set(), first = flyers.filter(f => { const s = marchand(f.merchant); if(seen.has(s)) return false; seen.add(s); return true; });
      flyers = first.concat(flyers.filter(f => !first.includes(f))).slice(0, 24); }
    const mots = motsCles(); const items = []; let ok = 0, fail = 0;
    for(let k = 0; k < flyers.length; k++){
      const f = flyers[k]; if(!src.robot) say(`Lecture de la circulaire ${k+1} / ${flyers.length} : ${marchand(f.merchant)}…`);
      try{
        (await src.items(f)).forEach(it => {
          const nn = norm(it.name||''); if(!nn || !mots.some(w => nn.includes(w)) || !isFood(nn)) return;
          const pr = parseFloat(String(it.price ?? it.current_price ?? '').replace(',', '.'));
          /* produits vendus au poids (Maxi, Provigo… : code « _KG ») : le prix affiché est à la livre */
          const per = /_KG$/i.test(String(it.print_id || it.sku || '')) ? 'lb' : /\/\s*kg\b/i.test(String(it.price_text||'')) ? 'kg' : /\/\s*lb\b/i.test(String(it.price_text||'')) ? 'lb' : '';
          const d = +it.discount;
          const rg = regOf(it, pr);
          items.push({s:marchand(f.merchant), t:String(it.name).slice(0, 200), p:isFinite(pr)&&pr>0 ? pr.toFixed(2).replace('.',',')+' $' : '', per, vf:dayOf(it.valid_from||f.valid_from), vt:dayOf(it.valid_to||f.valid_to), d: d > 0 && d < 95 ? Math.round(d) : 0, o: rg ? rg.toFixed(2).replace('.',',')+' $' : ''});
        });
        ok++;
      }catch(e){ fail++; if(e.net && fail >= 3 && !ok){ throw e; } }
    }
    const uniq = new Map(); items.forEach(i => uniq.set(i.s+'|'+norm(i.t), i));
    const list = [...uniq.values()].sort((a,b) => (b.d||0)-(a.d||0)).slice(0,600);
    /* rien de lisible : on garde les spéciaux déjà trouvés plutôt que de les effacer */
    if(!ok || !list.length){ say((S.auto && S.auto.items.length ? 'Aucun spécial lisible cette fois-ci : les spéciaux trouvés avant sont gardés. ' : 'Les circulaires ont été trouvées, mais leur contenu est illisible. ') + 'Réessaie plus tard ou utilise le collage manuel ci-dessous.'); return; }
    S.auto = {items:list, maj:isoToday(), shop, anyDate, robot:src.robot, src:[...new Set(flyers.map(f => marchand(f.merchant)))].join(', ')};
    try{ noterPrix(); }catch(e){}
    spBusy = false; save(); render();
    say(`${list.length} spéciaux retenus dans ${ok} circulaire${ok>1?'s':''} (${S.auto.src}) pour le ${fmtDate(shop)}${note}.` + (fail ? ` ${fail} circulaire${fail>1?'s':''} illisible${fail>1?'s':''} : relance plus tard pour les avoir.` : '') + ((S.skip||[]).some(s => S.stores.includes(s)) ? ` Cette semaine : ${autoItems().length} chez ${goStores().join(', ') || 'aucune épicerie'}.` : ''));
  }catch(e){
    say(e.net
      ? "Le navigateur a bloqué la requête vers Flipp, la connexion est trop lente ou tu es hors ligne. Réessaie, ou ouvre « Si la recherche ne fonctionne pas » : colle le texte d'une circulaire, ou ajoute un relais."
      : 'La recherche a échoué ('+(e.message||'erreur')+'). Réessaie plus tard ou colle le texte de la circulaire.');
  }finally{
    spBusy = false; const b = $('#sp_go'); if(b) b.disabled = false;
  }
}

/* ---------- copier pour envoyer ---------- */
/* renvoie true seulement si le texte est vraiment dans le presse-papiers */
async function copier(text, msgId){
  try{ await navigator.clipboard.writeText(text); const msg = $(msgId); if(msg) msg.textContent = 'Copié. Colle-le dans un message.'; return true; }
  catch(e){
    const msg = $(msgId); if(!msg) return false;
    msg.innerHTML = 'Copie bloquée : sélectionne le texte ci-dessous.<textarea readonly id="exout" style="margin-top:6px;min-height:160px"></textarea>';
    const ta = $('#exout'); ta.value = text; ta.focus(); ta.select(); return false;
  }
}
function partagerHtml(){
  if(!S.menu.date) return `<div class="empty"><b>Rien à partager pour l'instant</b><span>Prépare d'abord le menu de la semaine.</span></div>`;
  const row = (c, t, d) => `<div class="item"><span class="t"><b>${t}</b><small>${d}</small></span><button class="btn s p" id="xp_${c}_copy">Copier</button></div>`;
  return `<div class="card"><p class="small">Rien n'est synchronisé entre les téléphones : copie, puis colle dans un message ou dans Notes.</p>
    <div class="list">${row('l', "Liste d'épicerie", 'Par rayon, avec les quantités')}${row('m', 'Menu de la semaine', 'Les plats et leurs accompagnements, jour par jour')}${row('d', 'Menu détaillé', 'Ingrédients et préparation de chaque plat')}</div>
    <div class="small" id="xp_msg"></div></div>
    <div class="card"><h3>Menu pour le frigo</h3><p class="small">Une image de la semaine à enregistrer dans Photos, imprimer ou envoyer.</p><div class="acts"><button class="btn s p" id="frigo">Créer l'image</button></div><div id="frigo_box"></div></div>`;
}

/* Menu de la semaine — Prix par épicerie et comparateur « Où faire l'épicerie cette semaine ».
   Les fichiers de js/ partagent les mêmes variables globales; ils sont chargés dans l'ordre de index.html.

   Le prix d'un article dans une épicerie vient, dans l'ordre :
   1. du prix que tu as payé ou inscrit chez elle (S.prices, avec le magasin) ;
   2. du relevé du robot (prix-epiceries.json : Maxi et IGA, chaque semaine) ;
   3. d'une estimation : le prix de référence Maxi × l'écart de cette épicerie (calculé sur le relevé, sinon une valeur de départ).
   Un spécial (circulaire Flipp ou promotion du relevé) valide le jour de l'épicerie le remplace s'il coûte moins. */
const PE_KEY = PFX + 'pe', PE_URL = 'prix-epiceries.json';
let PE = null, _PEX = null, _CAT_S = new Map(), _DCA = new Map(), _CMPR = null, _SPA = null;
/* chaînes relevées par le robot */
const CHAINES = {Maxi:'maxi', IGA:'iga'};
/* écart de départ avec Maxi, quand le relevé ne permet pas de le calculer (prix réguliers moyens) */
const ECART0 = {Maxi:1, 'Super C':1.01, Walmart:1.0, 'Tigre Géant':1.03, Costco:0.92, IGA:1.12, Metro:1.13, Provigo:1.1, 'Inter-Marché':1.1, 'Marché Ami':1.1, 'Marché Richelieu':1.12, 'Marchés Tradition':1.12, Bonichoix:1.14, Axep:1.14, Mayrand:0.97};
function peReset(){ _PEX = null; _CAT_S = new Map(); _DCA = new Map(); _CMPR = null; _SPA = null; }
function peLoad(){ try{ const o = JSON.parse(localStorage.getItem(PE_KEY) || 'null'); if(peOk(o)) PE = o; }catch(e){} }
const peOk = o => !!o && o.v === 1 && isObj(o.p) && Array.isArray(o.magasins);
/* va chercher le dernier relevé (une fois par jour, ou sur demande) */
let peBusy = false;
async function peFetch(force){
  if(peBusy || (!force && PE && (S.pe||{}).f === isoToday())) return false;
  peBusy = true;
  try{
    /* le relevé chiffré (code de la famille), sinon l'ancien fichier en clair tant que le robot n'a pas le code */
    let o = null; const code = familleCode();
    if(code){ try{ o = await lireChiffre(PE_ENC, code); }catch(e){ if(e.code !== 'cle') throw e; } }
    if(!o){
      const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null; const tm = ctl ? setTimeout(() => ctl.abort(), 10000) : 0;
      const r = await fetch(PE_URL, {cache:'no-store', signal: ctl ? ctl.signal : undefined}); clearTimeout(tm);
      if(!r.ok) throw new Error('HTTP ' + r.status);
      o = await r.json(); }
    if(!peOk(o)) throw new Error('relevé illisible');
    PE = o; try{ localStorage.setItem(PE_KEY, JSON.stringify(o)); }catch(e){}
    S.pe = Object.assign({}, S.pe, {f: isoToday()}); peSel(); resetCaches(); return true;
  } finally { peBusy = false; }
}
/* magasin choisi pour chaque chaîne (le premier du relevé par défaut) */
function peSel(){
  if(!isObj(S.pe)) S.pe = {};
  if(PE) Object.values(CHAINES).forEach(ch => { const L = PE.magasins.filter(m => m.ch === ch); if(L.length && !L.some(m => m.id === S.pe[ch])) S.pe[ch] = L[0].id; });
  return S.pe;
}
const peMag = store => { const ch = CHAINES[store]; if(!ch || !PE) return null; const id = peSel()[ch]; return PE.magasins.find(m => m.ch === ch && m.id === id) || null; };
const peData = store => { const m = peMag(store); return m ? PE.p[m.ch + ':' + m.id] || null : null; };
/* date du relevé le plus récent (AAAA-MM-JJ), '' sans relevé */
const peDate = () => PE ? PE.magasins.map(m => m.d || '').sort().pop() || '' : '';
const peFrais = () => { const d = peDate(); return !!d && gapDays(d, isoToday()) <= 30; };

/* ---------- coût d'une ligne avec un barème donné (formats ou prix au kilo) ---------- */
function costWith(r, o){
  const n = norm(r.name), q = r.def > 0 ? r.def : r.buy;
  if(o.kg){ const g = r.u==='g' ? q : r.u==='un' ? q * (gpuOf(n) || o.gpu || 0) : 0; return g ? g/1000*o.kg : null; }
  if(!o.f || !o.f.length) return null;
  if(r.u===o.u) return bestFormats(q, o.f).cost;
  if(r.u==='un' && o.u==='g' && gpuOf(n)) return bestFormats(q*gpuOf(n), o.f).cost;
  if(r.u==='un') return q * o.f[0][1];
  return null;
}
/* prix de référence (Maxi) sans tes prix : barème ou estimation */
function estBase(r){
  if(r.plan) return r.plan.cost; const bc = baremeCost(r); if(bc != null) return bc;
  let q = r.buy; const n = norm(r.name), A = art(r.name);
  if(r.u==='un' && !PKG_RE.test(n)){ const d = A.pk && A.pk.u==='un' && A.pk.q > 0 ? [0, A.pk.q] : PACK_UN.find(([re]) => re.test(n)); if(d) q = Math.max(1, Math.ceil(r.buy/d[1] - 0.05)) * d[1]; }
  return prixBase(r.name, r.u, r.rayon) * q;
}
/* prix unitaire régulier d'une entrée du relevé (par g, ml, unité ou kg) */
const peUnit = e => !e ? null : e.kg ? e.kg[0] : (() => { const L = e.f.filter(x => x[1] != null).map(x => x[1]/x[0]); return L.length ? Math.min(...L) : null; })();
/* une promotion du relevé est-elle valide le jour de l'épicerie ? */
function peValide(c, deb, fin){
  if(!(c > 0)) return false; const d = shopISO();
  if(deb && deb > d) return false;
  return fin ? fin >= d : !!deb && addDays(deb, 6) >= d;
}
/* le relevé pour une ligne dans une épicerie : {reg, cur, sp, nom, fin} ou null */
function peLine(r, store, marque){
  const D = peData(store); if(!D) return null;
  const b = baremeRaw(r.name); if(!b) return null;
  let e = D[bxKey(b)]; if(!e) return null;
  /* marque : le prix de la marque connue (m, mk), 1 = la même chose que le moins cher */
  if(marque){ const mk = e.kg ? e.mk : e.m; if(!mk) return null; if(mk !== 1) e = e.kg ? {kg:mk} : {f:mk}; }
  /* garde-fou : un prix très loin de la référence Maxi est probablement un autre produit */
  const ref = (() => { const M = peData('Maxi'), m = M && M[bxKey(b)]; const u = peUnit(m); if(u) return u; const o = b[1]; return o.kg || Math.min(...o.f.map(x => x[1]/x[0])); })();
  const u = peUnit(e); if(u != null && ref && (u > ref*2.2 || u < ref*0.4)) return null;
  const o = b[1];
  if(e.kg){ const [reg, c, deb, fin, nom] = e.kg, sp = peValide(c, deb, fin);
    const R = reg != null ? costWith(r, {kg:reg, gpu:o.gpu}) : null, C = sp ? costWith(r, {kg:c, gpu:o.gpu}) : R;
    return R == null && C == null ? null : {reg:R, cur:C == null ? R : C, sp: sp && C != null && (R == null || C < R - 0.01), nom, fin}; }
  const FR = e.f.filter(x => x[1] != null).map(x => [x[0], x[1]]);
  const FC = e.f.map(x => [x[0], peValide(x[2], x[3], x[4]) ? x[2] : x[1]]).filter(x => x[1] != null);
  const R = FR.length ? costWith(r, {u:o.u, f:FR, gpu:o.gpu}) : null, C = FC.length ? costWith(r, {u:o.u, f:FC, gpu:o.gpu}) : R;
  if(R == null && C == null) return null;
  const spx = e.f.find(x => peValide(x[2], x[3], x[4]));
  return {reg:R, cur:C == null ? R : C, sp: !!spx && C != null && (R == null || C < R - 0.01), nom: (spx || e.f[0])[5], fin: spx ? spx[4] : ''};
}
/* prix régulier d'une marque connue (Québon, Heinz, Kraft…), relevé chez Maxi et IGA : à peu près le même partout,
   il sert pour les épiceries sans relevé, qui n'ont ni Sans Nom ni Compliments */
function natReg(r){
  const L = Object.keys(CHAINES).map(s => peLine(r, s, true)).filter(l => l && l.reg != null).map(l => l.reg);
  return L.length ? L.reduce((a, b) => a + b, 0) / L.length : null;
}
/* écart de prix d'une épicerie avec Maxi : médiane sur les articles relevés aux deux endroits */
function ecart(store){
  if(store === 'Maxi' || !S.stores.includes(store)) return 1;
  if(!_PEX) _PEX = {};
  if(_PEX[store] != null) return _PEX[store];
  let v = ECART0[store] || 1.08;
  const D = peData(store), M = peData('Maxi');
  if(D && M){ const R = Object.keys(D).map(k => { const a = peUnit(D[k]), b = peUnit(M[k]); return a && b ? a/b : 0; }).filter(x => x > 0.4 && x < 2.5).sort((a,b) => a-b);
    if(R.length >= 15) v = Math.max(0.85, Math.min(1.4, R[Math.floor(R.length/2)])); }
  else if(!D){ const R = ecartCirc(store);   /* sans relevé : les prix réguliers de ses circulaires, mêlés à la valeur de départ */
    if(R.length >= 8){ const med = R[Math.floor(R.length/2)]; v = Math.max(0.85, Math.min(1.4, (R.length * med + 10 * v) / (R.length + 10))); } }
  return (_PEX[store] = Math.round(v*1000)/1000);
}
/* prix régulier de la circulaire ÷ prix de la marque connue (Maxi et IGA), pour les articles de la liste en spécial dans cette épicerie */
function ecartCirc(store){
  let rows = []; try{ rows = buyList().rows; }catch(e){ return []; }
  const R = [];
  rows.forEach(r => { const d = dealsAll(r.name).find(s => s.s === store && s.o); if(!d) return;
    /* une circulaire annonce surtout des marques connues : on compare au prix de la même sorte de marque chez Maxi et IGA */
    const rc = dealCost(Object.assign({}, d, {p:d.o}), r), ref = natReg(r);
    if(rc > 0 && ref > 0){ const x = rc / ref; if(x > 0.6 && x < 1.6) R.push(x); } });   /* au-delà : probablement un autre format */
  return R.sort((a,b) => a-b);
}
/* spéciaux des circulaires (toutes tes épiceries) qui correspondent à un article */
function dealsAll(name){
  if(_DCA.has(name)) return _DCA.get(name);
  const man = (S.menu.dsel||{})[artB(name)]; let L = [];
  if(man !== 'none'){ const all = _SPA || (_SPA = allSpecAll().filter(s => isFinite(priceOf(s)))); L = man ? all.filter(s => spId(s)===man) : dealCands(name, prep(all)); }
  _DCA.set(name, L); return L;
}
/* coût d'une ligne dans une épicerie : {cost, reg, src: 'mine'|'robot'|'ref'|'est', deal, rsp} */
function costAt(r, store){
  const key = r.k + '|' + store; if(_CAT_S.has(key)) return _CAT_S.get(key);
  const L = (S.prices||{})[r.k], mine = L && !L.sp && L.pu > 0 && (L.s === store || (!L.s && store === mainStore()));
  let reg, src, line = null;
  if(mine){ reg = costEst(r); src = 'mine'; }
  else if((line = peLine(r, store)) && line.reg != null){ reg = line.reg; src = 'robot'; }
  else if(!CHAINES[store] && S.stores.includes(store) && (reg = natReg(r)) != null){ src = 'marque'; }
  else { const lm = store !== 'Maxi' ? peLine(r, 'Maxi') : null; reg = (lm && lm.reg != null ? lm.reg : estBase(r)) * ecart(store); src = store === 'Maxi' || !S.stores.includes(store) ? 'ref' : 'est'; if(line && line.cur != null && line.cur > reg) reg = line.cur; }
  let cost = reg, deal = null, rsp = null;
  if(line && line.sp && line.cur < cost - 0.005){ cost = line.cur; rsp = line; }
  dealsAll(r.name).filter(s => s.s === store).forEach(d => { const dc = dealCost(d, r);
    /* moins de 40 % du prix habituel sans rabais annoncé : probablement un prix à la livre ou un autre format */
    if(dc != null && dc < cost - 0.005 && (d.d > 0 || dc <= reg*1.15 || mine) && (dc >= reg*0.4 || d.d >= 55)){ cost = dc; deal = d; rsp = null; } });
  /* épicerie sans relevé : sa circulaire donne son vrai prix (rabais et prix régulier), mieux qu'une estimation */
  if(src === 'est' || src === 'marque'){
    const d2 = deal && deal.o ? deal : dealsAll(r.name).find(s => s.s === store && s.o);
    if(d2){ const rc = dealCost(Object.assign({}, d2, {p:d2.o}), r), dc = dealCost(d2, r);
      if(rc != null && dc != null && rc > dc && rc > reg * 0.4 && rc < reg * 2.5){ reg = rc; src = 'circ'; if(!deal || dc < cost - 0.005){ cost = dc; deal = d2; rsp = null; } } }
  }
  const o = {cost, reg: Math.max(reg, cost), src, deal, rsp};
  _CAT_S.set(key, o); return o;
}
/* à quelle épicerie va un article : la principale, sauf si une autre de la semaine est nettement moins chère */
function assign(r, stores, main){
  if(stores.length <= 1) return stores[0] || main;
  let best = stores.includes(main) ? main : stores[0], bc = costAt(r, best).cost;
  stores.forEach(s => { if(s === best) return; const c = costAt(r, s).cost; if(c < bc*0.97 && bc - c >= 0.25){ best = s; bc = c; } });
  return best;
}
/* ---------- comparateur : une, deux, trois ou quatre épiceries ---------- */
const STORE_MAX = 6;
function comparer(rows){
  if(_CMPR && _CMPR.rows === rows) return _CMPR.res;
  const R = rows.filter(r => !S.menu.chk[r.k]);
  let st = S.stores.length ? S.stores.slice() : [mainStore()];
  const single = s => { let t = 0, ok = 0; R.forEach(r => { const c = costAt(r, s); t += c.cost; if(c.src !== 'est' || c.deal || c.rsp) ok += c.cost; }); return {stores:[s], total:t, real: t ? ok/t : 1}; };
  const singles = st.map(single).sort((a,b) => a.total - b.total);
  if(st.length > STORE_MAX) st = singles.slice(0, STORE_MAX).map(x => x.stores[0]);
  const best1 = singles[0], combos = [];
  const subsets = (k, from = 0, cur = []) => { if(cur.length === k){ combos.push(cur.slice()); return; } for(let i = from; i < st.length; i++){ cur.push(st[i]); subsets(k, i+1, cur); cur.pop(); } };
  for(let k = 2; k <= Math.min(4, st.length); k++) subsets(k);
  const multi = combos.map(C => {
    const main = C.includes(S.p.main) ? S.p.main : singles.find(x => C.includes(x.stores[0])).stores[0];
    const per = {}; let t = 0; C.forEach(s => per[s] = {n:0, t:0});
    R.forEach(r => { const s = assign(r, C, main), c = costAt(r, s).cost; per[s].n++; per[s].t += c; t += c; });
    return {stores:C, main, total:t, per, used: C.every(s => per[s].n > 0)};
  }).filter(x => x.used);
  const bestK = [];
  for(let k = 2; k <= 4; k++){ const L = multi.filter(x => x.stores.length === k).sort((a,b) => a.total - b.total); if(L.length && best1.total - L[0].total >= 2 && (!bestK.length || bestK[bestK.length-1].total - L[0].total >= 2)) bestK.push(L[0]); }
  const res = {rows:R, singles, multi:bestK, best:best1};
  _CMPR = {rows, res}; return res;
}
const goKey = L => L.slice().sort().join('|');
/* choisir les épiceries de la semaine (une ou plusieurs) */
function choisirEpiceries(L){
  L = L.filter(s => S.stores.includes(s)); if(!L.length) return;
  S.skip = S.stores.filter(s => !L.includes(s)); S.goSome = L.length > 1 && L.length < S.stores.length; S.goAuto = false;
  if(L.length > 1) S.p.grp = 'magasin';
}
function ouAllerCard(rows){
  if(S.stores.length < 2 || !rows.length) return '';
  const C = comparer(rows), cur = goKey(goStores()), b = C.best;
  const pct = x => Math.round(x*100);
  const opt = (o, extra) => { const on = goKey(o.stores) === cur, lbl = o.stores.length === 1 ? `${o.stores[0]} seulement` : o.stores.join(' + ');
    return `<div class="item ou${on ? ' on' : ''}"><span class="t"><b>${esc(lbl)}</b>${extra}</span><span class="qcol"><span class="q">≈ ${money(o.total * calF())}</span>${on ? '<span class="small ok">Ton choix</span>' : `<button class="btn s" data-a="ou_pick" data-v="${esc(o.stores.join('|'))}">Choisir</button>`}</span></div>`; };
  let h = `<details class="card ouc" data-pan="ou" ${openPan.has('ou')?'open':''}><summary>Où faire l'épicerie <span class="rm">la moins chère : ${esc(b.stores[0])}</span></summary><p class="small">Le coût de ta liste dans chacune de tes épiceries, spéciaux et prix réguliers compris.</p><div class="list">`;
  C.singles.forEach((o, i) => { h += opt(o, `<small>${i === 0 ? 'La moins chère pour une seule épicerie' : `${money((o.total - b.total) * calF())} de plus`}${o.real < 0.6 ? ' · surtout estimé' : ` · prix connus pour ${pct(o.real)} %`}</small>`); });
  C.multi.forEach(o => { const det = o.stores.filter(s => s !== o.main).map(s => `${s} : ${o.per[s].n} article${o.per[s].n>1?'s':''}`).join(', ');
    h += opt(o, `<small class="ok"><b>${money((b.total - o.total) * calF())} de moins</b> que ${esc(b.stores[0])} seulement</small><small>Le reste chez ${esc(o.main)}; ${esc(det)}.</small>`); });
  if(!C.multi.length) h += `<p class="small">Aller à plus d'une épicerie ferait économiser moins de 2 $ cette semaine.</p>`;
  const pd = peDate();
  h += `</div><p class="small">À toi de voir si l'économie vaut le déplacement. ${pd ? `Prix réguliers relevés le ${esc(dShort(pd))} chez ${esc(PE.magasins.filter(m => m.ok || m.n).map(m => m.ch === 'maxi' ? 'Maxi' : 'IGA').filter((x, i, a) => a.indexOf(x) === i).join(' et '))}` : 'Pas encore de relevé des prix'}. Ailleurs, chaque article est compté au prix d'une marque connue (Québon, Heinz, Kraft…), à peu près le même partout, sinon estimé d'après l'écart habituel avec Maxi; tes prix payés les corrigent.</p></details>`;
  return h;
}
/* ligne « Où aller » dans Ma semaine */
function ouAllerLigne(rows){
  if(S.stores.length < 2 || !rows.length) return '';
  const C = comparer(rows), b = C.best, m = C.multi[0], go = goStores();
  const cur = C.singles.concat(C.multi).find(o => goKey(o.stores) === goKey(go));
  let t = `Le moins cher pour une seule épicerie : <b>${esc(b.stores[0])}</b> (≈ ${money(b.total*calF())}).`;
  if(m) t += ` ${esc(m.stores.join(' + '))} : ${money((b.total - m.total)*calF())} de moins.`;
  if(cur && goKey(cur.stores) !== goKey(b.stores) && cur.total > b.total + 2 && !m || (cur && m && cur.total > Math.min(b.total, m.total) + 2)) t += ` Ton choix actuel coûte ≈ ${money((cur.total - Math.min(b.total, m ? m.total : b.total))*calF())} de plus.`;
  return `<p class="small">${t} <a href="#" data-a="view" data-v="epicerie">Comparer</a></p>`;
}
/* ---------- relevé : carte dans Prix ---------- */
function peCard(){
  const pd = peDate(), sel = peSel();
  const mags = PE ? PE.magasins : [];
  const lig = mags.map(m => `<li>${esc(m.nom)} : ${m.ok ? `${m.n} articles` : `<span class="over">échec du dernier relevé</span>${m.n ? ` (prix du ${esc(dShort(m.d || pd))} gardés)` : ''}`}</li>`).join('');
  const igas = mags.filter(m => m.ch === 'iga');
  return `<div class="card"><h3>Prix des épiceries</h3>
    <p class="small">${pd ? `Un robot relève chaque semaine les prix réguliers et les promotions de Maxi et d'IGA. Dernier relevé : <b>${esc(fmtDate(pd))}</b>.` : "Le relevé automatique des prix n'est pas encore disponible."} Pour chaque article, il note le moins cher (souvent Sans Nom ou Compliments) et, à part, le moins cher des marques connues. Les autres épiceries n'ont pas ces marques maison : on y compte le prix de la marque connue, à peu près le même partout, sinon une estimation d'après leur écart habituel avec Maxi. Tes prix payés corrigent le tout.</p>
    ${lig ? `<ul class="todo">${lig}</ul>` : ''}
    ${igas.length > 1 ? `<label class="f">Ton IGA<select data-a="pe_mag" data-ch="iga">${igas.map(m => `<option value="${esc(m.id)}" ${sel.iga === m.id ? 'selected' : ''}>${esc(m.nom)}</option>`).join('')}</select></label>` : ''}
    ${S.stores.filter(s => s !== 'Maxi').length ? `<p class="small">Écart avec Maxi : ${S.stores.filter(s => s !== 'Maxi').map(s => `${esc(s)} ${ecart(s) >= 1 ? '+' : '−'}${Math.round(Math.abs(ecart(s) - 1)*100)} %${peData(s) ? '' : ' (estimé)'}`).join(' · ')}</p>` : ''}
    <div class="acts"><button class="btn s p" data-a="pe_maj" ${peBusy ? 'disabled' : ''}>Mettre à jour les prix maintenant</button></div><p class="note" id="pe_msg" hidden></p></div>`;
}
/* sous un article de Prix : le prix relevé dans chaque chaîne */
function peTxt(b){
  if(!PE) return '';
  const k = bxKey(b), L = Object.keys(CHAINES).map(s => { const D = peData(s), e = D && D[k]; if(!e) return '';
    const mq = (nom, prix, kg) => prix != null ? ` · marque connue (${String(nom||'').slice(0, 28)}) ${money(prix)}${kg ? '/kg' : ''}` : '';
    if(e.kg) return `${s} ${e.kg[0] != null ? money(e.kg[0]) + '/kg' : ''}${e.kg[1] > 0 ? ` (promo ${money(e.kg[1])}/kg)` : ''}${Array.isArray(e.mk) ? mq(e.mk[4], e.mk[0], true) : ''}`;
    return `${s} ${e.f.map(x => `${fq(x[0], b[1].u)} ${x[1] != null ? money(x[1]) : ''}${x[2] > 0 ? ` (promo ${money(x[2])})` : ''}`).join(', ')}${Array.isArray(e.m) && e.m[0] ? mq(e.m[0][5], e.m[0][1]) : ''}`; }).filter(Boolean);
  return L.length ? `<small>Relevé : ${esc(L.join(' · '))}</small>` : '';
}

/* Menu de la semaine — Écrans : menu, épicerie, maison, recettes, articles, prix.
   Les fichiers de js/ partagent les mêmes variables globales; ils sont chargés dans l'ordre de index.html. */
/* ---------- rendu : menu ---------- */
function avecTxt(it){
  const lbl = q => ({0:'aucun',0.5:'moins',1.5:'plus',2:'double'})[q]||'';
  const sf = sideById(it.sf), sv = sideById(it.sv);
  return [(it.fm??1)>0 && sf && sf.n + ((it.fm??1)===1?'':' ('+lbl(it.fm)+')'), (it.vm??1)>0 && sv && sv.n + ((it.vm??1)===1?'':' ('+lbl(it.vm)+')')].filter(Boolean).join(' + ');
}
/* Portions d'un plat : souper + restes par défaut; 2 pour un souper en amoureux, plus quand on reçoit. */
function portionSel(it, i, l){
  const def = ptDef(it, l), cur = it.pt || def, habit = ['items','din','dej'].includes(l);
  const opts = [1,2,3,4,5,6,7,8,9,10,12,14,16,20,24].concat([cur]).filter((v,j,a) => a.indexOf(v)===j).sort((a,b) => a-b);
  return `<label class="inl"><select class="day" data-a="portions" data-ml="${l}" data-i="${i}" aria-label="Portions">${opts.map(v => `<option value="${v===def && !it.pt ? 0 : v}" ${v===cur?'selected':''}>${v} portion${v>1?'s':''}${v===def ? (habit ? ' (habituel)' : ' (recette)') : v===2 ? ' (à deux)' : ''}</option>`).join('')}</select></label>`;
}
const dcolHtml = d => { const dt = d ? new Date(d+'T12:00:00') : null;
  return dt ? `<span class="dcol${isOff(d)?' off':''}${d===isoToday()?' now':''}"><small>${esc(dt.toLocaleDateString('fr-CA',{weekday:'short'}))}</small><b>${dt.getDate()}</b></span>` : `<span class="dcol"><small>jour</small><b>?</b></span>`; };
/* jour de dîner sans plat : les restes de la veille, ou rien de prévu */
function restRow(p){
  if(p.rest) return `<div class="restd"><div class="dsum">${dcolHtml(p.d)}<span class="dmain"><span class="dline"><span class="dname">Restes : ${esc(p.rest.r)}</span></span><span class="dsub">du souper de ${esc(dayLbl(p.rest.d).toLowerCase())}, rien à acheter</span>${S.menu.achete ? '' : `<button class="lnk" data-a="dincook" data-d="${p.d}">Préparer un dîner à la place</button>`}</span></div></div>`;
  return `<div class="restd"><div class="dsum">${dcolHtml(p.d)}<span class="dmain"><span class="dline"><span class="dname">Dîner à prévoir</span></span><span class="dsub">pas de restes la veille : un lunch avec ce qu'il y a à la maison, ou ajoute un plat</span><button class="lnk" data-a="din_add" data-d="${p.d}">Ajouter un plat ce midi-là</button></span></div></div>`;
}
/* « 3 autres choix » : des plats semblables (même sorte, temps proche), pas déjà au menu ni faits récemment, avec l'écart de coût */
let altKey = '';
function altsFor(it, l){
  const r = byName(it.r); if(!r) return [];
  const kind = kindOf(r), used = new Set(allItems().map(x => x.r)), recent = recentSet(), c0 = dishCost(it), t0 = tpOf(r), lg = isLong(r);
  return allRecipes().filter(x => kindOf(x)===kind && (!x.oc || r.oc) && !used.has(x.n) && !S.dis[x.n] && !softBad(x) && ppOk(x) && simpleOk(x) && !recent.has(x.n) && (lg || !isLong(x)) && Math.abs(tpOf(x) - t0) <= 20)
    .map(x => ({x, s: score(x) + (protein(x)===protein(r) ? .3 : 0)})).sort((a, b) => b.s - a.s).slice(0, 3)
    .map(({x}) => { const ni = (l==='items' || l==='din') ? mkItem(x, new Set(), pickVar(x)) : {r:x.n, v:0}; if(it.pt) ni.pt = it.pt; return {x, dc: dishCost(ni) - c0, why: whyOf(ni)}; });
}
function altsHtml(it, i, l){
  const A = altsFor(it, l); if(!A.length) return '<p class="small">Aucun autre plat semblable pour l\'instant.</p>';
  return `<div class="list alts">${A.map(o => `<div class="item"><span class="t"><b>${esc(o.x.n)}</b><small>${esc(tmShort(o.x))} · ${o.dc >= 0 ? '+' : '−'}${money(Math.abs(o.dc))}${o.why.length ? ' · ' + esc(o.why.slice(0, 2).join(' · ')) : ''}</small></span><button class="btn s p" data-a="mpick" data-ml="${l}" data-i="${i}" data-r="${esc(o.x.n)}">Choisir</button></div>`).join('')}</div>`;
}
function carte(it, i, l){
  const m = S.menu, r = byName(it.r); if(!r) return '';
  const dis = '', souper = l==='items', meal = l==='items' || l==='din', dated = meal || l==='dej';
  const B = (a, label, cls, always) => `<button class="btn s ${cls||''}" data-a="${a}" data-ml="${l}" data-i="${i}" ${always?'':dis}>${label}</button>`;
  const vs = vars(r), cur = it.v>0 ? vs[it.v-1] : null, k = cmEff(it, r), M = methods(r);
  const deals = itemDeals(it, r), sto = stockOf(it);
  const ing = fullIngs(it,true).sort((a,b) => a.name.localeCompare(b.name,'fr'));
  const avec = meal ? avecTxt(it) : '';
  const fo = souper ? follOf(it) : null, pr = souper && r.ur ? primOf(it) : null;
  const showRate = dated ? (it.d && it.d <= isoToday()) : m.achete;
  const pk = `dish|${l}|${i}`, open = openPan.has(pk);
  const xtra = l==='ent' || l==='sou', dcol = dated || (xtra && it.d) ? dcolHtml(it.d) : '';
  const ext = souper ? extrasDe(it.d) : [];
  const restA = l==='din' ? restesAvail(it.d) : null;
  const flags = [deals.length ? ['En spécial','sp'] : null, it.sr ? ['Soupe-repas','k'] : null, it.cm ? ['Repas plaisir','k'] : null, xtra && it.ro ? [roleTxt(it, l).replace(/,.*$/, '').replace(/ de .*$/, ''),'a'] : null, it.rep ? ['Reporté','k'] : null, it.pt && it.pt!==ptDef(it, l) ? [`${it.pt} portion${it.pt>1?'s':''}`,'a'] : null, it.lock ? ['Gardé','a'] : null, cur ? [vname(cur[0]),''] : null, fo ? ['Donne des restes','k'] : null, pr ? ['Avec les restes','k'] : null,
    meal && p2Info(it, l) ? ['2e protéine','k'] : null, r.pp ? ['Prêt à servir',''] : null, k ? [CM_L[k],'k'] : souper && mjOf(r) && it.d && !isOff(it.d) && (mjOf(r)===1 || tmOf(r) > MAX_FOUR) ? ['Mijoteuse','k'] : null, it.rt==='up' ? ['Aimé','a'] : it.rt==='down' ? ['Pas aimé','w'] : null, sto.length ? ['Déjà à la maison','a'] : null].filter(Boolean);
  return `<details class="dish${it.lock?' locked':''}" data-pan="${pk}" ${open?'open':''}><summary>${dcol}${recipePhoto(r, 'dish-photo')}
    <span class="dmain"><span class="dline"><span class="dname">${esc(r.n)}</span><span class="lead" aria-hidden="true"></span><span class="dtime">${fmtMin(tpM(r, k))}</span></span>
      <span class="dsr">${(meal && avec) || it.sc ? `<span class="dsub">${esc([meal && avec ? 'avec '+avec.split(' + ').map(lowFirst).join(' et ') : '', it.sc ? lowFirst(it.sc.replace(/\s*\(.*\)$/,'')) : ''].filter(Boolean).join(', '))}</span>` : ''}<button class="cookb" data-a="cook" data-ml="${l}" data-i="${i}">Recette</button></span>
      ${ext.length ? `<span class="dsub">+ ${esc(ext.join(' · '))}</span>` : ''}${xtra && it.ro && it.d ? `<span class="dsub">${esc(roleTxt(it, l))}${(m => m ? ' : ' + lowFirst(m.r) : '')(mlist('items').find(x => x.d===it.d))}</span>` : ''}
      ${flags.length ? `<span class="flags">${flags.map(([t,c]) => `<span class="flag ${c}">${esc(t)}</span>`).join('')}</span>` : ''}
</span></summary>
    <div class="dbody">
    <div class="drow">${dated ? `<span class="dayw">${daySelect(it,i,l)}</span>` : ''}${portionSel(it, i, l)}</div>
    ${deals.length?`<span class="tags">${deals.map(d => tagHtml(d.hit)).join('')}</span>`:''}
    ${xtra ? extraCtl(it, i, l) : ''}
    ${it.sr ? `<p class="small">Soupe-repas : servie comme souper, avec ses accompagnements. <button class="lnk" data-a="srback" data-ml="${l}" data-i="${i}">En faire plutôt une soupe à côté</button></p>` : ''}
    ${metaTags(r, souper)}
    ${souper ? (w => w.length ? `<p class="why"><b>Pourquoi ce plat :</b> ${esc(w.join(' · '))}</p>` : '')(whyOf(it)) : ''}
    ${tmM(r, k) > tpM(r, k) + 5 ? `<p class="small">${esc(tmTxtM(r, k))}</p>` : ''}
    ${nutLigne(nutPlat(it), meal || it.sr)}
    ${souper && mjTxt(it, r) ? `<p class="rest">${esc(mjTxt(it, r))}</p>` : ''}
    ${meal && p2Txt(it, l) ? `<p class="rest">${esc(p2Txt(it, l))}</p>${p2Sel(it, l, i) ? `<label class="f">2e protéine${p2Sel(it, l, i)}</label>` : ''}` : ''}
    ${meal && autreTxt(it, l) ? `<p class="small">${esc(autreTxt(it, l))}</p>` : ''}${!meal && !it.sr && pasPour(it) ? `<p class="small">${esc(pasPour(it))}.</p>` : ''}
    ${fo ? `<p class="rest">Restes prévus pour ${esc(fo.r)}${fo.d ? ' ('+esc(dayLbl(fo.d).toLowerCase())+')' : ''}. Achète un peu plus et garde le reste.</p>` : ''}
    ${pr ? `<p class="rest">Avec les restes de ${esc(pr.r)}. Pas besoin d'en racheter.</p>` : ''}
    ${sto.length?`<p class="stock">À la maison : ${esc(sto.join(', '))}</p>`:''}
    ${vs.length && M.length ? '<p class="small segl">Version</p>' : ''}${vs.length?`<div class="seg" role="group" aria-label="Version">${['Normale'].concat(vs.map(x=>vname(x[0]))).map((nm,j)=>`<button class="${j===it.v?'on':''}" data-a="msetv" data-ml="${l}" data-i="${i}" data-v="${j}" ${dis}>${esc(nm)}</button>`).join('')}</div>`:''}
    ${cur ? varDetail(cur) : ''}
    ${M.length ? `<p class="small segl">Cuisson</p><div class="seg" role="group" aria-label="Cuisson">${M.map(m => `<button class="${m.k===k?'on':''}" data-a="msetcm" data-ml="${l}" data-i="${i}" data-k="${m.k||'b'}">${esc(m.l)} <small>${esc(fmtMin(m.k==='mj' ? m.tp : m.tm))}</small></button>`).join('')}</div>${cmAuto(it, r) ? `<p class="small">${esc(CM_L[k])} : choisi parce que c'est un soir de semaine. Touche une autre cuisson pour changer.</p>` : ''}` : ''}
    ${meal ? `<details class="panel"><summary>${it.sr ? 'Avec la soupe' : 'Accompagnements'}</summary>${sideBlock(it,i,l)}<div class="acts">${B('mreroll','Autres accompagnements')}</div></details>` : ''}
    ${meal ? `<label class="f">Sauce en complément (facultatif)<select data-a="msauce" data-ml="${l}" data-i="${i}" ${dis}><option value="">Aucune</option>${allRecipes().filter(x => kindOf(x)==='sauce').sort((a,b) => a.n.localeCompare(b.n,'fr')).map(x => `<option ${it.sc===x.n?'selected':''}>${esc(x.n)}</option>`).join('')}</select></label>` : ''}
    <details class="panel"><summary>Recette et ingrédients</summary>
      <ul class="ing">${ing.map(g=>`<li class="${g.x?'x':''}"><span>${esc(g.name)}</span><span>${fq(g.q,g.u)}${g.rest ? '<em class="restq">restes</em>' : `<a href="#" data-a="mexing" data-ml="${l}" data-i="${i}" data-k="${esc(g.k)}" aria-label="${g.x?'Remettre':'Retirer'} ${esc(g.name)}">${g.x?'remettre':'retirer'}</a>`}</span></li>`).join('')}</ul>
      <p class="small">« Retirer » enlève l'ingrédient de la liste d'épicerie.</p>
      <p class="steps">${k ? `<b>${esc(CM_L[k])} :</b> ` : ''}${esc(stepsM(r, k))}</p>${cur && cur[2] ? `<p class="steps"><b>Pour cette version :</b> ${esc(cur[2])}</p>` : ''}
    </details>
    ${showRate ? `<div class="rate"><span class="small">Après le repas</span>${B('mup', it.rt==='up'?'On a aimé ✓':'On a aimé', it.rt==='up'?'p':'', true)}${B('mdown', it.rt==='down'?'Pas aimé ✓':'Pas aimé', it.rt==='down'?'p':'', true)}</div>` : ''}
    ${altKey===l+'|'+i ? altsHtml(it, i, l) : ''}<div class="acts">${B('mlock', it.lock?'Gardé ✓':'Garder', it.lock?'p':'')}${B('malts', altKey===l+'|'+i ? 'Fermer les choix' : '3 autres choix')}${B('mswap','Au hasard')}
      ${souper ? `<details class="more"><summary>Reporter</summary><div class="more-p"><p class="small" style="flex-basis:100%">Resto ou changement de plan ? Le plat garde ses ingrédients.</p>${B('rep1','À demain','',true)}${B('repw','À la semaine prochaine','',true)}</div></details>` : ''}
      ${restA ? B('dinrest', `Manger plutôt les restes de ${esc(restA.r)}`) : ''}
      <details class="more"><summary>Plus</summary><div class="more-p">${B('mcopy','Copier la recette','',true)}${B('mdis',"Je n'aime pas")}${l==='din' ? B('dinno','Pas de dîner ce jour-là','d') : B('mrm','Retirer du menu','d')}</div></details></div>
    <div class="small" id="rmsg_${l}_${i}"></div></div></details>`;
}
function countSelects(dis){
  return [['nDej','Déjeuners',[0,1,2,3,4,5,6,7]],['nDin','Dîners',[0,1,2,3,4,5,6,7]],['n','Soupers',[3,4,5,6,7]],['nSr','Dont soupes-repas',[0,1,2]],['nCm','Dont repas plaisir',[0,1,2]],['nEnt','Entrées',[0,1,2,3,4,5,6,7]],['nSou','Soupes à côté',[0,1,2,3]],['nDes','Desserts',[0,1,2,3,4,5,6,7]]].map(([k,lab,opts]) => `<label class="f">${lab}<select data-p="${k}" ${dis||''}>${opts.map(v=>`<option ${(S.p[k]||0)===v?'selected':''}>${v}</option>`).join('')}</select></label>`).join('');
}
function renderSetup(){
  const p = S.p;
  return `<div class="card call"><h3>Bienvenue ! On prépare ton application</h3>
    <p class="small">Elle démarre vide. Choisis tes épiceries, ton code postal et ce que tu veux planifier chaque semaine. Tout se change plus tard dans Profil.</p>
    <label class="f">Code postal<input type="text" data-cp="1" value="${esc(S.cp)}" autocapitalize="characters" placeholder="A1A 1A1"></label>
    <p class="small"><b>Mes épiceries</b>, pour chercher les spéciaux. Coche celles où tu vas, ou touche le bouton pour voir celles qui ont une circulaire près de chez toi.</p>
    ${storePicker()}
    <div class="grid2">${countSelects()}</div>
    <div class="grid2"><label class="f">Portions au souper<select data-p="souper">${[2,3,4,5,6,7,8].map(n=>`<option ${p.souper===n?'selected':''}>${n}</option>`).join('')}</select></label>
      <label class="f">Restes pour le dîner<select data-p="restes">${[0,1,2,3,4,5].map(n=>`<option ${p.restes===n?'selected':''}>${n}</option>`).join('')}</select></label></div>
    <label class="check"><input type="checkbox" id="su_ess"> Ajouter une liste de départ pour les déjeuners, lunchs, collations et boissons</label>
    <button class="btn p" id="setup_done">Commencer</button></div>`;
}
function semaineCard(){
  const m = S.menu;
  if(!m.date) return `<div class="card week call"><h2>Pas encore de menu</h2><p class="small">Ramassage ${esc(fmtDate(nextPickup()))}. Quelques questions sur ta semaine, une ébauche à ajuster, puis le menu final et la liste d'épicerie.</p>
    <div class="acts"><button class="btn p" id="prep_week" data-armed="0" ${prepBusy ? 'disabled' : ''}>${prepBusy ? 'Préparation en cours…' : 'Préparer ma semaine'}</button></div>${specDetails()}</div>`;
  const {rows} = buyList(), nDeal = rows.filter(r => dealFor(r.name)).length, t = listTotals(rows), b = +S.p.budget || 0;
  const cnt = [['items','souper'],['din','dîner'],['dej','déjeuner'],['ent','entrée'],['sou','soupe'],['des','dessert']].map(([l, w]) => { const n = l==='din' ? dinPlan().length : mlist(l).length; return n ? `${n} ${w}${n>1?'s':''}` : ''; }).filter(Boolean).join(' · ');
  const over = b && t.cost > b && !m.achete;
  return `<div class="card tally"><p><b>${rows.length}</b> article${rows.length>1?'s':''} à acheter${nDeal?`, dont <b>${nDeal}</b> en spécial`:''}<br><span class="small" style="color:inherit;opacity:.85">≈ ${money(t.cost)}${b ? ` sur ${money(b)} de budget` : ''}</span></p><button class="btn s p" id="go_liste">Voir la liste</button></div>
    <div class="card week"><h2>Du ${esc(dayLbl(m.start).toLowerCase())} au ${esc(dayLbl(addDays(m.start, 6)).toLowerCase())}</h2>
    <p class="small">${esc(cnt)}. Épicerie ${esc(fmtDate(m.shop || shopISO()))}.</p>
    ${over ? `<p class="small"><b class="over">Le budget est dépassé de ≈ ${money(t.cost - b)}.</b></p>` : ''}
    <div class="acts"><button class="btn s" id="refaire">Refaire le menu</button><button class="btn s" data-a="plus_open" data-k="partager">Partager</button>${over ? '<button class="btn s" id="bfit">Remplacer des soupers trop chers</button>' : ''}</div>
    ${specDetails()}</div>`;
}
/* spéciaux et dates : la recherche, les spéciaux trouvés, les dates, et le plan B si la recherche ne marche pas */
function specDetails(){
  const items = autoItems(), shop = shopISO(), stores = S.stores.length ? S.stores : allStores();
  const go = goStores();
  const status = S.stores.length && !go.length ? 'Coche au moins une épicerie pour voir ses spéciaux.'
    : S.auto ? `${items.length} spécia${items.length>1?'ux':'l'} valide${items.length>1?'s':''} ce jour-là, dans ${esc(go.join(', ') || S.auto.src || 'les circulaires')}.`
    : !familleCode() ? 'Sans le code de la famille, le menu se fait sans les spéciaux.' : S.stores.length ? 'Les spéciaux de tes épiceries ne sont pas encore cherchés.' : 'Choisis tes épiceries dans Profil pour chercher les spéciaux.';
  return `<details class="panel" data-pan="spec" ${openPan.has('spec')?'open':''}><summary>Spéciaux et dates</summary>
    ${familleCode() ? '' : `<p class="note">Les spéciaux sont réservés à la famille et aux amis. <button class="btn s" data-a="view" data-v="compte">Entrer le code de la famille</button></p>`}
    ${familleCode() ? `<div class="acts"><button class="btn s" id="sp_go" ${spBusy ? 'disabled' : ''}>${spBusy ? 'Recherche en cours…' : 'Chercher les spéciaux'}</button></div>` : ''}
    <p class="small" id="sp_status">${status}</p>
    ${items.length?`<details class="panel"><summary>Voir les spéciaux <span class="rm">${items.length}</span></summary><div class="list">${items.slice(0,150).map(i=>`<div class="item"><span class="t">${tagHtml({t:nice(i.t), p:i.p||'', s:i.s})}${i.vt?`<small>Jusqu'au ${esc(fmtDate(i.vt))}</small>`:''}</span></div>`).join('')}</div></details>`:''}
    <div class="grid2"><label class="f">Je planifie le<input type="date" id="d_plan" value="${esc(S.dates.plan||isoToday())}"></label><label class="f">J'achète le<input type="date" id="d_shop" value="${esc(shop)}"></label></div>
    <p class="small">Les spéciaux retenus sont ceux valides le jour de l'épicerie. Les nouvelles circulaires sortent le jeudi : si elles ne sont pas encore là, relance la recherche plus tard.</p>
    <details class="panel"><summary>Si la recherche ne fonctionne pas</summary>
      <label class="f">Code postal<input type="text" data-cp="1" value="${esc(S.cp)}" autocapitalize="characters" placeholder="A1A 1A1"></label>
      <p class="small">Certains navigateurs bloquent la recherche. Copie alors le texte d'une circulaire sur <a href="https://flipp.com/fr-ca" target="_blank" rel="noopener">Flipp</a> et colle-le ici.</p>
      <label class="f">Magasin<select id="spstore">${stores.map(s=>`<option>${esc(s)}</option>`).join('')}</select></label>
      <textarea id="sptxt" placeholder="Poitrines de poulet 4,99 $&#10;Boeuf haché mi-maigre 3,95 $" aria-label="Texte de la circulaire"></textarea>
      <div class="acts"><button class="btn s p" id="spadd">Ajouter ces spéciaux</button>${S.spec.length?'<button class="btn s d" id="spclr">Vider les ajouts</button>':''}</div>
      <div id="spmsg" class="small"></div>
      ${S.spec.length?`<div class="chips">${S.spec.slice(0,60).map((s,i)=>`<span class="chip">${esc(s.t.slice(0,60))} · ${esc(s.s)} <a href="#" data-a="spdel" data-i="${i}" aria-label="Retirer">×</a></span>`).join('')}</div>`:''}
      <label class="f">Relais (facultatif, pour utilisateurs avancés)<input type="text" id="relay_in" value="${esc(S.relay)}" placeholder="https://…?url="></label>
    </details>
  </details>`;
}
function daySelect(it,i,l){
  l = l || 'items'; const ds = l==='din' ? [...new Set(dinNeed().concat(it.d ? [it.d] : []))].sort() : weekDates();
  return `<select class="day" data-a="mday" data-ml="${l}" data-i="${i}" aria-label="Jour">${it.d && ds.includes(it.d) ? '' : '<option value="" selected>Sans jour</option>'}${ds.map(d => `<option value="${d}" ${it.d===d?'selected':''}>${esc(dayLbl(d))}${isOff(d)?' (congé)':''}</option>`).join('')}</select>`;
}
function mainMeat(it){
  const g = fullIngs(it).filter(g => (g.rayon==='viandes'||g.rayon==='poissonnerie') && !/cuit|tranch|pepperoni|bacon|bologne|fume|saucisses? a hot/.test(norm(g.name))).sort((a,b) => (b.u==='g'?b.q:b.q*150)-(a.u==='g'?a.q:a.q*150))[0];
  return g ? g.name : '';
}
/* Reporter : à demain (les plats suivants glissent d'un jour jusqu'au prochain soir libre), ou à la semaine prochaine. */
const KEEPF = ['r','v','sf','sv','fm','vm','pt','ex','sc','ovr','man'];
function reportWeek(i, quiet){
  const L = mlist('items'), it = L[i]; if(!it) return '';
  const o = {}; KEEPF.forEach(k => { if(it[k]!==undefined) o[k] = it[k]; });
  S.report = (S.report||[]).concat([o]);
  L.splice(i, 1); L.forEach(x => { if(x.after===it.r) delete x.after; });
  const r = byName(it.r), fresh = r && r.i.some(g => g[3]==='viandes' || g[3]==='poissonnerie');
  return quiet ? it.r : `${it.r} est reporté à la semaine prochaine : il sera déjà au menu quand tu la commenceras, et ses ingrédients restent dans Maison.${fresh ? ' Si la viande ou le poisson sont frais, congèle-les.' : ''}`;
}
function reportTomorrow(i){
  const L = mlist('items'), it = L[i]; if(!it) return '';
  const ds = weekDates(), last = ds[ds.length-1];
  if(!it.d) return '';
  let mover = it, d = addDays(it.d, 1); const moved = [];
  for(let k = 0; k < 8 && mover; k++){
    const occ = L.find(x => x!==mover && x.d===d);
    mover.d = d; mover.dfix = true; moved.push(mover.r);
    mover = occ; d = addDays(d, 1);
  }
  const out = L.filter(x => x.d && x.d > last).map(x => L.indexOf(x)).sort((a,b) => b-a).map(j => reportWeek(j, true));
  return `${it.r} est reporté à ${dayLbl(it.d).toLowerCase()}${moved.length>1 ? `; ${moved.slice(1).join(', ')} ${moved.length>2?'glissent':'glisse'} aussi d'un jour` : ''}.${out.length ? ` ${out.join(', ')} passe${out.length>1?'nt':''} à la semaine prochaine.` : ''}`;
}
/* resto ce matin : le déjeuner passe au prochain jour libre de la semaine (même genre de jour si possible) */
function reportDej(i){
  const L = mlist('dej'), it = L[i]; if(!it || !it.d) return '';
  const r = byName(it.r), ds = weekDates().filter(d => d > it.d && !L.some(x => x.d===d));
  const nd = ds.find(d => r && isSimple(r) ? !isOff(d) : isOff(d)) || ds[0];
  if(nd){ it.d = nd; it.dfix = true; return `${it.r} est déplacé à ${dayLbl(nd).toLowerCase()}.`; }
  L.splice(i, 1); return `${it.r} est retiré du menu de cette semaine.`;
}
/* resto ce midi : pas de dîner aujourd'hui; un plat cuisiné prévu va au prochain midi qui en a besoin */
function restoMidi(d){
  const P = dinPlan().find(p => p.d===d && (p.it || p.rest)); if(!P) return '';
  (S.menu.dinNo = S.menu.dinNo||{})[d] = true;
  if(P.rest) return `Pas de dîner à prévoir ce midi. Les restes de ${P.rest.r} se congèlent ou servent un autre jour.`;
  const it = P.it; it.lock = true; delete it.dfix; syncDin(false);
  return it.d && it.d!==d ? `Pas de dîner ce midi. ${it.r} passe au dîner de ${dayLbl(it.d).toLowerCase()}.` : `Pas de dîner ce midi. ${it.r} reste dans les dîners, sans jour pour l'instant.`;
}
function renderReport(){
  const R = S.report||[]; if(!R.length) return '';
  return `<div class="card"><h3>Reporté à la semaine prochaine</h3><p class="small">Ces plats seront déjà au menu de la semaine prochaine. Leurs ingrédients restent dans Maison.</p><div class="list">${R.map((x,j) => `<div class="item"><span class="t"><b>${esc(x.r)}</b></span><button class="btn s" data-a="unrep" data-j="${j}">Remettre cette semaine</button></div>`).join('')}</div></div>`;
}
function renderToday(){
  const m = S.menu; if(!m.date) return '';
  const td = isoToday(), tmw = addDays(td,1), L = mlist('items');
  const PV = (S.menu.prev || []).filter(x => x.d && byName(x.r)); const tonight = L.find(x => x.d===td) || PV.find(x => x.d===td), tomorrow = L.find(x => x.d===tmw) || PV.find(x => x.d===tmw);
  const dej = mlist('dej').find(x => x.d===td), dejT = mlist('dej').find(x => x.d===tmw);
  const P = dinPlan(), dinP = P.find(p => p.d===td && (p.it || p.rest)), dinT = P.find(p => p.d===tmw);
  if(!tonight && !tomorrow && !dej && !dinP) return '';
  const mij = it => { const r = byName(it.r); if(!r) return false; const mj = mjOf(r), k = cmEff(it, r); if(k) return k==='mj'; return mj===1 || (mj===2 && it.d && !isOff(it.d) && tmOf(r) > MAX_FOUR) || (!mj && /mijoteuse/.test(norm(r.n+' '+(r.s||'')))); };
  const todo = [];
  if(tonight && mij(tonight)) todo.push(`Ce matin : partir la mijoteuse pour ${tonight.r}.`);
  if(tonight && primOf(tonight)) todo.push(`Ce soir, on utilise les restes de ${primOf(tonight).r}.`);
  if(tonight && follOf(tonight)) todo.push(`Garde les restes de ${tonight.r} : ils servent pour ${follOf(tonight).r}.`);
  if(tomorrow && !primOf(tomorrow)){ const meat = mainMeat(tomorrow); if(meat) todo.push(`Ce soir : sortir ${meat} du congélateur pour demain, si c'est congelé.`); }
  if(tomorrow && mij(tomorrow)) todo.push(`Ce soir : préparer les ingrédients de ${tomorrow.r}; demain matin, partir la mijoteuse.`);
  if(tonight && dinT && dinT.rest===tonight) todo.push(`Garde ${S.p.restes} portion${S.p.restes>1?'s':''} de ${tonight.r} pour le dîner de demain.`);
  if(dejT){ const r = byName(dejT.r); if(r && /la veille/.test(norm(r.s||''))) todo.push(`Ce soir : préparer ${dejT.r} pour demain matin.`); }
  const ti = tonight ? (L.includes(tonight) ? L.indexOf(tonight) : (S.menu.prev||[]).indexOf(tonight)) : -1, tml = tonight && !L.includes(tonight) ? 'prev' : 'items';
  const midi = dinP ? (dinP.rest ? 'Restes de '+dinP.rest.r : dinP.it.r) : '';
  /* le prochain repas selon l'heure est mis en avant */
  const hr = new Date().getHours(), slots = [dej ? 'matin' : '', midi ? 'midi' : '', tonight ? 'soir' : ''].filter(Boolean);
  const want = hr < 10 ? ['matin','midi','soir'] : hr < 14 ? ['midi','soir'] : ['soir'];
  const now = want.find(s => slots.includes(s)) || slots[slots.length-1];
  const photoIt = now==='matin' ? dej : now==='midi' ? (dinP.it || dinP.rest) : tonight;
  const row = (slot, lbl, name, sub, btn) => `<div class="td-m${slot===now?' now':''}"><span class="td-l">${lbl}</span><b class="td-n">${esc(name)}</b>${sub ? `<span class="td-x">${esc(sub)}</span>` : ''}${btn || ''}</div>`;
  const cb = (ml, i, main) => { const it = mlist(ml)[i], r = it && byName(it.r); return `<button class="btn s ${main?'p':''}" data-a="cook" data-ml="${ml}" data-i="${i}">${r && isSimple(r) ? 'Recette' : 'Cuisiner'}</button>`; };
  const rx = it => { const r = byName(it.r); if(!r) return ''; const k = cmEff(it, r); if(k) return CM_L[k]+', '+lowFirst(tmTxtM(r, k)); const a = tpOf(r), t = tmOf(r); return t > a + 5 ? `${fmtMin(a)} de préparation${mjOf(r)===1 ? ', mijoteuse' : ', '+fmtMin(t)+' au total'}` : fmtMin(t); };
  let dl = ''; try{ dl = cap(new Date(td+'T12:00:00').toLocaleDateString('fr-CA', {weekday:'long', day:'numeric', month:'long'})); }catch(e){ dl = dayLbl(td); }
  return `<div class="card today">${photoIt ? recipePhoto(byName(photoIt.r), 'today-photo', true) : ''}<p class="td-k">Aujourd'hui</p><h2 class="td-d">${esc(dl)}</h2>
    ${dej ? row('matin', 'Ce matin', dej.r, rx(dej), cb('dej', mlist('dej').indexOf(dej), now==='matin')) : ''}
    ${midi ? row('midi', 'Ce midi', midi, dinP.rest ? 'Les restes du souper d\'hier' : rx(dinP.it), dinP.it ? cb('din', dinP.i, now==='midi') : '') : ''}
    ${tonight ? row('soir', 'Ce soir', tonight.r, [rx(tonight), avecTxt(tonight) ? 'avec '+avecTxt(tonight).split(' + ').map(lowFirst).join(' et ') : ''].filter(Boolean).join(' · '), cb(tml, ti, now==='soir')) : ''}
    <div class="td-f">${todo.length?`<ul class="todo">${todo.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}
    ${tomorrow?`<p class="td-tm"><span class="small">Demain soir</span> <b>${esc(tomorrow.r)}</b></p>`:''}
    <p class="td-resto"><span class="small">On mange au resto :</span>${dej ? '<button class="lnk2" data-a="resto" data-m="matin">ce matin</button>' : ''}${midi ? '<button class="lnk2" data-a="resto" data-m="midi">ce midi</button>' : ''}${tonight ? '<button class="lnk2" data-a="resto" data-m="soir">ce soir</button>' : ''}</p></div></div>`;
}
/* Collations : fruits d'abord, puis produits laitiers, puis le reste. */
const SNACK_WORDS = ['clementine','mandarine','pomme','banane','raisin','poire','fraise','bleuet','framboise','melon','cantaloup','ananas','kiwi','mangue','orange','mini-carotte','carottes miniatures','yogourt','yop','danino','minigo','fromage ficelle','ficelle','babybel','compote','pouding','jell','noix','amande','galette de riz','craquelin','ritz','goldfish','bretzel','mais souffle','popcorn','barre','muffin','biscuit','croustille','chips','sucette glacee','popsicle','collation'];
const SNACK_RE = SNACK_WORDS.map(w => new RegExp('\\b'+w));
const SNACK_NO = /pomme de terre|pommes de terre|patate|\bjus\b|tarte|sauce|beurre|vinaigre|croustade|gateau|creme glacee|cidre|gelee|confiture|farine|cereale|\bpain\b|poulet|boeuf|porc|sirop|savon|shampo|nourriture|chien|chat\b|litiere|noix de coco|chocolat a cuire|brisure|pepite|chips de chocolat|boisson|gazeuse|crush|muffins? anglais|nourrisson|bebe/;
function snackSugg(){
  if(S.p.snk===false) return [];
  const used = new Set(buyList().rows.map(r => dealFor(r.name)).filter(Boolean).map(x => x.t));
  const added = new Set((S.menu.sn||[]).map(x => x.t)), seen = new Set(), out = [];
  allSpec().forEach(s => { const t = norm(s.t); if(SNACK_NO.test(t) || used.has(s.t) || added.has(s.t)) return; const i = SNACK_RE.findIndex(re => re.test(t)); if(i>=0) out.push({s, i}); });
  out.sort((a,b) => a.i-b.i || priceOf(a.s)-priceOf(b.s));
  return out.filter(x => { if(seen.has(x.i)) return false; seen.add(x.i); return true; }).slice(0,8).map(x => x.s);
}
function renderSnacks(){
  if(S.p.snk===false) return '';
  const m = S.menu, add = (m.sn||[]).filter(x => !x.src), sug = snackSugg(); if(!add.length && !sug.length) return '';
  const dis = '';
  return `<div class="card"><h3>Collations en spécial</h3><p class="small">Des collations annoncées dans tes circulaires. « Ajouter » en met un paquet dans la liste d'épicerie, pour cette semaine seulement.</p><div class="list">`
    + (m.sn||[]).map((x,j) => [x,j]).filter(([x]) => !x.src).map(([x,j]) => `<div class="item"><span class="t">${tagHtml({t:x.t, p:x.p, s:x.s})}<small>Dans la liste</small></span><button class="btn s" data-a="snrm" data-i="${j}" ${dis}>Retirer</button></div>`).join('')
    + sug.map(s => `<div class="item"><span class="t">${tagHtml(s)}</span><button class="btn s p" data-a="snadd" data-t="${esc(s.t)}" ${dis}>Ajouter</button></div>`).join('')
    + `</div></div>`;
}
let pick = {q:'', r:'', v:0};
/* bouton + : une feuille par-dessus l'écran; plusK = '' (fermée), 'menu' (la liste des ajouts) ou l'ajout ouvert */
let plusK = '', plusFromMenu = false, plusShown = '';
const PLUS = [['plat', 'Ajouter un plat au menu', 'Une envie précise : un plat, une version ou un ingrédient.'],
  ['recois', 'Je reçois ou repas à deux', "Une liste d'épicerie juste pour ce repas."],
  ['reel', 'Importer un reel', "Des captures d'écran deviennent une recette, avec ton Gemini."],
  ['coller', 'Coller une recette', "Copiée d'un site (Ricardo, 5-15…) ou envoyée par quelqu'un."],
  ['nouvelle', 'Nouvelle recette', 'Écrire une recette à la main.'],
  ['acc', 'Nouvel accompagnement', 'Un féculent, un légume ou une salade.'],
  ['frigo', 'Photo du frigo', 'Ton Gemini fait l\'inventaire de Maison à partir de photos.']];
const PLUS_T = {menu:'Ajouter', plat:'Ajouter un plat au menu', recois:'Je reçois ou repas à deux', reel:'Importer un reel', coller:'Coller une recette', nouvelle:'Nouvelle recette', acc:'Nouvel accompagnement', frigo:'Photo du frigo', partager:'Partager'};
function plusBody(k){
  if(k==='menu') return `<div class="plus-l">${PLUS.map(([key, t, d]) => `<button class="plus-i" data-a="plus_open" data-k="${key}"><b>${esc(t)}</b><span>${esc(d)}</span></button>`).join('')}</div>`;
  if(k==='plat'){ openPan.add('pick'); return renderPicker(); }
  if(k==='recois'){ openPan.add('occ'); return renderOcc(); }
  if(k==='frigo'){ openPan.add('inv'); return invCard(); }
  if(k==='partager') return partagerHtml();
  if(['reel','coller','nouvelle','acc'].includes(k)) return `<div class="card list">${recPanel(k)}</div>`;
  return '';
}
function renderPlus(){
  const el = $('#plus'), fab = $('#fab'); if(!el) return;
  const g = groupOf(tab), fabOk = !!S.setup && !storeMode && !cook && (g==='menu' || g==='recettes');
  if(fab) fab.hidden = !fabOk || !!plusK;
  document.body.classList.toggle('has-fab', fabOk);
  if(!plusK){ if(!el.hidden){ el.hidden = true; el.innerHTML = ''; } document.documentElement.classList.remove('plus-on'); plusShown = ''; return; }
  if(plusK==='frigo'){ const mh = $('#tab-maison'); if(mh) mh.innerHTML = ''; }   /* un seul formulaire de photos à la fois */
  const keep = plusShown===plusK ? el.scrollTop : 0;
  const back = plusK!=='menu' && plusFromMenu ? `<button class="btn s" data-a="plus_open" data-k="menu" aria-label="Retour à la liste des ajouts">←</button>` : '';
  el.innerHTML = `<div class="ck-in"><div class="ck-top"><span class="pl-h">${back}<b class="pl-t">${esc(PLUS_T[plusK] || '')}</b></span><button class="btn s" data-a="plus_close">Fermer</button></div><div class="pl-b">${plusBody(plusK)}</div></div>`;
  el.hidden = false; document.documentElement.classList.add('plus-on'); el.scrollTop = keep; plusShown = plusK;
}
/* Je reçois ou repas à deux : quelques plats, un nombre de personnes, une liste juste pour ce repas. */
const occ = () => (S.occ = S.occ || {n:2, items:[], home:true});
function occItems(){ return occ().items.map(x => { const r = byName(x.r); if(!r) return null; const it = {r:x.r, v:x.v||0, pt:occ().n, fm:1, vm:1, ex:[]}; if(kindOf(r)==='souper'){ it.sf = x.sf ?? ''; it.sv = x.sv ?? ''; } return it; }).filter(Boolean); }
function occList(){
  const map = new Map();
  occItems().forEach(it => fullIngs(it).forEach(g => { const [q,u] = normQU(g.name, g.q, g.u), k = keyOf(g.name, u), o = map.get(k); if(o) o.q += q; else map.set(k, {k, q, u, name:g.name, rayon:classer(g.name, g.rayon)}); }));
  const rows = [], home = [];
  map.forEach(n => {
    if(isMaison(n.name)){ home.push(n); return; }
    const sk = occ().home ? stockKey(n) : null, st = sk ? S.stock[sk].q : 0, def = n.q - st;
    if(def <= 0.001){ home.push(n); return; }
    const p = packOf(n.name, n.u), buy = p ? Math.ceil(def/p - 1e-9)*p : n.u==='un' ? Math.max(1, Math.ceil(def - 0.05)) : def;
    rows.push({...n, buy});
  });
  return {rows, home};
}
const occText = () => { const {rows} = occList(), o = occ();
  const L = [`ÉPICERIE - repas pour ${o.n} personne${o.n>1?'s':''}`, occItems().map(it => '• '+it.r+(it.v ? ' ('+vname(vars(byName(it.r))[it.v-1][0])+')' : '')).join('\n'), ''];
  RAYONS.forEach(ray => { const R = rows.filter(r => (r.rayon||'épicerie')===ray); if(!R.length) return; L.push(cap(ray)); R.forEach(r => { const d = dealFor(r.name); L.push(`- ${cap(r.name)} : ${fq(r.buy, r.u).replace('× ','')}${d ? ` (spécial ${specTxt(d)})` : ''}`); }); L.push(''); });
  return L.join('\n').trim(); };
function renderOcc(){
  const o = occ(), its = occItems(), open = openPan.has('occ');
  let body = `<p class="small">Tu reçois, ou c'est un souper en amoureux ? Choisis les plats et le nombre de personnes : l'application fait une liste d'épicerie juste pour ce repas, à part de celle de la semaine. Tu peux aussi le mettre au menu un soir.</p>
    <label class="f">Nombre de personnes<select data-a="occ_n">${[1,2,3,4,5,6,7,8,9,10,12,14,16,18,20,24,30].map(n => `<option ${o.n===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <input type="text" id="oc_q" placeholder="Ajouter un plat : entrée, souper, dessert…" autocomplete="off" aria-label="Ajouter un plat au repas"><div class="list" id="oc_res"></div>
    <button class="lnk2" data-a="avec_occ">Pas eu le temps de faire l'épicerie ? Voir ce qui se fait avec ce qu'on a, pour ${o.n} personne${o.n>1?'s':''}</button>`;
  if(its.length){
    const {rows, home} = occList();
    body += `<div class="list">${its.map((it,j) => { const r = byName(it.r), vs = vars(r); return `<div class="item"><span class="t"><b>${esc(it.r)}</b><small>${esc([KIND1[kindOf(r)], it.v ? 'version '+vname(vs[it.v-1][0]).toLowerCase() : '', kindOf(r)==='souper' ? (avecTxt(it) ? 'avec '+avecTxt(it).split(' + ').map(lowFirst).join(' et ') : 'sans accompagnement') : ''].filter(Boolean).join(' · '))}</small></span><button class="ib_x" data-a="occ_rm" data-j="${j}" aria-label="Retirer">×</button></div>`; }).join('')}</div>
      <label class="check"><input type="checkbox" data-a="occ_home" ${o.home?'checked':''}> Enlever ce qu'il y a déjà à la maison</label>
      <h3 style="font-size:1.05rem">La liste pour ${o.n} personne${o.n>1?'s':''} <span class="small">${rows.length} article${rows.length>1?'s':''}</span></h3>
      <div class="list">${RAYONS.map(ray => { const R = rows.filter(r => (r.rayon||'épicerie')===ray); return R.length ? `<p class="aisle">${esc(cap(ray))}</p>` + R.map(r => { const d = dealFor(r.name); return `<div class="item"><span class="t"><b>${esc(cap(r.name))}</b>${d ? `<span class="tags">${tagHtml(d)}</span>` : ''}</span><span class="q">${fq(r.buy, r.u)}</span></div>`; }).join('') : ''; }).join('')}</div>
      ${home.length ? `<p class="small">Déjà à la maison : ${esc(home.map(x => x.name).join(', '))}.</p>` : ''}
      <div class="acts"><button class="btn p" data-a="occ_copy">Copier la liste</button><button class="btn s d" data-a="occ_clear">Vider</button></div><div class="small" id="occ_msg"></div>
      <div class="pk_sel"><label class="f">Le mettre au menu de la semaine<select id="oc_d">${weekDates().map(d => { const x = mlist('items').find(y => y.d===d); return `<option value="${d}">${esc(dayLbl(d))} ${x ? '— remplace '+esc(x.r) : '— libre'}</option>`; }).join('')}</select></label>
      <button class="btn s" data-a="occ_menu">Mettre au menu pour ${o.n} personne${o.n>1?'s':''}</button><p class="small">Les plats s'ajoutent alors à la liste de la semaine.</p></div>`;
  }
  return `<details class="card pick" data-pan="occ" ${open?'open':''}><summary>Je reçois ou repas à deux</summary>${body}</details>`;
}
function occToMenu(){
  const o = occ(), d = ($('#oc_d')||{}).value || '', L = mlist('items'); let msg = [];
  occItems().forEach(it => { const r = byName(it.r), kd = kindOf(r);
    if(kd==='sauce'){ return; }
    if(kd==='souper'){ const x = mkItem(r, usedSides(L), it.v); Object.assign(x, {pt:o.n, lock:true}); if(it.sf!==undefined) x.sf = it.sf; if(it.sv!==undefined) x.sv = it.sv;
      if(d){ const j = L.findIndex(y => y.d===d); x.d = d; x.dfix = true; if(j>=0){ msg.push(`${r.n} remplace ${L[j].r}`); L[j] = x; } else L.push(x); } else L.push(x);
      linkFollow(x); }
    else mlist(LOFK[kd]).push({r:r.n, v:it.v, pt:o.n, lock:true}); });
  assignDays(false); o.items = []; S.flash = `Repas pour ${o.n} ajouté au menu${d ? ', '+dayLbl(d).toLowerCase() : ''}.${msg.length ? ' '+msg.join('; ')+'.' : ''}`;
}
/* ---------- avec ce qu'on a à la maison ----------
   fitStock : pour une recette et un nombre de portions, ce qui est à la maison et ce qui manque.
   Le sel, le poivre et les autres « toujours à la maison » ne comptent pas. Un peu moins que la quantité (75 %) suffit. */
let STK = null;   /* pendant la création d'un menu « sans épicerie » : ce qui reste à la maison {clé: quantité} */
const stockLeft = () => { const o = {}; Object.entries(S.stock||{}).forEach(([k,v]) => { o[k] = +v.q || 0; }); return o; };
/* condiments et produits de base qu'on a presque toujours sans les noter dans Maison : leur absence ne bloque pas un plat (« à vérifier ») */
const COND_RE = /sauce (bbq|soya|brune|piquante|worcestershire|teriyaki|hoisin|aux huitres|chili|tomate)|ketchup|moutarde|mayonnaise|relish|bouillon|epice|assaisonnement|vinaigre|vinaigrette|sirop|miel|vanille|fecule|poudre|bicarbonate|cassonade|(^|\s)sucre( |$)|sucre a glacer|farine|huile|cacao|paprika|origan|cumin|cannelle|muscade|thym|laurier|herbes|clou de girofle|gingembre moule|piment|flocons|graines de sesame|chapelure|pate de tomates|salsa|tabasco|sriracha|cornichons?|olives|levure|gelatine/;
function fitStock(r, pt, left, v){
  left = left || stockLeft(); const kd = kindOf(r);
  const f = (kd==='souper' || kd==='dejeuner') ? (pt||6)/6 : (pt ? pt/6 : 1);
  const use = {}, have = [], miss = [], verif = []; let wt = 0, hw = 0, protMiss = false;
  effective(r, v||0).forEach(g => {
    if(isMaison(g.name)) return;
    const [q, u] = normQU(g.name, scaleQ(g.q, g.u, f), g.u);
    const sk = stockKey({k:keyOf(g.name, u), name:g.name, u, q});
    const ray = classer(g.name, g.rayon), prot = ray==='viandes' || ray==='poissonnerie';
    const cond = !prot && (COND_RE.test(norm(g.name)) || (u==='ml' && q <= 30) || (u==='g' && q <= 30));
    const w = prot ? 3 : cond ? .3 : 1; wt += w;
    const av = sk ? Math.max(0, (left[sk]||0) - (use[sk]||0)) : 0;
    if(sk && av >= q * .75){ hw += w; use[sk] = (use[sk]||0) + Math.min(q, av); have.push(g.name); }
    else if(cond) verif.push(g.name);
    else { miss.push(g.name); if(prot) protMiss = true; }
  });
  return {use, have, miss, verif, protMiss, score: wt ? hw/wt : 0, ok: !miss.length && have.length > 0, presque: !protMiss && miss.length === 1 && have.length > 0};
}
/* accompagnements tirés de la maison : ceux qui se font avec ce qui reste, sinon aucun */
function maisonSides(it, r, pt, left){
  [['f','sf'],['v','sv']].forEach(([sl, key]) => {
    const okS = sd => sd && fitStock({n:sd.n, i:sd.i, k:'souper'}, pt, left).ok, cur = sideById(it[key]);
    const c = cur && okS(cur) ? cur : sidesOf(sl).filter(sd => compat(sd, r) && !(sl==='f' && clash(sd, r)) && okS(sd)).sort((a,b) => (b.id.startsWith('st:')?1:0) - (a.id.startsWith('st:')?1:0))[0];
    it[key] = c ? c.id : '';
    if(c){ const fs = fitStock({n:c.n, i:c.i, k:'souper'}, pt, left); Object.entries(fs.use).forEach(([k,q]) => { left[k] = Math.max(0, (left[k]||0) - q); }); }
  });
  it.ovr = {f:true, v:true};
}
/* pendant un menu « sans épicerie » : la recette doit se faire avec ce qui reste, puis on retire ce qu'elle utilise */
const stkOk = (r, pt) => !STK || fitStock(r, pt, STK).ok;
const stkUse = (r, pt) => { if(!STK || !r) return; const f = fitStock(r, pt, STK); Object.entries(f.use).forEach(([k,q]) => { STK[k] = Math.max(0, (STK[k]||0) - q); }); };
let avec = {n:0, k:'souper', all:false, r:'', cm:''};
/* ---------- jumeler les plats : ambiance, même appareil, pas les mêmes ingrédients ---------- */
const THEMES = [['tailgate',/poppers|jalap|\bailes\b|nachos|rondelles|bretzel|buffalo|queso|pelures|burger|hot-?dog|michigan|poutine|cotes levees|brisket|effiloch|smash|slider|bratwurst|fish|pogo|bouts de cotes|mac and cheese|mac n cheese|grilled cheese|sous-marin|philly|cubain|club sandwich/],
  ['mex',/tacos?\b|fajita|quesadilla|burrito|nachos|guacamole|queso|enchilada|mexicain|salsa/],
  ['asia',/soya|teriyaki|general tao|ramen|egg roll|\bwok\b|sesame|pad thai|bulgogi|gochujang|tonkinoise|chow mein|chop suey|sushi|rouleaux de printemps|poulet a l.orange/],
  ['italien',/pizza|lasagne|spaghetti|bruschetta|caprese|tortellini|gnocchi|carbonara|alfredo|parmesan|pesto|primavera|minestrone|crostini|tiramisu/],
  ['grec',/grec|souvlaki|shish|taouk|tzatziki|hummus|\bpitas?\b|agneau/],
  ['fin',/tartare|petoncle|saumon|tournedos|filet mignon|cote de boeuf|contre-filet|picanha|creme brulee|fondant|moules|canard|\bbrie\b|chevre|pavlova/],
  ['quebec',/pate chinois|tourtiere|pate a la viande|ragout|cretons|feves au lard|pouding chomeur|tarte au sucre|soupe aux pois|jambon|cabane|hachis|pouding au pain|grands-peres/]];
const THEME_TXT = {tailgate:'ambiance pub', mex:'ambiance mexicaine', asia:'saveurs asiatiques', italien:"à l'italienne", grec:'à la grecque', fin:'souper raffiné', quebec:'classique québécois'};
function themesOf(r){
  const st = styOf(r), t = norm(r.n), s = new Set(THEMES.filter(([,re]) => re.test(t)).map(([k]) => k));
  const ex = r.st || [];   /* styles notés dans la recette (pas ceux devinés d'après le nom) */
  if(kindOf(r)!=='dessert' && (ex.includes('pub') || ex.includes('fumoir'))) s.add('tailgate');
  if(st.includes('mex')) s.add('mex'); if(st.includes('asia')) s.add('asia'); if(st.includes('pates')) s.add('italien');
  return s;
}
const applOf = r => { const ex = r.st || [], t = norm(r.s||'').replace(/sauce bbq/g, ''); return {fumoir: ex.includes('fumoir') || /fumoir|\bfumer\b/.test(t), bbq: /\bbbq\b|\bgrill\b|barbecue/.test(t), plancha: ex.includes('plancha') || /plancha/.test(t)}; };
const lourds = r => new Set(effective(r, 0).filter(g => !isMaison(g.name) && !COND_RE.test(norm(g.name))).flatMap(g => sigWords(g.name)));
function pairWith(r, n){
  const kd = kindOf(r), A = applOf(r), T = themesOf(r), fr = famOf(r), heavy = lourds(r), left = stockLeft(), hasStock = Object.keys(S.stock||{}).length > 0;
  const targets = kd==='souper' ? ['entree','dessert'] : ['souper','dessert'];
  return targets.map(k => {
    const C = allRecipes().filter(c => kindOf(c)===k && c.n!==r.n && !S.dis[c.n] && !softBad(c) && !c.ur && (k!=='dessert' || simpleOk(c)) && !(fr && famOf(c)===fr));
    const L = C.map(c => { const why = []; let s = 0; const Tc = themesOf(c), Ac = applOf(c);
      const common = [...T].filter(x => Tc.has(x)).sort((a,b) => (a==='tailgate') - (b==='tailgate'));
      common.forEach((x, j) => { s += j ? 1.5 : x==='tailgate' ? 2.5 : 3.5; }); if(common.length) why.push(THEME_TXT[common[0]]);
      if(A.fumoir && Ac.fumoir){ s += 2.5; why.push('même fumoir'); }
      else if((A.bbq || A.fumoir || A.plancha) && (Ac.bbq || Ac.plancha)){ s += k==='dessert' ? 2 : 1.5; why.push(k==='dessert' ? 'sur le BBQ, à la fin' : 'le BBQ sera déjà chaud'); }
      const ov = new Set([...lourds(c)].filter(w => heavy.has(w))); s -= Math.min(2.4, ov.size * .8);
      if(k==='souper' && tmOf(c) > 150) s -= 2.5;   /* ce soir : pas un brisket de 12 h */
      if(k==='souper' && tpOf(c) <= 30) s += .3;
      if(k==='souper' && kd!=='souper' && /^(ailes|nachos|pogo|doigts|croquettes)/.test(norm(c.n))) s -= .8;   /* avec une bouchée : un vrai plat principal d'abord */
      let f = null; if(hasStock){ f = fitStock(c, k==='souper' ? n : 0, left); if(f.ok){ s += 2; why.push('tout est à la maison'); } else if(f.presque){ s += .8; why.push('il manque : ' + lowFirst(f.miss[0])); } }
      if(S.fav[c.n]) s += .6; const rt = (S.rate||{})[c.n]; if(rt && rt.up > rt.down) s += .5;
      return {r:c, s, why, f}; }).sort((a,b) => b.s - a.s || a.r.n.localeCompare(b.r.n, 'fr'));
    return {k, L:L.filter(x => x.s > .5).slice(0, k==='dessert' ? 3 : 5)};
  });
}
const PAIR_T = {souper:'Un plat principal', entree:'Une entrée', dessert:'Un dessert'};
/* le plat choisi et la suggestion, ce soir */
function avecPairToMenu(names){
  const n = avecN(), msgs = [];
  names.forEach(nm => { const r = byName(nm); if(!r) return; const kd = kindOf(r);
    if(kd==='souper'){ avecToMenu(nm); msgs.push(S.flash.replace(/\.$/, '')); }
    else { mlist(LOFK[kd] || 'ent').push({r:r.n, v:0, pt:n, lock:true}); msgs.push(`${r.n} ajouté${kd==='entree' ? 'e' : ''} ${kd==='entree' ? 'aux entrées' : kd==='dessert' ? 'aux desserts' : 'au menu'}`); } });
  S.flash = msgs.join('. ') + '.';
}
const avecN = () => avec.n || totalPortions();
function avecList(){
  const left = stockLeft(), n = avecN(), out = [];
  allRecipes().forEach(r => { if(kindOf(r)!==avec.k || S.dis[r.n] || softBad(r) || r.ur) return;
    const f = fitStock(r, n, left); if(!f.ok && !f.presque) return; if(!f.have.length && !f.ok) return;
    out.push({r, f, s: (f.ok ? 10 : 0) + f.score*3 + f.have.length*.15 + (S.fav[r.n] ? .5 : 0) - f.miss.length*.8 - f.verif.length*.25}); });
  return out.sort((a,b) => b.s - a.s);
}
function renderGout(n){
  const r = avec.r ? byName(avec.r) : null;
  let b = `<label class="f">J'ai le goût de…<input type="text" id="avec_q" placeholder="ex. jalapeños poppers, côtes levées, tiramisu" autocomplete="off"></label><div class="list" id="avec_res"></div>`;
  if(!r) return b;
  const P = pairWith(r, n), kd = kindOf(r), M = methods(r), ck = cmOf(r, avec.cm) ? avec.cm : '', fm = fastM(r), mc = M.find(m => m.k===ck);
  const cmH = M.length ? `<p class="small" style="margin-top:10px"><b>Comment le faire</b></p><div class="seg" role="group" aria-label="Façon de cuire">${M.map(m => `<button class="${m.k===ck?'on':''}" data-a="avec_cm" data-k="${m.k}">${esc(m.l)} <small>${esc(fmtMin(m.tm))}</small></button>`).join('')}</div>
    <p class="small">${esc(mc.l)} : ${esc(tmTxtM(r, ck))}.${ck==='mj' ? ' À partir le matin.' : fm && fm.k===ck ? ' Le plus rapide.' : fm ? ` Plus rapide : ${esc(fm.l.toLowerCase())}, ${esc(fmtMin(fm.tm))} au total.` : ''}</p>` : '';
  const row = x => `<div class="item avr"><span class="t"><b>${esc(x.r.n)}</b><small>${esc([kindOf(x.r)==='souper' ? tmShort(x.r) : '', ...x.why].filter(Boolean).join(' · '))}</small>${x.f && x.f.verif.length && x.f.ok ? `<small>À vérifier : ${esc(x.f.verif.map(lowFirst).join(', '))}</small>` : ''}</span>
    <span class="acts"><button class="btn s" data-a="cook" data-r="${esc(x.r.n)}" data-pt="${n}" data-ms="1">Recette</button><button class="btn s p" data-a="avec_pair" data-r="${esc(x.r.n)}">Ce soir, ensemble</button></span></div>`;
  return b + `<div class="pk_sel"><p class="small">Ton choix : <b>${esc(r.n)}</b> (${esc(lowFirst(KIND1[kd] || ''))}).</p>${cmH}<p class="small" style="margin-top:10px">Avec quoi le jumeler :</p>
    ${P.map(g => g.L.length ? `<p class="aisle">${esc(PAIR_T[g.k])}</p><div class="list">${g.L.map(row).join('')}</div>` : '').join('')}
    <div class="acts"><button class="btn s" data-a="cook" data-r="${esc(r.n)}" data-pt="${n}" data-ms="1" data-cm="${ck}">Recette : ${esc(r.n)}${ck ? ' ('+esc(CM_L[ck].toLowerCase())+')' : ''}</button><button class="btn s" data-a="avec_clear">Choisir un autre plat</button></div></div>`;
}
function renderAvec(){
  const open = openPan.has('avec'), nst = Object.keys(S.stock||{}).filter(k => !isMaison(S.stock[k].name)).length, n = avecN();
  let body = `<p class="small">Pars d'un plat dont tu as le goût : l'application propose avec quoi le jumeler. Ou pars de ce qu'il y a à la maison, quand l'épicerie n'est pas faite ou que la visite arrive.</p>
    <label class="f">Personnes<select data-a="avec_n">${[1,2,3,4,5,6,7,8,9,10,12,14,16,18,20,24].concat([n]).filter((v,j,a) => a.indexOf(v)===j).sort((a,b) => a-b).map(v => `<option value="${v}" ${v===n?'selected':''}>${v}</option>`).join('')}</select></label>`;
  if(open) body += renderGout(n);
  body += `<h3 style="font-size:1.05rem;margin-top:6px">Avec ce qu'on a à la maison</h3>`;
  if(!nst) return `<details class="card pick" data-pan="avec" ${open?'open':''}><summary>Ce soir, on mange quoi ?</summary>${body}<p class="note">Ta liste Maison est vide. Ajoute ce que tu as au frigo, au congélateur et au garde-manger (Épicerie → Maison) : l'application pourra ensuite te proposer des plats.</p></details>`;
  body += `<label class="f">Quoi<select data-a="avec_k">${[['souper','Un repas'],['entree','Une entrée'],['dessert','Un dessert'],['dejeuner','Un déjeuner']].map(([k,t]) => `<option value="${k}" ${avec.k===k?'selected':''}>${t}</option>`).join('')}</select></label>`;
  if(open){
    const L = avecList(), ok = L.filter(x => x.f.ok), pr = L.filter(x => !x.f.ok), show = avec.all ? 30 : 6;
    const row = x => `<div class="item avr"><span class="t"><b>${esc(x.r.n)}</b><small>${esc(tmShort(x.r))}</small>${x.f.miss.length ? `<small class="avm">Il manque : ${esc(x.f.miss.map(lowFirst).join(', '))}</small>` : ''}${x.f.verif.length ? `<small>À vérifier : ${esc(x.f.verif.map(lowFirst).join(', '))}</small>` : ''}</span>
      <span class="acts"><button class="btn s p" data-a="cook" data-r="${esc(x.r.n)}" data-pt="${n}" data-ms="1">Cuisiner</button>${avec.k==='souper' ? `<button class="btn s" data-a="avec_menu" data-r="${esc(x.r.n)}">Ce soir</button>` : ''}</span></div>`;
    body += ok.length ? `<p class="aisle">Tout est à la maison</p><div class="list">${ok.slice(0, show).map(row).join('')}</div>` : `<p class="small"><b>Aucun plat complet</b> avec ce qu'il y a dans Maison pour ${n} personne${n>1?'s':''}.</p>`;
    if(pr.length) body += `<p class="aisle">Il manque un article</p><div class="list">${pr.slice(0, show).map(row).join('')}</div>`;
    if(ok.length > show || pr.length > show) body += `<button class="lnk2" data-a="avec_all">${avec.all ? 'Moins de choix' : 'Plus de choix'}</button>`;
    body += `<div class="pk_sel"><p class="small"><b>Une semaine sans épicerie ?</b> Crée le menu des soupers seulement avec ce qu'il y a à la maison. Les plats se partagent ce qu'il y a : deux soupers ne comptent pas sur le même poulet. Les accompagnements aussi viennent de la maison.</p>
      <button class="btn s" data-a="avec_sem" data-armed="0">Menu de la semaine avec ce qu'on a</button></div>`;
  }
  return `<details class="card pick" data-pan="avec" ${open?'open':''}><summary>Ce soir, on mange quoi ?</summary>${body}</details>`;
}
/* au menu ce soir (ou le premier jour du menu), pour le nombre de personnes choisi */
function avecToMenu(name){
  const r = byName(name); if(!r) return; const L = mlist('items'), ds = weekDates(), td = isoToday(), d = ds.includes(td) ? td : ds[0];
  const x = mkItem(r, usedSides(L), 0); Object.assign(x, {pt:avecN(), lock:true, d, dfix:true}); if(name===avec.r && cmOf(r, avec.cm)) x.cm = avec.cm;
  const left = stockLeft(); Object.entries(fitStock(r, avecN(), left).use).forEach(([k,q]) => { left[k] = Math.max(0, left[k] - q); }); maisonSides(x, r, avecN(), left);
  const j = L.findIndex(y => y.d===d); let msg = `${r.n} est au menu ${d===td ? 'ce soir' : dayLbl(d).toLowerCase()}`;
  if(j >= 0){ msg += `, à la place de ${L[j].r}`; L[j] = x; } else L.push(x);
  linkFollow(x); assignDays(false); S.flash = msg + '.';
}
/* menu de la semaine « sans épicerie » : seulement ce qu'il y a à la maison */
function genMenuMaison(){
  STK = stockLeft();
  try{
    const m = S.menu, shop = shopISO(), start = startFrom(shop), nm = {date:fmtDate(start), start, shop, chk:{}, extra:{}, achete:false, snap:null, useup:m.useup||{}, sn:m.date ? (m.sn||[]) : [], dinCook:{}, dinNo:{}, dsel:m.dsel||{}, maison:true};
    ['items','dej','ent','sou','des'].forEach(l => { nm[l] = fill(nOf(l), [], l); });
    /* accompagnements : seulement ce qui se fait avec la maison, sinon aucun */
    nm.items.forEach(it => { const r = byName(it.r); if(r) maisonSides(it, r, portionsOf(it), STK); });
    nm.din = [];
    S.menu = nm; assignDays(true); assignDej(true); syncDin(true); resetCaches();
    const n = nm.items.length, want = nOf('items'), rows = buyList().rows;
    S.flash = n ? `Menu fait avec ce qu'il y a à la maison : ${n} souper${n>1?'s':''}${n < want ? ` (seulement ${n} possible${n>1?'s':''} sur ${want})` : ''}. ${rows.length ? `La liste n'a plus que ${rows.length} article${rows.length>1?'s':''}, surtout du garde-manger et des condiments : vérifie ce que tu as déjà.` : 'Rien à acheter.'}`
      : `Pas assez à la maison pour un souper complet. Ajoute ce que tu as dans Maison, ou regarde « Il manque presque rien ».`;
  } finally { STK = null; }
  save(); render();
}
function pickSearch(q){
  const n = norm(q).trim(); if(n.length < 2) return [];
  const sq = x => x.replace(/(.)\1+/g, '$1'), words = n.split(/\s+/).map(sq), out = [];
  allRecipes().forEach(r => {
    if(S.dis[r.n]) return;
    const nm = sq(norm(r.n+' '+(Array.isArray(r.al) ? r.al.join(' ') : ''))), base = sq(norm(r.n+' '+(r.m||[]).join(' ')+' '+r.i.map(g => g[2]).join(' ')));
    const vs = vars(r); let v = 0, score = 0;
    if(words.every(w => nm.includes(w))) score = 3;
    else if(words.every(w => base.includes(w))) score = 1;
    const vi = vs.findIndex(x => words.every(w => sq(norm(x[0])).includes(w) || nm.includes(w)));
    if(vi >= 0 && score < 3){ v = vi+1; score = Math.max(score, 2); }
    if(score) out.push({r, v, score});
  });
  return out.sort((a,b) => b.score-a.score || a.r.n.localeCompare(b.r.n,'fr')).slice(0, 8);
}
const pickRows = q => { const L = pickSearch(q); if(!L.length) return norm(q).trim().length>=2 ? '<p class="small">Aucun plat trouvé. Essaie un autre mot, ou crée la recette dans l\'onglet Recettes.</p>' : '';
  return L.map(x => { const vs = vars(x.r); return `<div class="item"><span class="t"><b>${esc(x.r.n)}</b><small>${esc([KIND1[kindOf(x.r)], x.v ? 'version '+vname(vs[x.v-1][0]).toLowerCase() : '', tmShort(x.r)].filter(Boolean).join(' · '))}</small></span><button class="btn s" data-a="pk_pick" data-r="${esc(x.r.n)}" data-v="${x.v}">Choisir</button></div>`; }).join(''); };
function renderPicker(){
  const m = S.menu;
  const r = pick.r ? byName(pick.r) : null, open = openPan.has('pick') || !!r;
  let chosen = '';
  if(r){
    const kd = kindOf(r), vs = vars(r), L = mlist('items');
    const verSel = vs.length ? `<label class="f">Version<select data-a="pk_v">${['Normale'].concat(vs.map(x => vname(x[0]))).map((nm,j) => `<option value="${j}" ${pick.v===j?'selected':''}>${esc(nm)}</option>`).join('')}</select></label>` : '';
    let where = '';
    if(kd==='souper' && pick.meal==='din'){
      const P = dinPlan(), ds = weekDates(), st = d => P.find(x => x.d===d);
      const first = (pick.d && ds.includes(pick.d) && pick.d) || ds.find(d => { const p = st(d); return p && !p.it && !p.rest; }) || ds.find(d => !st(d)) || ds[0];
      where = `<div class="seg" role="group" aria-label="Repas"><button data-a="pk_meal" data-v="items">Au souper</button><button class="on" data-a="pk_meal" data-v="din">Au dîner</button></div>
        <label class="f">Quel jour ?<select id="pk_d">${ds.map(d => { const p = st(d); return `<option value="${d}" ${d===first?'selected':''}>${esc(dayLbl(d))} ${p && p.it ? '— remplace '+esc(p.it.r) : p && p.rest ? '— au lieu des restes de '+esc(p.rest.r) : '— libre'}</option>`; }).join('')}</select></label>`;
    } else if(kd==='dejeuner'){
      const D = mlist('dej'), ds = weekDates(), free = ds.find(d => !D.some(x => x.d===d)) || '';
      where = `<label class="f">Quel jour ?<select id="pk_d">${ds.map(d => { const o = D.find(x => x.d===d); return `<option value="${d}" ${d===free?'selected':''}>${esc(dayLbl(d))}${isOff(d)?' (congé)':''} ${o ? '— remplace '+esc(o.r) : '— libre'}</option>`; }).join('')}<option value="" ${free?'':'selected'}>En plus, sans jour précis</option></select></label>`;
    } else if(kd==='souper'){
      const ds = weekDates(), free = ds.find(d => !L.some(x => x.d===d)) || '';
      where = `<div class="seg" role="group" aria-label="Repas"><button class="on" data-a="pk_meal" data-v="items">Au souper</button><button data-a="pk_meal" data-v="din">Au dîner</button></div>
        <label class="f">Quel jour ?<select id="pk_d">${ds.map(d => { const o = L.find(x => x.d===d); return `<option value="${d}" ${d===free?'selected':''}>${esc(dayLbl(d))}${isOff(d)?' (congé)':''} ${o ? '— remplace '+esc(o.r) : '— libre'}</option>`; }).join('')}<option value="" ${free?'':'selected'}>En plus, sans jour précis</option></select></label>`;
    } else if(kd==='sauce'){
      where = L.length ? `<label class="f">Avec quel plat ?<select id="pk_d">${L.map((x,j) => `<option value="${j}">${esc((x.d ? dayLbl(x.d)+' : ' : '')+x.r)}${x.sc ? ' (remplace '+esc(x.sc)+')' : ''}</option>`).join('')}</select></label>` : '<p class="note">Crée d\'abord le menu ou ajoute un souper : la sauce s\'ajoute à un plat.</p>';
    } else where = `<p class="small">S'ajoute aux ${esc(KINDS[kd].toLowerCase())} de la semaine.</p>`;
    chosen = `<div class="pk_sel"><p class="dname">${esc(r.n)}</p>${verSel}${where}
      <div class="acts"><button class="btn p" data-a="pk_add" ${kd==='sauce' && !L.length ? 'disabled' : ''}>${kd==='sauce' ? 'Ajouter la sauce' : 'Ajouter au menu'}</button><button class="btn s" data-a="pk_cancel">Annuler</button></div></div>`;
  }
  return `<details class="card pick" data-pan="pick" ${open?'open':''}><summary>Ajouter un plat de mon choix</summary>
    ${pick.msg ? `<p class="note">${esc(pick.msg)}</p>` : ''}
    <p class="small">${pick.meal==='din' && pick.d ? `Pour le dîner de ${esc(dayLbl(pick.d).toLowerCase())} : cherche un plat dans la banque des soupers.` : "Une envie ? Cherche un plat, une version ou un ingrédient : burger Nashville, smash burger, saumon, soupe… Il reste au menu quand tu le refais."}</p>
    ${chosen || `<input type="text" id="pk_q" value="${esc(pick.q)}" placeholder="Burger, Nashville, saumon, potage…" autocomplete="off" aria-label="Chercher un plat"><div class="list" id="pk_res">${pickRows(pick.q)}</div>`}</details>`;
}
function addPicked(){
  const r = byName(pick.r); if(!r) return;
  const kd = kindOf(r), sel = $('#pk_d'), d = sel ? sel.value : '';
  let msg = '';
  if(kd==='sauce'){ const it = mlist('items')[+d]; if(!it) return; it.sc = r.n; msg = `${r.n} ajoutée à ${it.r}.`; }
  else {
    const l = kd==='souper' && pick.meal==='din' ? 'din' : LOFK[kd], L = mlist(l);
    if(l==='items' || l==='din' || l==='dej'){
      const it = l==='dej' ? {r:r.n, v:pick.v} : mkItem(r, usedSides(L), pick.v); it.lock = true; if(l==='din') it.din = true;
      if(d){
        if(l==='din'){ if(restesAvail(d)) S.menu.dinCook = Object.assign(S.menu.dinCook||{}, {[d]:true}); if(S.menu.dinNo) delete S.menu.dinNo[d]; }
        const j = L.findIndex(x => x.d===d); it.d = d; it.dfix = true; if(j>=0){ msg = `${r.n} remplace ${L[j].r}.`; L[j] = it; } else L.push(it); } else L.push(it);
      if(l==='items'){ linkFollow(it); assignDays(false); } else if(l==='dej') assignDej(false); else syncDin(false);
      msg = msg || `${r.n} ajouté ${l==='items' ? 'au souper' : l==='din' ? 'au dîner' : 'au déjeuner'}${it.d ? ', '+dayLbl(it.d).toLowerCase() : ''}.`;
    } else { L.push({r:r.n, v:pick.v, lock:true}); msg = `${r.n} ajouté aux ${KINDS[kd].toLowerCase()}.`; }
  }
  pick = {q:'', r:'', v:0, msg}; openPan.add('pick'); save(); render();
}
function renderPP(){
  if(S.p.pp==='never') return '';
  const inM = new Set(allItems().map(x => x.r));
  const L = allRecipes().filter(r => r.pp && !S.dis[r.n] && !inM.has(r.n)).map(r => ({r, d:dealsOf(r)})).filter(x => x.d.length);
  if(!L.length) return '';
  return `<div class="card"><h3>Plats préparés en spécial</h3><p class="small">Prêts à servir et en spécial dans tes circulaires. Pratique pour un soir pressé.</p><div class="list">${L.map(x => `<div class="item"><span class="t"><b>${esc(x.r.n)}</b><span class="tags">${tagHtml(x.d[0].hit)}</span></span><button class="btn s" data-a="addrec" data-r="${esc(x.r.n)}" ${S.menu.achete?'disabled':''}>Ajouter</button></div>`).join('')}</div></div>`;
}
function renderMenu(){
  const el = $('#tab-menu'); const m = S.menu; let h = '';
  if(m.date) assignDays(false);
  if(!S.setup){ el.innerHTML = `<div class="card call"><h3>Bienvenue</h3><p class="small">Commence par décrire ta famille et ton horaire : ça prend une minute.</p><div class="acts"><button class="btn p" data-a="view" data-v="semaine">Commencer</button></div></div>`; return; }
  else if(!S.help) h += `<div class="card call"><h3>Première fois ?</h3><p class="small">L'aide explique comment installer l'application sur ${IOS ? "l'iPhone" : 'ton téléphone'}, préparer la première semaine et copier la liste.</p><div class="acts">${instBtn()}<button class="btn s p" id="help_open">Lire l'aide</button><button class="btn s" id="help_hide">Plus tard</button></div></div>`;
  h += `<p class="note" id="flash" ${S.flash ? '' : 'hidden'}>${esc(S.flash||'')}</p>`; S.flash = '';
  if(bkBar && S.setup && S.p.bkOpen!==false && (S.bkDirty || !S.lastExport))
    h += `<div class="bkbar"><span><b>Sauvegarde</b> Des changements depuis ta dernière copie${S.lastExport ? ' ('+esc(dShort(S.lastExport))+')' : ''}.</span><button class="btn s p" id="bk_file">Sauvegarder</button><button class="ib_x" data-a="bk_hide" aria-label="Pas maintenant">×</button></div>`;
  { const n = Object.keys(S.stock||{}).length + (S.custom||[]).length*3 + Object.keys(S.prices||{}).length, old = !S.lastExport || addDays(S.lastExport, 30) < isoToday();
    if(S.p.bkOpen===false && S.setup && n >= 10 && old && !(S.bkSnooze && S.bkSnooze > isoToday())) h += `<div class="card"><h3>Protège tes données</h3><p class="small">${S.lastExport ? 'Ta dernière copie dans ' + FICH + ' date de plus d\'un mois.' : 'Ton garde-manger et tes recettes ne sont gardés que sur ce téléphone.'} Une copie dans ${FICH} les protège si l'icône est supprimée ou si tu changes de téléphone.</p><div class="acts"><button class="btn s p" data-a="bk_go">Faire une copie</button><button class="btn s" data-a="bk_later">Plus tard</button></div></div>`; }
  if(m.date && m.eb) h += `<p class="note">C'est l'ébauche du menu. Réponds aux questions et bâtis le menu final dans Aujourd'hui. <button class="btn s" data-a="view" data-v="semaine">Voir l'ébauche</button></p>`;
  h += semaineCard();
  if(!m.date){
    LISTS.forEach(l => { const L = mlist(l); if(!L.length) return; h += `<h2 class="sec">Tes choix : ${LBL[l].toLowerCase()}<span>${L.length}</span></h2><div class="sheet">${L.map((it,i) => carte(it,i,l)).join('')}</div>`; });
    h += `<div class="empty"><b>Pas encore de menu cette semaine</b><span>« Préparer ma semaine » pose quelques questions, montre une ébauche, puis bâtit le menu final et la liste.</span><span>Une envie précise ? Le bouton + ajoute d'avance un plat de ton choix.</span></div>`;
  } else {
    if(m.achete) h += `<p class="note">Épicerie faite. Tu peux encore changer les plats, les portions ou ajouter un repas : ce qui manque s'ajoute à la liste, sous « À acheter en plus ».</p>`;
    LISTS.forEach(l => {
      if(l==='din'){ const P = dinPlan(); if(!P.length) return; const nr = P.filter(p => p.rest).length;
        h += `<h2 class="sec">Dîners<span>${P.length}</span></h2>${nr && S.p.dinRestes!==false ? `<p class="small secnote">Le midi, les restes du souper de la veille d'abord. Les autres jours, un plat de la banque des soupers pour ${pDin()} portion${pDin()>1?'s':''}.</p>` : ''}<div class="sheet">${P.map(p => p.it ? carte(p.it, p.i, 'din') : restRow(p)).join('')}</div>`; return; }
      const L = mlist(l); if(!L.length && !nOf(l)) return;
      h += `<h2 class="sec">${LBL[l]}<span>${L.length}</span></h2>`;
      const ord = L.map((it,i) => [it,i]); if(['items','dej','ent','sou'].includes(l)) ord.sort((a,b) => (a[0].d||'9').localeCompare(b[0].d||'9'));
      if(ord.length) h += `<div class="sheet">${ord.map(([it,i]) => carte(it,i,l)).join('')}</div>`; });
    h += renderReport();
    h += renderPP();
    h += renderSnacks();
    h += renderUtiliser();
    if(!(m.start && m.start > isoToday())) h += `<div class="card"><h3>Fin de la semaine</h3><p class="small">Retire de la maison ce qui a été utilisé, garde les restes et range les plats dans l'historique pour ne pas les répéter.</p><button class="btn p" id="fin" data-armed="0">Terminer la semaine</button></div>`;
  }
  if(S.hist.length) h += `<button class="btn wide" data-a="view" data-v="historique">Semaines passées (${S.hist.length})</button>`;
  el.innerHTML = h;
}

/* ---------- rendu : épicerie ---------- */
let storeMode = false, wakeLock = null;
async function lockScreen(on){
  try{
    if(on && 'wakeLock' in navigator && !wakeLock){ wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => { wakeLock = null; }); }
    else if(!on && wakeLock){ await wakeLock.release(); wakeLock = null; }
  }catch(e){}
}
document.addEventListener('visibilitychange', () => { if(storeMode && document.visibilityState==='visible') lockScreen(true); });
const mainStore = () => { const go = goStores(); return (S.p.main && go.includes(S.p.main) ? S.p.main : go[0]) || S.p.main || S.stores[0] || 'Mon épicerie'; };
/* l'épicerie d'un article : la principale de la semaine, sauf si une autre épicerie de la semaine est nettement moins chère */
const storeOf = r => assign(r, goStores(), mainStore());
function specTotal(rows){ let t = 0, n = 0; rows.forEach(r => { const d = dealFor(r.name), c = d ? dealCost(d, r) : null; if(c != null){ t += c; n++; } }); return {t, n}; }
/* ordre des rayons : celui choisi dans Profil → Épiceries (le parcours du magasin ou de l'appli), sinon l'ordre de base */
const rayOrder = () => { const o = (isObj(S.profil) && Array.isArray(S.profil.rayons)) ? S.profil.rayons.filter(r => RAYONS.includes(r)) : []; return o.concat(RAYONS.filter(r => !o.includes(r))); };
/* recherche du produit sur le site de l'épicerie, pour remplir le panier en ligne */
const SHOP_URL = {Maxi:'https://www.maxi.ca/fr/search?search-bar=', Provigo:'https://www.provigo.ca/fr/search?search-bar=', IGA:'https://www.iga.net/fr/search?k=', Metro:'https://www.metro.ca/epicerie-en-ligne/recherche?filter=', Walmart:'https://www.walmart.ca/fr/search?q=', Costco:'https://www.costco.ca/CatalogSearch?keyword='};
const shopLink = (r, store) => { const u = SHOP_URL[store]; if(!u) return ''; const q = plain(r.name).replace(/\s+\b(pour|de la|du|des)\b.*$/i, '');
  return `<a class="shopl" href="${u}${encodeURIComponent(q)}" target="_blank" rel="noopener">Chercher chez ${esc(store)} ↗</a>`; };
function groupsOf(rows){
  const byRay = list => rayOrder().map(ray => ({ray, rows:list.filter(r => r.rayon===ray).sort((a,b) => a.name.localeCompare(b.name,'fr'))})).filter(g => g.rows.length);
  if(S.p.grp==='magasin'){
    const ms = mainStore(), stores = [...new Set(rows.map(storeOf))].sort((a,b) => a===ms ? -1 : b===ms ? 1 : a.localeCompare(b,'fr'));
    return stores.map(s => ({title:s, sub:byRay(rows.filter(r => storeOf(r)===s))}));
  }
  return byRay(rows).map(g => ({title:cap(g.ray), sub:[{ray:'', rows:g.rows}]}));
}
function rowHtml(r, m){
  const e = rowEco(r), d = e.deal, pk = packInfo(r), hl = !d && !storeMode ? histLine(r.name) : '';
  return `<label class="item ${m.chk[r.k]?'done':''}"><input type="checkbox" data-a="chk" data-k="${esc(r.k)}" ${m.chk[r.k]?'checked':''}>
    <span class="t"><b>${esc(cap(r.name))}</b>${S.p.cmd && !storeMode ? shopLink(r, S.p.grp==='magasin' ? storeOf(r) : mainStore()) : ''}${d?`<span class="tags">${tagHtml(d)}${storeMode ? '' : `<a href="#" class="fixl" data-a="ar_go" data-b="${esc(artB(r.name))}">Pas le bon ?</a>`}</span>`: e.rsp ? `<span class="tags"><span class="flag">Promo ${esc(e.store)}${e.rsp.fin ? ' jusqu\'au ' + esc(dShort(e.rsp.fin)) : ''}</span></span><small>${esc(e.rsp.nom)}</small>` : ''}${pk?`<small>${esc(pk)}</small>`:''}${hl?`<small class="hist">${esc(hl)}</small>`:''}${!storeMode && r.st>0?`<small>Il en faut ${fq(r.q,r.u)}, il y en a déjà ${fq(r.st,r.u)} à la maison</small>`:''}${!storeMode && r.src.length?`<small>${esc(r.src.slice(0,3).join(', '))}${r.src.length>3?'…':''}</small>`:''}${cmpLine(r)}</span>
    <span class="qcol"><span class="q">${fq(r.buy,r.u)}</span>${priceBtn(r)}</span></label>`;
}
function cmpLine(r){ const c = cheaper(r); if(!c) return '';
  return `<small class="cmp">${c.sp ? 'En spécial' : 'Moins cher'} chez ${esc(c.store)} : ${money(c.cost)} (${esc(c.A)} : ${c.aDeal ? '' : '≈ '}${money(c.costA)})</small>`; }
function priceBtn(r){
  const e = rowEco(r);
  if(prEdit===r.k) return `<input type="text" inputmode="decimal" class="num prin" data-a="pr_in" data-k="${esc(r.k)}" placeholder="Prix payé" aria-label="Prix payé pour ${esc(r.name)}" autofocus>`;
  return `<button type="button" class="prix${e.mine?' mine':''}" data-a="pr_edit" data-k="${esc(r.k)}" aria-label="Corriger le prix">${e.deal || e.mine || e.rsp || e.src==='robot' || e.src==='circ' ? '' : '≈ '}${money(e.cost)}</button>`;
}
/* un rayon se replie (touche son nom); dans un rayon, les articles cochés descendent */
const rayFerme = new Set();
const groupHtml = (gs, m) => gs.map(g => { const n = g.sub.reduce((a,s) => a+s.rows.length, 0), left = g.sub.reduce((a,s) => a+s.rows.filter(r => !m.chk[r.k]).length, 0);
  return `<details class="rayg" data-ray="${esc(g.title)}" ${rayFerme.has(g.title) ? '' : 'open'}><summary class="sec">${esc(g.title)}<span>${left < n ? `${left} sur ${n}` : n}</span></summary><div class="card list">` + g.sub.map(s => (s.ray ? `<p class="aisle">${esc(cap(s.ray))}</p>` : '') + s.rows.slice().sort((a, b) => (m.chk[a.k] ? 1 : 0) - (m.chk[b.k] ? 1 : 0)).map(r => rowHtml(r,m)).join('')).join('') + `</div></details>`; }).join('');
const paidField = m => `<label class="f">Total payé à la caisse ($)<input type="text" inputmode="decimal" class="num" id="paid" value="${m.paid||''}" placeholder="0,00"></label>`;
function budgetHtml(rows){
  const t = listTotals(rows), b = +S.p.budget || 0, rest = b - t.cost;
  const cf = calF(), calTxt = Math.abs(cf - 1) >= .02 ? `<p class="small">Estimation corrigée de ${cf > 1 ? '+' : '−'}${Math.round(Math.abs(cf - 1) * 100)} % d'après tes dernières factures.</p>` : '';
  const fit = b && rest < 0 && S.menu.date && !S.menu.achete ? `<div class="acts"><button class="btn s" id="bfit">Remplacer des soupers par des plats moins chers</button></div>` : '';
  return `<div class="budget"><p><span class="small">Total estimé</span> <b>≈ ${money(t.cost)}</b>${t.save >= 1 ? `<span class="small"> · ≈ ${money(t.save)} économisés en spéciaux</span>` : ''}</p>
    ${b ? `<div class="bar ${rest<0?'over':''}"><i style="width:${Math.min(100, t.cost/b*100)}%"></i></div><p class="small">Budget ${money(b)} : ${rest >= 0 ? `il reste ≈ <b>${money(rest)}</b>` : `<b class="over">dépasse de ≈ ${money(-rest)}</b>`}</p>` : ''}
    ${calTxt}${fit}${prixVieux() ? `<p class="small over">Les prix de référence datent de plus de 4 mois (${esc(PRIX_MAJ_TXT())}) : le total est probablement sous-estimé. <a href="#" data-a="pm_go">Les mettre à jour</a></p>` : ''}<details class="mini"><summary>D'où viennent les prix</summary><p class="small">${peDate() ? `Prix réguliers relevés le ${esc(dShort(peDate()))} pour Maxi et IGA` : `Prix réguliers du barème Maxi (${esc(PRIX_MAJ_TXT())})`} pour les formats à acheter (le reste du format va dans Maison), remplacés par les spéciaux et par tes prix : touche un prix pour le corriger. Un prix sans « ≈ » est un vrai prix.</p></details></div>`;
}
function renderEpicerie(){
  const el = $('#tab-epicerie'); const m = S.menu;
  if(!m.date){ storeMode = false; lockScreen(false); }
  document.body.classList.toggle('store', storeMode);
  if(!m.date){ el.innerHTML = `<div class="empty"><b>La liste se construit toute seule</b><span>Crée d'abord le menu de la semaine dans l'onglet Menu.</span></div>`; return; }
  const {rows, covered, verify} = buyList();
  let h = '';
  if(m.achete && m.snap && !storeMode){
    const got = m.snap.filter(r => r.ok).length;
    h += `<div class="card"><h3>Épicerie faite</h3><p class="small">${got} article${got>1?'s':''} ajouté${got>1?'s':''} à la maison (onglet Maison). Tu peux encore changer le menu : ce qui manque apparaît ci-dessous.</p>${paidField(m)}</div>`;
    if(!rows.length){ el.innerHTML = h + `<div class="empty"><b>Rien à acheter en plus</b><span>Tout ce qu'il faut pour le menu est à la maison.</span></div>`; return; }
    h += `<h2 class="sec">À acheter en plus<span>${rows.length}</span></h2><p class="small">Ce qui n'a pas été acheté, ou ce que tes changements au menu demandent.</p>`;
    h += groupHtml(groupsOf(rows), m);
    h += `<div class="card"><button class="btn p" id="store_on">Mode magasin</button><button class="btn" id="achete" style="margin-top:8px">Ces achats sont faits</button></div>`;
    el.innerHTML = h; return;
  }
  const done = rows.filter(r => m.chk[r.k]).length, pct = rows.length ? done/rows.length*100 : 0;
  if(storeMode){
    const todo = rows.filter(r => !m.chk[r.k]), got = rows.filter(r => m.chk[r.k]);
    h += `<div class="storebar"><div><b id="pg-t">${done} sur ${rows.length} dans le panier</b><div class="bar"><i id="pg-b" style="width:${pct}%"></i></div></div><button class="btn s" id="store_off">Quitter</button></div>`;
    h += groupHtml(groupsOf(todo), m);
    if(!todo.length) h += `<div class="empty"><b>Tout est dans le panier</b><span>Touche « Quitter », puis « Épicerie terminée » une fois à la maison.</span></div>`;
    if(got.length) h += `<h2 class="sec">Dans le panier<span>${got.length}</span></h2><div class="card list">${got.sort((a,b) => a.name.localeCompare(b.name,'fr')).map(r => rowHtml(r,m)).join('')}</div>`;
    el.innerHTML = h; return;
  }
  const st = specTotal(rows);
  h += `<div class="card"><h2 style="font-size:1.25rem">Épicerie du ${esc(fmtDate(shopISO()))}</h2><p class="small" id="pg-t">${done} sur ${rows.length} dans le panier</p><div class="bar"><i id="pg-b" style="width:${pct}%"></i></div>
    <div class="seg" role="group" aria-label="Regrouper la liste"><button class="${S.p.grp!=='magasin'?'on':''}" data-a="grp" data-v="rayon">Par rayon</button><button class="${S.p.grp==='magasin'?'on':''}" data-a="grp" data-v="magasin">Par magasin</button></div>
    ${budgetHtml(rows)}
    <div class="seg" role="group" aria-label="Façon de faire l'épicerie"><button class="${S.p.cmd?'on':''}" data-a="cmdmode" data-v="1">Commande en ligne</button><button class="${!S.p.cmd?'on':''}" data-a="cmdmode" data-v="0">En magasin</button></div>
    ${S.p.cmd ? `<p class="small">Chaque article a un lien vers le site de l'épicerie : ouvre-le, ajoute au panier, reviens et coche. Le format à commander est indiqué sous le nom.</p>` : `<button class="btn p" id="store_on">Mode magasin</button>`}
    <button class="btn s" data-a="plus_open" data-k="partager">Partager la liste</button></div>`;
  if(S.p.grp==='magasin') h += `<p class="small">${goStores().length > 1 ? `Chaque article va à l'épicerie de la semaine où il coûte nettement moins; le reste va à ${esc(mainStore())}.` : `Tout va à ${esc(mainStore())} cette semaine.`} Les prix des circulaires ne sont pas toujours pour le même format.</p>`;
  h += ouAllerCard(rows);
  h += renderAubaines();
  h += groupHtml(groupsOf(rows), m);
  if(verify.length){
    h += `<h2 class="sec">Vérifier avant de partir<span>${verify.length}</span></h2><div class="card list"><p class="small">Ces articles sont censés être déjà à la maison. S'il en manque un, touche « Il manque » : il passe dans la liste.</p>`;
    verify.sort((a,b)=>a.name.localeCompare(b.name,'fr')).forEach(v => {
      h += `<div class="item"><span class="t"><b>${esc(cap(v.name))}</b><small>Pour : ${esc(v.src.slice(0,3).join(', '))}</small></span><button class="btn s ${v.manque?'p':''}" data-a="manque" data-k="${esc(v.k)}">${v.manque?'Ajouté':'Il manque'}</button></div>`;
    });
    h += `</div>`;
  }
  if(covered.length) h += `<details class="card"><summary>Déjà à la maison <span class="rm">${covered.length}</span></summary>${covered.sort((a,b)=>a.name.localeCompare(b.name,'fr')).map(c=>`<div class="item"><span class="t"><b>${esc(cap(c.name))}</b></span><span class="q">${fq(c.q,c.u)}</span></div>`).join('')}</details>`;
  h += `<div class="card"><h3>De retour de l'épicerie</h3><p class="small">Les articles cochés entrent dans l'onglet Maison. Ce qui n'est pas utilisé cette semaine reste en stock et sera déduit de la prochaine liste.</p>${paidField(m)}<button class="btn p" id="achete">Épicerie terminée</button></div>`;
  el.innerHTML = h;
}

/* ---------- rendu : maison (garde-manger) ---------- */
let filtre = '', anRay = '';
function anFill(c, keep){
  const info = $('#an_info'); if(!info) return;
  if(c){ $('#an').value = c.n; $('#au').value = c.u; $('#ar').value = c.ray; $('#acat').value = catGuess(c); info.textContent = 'Aliment connu : unité, rayon et catégorie remplis. Vérifie la quantité.'; }
  else if($('#an').value.trim()){ $('#ar').value = guessRayon($('#an').value); info.textContent = 'Nouvel aliment : vérifie son rayon et sa catégorie.'; }
  else info.textContent = '';
  const sg = $('#an_sugg'); if(sg && !keep) sg.innerHTML = '';
}
function stepOf(u){ return u==='un' ? 1 : 100; }
/* Maison : inventaire par photos du frigo, du congélateur et du garde-manger */
function invCard(){
  const open = openPan.has('inv') || !!robotJobs.inventaire || !!invRes;
  let b = '';
  if(!geminiCle() && !invRes && !robotJobs.inventaire) b = `<p class="note">Pour lire tes photos, ajoute ta clé Gemini gratuite (2 minutes). <button class="btn s" data-a="view" data-v="compte">Ajouter ma clé</button></p>`;
  else if(invRes && invRes.length){
    const n = invRes.filter(x => x.on).length;
    b = `<p class="small">Gemini a reconnu ${invRes.length} article${invRes.length>1?'s':''}. Décoche ce qui n'est pas bon et corrige les quantités : elles remplacent celles de Maison.</p>
      <div class="list">${invRes.map((x, i) => `<label class="item inv"><input type="checkbox" data-inv="${i}" ${x.on?'checked':''}><span class="t"><b>${esc(cap(x.name))}</b><small>${esc([({frigo:'frigo', congelateur:'congélateur', 'garde-manger':'garde-manger'})[norm(x.lieu)] || x.lieu, x.rayon].filter(Boolean).join(' · '))}</small></span>
        <span class="qcol"><input type="text" inputmode="decimal" class="num mini" data-invq="${i}" value="${String(x.q).replace('.', ',')}" aria-label="Quantité de ${esc(x.name)}"><select class="mini" data-invu="${i}" aria-label="Unité">${['g','ml','un'].map(u => `<option ${x.u===u?'selected':''}>${u}</option>`).join('')}</select></span></label>`).join('')}</div>
      <div class="acts"><button class="btn p" id="inv_add">Mettre à jour Maison (${n})</button><button class="btn s" id="inv_copy">Copier en texte</button><button class="btn s" id="inv_clear">Effacer</button></div>`;
  } else b = `<p class="small">Prends 1 à 6 photos du frigo, du congélateur ou du garde-manger, portes ouvertes et bien éclairées. Ton Gemini liste ce qu'il voit; tu corriges avant de mettre à jour Maison.</p>
      ${robotStatut('inventaire', 'inv')}${!robotJobs.inventaire ? `<label class="f">Photos<input type="file" id="inv_img" accept="image/*" multiple></label><button class="btn p" id="inv_go">Lire les photos</button>` : ''}`;
  return `<details class="card" id="inv_card" data-pan="inv" ${open?'open':''}><summary><b>Inventaire par photos</b></summary>${b}<div class="small" id="inv_msg"></div></details>`;
}
function renderMaison(){
  const el = $('#tab-maison');
  const items = Object.entries(S.stock).filter(([k,o]) => !filtre || norm(o.name).includes(norm(filtre))).sort((a,b) => a[1].name.localeCompare(b[1].name,'fr'));
  let h = `<div class="card"><h3>Ce qu'il y a à la maison</h3><p class="small">Ce qui est ici est déduit de la prochaine liste, et le menu favorise les plats qui l'utilisent. Acheté hors liste, du fromage pour un lunch par exemple ? Ajoute-le en bas.</p>
    <input type="text" id="filt" placeholder="Chercher" value="${esc(filtre)}" aria-label="Chercher"></div>`;
  h += invCard();
  if(!items.length) h += `<div class="empty"><b>Rien à la maison pour l'instant</b><span>Après ta première épicerie, les restes apparaissent ici, par exemple 4 oeufs sur 12. Tu peux aussi ajouter ce que tu as déjà.</span></div>`;
  else RAYONS.forEach(ray => {
    const L = items.filter(([k,o]) => (o.rayon||'épicerie')===ray); if(!L.length) return;
    h += `<h2 class="sec">${esc(ray[0].toUpperCase()+ray.slice(1))}<span>${L.length}</span></h2><div class="card list">` + L.map(([k,o]) => `<div class="item"><span class="t"><b>${esc(cap(o.name))}</b><select class="mini" data-a="stcat" data-k="${esc(k)}" aria-label="Catégorie">${CATS.map(([v,n]) => `<option value="${v}" ${(o.cat||'')===v?'selected':''}>${n}</option>`).join('')}</select>${(o.cat==='f'||o.cat==='v')?`<button class="btn s" data-a="keepside" data-k="${esc(k)}">En faire un accompagnement</button>`:''}</span><div class="step"><button data-a="stm" data-k="${esc(k)}" aria-label="Moins">−</button><input type="text" inputmode="decimal" class="num" data-a="stq" data-k="${esc(k)}" value="${Math.round(o.q*10)/10}" aria-label="Quantité en ${o.u}"><span class="small">${o.u}</span><button data-a="stp" data-k="${esc(k)}" aria-label="Plus">+</button></div></div>`).join('') + `</div>`;
  });
  h += `<div class="card"><h3>Ajouter un article</h3>
    <label class="f">Aliment<input type="text" id="an" placeholder="Tape quelques lettres : fromage, poulet, lait…" autocomplete="off"></label>
    <div class="sugg" id="an_sugg"></div>
    <details class="panel" data-pan="an_browse" ${openPan.has('an_browse')?'open':''}><summary>Ou choisir par rayon</summary>
      <div class="chips">${RAYONS.map(r => `<button type="button" class="chip${anRay===r?' on':''}" data-a="an_ray" data-r="${esc(r)}">${esc(cap(r))}</button>`).join('')}</div>
      ${anRay ? `<div class="sugg">${sugBtns(catalog().filter(c => c.ray===anRay), 'data-a="an_pick"')}</div>` : ''}</details>
    <p class="small" id="an_info"></p>
    <div class="grid2"><label class="f">Quantité<input type="text" inputmode="decimal" class="num" id="aq" value="1"></label><label class="f">Unité<select id="au">${UNITS.map(([v,l]) => `<option value="${v}">${l}</option>`).join('')}</select></label></div>
    <div class="grid2"><label class="f">Rayon<select id="ar">${RAYONS.map(r=>`<option>${r}</option>`).join('')}</select></label>
    <label class="f">Catégorie<select id="acat">${CATS.map(([v,n]) => `<option value="${v}">${n}</option>`).join('')}</select></label></div>
    <p class="small">Féculent ou légume : le menu pourra s'en servir comme accompagnement (par exemple un sac de rouleaux de printemps = féculent). Collation : il apparaît dans « À utiliser cette semaine ».</p>
    <button class="btn p" id="aadd">Ajouter à la maison</button><div class="small" id="amsg"></div></div>`;
  el.innerHTML = h;
}


/* ---------- banque de recettes : ajout de plats et de variantes ---------- */
const RAY_WORDS = {
  'viandes':['poulet','boeuf','porc','saucisse','jambon','bacon','dinde','bologne','agneau','steak','cote','pepperoni','salami','bavette','filet mignon'],
  'poissonnerie':['poisson','saumon','crevette','morue','aiglefin','thon'],
  'produits laitiers':['lait','creme','fromage','beurre','yogourt','oeuf','mozzarella','cheddar','parmesan','feta','ricotta','babeurre'],
  'fruits et légumes':['oignon','ail','tomate','laitue','carotte','poivron','brocoli','patate','pomme','concombre','champignon','chou','epinard','avocat','citron','lime','celeri','persil','coriandre','ananas','courgette','mais frais','haricot vert','salade','basilic','ciboulette','aneth','menthe','gingembre','echalote','poireau','radis','betterave','navet','fraise','framboise','banane','raisin','poire','melon','mangue','kiwi','clementine','herbes fraiches'],
  'boulangerie':['pain','tortilla','pita','naan','bun','brioche','sous-marin','hamburger','hot-dog'],
  'surgelés':['surgele','frite','egg roll','pogo','pate a tarte','abaisse'],
  'garde-manger':['farine','sucre','sel','poivre','epice','cannelle','paprika','cayenne','cumin','origan','huile','fecule','poudre','bicarbonate','cassonade']
};
function guessRayon(name){
  const n = norm(name);
  for(const [ray,words] of Object.entries(RAY_WORDS)) if(words.some(w => n.includes(w))) return ray;
  return 'épicerie';
}
/* ---------- formulaires guidés : catalogue d'aliments ---------- */
const UNITS = [['un','unités'],['g','g'],['kg','kg'],['ml','ml'],['L','L']];
const toBase = (q,u) => u==='kg' ? [q*1000,'g'] : u==='L' ? [q*1000,'ml'] : [q, u];
const niceUnit = (q,u) => u==='g' && q>=1000 && q%100===0 ? [q/1000,'kg'] : u==='ml' && q>=1000 && q%100===0 ? [q/1000,'L'] : [q, u];
const lowFirst = s => s ? s.charAt(0).toLowerCase()+s.slice(1) : s;
const plain = n => String(n||'').replace(/\s*\([^)]*\)/g,'').trim();
function catalog(){
  if(_CAT) return _CAT;
  const m = new Map();
  const add = (n,u,ray,w) => { const nm = plain(n); const b = baseOf(nm); if(!b || b.length<2) return; let o = m.get(b); if(!o){ o = {b, names:{}, units:{}, rays:{}}; m.set(b,o); } o.names[nm]=(o.names[nm]||0)+w; o.units[u]=(o.units[u]||0)+w; o.rays[ray]=(o.rays[ray]||0)+w; };
  allRecipes().forEach(r => { r.i.forEach(g => add(g[2],g[1],g[3],1)); (r.v||[]).forEach(v => deltaItems(v[1]).add.forEach(a => add(a.name,a.u,a.ray||guessRayon(a.name),1))); });
  SIDES.concat(S.sidesx||[]).forEach(s => s.i.forEach(g => add(g[2],g[1],g[3],1)));
  ESS_START().concat(S.ess||[], S.snacks||[]).forEach(s => add(s.name,s.u,s.r,2));
  Object.values(S.stock).forEach(o => add(o.name,o.u,o.rayon||'épicerie',2));
  const top = o => Object.entries(o).sort((a,b) => b[1]-a[1])[0][0];
  _CAT = [...m.values()].map(o => { const n = top(o.names), ray = top(o.rays); return {n:cap(n), u:top(o.units), ray:classer(n, RAYONS.includes(ray) ? ray : guessRayon(n)), b:o.b}; }).sort((a,b) => a.n.localeCompare(b.n,'fr'));
  return _CAT;
}
const catFind = name => { const b = baseOf(plain(name)); return b ? catalog().find(c => c.b===b) || null : null; };
function catSearch(q, max){
  const n = norm(q).trim(); if(n.length<2) return [];
  const words = n.split(/\s+/);
  return catalog().filter(c => { const t = norm(c.n); return words.every(w => t.includes(w)); })
    .sort((a,b) => (norm(b.n).startsWith(n)?1:0) - (norm(a.n).startsWith(n)?1:0) || a.n.length - b.n.length).slice(0, max||6);
}
function catGuess(c){
  const n = norm(c.n);
  if(c.ray==='viandes' || c.ray==='poissonnerie') return 'p';
  if(/abaisse|pate a tarte|pate feuillet|pate a pizza/.test(n)) return '';
  if(/frite|pomme de terre|patate|\briz\b|\bpates\b|spaghetti|macaroni|penne|fusilli|linguine|rotini|tortellini|ravioli|orzo|vermicelle|nouille|pain|tortilla|naan|gnocchi|egg roll|rouleau|couscous|quinoa/.test(n)) return 'f';
  if(/brocoli|haricot|mais|pois|carotte|salade|laitue|concombre|chou|epinard|courgette|poivron|legume/.test(n)) return 'v';
  if(/yogourt|ficelle|croustille|barre|biscuit|compote|noix|amande|fromage|craquelin|muffin|fruit/.test(n)) return 'c';
  return '';
}
/* Brouillons : les formulaires gardent ce qui est tapé même quand l'écran se redessine. */
let drafts = {}, openPan = new Set();
const emptyRows = n => Array.from({length:n}, () => ({n:'', q:'', u:'un', ray:''}));
const rowsFromIng = ing => ing.map(g => { const [q,u] = niceUnit(+g[0], g[1]); return {n:cap(g[2]), q:String(+(+q).toFixed(3)), u, ray:g[3]}; });
const draftFor = (key, init) => drafts[key] || (drafts[key] = init());
const F = (dk, df) => `data-dk="${esc(dk)}" data-df="${df}"`;
const say = (el, txt) => { if(el){ el.textContent = txt; el.hidden = !txt; } };
function bindDraft(t){
  const dk = t.dataset && t.dataset.dk, df = t.dataset && t.dataset.df; if(!dk || !df || !drafts[dk]) return false;
  const d = drafts[dk];
  if(df==='rem' || t.dataset.arr){ const s = new Set(d[df]||[]); if(t.checked) s.add(t.value); else s.delete(t.value); d[df] = [...s]; }
  else if(t.type==='checkbox') d[df] = t.checked;
  else if(t.multiple) d[df] = [...t.selectedOptions].map(o => o.value);
  else d[df] = t.value;
  return true;
}
const rayPick = (key,j,x) => `<label class="f">Nouvel aliment : dans quel rayon ?<select class="ib_ray" data-ib="${esc(key)}" data-j="${j}">${RAYONS.map(r => `<option ${(x.ray||guessRayon(x.n))===r?'selected':''}>${r}</option>`).join('')}</select></label>`;
function ibRow(key, j, x){
  const a = `data-ib="${esc(key)}" data-j="${j}"`, known = x.n ? catFind(x.n) : null;
  return `<div class="ibw${x.doute ? ' doute' : ''}">${x.doute ? `<small class="dt">À vérifier : ${esc(x.doute)}</small>` : ''}<div class="ibr"><input type="text" class="ib_n" ${a} value="${esc(x.n||'')}" placeholder="Aliment : tape quelques lettres" aria-label="Aliment ${j+1}" autocomplete="off">
    <button type="button" class="ib_x" data-a="ib_rm" ${a} aria-label="Retirer cet ingrédient">×</button>
    <div class="sugg"></div>
    <input type="text" inputmode="decimal" class="num ib_q" ${a} value="${esc(x.q||'')}" placeholder="Qté" aria-label="Quantité">
    <select class="ib_u" ${a} aria-label="Unité">${UNITS.map(([v,l]) => `<option value="${v}" ${(x.u||'un')===v?'selected':''}>${l}</option>`).join('')}</select></div>
    <div class="ib_rw">${x.n && !known ? rayPick(key,j,x) : ''}</div></div>`;
}
const ingBuilder = (key, rows) => `<div class="ib">${rows.map((x,j) => ibRow(key,j,x)).join('')}<button type="button" class="btn s" data-a="ib_add" data-ib="${esc(key)}">+ Ajouter un ingrédient</button></div>`;
function readRows(rows){
  const ing = []; let err = '';
  rows.forEach((x,j) => {
    const n = String(x.n||'').trim(), qs = String(x.q||'').trim();
    if(!n && !qs) return;
    if(!n){ err = err || `Ligne ${j+1} : choisis un aliment.`; return; }
    const q = parseFloat(qs.replace(',','.'));
    if(!(q>0)){ err = err || `« ${n} » : indique une quantité.`; return; }
    const [qq,uu] = toBase(q, x.u||'un'), c = catFind(n);
    ing.push([qq, uu, lowFirst(n), c ? c.ray : (x.ray || guessRayon(n))]);
  });
  return {ing, err};
}
const sugBtns = (list, attrs) => list.map(c => `<button type="button" ${attrs} data-c="${esc(c.n)}">${esc(c.n)}<small>${esc(c.ray)}</small></button>`).join('');

let rf = {q:'', k:'', pr:'', st:'', g:'pr', fast:false, fav:false, dis:false}, openRec = new Set(), grpAll = new Set();
/* tendances TikTok : un plat marqué TikTok (r.al) ou une de ses versions « … (TikTok) » */
const tiktokVi = r => vars(r).findIndex(v => /tiktok/i.test(v[0]));
const estTiktok = r => (Array.isArray(r.al) && r.al.some(a => /tiktok/i.test(a))) || tiktokVi(r) >= 0;
function recFiltered(){
  const q = norm(rf.q);
  return allRecipes().filter(r => {
    if(rf.k==='acc') return false;
    if(q && !norm(r.n+' '+(Array.isArray(r.al) ? r.al.join(' ')+' ' : '')+(r.m||[]).join(' ')+' '+r.i.map(g => g[2]).join(' ')+' '+vars(r).map(v => v[0]).join(' ')).includes(q)) return false;
    if(rf.k==='match'){ if(!r.oc && !styOf(r).includes('pub') && !styOf(r).includes('poutine')) return false; }
    else if(rf.k==='tiktok'){ if(!estTiktok(r)) return false; }
    else if(rf.k && kindOf(r)!==rf.k) return false;
    if(rf.pr && prOf(r)!==rf.pr) return false;
    if(rf.st && !styOf(r).includes(rf.st)) return false;
    if(rf.fast && tpOf(r) > 30) return false;
    if(rf.fav && !S.fav[r.n]) return false;
    if(rf.mij && !mjOf(r) && !cmOf(r, 'mj')) return false;
    if(rf.af && !cmOf(r, 'af')) return false;
    if(rf.aime && !(S.fav[r.n] || ((S.rate[r.n]||{}).up||0) > ((S.rate[r.n]||{}).down||0))) return false;
    if(rf.spec && !dealsOf(r).length) return false;
    if(!!S.dis[r.n] !== !!rf.dis) return false;
    return true;
  }).sort((a,b) => a.n.localeCompare(b.n,'fr'));
}
const sideOpts = (sl, cur, withAuto, withDef) => (withDef?`<option value="def" ${cur==='def'?'selected':''}>Celui du plat</option>`:'') + (withAuto?`<option value="auto" ${cur==='auto'?'selected':''}>Auto (varie)</option>`:'') + `<option value="" ${cur===''?'selected':''}>Aucun</option>` + sidesOf(sl).filter(s => !s.id.startsWith('st:')).map(s => `<option value="${esc(s.id)}" ${cur===s.id?'selected':''}>${esc(s.n)}</option>`).join('');
function varEditor(r, row){
  const key = row ? `va|${r.n}|${row.src}|${row.i}` : `vn|${r.n}`, souper = kindOf(r)==='souper';
  const d = draftFor(key, () => {
    const v = row ? row.v : ['', '', ''], dd = deltaItems(v[1]), t = v[0]||'', ix = t.indexOf(':');
    const rem = []; dd.rem.filter(x => !x.q).forEach(x => r.i.forEach(g => { if(norm(g[2]).includes(norm(x.name)) && !rem.includes(g[2])) rem.push(g[2]); }));
    return {nm:ix>0 ? t.slice(0,ix).trim() : t, ds:ix>0 ? t.slice(ix+1).trim() : '', p:v[2]||'',
      f:dd.f===undefined ? 'def' : (dd.f==='aucun' ? '' : dd.f), v:dd.v===undefined ? 'def' : (dd.v==='aucun' ? '' : dd.v),
      rows:dd.add.length ? dd.add.map(a => { const [q,u] = niceUnit(a.q,a.u); return {n:cap(a.name), q:String(q), u, ray:a.ray}; }) : emptyRows(1),
      rem, keep:dd.rem.filter(x => x.q).map(x => `-${x.q} ${x.u} ${x.name}`)};
  });
  const B = (a, label, cls) => `<button class="btn s ${cls}" data-a="${a}" data-r="${esc(r.n)}" data-key="${esc(key)}"${row ? ` data-s="${row.src}" data-i="${row.i}"` : ''}${a==='vrm' ? ' data-armed="0"' : ''}>${label}</button>`;
  return `<div class="vbox">
    <label class="f">Nom de la version<input type="text" ${F(key,'nm')} value="${esc(d.nm)}" placeholder="Épicée, Nashville…"></label>
    <label class="f">Description<input type="text" ${F(key,'ds')} value="${esc(d.ds)}" placeholder="Ce qui change, en quelques mots"></label>
    <p class="small"><b>Ingrédients à retirer</b> (touche pour cocher)</p>
    <div class="chips">${r.i.map(g => `<label class="chip rm"><input type="checkbox" ${F(key,'rem')} value="${esc(g[2])}" ${d.rem.includes(g[2])?'checked':''}>${esc(cap(g[2]))}</label>`).join('')}</div>
    <p class="small"><b>Ingrédients à ajouter</b></p>
    ${ingBuilder(key, d.rows)}
    ${souper ? `<div class="grid2"><label class="f">Féculent<select ${F(key,'f')}>${sideOpts('f', d.f, false, true)}</select></label><label class="f">Légume ou salade<select ${F(key,'v')}>${sideOpts('v', d.v, false, true)}</select></label></div>` : ''}
    <label class="f">Préparation de cette version<textarea ${F(key,'p')}>${esc(d.p)}</textarea></label>
    <div class="note ve_msg" hidden></div>
    <div class="acts">${row ? B('vsave','Enregistrer','p')+B('vrm','Retirer cette version','d') : B('vadd','Ajouter la version','p')}</div></div>`;
}
function varFromDraft(key){
  const d = drafts[key]; if(!d) return {err:'Rien à enregistrer.'};
  const nm = String(d.nm||'').trim(); if(!nm) return {err:'Donne un nom à la version.'};
  const {ing, err} = readRows(d.rows); if(err) return {err};
  const toks = ing.map(([q,u,n,ray]) => `+${q} ${u} ${n}|${ray}`).concat((d.rem||[]).map(n => `-${n}`), d.keep||[]);
  if(d.f!=='def') toks.push('@f='+(d.f||'aucun'));
  if(d.v!=='def') toks.push('@v='+(d.v||'aucun'));
  const title = String(d.ds||'').trim() ? nm+' : '+String(d.ds).trim() : nm, p = String(d.p||'').trim();
  return {val: p ? [title, toks.join(' ; '), p] : [title, toks.join(' ; ')]};
}
function recEditor(r){
  const key = 'edit|'+r.n;
  const d = draftFor(key, () => ({k:kindOf(r), pr:r.pr||'', st:styOf(r), t:r.t||'viande', tm:String(tmOf(r)), tp:String(tpOf(r)), mj:!!mjOf(r), sp:!!r.sp, oc:!!r.oc, sf:r.sf||'', sv:r.sv||'', m:(r.m||[]).join(', '), s:r.s||'', rows:rowsFromIng(r.i)}));
  return `<div class="rbox">
    <div class="grid2"><label class="f">Genre<select ${F(key,'k')}>${Object.entries(KIND1).map(([k,v]) => `<option value="${k}" ${d.k===k?'selected':''}>${v}</option>`).join('')}</select></label>
    <label class="f">Protéine<select ${F(key,'pr')}><option value="">Automatique</option>${Object.entries(PRS).map(([k,v]) => `<option value="${k}" ${d.pr===k?'selected':''}>${v}</option>`).join('')}</select></label></div>
    <p class="small"><b>Styles</b> (touche pour choisir, un ou plusieurs)</p><div class="chips">${Object.entries(STYS).map(([k,v]) => `<label class="chip"><input type="checkbox" ${F(key,'st')} data-arr="1" value="${k}" ${d.st.includes(k)?'checked':''}>${v}</label>`).join('')}</div>
    <div class="grid2"><label class="f">Type (accompagnements)<select ${F(key,'t')}>${Object.entries(TYPES).map(([k,v]) => `<option value="${k}" ${d.t===k?'selected':''}>${v}</option>`).join('')}</select></label>
    <label class="f">Préparation<select ${F(key,'tp')}>${optMin(TP_L, d.tp||d.tm)}</select></label></div>
    <div class="grid2"><label class="f">Temps total<select ${F(key,'tm')}>${optMin(TM_L, d.tm)}</select></label>
    <label class="check"><input type="checkbox" ${F(key,'mj')} ${d.mj?'checked':''}> Peut cuire à la mijoteuse pendant la journée</label></div>
    <label class="check"><input type="checkbox" ${F(key,'sp')} ${d.sp?'checked':''}> Déjeuner de semaine (jours de travail) ou dessert simple (pas proposé, sauf si permis dans Profil)</label>
    <label class="check"><input type="checkbox" ${F(key,'oc')} ${d.oc?'checked':''}> À l'occasion seulement (soir de match, tailgate) : jamais choisi pour le menu de la semaine</label>
    <div class="grid2"><label class="f">Féculent par défaut<select ${F(key,'sf')}>${sideOpts('f', d.sf, true)}</select></label><label class="f">Légume par défaut<select ${F(key,'sv')}>${sideOpts('v', d.sv, true)}</select></label></div>
    <p class="small"><b>Ingrédients</b>${kindOf(r)==='souper' ? ' pour 6 portions' : ''}. Tape quelques lettres et choisis l'aliment proposé.</p>
    ${ingBuilder(key, d.rows)}
    <label class="f">Mots pour trouver les spéciaux (virgules)<input type="text" ${F(key,'m')} value="${esc(d.m)}"></label>
    <label class="f">Préparation<textarea ${F(key,'s')}>${esc(d.s)}</textarea></label>
    <div class="note re_msg" hidden></div>
    <div class="acts"><button class="btn s p" data-a="rsave" data-r="${esc(r.n)}">Enregistrer la recette</button>${!r.c && S.redit[r.n] ? `<button class="btn s" data-a="rreset" data-r="${esc(r.n)}">Revenir à l'original</button>` : ''}</div></div>`;
}
/* Accompagnements d'une recette : « varié » (l'application choisit), aucun, ou un accompagnement fixe. */
function recSides(r){
  const base = baseRecipe(r.n) || r, nm = id => (sideById(id)||{}).n || '';
  const sel = slot => { const cur = (slot==='f' ? r.sf : r.sv) ?? '', fixed = r.fx && r.fx[slot] && sideById(cur), pref = !fixed && cur && cur!=='auto' && sideById(cur) ? nm(cur) : '';
    const val = fixed ? cur : cur==='' ? '' : 'auto';
    return `<option value="auto" ${val==='auto'?'selected':''}>Varié chaque semaine${pref ? ' (souvent '+esc(pref.toLowerCase())+')' : ''}</option><option value="" ${val===''?'selected':''}>Aucun</option>`
      + sidesOf(slot).filter(s => !s.id.startsWith('st:')).map(s => `<option value="${esc(s.id)}" ${val===s.id?'selected':''}>${esc(s.n)}${(S.sdis||{})[s.id]?' (mis de côté)':''}</option>`).join(''); };
  return `<div class="sidepick"><p class="small"><b>Accompagnements</b> (${esc((TYPES[r.t||'viande']||'').toLowerCase())}). Varié : l'application choisit chaque semaine parmi ceux qui vont avec ce plat. Choisis-en un pour l'avoir à tout coup.</p>
    <div class="grid2"><label class="f">Féculent<select data-a="rside" data-r="${esc(r.n)}" data-s="f">${sel('f')}</select></label><label class="f">Légume ou salade<select data-a="rside" data-r="${esc(r.n)}" data-s="v">${sel('v')}</select></label></div></div>`;
}
function setRecSide(name, slot, val){
  const r = byName(name); if(!r) return;
  const base = baseRecipe(name), key = slot==='f' ? 'sf' : 'sv';
  const fx = Object.assign({}, r.fx||{}); let sv;
  if(val==='auto'){ const orig = base ? base[key] : r[key]; sv = orig && orig!=='' ? orig : 'auto'; fx[slot] = false; }
  else if(val===''){ sv = ''; fx[slot] = false; }
  else { sv = val; fx[slot] = true; }
  if(r.c){ const c = S.custom.find(x => x.n===name); if(c){ c[key] = sv; c.fx = fx; } }
  else S.redit[name] = Object.assign({}, S.redit[name]||{}, {[key]:sv, fx});
  openRec.add(name); save(); render();
}
/* Liste des accompagnements dans Recettes */
function sidesSection(){
  const q = norm(rf.q), dis = S.sdis||{};
  const L = ALLS().filter(s => !s.id.startsWith('st:') && (!q || norm(s.n+' '+s.i.map(g => g[2]).join(' ')).includes(q)) && (!rf.dis || dis[s.id]));
  if(!L.length) return '';
  const row = s => { const k = 'side|'+s.id, open = openRec.has(k), mine = (S.sidesx||[]).some(x => x.id===s.id);
    return `<details class="row" data-rec="${esc(k)}" ${open?'open':''}><summary><span>${esc(s.n)}${dis[s.id]?' <span class="small">(mis de côté)</span>':''}${mine?' <span class="small">(le tien)</span>':''}</span></summary>
      <div class="rbody"><p class="small">Va avec : ${esc((s.ty||[]).map(t => t==='all' ? 'tous les plats' : (TYPES[t]||t).toLowerCase()).join(', ') || 'tous les plats')}. Quantités pour 6 portions.</p>
      <ul class="ing">${s.i.map(g => `<li><span>${esc(g[2])}</span><span>${fq(g[0],g[1])}</span></li>`).join('')}</ul>
      <div class="acts"><button class="btn s ${dis[s.id]?'p':''}" data-a="sdis" data-id="${esc(s.id)}">${dis[s.id] ? 'Le proposer de nouveau' : 'Ne plus le proposer'}</button>${mine ? `<button class="btn s d" data-a="sdel2" data-id="${esc(s.id)}">Supprimer</button>` : ''}</div></div></details>`; };
  if(rf.k!=='acc' && !q) return `<h2 class="sec">Accompagnements<span>${L.length}</span></h2><div class="card list"><button type="button" class="lnk2 rf-more" data-a="rf_k" data-v="acc">Voir les ${L.length}</button></div>`;
  const f = L.filter(s => s.sl==='f'), v = L.filter(s => s.sl==='v');
  return `<h2 class="sec">Accompagnements<span>${L.length}</span></h2><div class="card list">${f.length ? `<p class="aisle">Féculents</p>${f.map(row).join('')}` : ''}${v.length ? `<p class="aisle">Légumes et salades</p>${v.map(row).join('')}` : ''}</div>
    <p class="small" style="padding:0 4px">Pour en créer un : bouton + → « Nouvel accompagnement ».</p>`;
}
function recBody(r, idx){
  const rows = varRows(r), mod = !r.c && (S.vared[r.n] || S.vardel[r.n]);
  const kd = kindOf(r);
  return `${recipePhoto(r, 'detail-photo')}${metaTags(r, kd==='souper')}
    <div class="acts"><button class="btn s p" data-a="radd" data-r="${esc(r.n)}" data-v="0">${kd==='sauce' ? 'Ajouter à un plat du menu' : 'Ajouter au menu de la semaine'}</button>${kd==='sauce' ? '' : `<button class="btn s" data-a="cook" data-r="${esc(r.n)}">Cuisiner</button>`}</div>
    ${kd==='souper' ? recSides(r) : ''}${!r.c && S.redit[r.n] ? '<p class="small"><b>Recette modifiée par toi.</b></p>' : ''}
    <div class="grid2"><label class="f">Préparation<select data-a="tpsel" data-r="${esc(r.n)}">${optMin(TP_L, tpOf(r))}</select></label>
    <label class="f">Temps total<select data-a="tmsel" data-r="${esc(r.n)}">${optMin(TM_L, tmOf(r))}</select></label></div>
    ${kd==='souper' ? (wk => `<p class="small">${isLong(r) ? 'Placé un jour de congé' : 'Possible un soir de semaine'} : seule la préparation compte${mjOf(r)===2 && tmOf(r) > MAX_FOUR ? ', et il peut cuire à la mijoteuse pendant la journée' : ''}.${isLong(r) && wk ? ` Un soir de semaine, il se fait ${wk.k==='mj' ? 'à la mijoteuse' : wk.k==='af' ? 'au air fryer' : 'au four'}.` : ''}</p>`)(methods(r).find(m => m.k && cmWeek(m))) : ''}
    <div class="acts"><button class="btn s ${S.fav[r.n]?'p':''}" data-a="fav" data-r="${esc(r.n)}">${S.fav[r.n]?'Favori ✓':'Ajouter aux favoris'}</button>
      <button class="btn s ${S.dis[r.n]?'p':''}" data-a="rdis" data-r="${esc(r.n)}">${S.dis[r.n]?'Remettre dans la banque':"Je n'aime pas"}</button></div>
    <ul class="ing">${r.i.map(g=>`<li><span>${esc(g[2])}</span><span>${fq(g[0],g[1])}</span></li>`).join('')}</ul>
    ${['souper','soupe','dejeuner','entree','dessert'].includes(kd) && !r.nonut ? nutLigne(nutRecette(r, 0), kd==='souper') : ''}
    ${r.s?`<p class="steps">${esc(r.s)}</p>`:''}
    ${(M => M.length ? `<h3 style="font-size:1rem">Autres façons de le cuire</h3><p class="small">Mêmes ingrédients que la recette ci-dessus (${esc(M[0].l.toLowerCase())}).</p>${M.slice(1).map(m => { const pk = 'cm|'+r.n+'|'+m.k; return `<details class="panel" data-pan="${esc(pk)}" ${openPan.has(pk)?'open':''}><summary>${esc(m.l)} · ${esc(tmTxtM(r, m.k))}</summary><p class="steps">${esc(stepsM(r, m.k))}</p><div class="acts"><button class="btn s" data-a="cook" data-r="${esc(r.n)}" data-cm="${m.k}">Cuisiner : ${esc(m.l.toLowerCase())}</button></div></details>`; }).join('')}` : '')(methods(r))}
    <h3 style="font-size:1rem">Variantes <span class="small">${rows.length}</span></h3>
    ${rows.length ? rows.map(row => { const pk = `va|${r.n}|${row.src}|${row.i}`; return `<div class="card" style="background:var(--bg)"><b>${esc(vname(row.v[0]))}${row.edited?' <span class="small">(modifiée)</span>':''}${row.src==='x'?' <span class="small">(ajoutée)</span>':''}</b>${varDetail(row.v)}
      <div class="acts"><button class="btn s" data-a="radd" data-r="${esc(r.n)}" data-v="${rows.indexOf(row)+1}">Ajouter cette version au menu</button></div>
      <details class="panel" data-pan="${esc(pk)}" ${openPan.has(pk)?'open':''}><summary>Modifier cette version</summary>${openPan.has(pk) ? varEditor(r,row) : ''}</details></div>`; }).join('') : '<p class="small">Aucune pour l\'instant.</p>'}
    ${mod ? `<p class="small"><a href="#" data-a="vrestore" data-r="${esc(r.n)}">Rétablir les variantes d'origine</a></p>` : ''}
    <details class="card" style="background:var(--bg)" data-pan="vn|${esc(r.n)}" ${openPan.has('vn|'+r.n)?'open':''}><summary>Ajouter une version</summary>${openPan.has('vn|'+r.n) ? varEditor(r,null) : ''}</details>
    <details class="card" style="background:var(--bg)" data-pan="edit|${esc(r.n)}" ${openPan.has('edit|'+r.n)?'open':''}><summary>Modifier la recette</summary>${openPan.has('edit|'+r.n) ? recEditor(r) : ''}</details>
    ${r.fam ? `<p class="small"><b>Banque commune de la famille</b>${r.ajout ? ', ajoutée le ' + esc(dShort(r.ajout)) : ''}.${r.src ? ` <a href="${esc(r.src)}" target="_blank" rel="noopener">Le reel d'origine</a>` : ''}</p>` : ''}
    <div class="acts"><button class="btn s" data-a="rshare2" data-r="${esc(r.n)}" data-x="${idx}">Copier cette recette</button>${familleCode() && r.c && !famHas(r.n) ? `<button class="btn s" data-a="fam_pub" data-r="${esc(r.n)}">Partager avec la famille</button>` : ''}${familleCode() && (r.fam || (r.c && famHas(r.n))) ? `<button class="btn s d" data-a="fam_rm" data-r="${esc(r.n)}" data-armed="0">Retirer de la banque commune</button>` : ''}${r.c?`<button class="btn s d" data-a="rdel" data-r="${esc(r.n)}" data-armed="0">Supprimer cette recette</button>`:''}</div><div class="small" id="rm2_${idx}"></div>`;
}
/* panneaux d'ajout (bouton +) : nouvelle recette, nouvel accompagnement, reel, recette copiée */
function recPanel(k){
  const dn = draftFor('new', () => ({n:'', k:'souper', pr:'', st:[], t:'viande', tm:'30', tp:'20', mj:false, sf:'auto', sv:'auto', fam:false, m:'', s:'', rows:emptyRows(4)}));
  const ds = draftFor('side', () => ({n:'', sl:'f', rows:emptyRows(3)}));
  if(k==='nouvelle') return `<details class="row" open data-rec="__new"><summary>Nouvelle recette</summary><div class="rbody">
    ${dn.note ? `<p class="note">${esc(dn.note)}</p>` : ''}
    <label class="f">Nom du plat<input type="text" ${F('new','n')} value="${esc(dn.n)}" placeholder="Poulet à la crème"></label>
    <div class="grid2"><label class="f">Genre<select ${F('new','k')}>${Object.entries(KIND1).map(([k,v]) => `<option value="${k}" ${dn.k===k?'selected':''}>${v}</option>`).join('')}</select></label>
    <label class="f">Protéine<select ${F('new','pr')}><option value="">Automatique</option>${Object.entries(PRS).map(([k,v]) => `<option value="${k}" ${dn.pr===k?'selected':''}>${v}</option>`).join('')}</select></label></div>
    <p class="small"><b>Styles</b> (touche pour choisir, un ou plusieurs)</p><div class="chips">${Object.entries(STYS).map(([k,v]) => `<label class="chip"><input type="checkbox" ${F('new','st')} data-arr="1" value="${k}" ${dn.st.includes(k)?'checked':''}>${v}</label>`).join('')}</div>
    <div class="grid2"><label class="f">Type (accompagnements)<select ${F('new','t')}>${Object.entries(TYPES).map(([k,v]) => `<option value="${k}" ${dn.t===k?'selected':''}>${v}</option>`).join('')}</select></label>
    <label class="f">Préparation<select ${F('new','tp')}>${optMin(TP_L, dn.tp||dn.tm)}</select></label></div>
    <div class="grid2"><label class="f">Temps total<select ${F('new','tm')}>${optMin(TM_L, dn.tm)}</select></label>
    <label class="check"><input type="checkbox" ${F('new','mj')} ${dn.mj?'checked':''}> Peut cuire à la mijoteuse pendant la journée</label></div>
    <div class="grid2"><label class="f">Féculent<select ${F('new','sf')}>${sideOpts('f', dn.sf, true)}</select></label><label class="f">Légume ou salade<select ${F('new','sv')}>${sideOpts('v', dn.sv, true)}</select></label></div>
    <label class="check"><input type="checkbox" ${F('new','fam')} ${dn.fam?'checked':''}> La famille aime ce plat (il revient plus souvent)</label>
    <label class="check"><input type="checkbox" ${F('new','oc')} ${dn.oc?'checked':''}> À l'occasion seulement (soir de match, tailgate) : jamais choisi pour le menu de la semaine</label>
    ${familleCode() ? `<label class="check"><input type="checkbox" ${F('new','partage')} ${dn.partage?'checked':''}> Ajouter à la banque commune : toute la famille l'aura</label>` : ''}
    <p class="small"><b>Ingrédients pour 6 portions.</b> Tape quelques lettres et choisis l'aliment proposé : l'unité et le rayon se remplissent tout seuls.</p>
    ${ingBuilder('new', dn.rows)}
    <label class="f">Mots pour trouver les spéciaux (virgules, facultatif)<input type="text" ${F('new','m')} value="${esc(dn.m)}" placeholder="poulet, crème"></label>
    <label class="f">Préparation<textarea ${F('new','s')}>${esc(dn.s)}</textarea></label>
    <div id="nr_msg" class="note" hidden></div>
    <button class="btn p" id="nr_save">Enregistrer la recette</button></div></details>`;
  if(k==='acc') return `<details class="row" open data-rec="__side"><summary>Nouvel accompagnement</summary><div class="rbody">
    <label class="f">Nom<input type="text" ${F('side','n')} value="${esc(ds.n)}" placeholder="Riz aux légumes"></label>
    <label class="f">Sorte<select ${F('side','sl')}><option value="f" ${ds.sl==='f'?'selected':''}>Féculent</option><option value="v" ${ds.sl==='v'?'selected':''}>Légume ou salade</option></select></label>
    <p class="small"><b>Ingrédients pour 6 portions</b></p>
    ${ingBuilder('side', ds.rows)}
    <div id="ns_msg" class="note" hidden></div><button class="btn p" id="ns_save">Enregistrer l'accompagnement</button>
    ${(S.sidesx||[]).length?`<p class="small">Les tiens : ${S.sidesx.map(s=>`${esc(s.n)} <a href="#" data-a="sdel" data-id="${esc(s.id)}">retirer</a>`).join(', ')}</p>`:''}</div></details>`;
  if(k==='reel') return `<details class="row" open data-rec="__reel"><summary>Importer un reel</summary><div class="rbody">
    ${geminiCle() || robotJobs.recette ? `<p class="small">Envoie 1 à 4 captures d'écran du reel : la description ouverte au complet, et les écrans où la recette apparaît. Ton Gemini écrit la recette en quelques secondes; tu la vérifies avant de l'enregistrer.</p>
    ${robotStatut('recette', 'reel')}
    ${!robotJobs.recette ? `<label class="f">Captures d'écran<input type="file" id="reel_img" accept="image/*" multiple></label>
    <label class="f">Lien du reel (facultatif, pour le crédit)<input type="url" id="reel_lien" placeholder="https://www.instagram.com/reel/…" autocomplete="off"></label>
    <label class="f">Une précision (facultatif)<input type="text" id="reel_note" placeholder="ex. la recette est pour 4 personnes" autocomplete="off"></label>
    <button class="btn p" id="reel_go">Lire le reel</button>` : ''}<div class="small" id="reel_msg"></div>`
    : `<p class="note">Pour lire un reel, ajoute ta clé Gemini gratuite (2 minutes). <button class="btn s" data-a="view" data-v="compte">Ajouter ma clé</button></p>`}</div></details>`;
  if(k==='coller') return `<details class="row" open data-rec="__imp"><summary>Importer une recette copiée</summary><div class="rbody">
    <p class="small">Colle une recette copiée d'un site (Ricardo, 5-15, Pratico-pratiques, Trois fourchettes…) : sélectionne le titre, les ingrédients et la préparation, puis Copier. Le formulaire « Nouvelle recette » se remplit pour que tu vérifies avant d'enregistrer. Une recette copiée avec « Copier la recette » de l'application est ajoutée directement, versions comprises.</p>
    <textarea id="imp_txt" placeholder="Colle le message ici"></textarea>
    <button class="btn p" id="imp_go">Importer</button><div class="small" id="imp_msg"></div></div></details>`;
  return '';
}
function renderRecettes(){
  const el = $('#tab-recettes');
  const list = recFiltered();
  const sel = (key, label, opts) => `<label class="f">${label}<select data-rf="${key}">${opts.map(([v,n]) => `<option value="${v}" ${rf[key]===v?'selected':''}>${n}</option>`).join('')}</select></label>`;
  const chk = (key, label) => `<label class="chip"><input type="checkbox" data-rf="${key}" ${rf[key]?'checked':''}>${label}</label>`;
  const nf = ['pr','st','fast','mij','af','spec','aime','fav','dis'].filter(k => rf[k]).length + (rf.g!=='pr' ? 1 : 0);
  const CATR = [['','Tout'],['souper','Soupers'],['match','Repas plaisir'],['tiktok','TikTok'],['soupe','Soupes'],['dejeuner','Déjeuners'],['entree','Entrées'],['dessert','Desserts'],['sauce','Sauces'],['acc','Accompagnements']];
  let h = `<div class="page-heading"><p class="eyebrow">À cuisiner, à partager</p><h2>La bibliothèque</h2><p>${allRecipes().length} idées pour se régaler au quotidien.</p>${photoDownloadControl()}</div>` + (recFlash ? `<p class="note">${esc(recFlash)}</p>` : '') + `<div class="card"><input type="text" id="rfilt" placeholder="Chercher (nom ou ingrédient)" value="${esc(rf.q)}" aria-label="Chercher">
    <div class="rf-cats" role="group" aria-label="Catégorie">${CATR.map(([v, t]) => `<button type="button" class="chip${rf.k===v?' on':''}" data-a="rf_k" data-v="${v}" aria-pressed="${rf.k===v}">${t}</button>`).join('')}</div>
    <details class="panel" data-pan="rf_plus" ${openPan.has('rf_plus')?'open':''}><summary>Filtres${nf ? ` <span class="rm">${nf} actif${nf>1?'s':''}</span>` : ''}</summary>
      <div class="grid2">${sel('pr','Protéine',[['','Toutes'],...Object.entries(PRS)])}${sel('st','Style',[['','Tous'],...Object.entries(STYS)])}${sel('g','Regrouper par',[['pr','Protéine'],['st','Style'],['k','Genre'],['','Ordre alphabétique']])}</div>
      <div class="chips">${chk('fast','Préparation 30 min ou moins')}${chk('mij','Mijoteuse')}${chk('af','Air fryer')}${chk('spec','En spécial cette semaine')}${chk('aime','Aimés de la famille')}${chk('fav','Favoris')}${chk('dis',"Mis de côté")}</div>
      ${nf ? `<button type="button" class="lnk2" data-a="rf_reset">Retirer les filtres</button>` : ''}</details>
    <p class="small">${list.length} recette${list.length>1?'s':''} sur ${allRecipes().length}.</p></div>`;
  const rg = rf.k==='match' && rf.g==='pr' ? 'st' : rf.g;   /* repas plaisir : regroupés par sorte (poutines, pub…) */
  const grp = r => rg==='pr' ? (kindOf(r)==='souper' ? PRS[prOf(r)] : KINDS[kindOf(r)]) : rg==='st' ? (STYS[styOf(r)[0]]||'Autres') : rg==='k' ? KINDS[kindOf(r)] : '';
  const order = rf.g==='pr' ? [...Object.values(PRS), ...Object.values(KINDS)] : rf.g==='st' ? [...Object.values(STYS),'Autres'] : Object.values(KINDS);
  const groups = new Map(); list.forEach(r => { const g = grp(r); if(!groups.has(g)) groups.set(g, []); groups.get(g).push(r); });
  [...groups.keys()].sort((a,b) => order.indexOf(a)-order.indexOf(b)).forEach(g => {
    const all = groups.get(g), lim = g ? 6 : 40, cut = !rf.q && !grpAll.has(g) && all.length > lim + 2;
    if(g) h += `<h2 class="sec">${esc(g)}<span>${all.length}</span></h2>`;
    h += `<div class="recipe-grid">`;
    (cut ? all.filter((r, j) => j < lim || openRec.has(r.n)) : all).forEach(r => {
      const idx = list.indexOf(r), open = openRec.has(r.n);
      h += `<details class="row" data-rec="${esc(r.n)}" data-lazy="1" ${open?'open':''}><summary>${recipePhoto(r, 'recipe-cover')}<span class="recipe-title">${esc(r.n)}${S.fav[r.n]?' <span class="small">(favori)</span>':''}</span><span class="rm">${tmList(r)}</span></summary>${open ? `<div class="rbody">${recBody(r, idx)}</div>` : ''}</details>`;
    });
    if(cut) h += `<button type="button" class="lnk2 rf-more" data-a="rf_more" data-g="${esc(g)}">Voir les ${all.length}</button>`;
    h += `</div>`;
  });
  const showSides = (rf.k==='' || rf.k==='acc') && !rf.pr && !rf.st && !rf.fast && !rf.fav && !rf.af && !rf.mij;
  const sides = showSides ? sidesSection() : '';
  if(!list.length && !sides) h += `<div class="empty"><b>Aucune recette</b><span>Rien ne correspond à ces filtres. Retire un filtre ou change la recherche.</span></div>`;
  h += sides;
  el.innerHTML = h;
}
function saveRecette(){
  const d = drafts.new, msg = $('#nr_msg'); if(!d) return;
  const name = String(d.n||'').trim();
  if(!name){ say(msg, 'Donne un nom au plat.'); return; }
  if(allRecipes().some(r => norm(r.n)===norm(name))){ say(msg, 'Une recette porte déjà ce nom.'); return; }
  const {ing, err} = readRows(d.rows); if(err){ say(msg, err); return; }
  if(!ing.length){ say(msg, 'Ajoute au moins un ingrédient.'); return; }
  let mots = String(d.m||'').split(',').map(x => x.trim()).filter(Boolean);
  if(!mots.length) mots = autoMots(ing, name);
  const k = d.k;
  const nr = {n:name, e:d.fam ? 'ff' : '', m:mots, k, pr:d.pr, st:d.st, t:d.t, tm:+d.tm, tp:Math.min(+d.tp||+d.tm, +d.tm), mj:d.mj ? 1 : 0, sf:k==='souper' ? d.sf : '', sv:k==='souper' ? d.sv : '', nw:true, c:true, i:ing, s:String(d.s||'').trim(), v:[]};
  if(d.oc) nr.oc = 1;
  if(d.src) nr.src = String(d.src).slice(0, 300);
  S.custom.push(nr);
  delete drafts.new; openRec.add(name); rf = Object.assign(rf, {q:name, k:'', pr:'', st:'', fast:false, fav:false, dis:false}); plusK = ''; tab = 'recettes';
  recFlash = d.partage && familleCode() ? `${name} : enregistrée. Ajout à la banque commune…` : '';
  save(); render();
  if(d.partage && familleCode()) famPublier(nr).then(() => { recFlash = `${name} est dans la banque commune : toute la famille l'aura à sa prochaine ouverture de l'application.`; render(); })
    .catch(e => { recFlash = `${name} est gardée sur ce téléphone, mais la banque commune n'a pas pu être mise à jour (${e.message}). Réessaie avec « Partager avec la famille ».`; render(); });
}
function saveRecEdit(btn){
  const r = byName(btn.dataset.r), key = 'edit|'+btn.dataset.r, d = drafts[key], msg = btn.closest('.rbox').querySelector('.re_msg'); if(!r || !d) return;
  const {ing, err} = readRows(d.rows); if(err){ say(msg, err); return; }
  if(!ing.length){ say(msg, 'La recette doit garder au moins un ingrédient.'); return; }
  const k = d.k;
  const patch = {k, pr:d.pr, st:d.st, t:d.t, tm:+d.tm, tp:Math.min(+d.tp||+d.tm, +d.tm), mj:d.mj ? (mjOf(r)||1) : 0, sp:d.sp ? 1 : 0, oc:d.oc ? 1 : 0, sf:k==='souper' ? d.sf : '', sv:k==='souper' ? d.sv : '', i:ing, m:String(d.m||'').split(',').map(x => x.trim()).filter(Boolean), s:String(d.s||'').trim()};
  if(r.c) Object.assign(S.custom.find(x => x.n===r.n), patch); else S.redit[r.n] = patch;
  delete S.tmx[r.n]; delete (S.tpx||{})[r.n]; delete drafts[key]; openPan.delete(key); openRec.add(r.n); save(); render();
}
function saveSide(){
  const d = drafts.side, msg = $('#ns_msg'); if(!d) return;
  const n = String(d.n||'').trim(); if(!n){ say(msg, "Donne un nom à l'accompagnement."); return; }
  const {ing, err} = readRows(d.rows); if(err){ say(msg, err); return; }
  if(!ing.length){ say(msg, 'Ajoute au moins un ingrédient.'); return; }
  S.sidesx = S.sidesx||[]; S.sidesx.push({id:'x'+Date.now().toString(36), n, sl:d.sl, ty:['all'], i:ing});
  delete drafts.side; plusK = ''; tab = 'recettes'; rf = Object.assign(rf, {q:'', k:'acc'}); recFlash = `${n} est dans tes accompagnements.`; save(); render(); window.scrollTo(0, 0);
}

/* ---------- onglet Articles ---------- */
const BOISSON_RE = /\b(jus(?! de (citron|lime))|boissons?|gazeuses?|eau petillante|eau de source|cafe|the|tisane|bieres?|cola|limonade|cidre)\b/;
const COLL_RE = /croustilles?|\bchips\b|biscuits?|barres? tendres?|craquelins?|mais souffle|bretzels?|melange de noix|bonbons?|guimauves?|compotes?|collations?|pouding|jello|\bjell/;
/* rayon d'un article : celui choisi dans Articles, sinon boissons et collations sortis de l'épicerie générale */
function classer(name, ray){
  const A = art(name); if(A.ray) return A.ray;
  ray = RAYONS.includes(ray) ? ray : (ray ? guessRayon(name) : 'épicerie');
  if(ray==='épicerie' || ray==='garde-manger'){ const n = norm(name); if(BOISSON_RE.test(n)) return 'boissons'; if(COLL_RE.test(n)) return 'collations'; }
  return ray;
}
let artF = {q:'', f:'week'}, artSq = {};
function artSet(b, patch){
  S.art = S.art || {}; const o = Object.assign({}, S.art[b], patch);
  Object.keys(o).forEach(k => { const v = o[k]; if(v==='' || v==null || (Array.isArray(v) && !v.length)) delete o[k]; });
  if(Object.keys(o).some(k => k!=='n')) S.art[b] = o; else delete S.art[b];
}
function artList(f){
  const m = new Map(), put = (b, n, u, ray, row) => { if(!m.has(b)) m.set(b, {b, n:cap(plain(n)), u, ray, row}); };
  if(f==='week') buyList().rows.forEach(r => put(artB(r.name), r.name, r.u, r.rayon, r));
  else if(f==='mod'){ const ks = new Set(Object.keys(S.art||{}).concat(Object.keys(S.menu.dsel||{})));
    ks.forEach(b => { const c = catalog().find(x => x.b===b), r = S.menu.date ? buyList().rows.find(x => artB(x.name)===b) : null; put(b, r ? r.name : c ? c.n : ((S.art||{})[b]||{}).n || b, r ? r.u : c ? c.u : 'un', r ? r.rayon : c ? c.ray : 'épicerie', r); }); }
  else { if(S.menu.date) buyList().rows.forEach(r => put(artB(r.name), r.name, r.u, r.rayon, r)); catalog().forEach(c => put(c.b, c.n, c.u, c.ray, null)); }
  let L = [...m.values()]; const q = norm(artF.q).trim();
  if(q) L = L.filter(x => q.split(/\s+/).every(w => norm(x.n).includes(w)));
  return L.sort((a,b) => a.n.localeCompare(b.n,'fr'));
}
function artRow(x){
  const key = 'art|'+x.b, open = openPan.has(key), d = dealFor(x.n), man = (S.menu.dsel||{})[x.b], A = (S.art||{})[x.b] || {};
  const st = man==='none' ? 'Aucun spécial' : d ? `${d.s}${d.p ? ' · '+d.p : ''}` : '—';
  const mod = Object.keys(A).some(k => k!=='n') || man;
  return `<details class="row art" data-pan="${esc(key)}" data-b="${esc(x.b)}" ${open?'open':''}><summary><span class="an">${esc(x.n)}<small>${esc(cap(x.ray||'épicerie'))}${mod ? ' · modifié' : ''}</small></span><span class="rm${d?' sp':''}">${esc(st)}</span></summary>${open ? `<div class="rbody">${artBody(x)}</div>` : ''}</details>`;
}
function artSearchRows(b, q){
  const n = norm(q).trim(); if(n.length < 2) return '';
  const w = n.split(/\s+/), L = allSpec().filter(s => w.every(x => norm(s.t+' '+s.s).includes(x))).slice(0, 8);
  if(!L.length) return '<p class="small">Aucun spécial avec ces mots cette semaine.</p>';
  return L.map(s => `<div class="item"><span class="t">${tagHtml(s)}</span><span class="acts"><button class="btn s" data-a="ar_spick" data-b="${esc(b)}" data-id="${esc(spId(s))}" data-v="w">Cette semaine</button><button class="btn s p" data-a="ar_spick" data-b="${esc(b)}" data-id="${esc(spId(s))}" data-v="a">Toujours</button></span></div>`).join('');
}
function artBody(x){
  const b = x.b, A = (S.art||{})[b] || {}, man = (S.menu.dsel||{})[b], u = x.u || 'un';
  const row = x.row || {name:x.n, u, buy: u==='un' ? 1 : 1000, rayon:x.ray, k:keyOf(x.n,u)};
  const cur = dealFor(x.n), have = S.auto || (S.spec||[]).length;
  const C = dealCands(x.n, prep(allSpec())).map(s => ({s, c: isFinite(priceOf(s)) ? dealCost(s, row) : Infinity})).sort((a,b) => a.c - b.c);
  const bA = `data-b="${esc(b)}" data-n="${esc(x.n)}" data-u="${esc(u)}"`;
  let h = `<p class="sgrp">Spécial cette semaine</p>`;
  if(!have) h += `<p class="small">Cherche d'abord les spéciaux (carte de la semaine, onglet Menu).</p>`;
  else {
    if(man==='none') h += `<p class="small">Tu as choisi : aucun spécial pour cet article cette semaine.</p>`;
    h += C.length ? `<div class="list">${C.slice(0,6).map(({s,c}) => { const on = cur && spId(cur)===spId(s); return `<div class="item"><span class="t">${tagHtml(s)}${x.row && isFinite(c) ? `<small>≈ ${money(c)} pour ${esc(qt(row.buy, row.u))}</small>` : ''}</span>${on ? '<span class="small ok">Associé</span>' : `<button class="btn s" data-a="ar_pick" ${bA} data-id="${esc(spId(s))}">Choisir</button>`}<button class="btn s d" data-a="ar_ex" ${bA} data-id="${esc(spId(s))}" title="Ce produit n'est pas cet article : ne plus jamais l'associer">Pas ce produit</button></div>`; }).join('')}</div>`
      : `<p class="small">Aucun spécial trouvé avec les mots « ${esc((A.kw || reqToks(x.n).join(' ')))} ».</p>`;
    h += `<div class="acts">${man!=='none' ? `<button class="btn s" data-a="ar_none" ${bA}>Aucun spécial cette semaine</button>` : ''}${man ? `<button class="btn s" data-a="ar_auto" ${bA}>Revenir à l'automatique</button>` : ''}</div>
      <label class="f">Chercher le bon spécial dans les circulaires<input type="text" class="ar_sq" data-b="${esc(b)}" value="${esc(artSq[b]||'')}" placeholder="Un mot du produit ou de la marque" autocomplete="off"></label>
      <div class="list ar_sr" data-b="${esc(b)}">${artSearchRows(b, artSq[b]||'')}</div>
      <p class="small">« Cette semaine » associe ce spécial jusqu'à la fin de la semaine. « Toujours » retient aussi ce produit : il sera reconnu les prochaines semaines.</p>`;
  }
  const H = (S.ph||{})[b] || [];
  h += `<p class="sgrp">Prix en spécial vus</p>${H.length ? `<ul class="todo">${H.map(e => `<li>${esc(dShort(e.d))} · ${esc(e.s)} · <b>${esc(money(e.p))}</b> · ${esc(e.t)}${e.r ? ` (habituel ≈ ${esc(money(e.r))})` : ''}</li>`).join('')}</ul>` : `<p class="small">Rien encore : le prix trouvé est noté à chaque recherche des spéciaux.</p>`}`;
  const est = prixBase(x.n, u, x.ray) * (u==='un' ? 1 : 1000), L = (S.prices||{})[keyOf(x.n,u)], unit = u==='g' ? '$ / kg' : u==='ml' ? '$ / L' : '$ / unité';
  const bt = baremeTxt(x.n); if(bt) h += `<p class="small"><b>Prix réguliers (barème Maxi)</b> : ${esc(bt)}.</p>`;
  h += `<p class="sgrp">Trouver ses spéciaux</p>
    <label class="f">Mots recherchés (une virgule sépare deux façons de le nommer)<input type="text" class="ar_in" data-k="kw" ${bA} value="${esc(A.kw||'')}" placeholder="${esc(reqToks(x.n).join(' '))}"></label>
    <label class="f">Mots à exclure<input type="text" class="ar_in" data-k="no" ${bA} value="${esc(A.no||'')}" placeholder="pané, assaisonné, bio…"></label>
    ${(A.ex||[]).length ? `<p class="small">Produits écartés : ${esc(A.ex.slice(-5).join(' ; '))}${A.ex.length > 5 ? ' …' : ''}. <a href="#" data-a="ar_unex" ${bA}>Les reprendre</a></p>` : ''}
    ${(A.learn||[]).length ? `<p class="small">Produits retenus : ${esc(A.learn.map(t => t.join(' ')).join(' ; '))}. <a href="#" data-a="ar_unlearn" ${bA}>Oublier</a></p>` : ''}
    <p class="sgrp">Classement, format et prix</p>
    <div class="grid2"><label class="f">Rayon<select class="ar_in" data-k="ray" ${bA}><option value="">Automatique</option>${RAYONS.map(r => `<option value="${r}" ${A.ray===r?'selected':''}>${esc(cap(r))}</option>`).join('')}</select></label>
      <label class="f">Prix habituel (${unit})<input type="text" inputmode="decimal" class="ar_in num" data-k="pu" ${bA} value="${L && !L.sp ? String(Math.round(L.pu*(u==='un'?1:1000)*100)/100).replace('.', ',') : ''}" placeholder="≈ ${String(Math.round(est*100)/100).replace('.', ',')}"></label></div>
    <div class="grid2"><label class="f">Se vend par paquet de<input type="text" inputmode="decimal" class="ar_in num" data-k="pkq" ${bA} value="${A.pk ? String(A.pk.q).replace('.', ',') : ''}" placeholder="${packOf(x.n, u) || '—'}"></label>
      <label class="f">Unité du paquet<select class="ar_in" data-k="pku" ${bA}>${[['un','unités'],['g','g'],['ml','ml']].map(([v,t]) => `<option value="${v}" ${((A.pk && A.pk.u) || u)===v?'selected':''}>${t}</option>`).join('')}</select></label></div>
    ${Object.keys(A).some(k => k!=='n') || man ? `<button class="btn s d" data-a="ar_reset" ${bA}>Tout remettre par défaut</button>` : ''}`;
  return h;
}
/* convertisseur : poids, volumes (tasse de 250 ml), densités courantes, prix à la livre et au kilo */
const CV_U = [['g','g',1,'m'],['kg','kg',1000,'m'],['lb','lb',453.6,'m'],['oz','oz',28.35,'m'],['ml','ml',1,'v'],['L','L',1000,'v'],['tasse','tasse',250,'v'],['cs','c. à soupe',15,'v'],['ct','c. à thé',5,'v']];
const CV_D = [['','Liquide (eau, lait, bouillon)',1],['farine','Farine',0.53],['sucre','Sucre',0.85],['cassonade','Cassonade',0.85],['glace','Sucre à glacer',0.5],['beurre','Beurre',0.96],['huile','Huile',0.92],['riz','Riz',0.85],['avoine',"Flocons d'avoine",0.38],['fromage','Fromage râpé',0.45],['chapelure','Chapelure',0.45],['cacao','Cacao',0.42],['miel','Miel',1.42],['sirop',"Sirop d'érable",1.32],['pepites','Pépites de chocolat',0.7]];
let cv = {q:'1', u:'tasse', i:'farine', pq:'', pu:'lb'};
const nfr = (x, d) => String(Math.round(x * 10**d) / 10**d).replace('.', ',');
const nAuto = x => x >= 100 ? nfr(x, 0) : x >= 10 ? nfr(x, 1) : nfr(x, 2);
function frac(x){
  const w = Math.floor(x + 1e-9), r = x - w, F = [[0,''],[.25,'¼'],[1/3,'⅓'],[.5,'½'],[2/3,'⅔'],[.75,'¾'],[1,'']];
  const [v, s] = F.reduce((a, f) => Math.abs(f[0]-r) < Math.abs(a[0]-r) ? f : a);
  if(Math.abs(v-r) > .04) return nAuto(x);
  const W = w + (v===1 ? 1 : 0); return W ? W+(s ? ' '+s : '') : (s || '0');
}
function convOut(){
  const q = parseFloat(String(cv.q).replace(',', '.')), U = CV_U.find(x => x[0]===cv.u), D = (CV_D.find(x => x[0]===cv.i) || CV_D[0])[2];
  if(!(q > 0) || !U) return '<p class="small">Entre une quantité.</p>';
  const g = U[3]==='m' ? q*U[2] : q*U[2]*D, ml = U[3]==='v' ? q*U[2] : q*U[2]/D;
  const M = [['g', nAuto(g)], ['kg', nAuto(g/1000)], ['lb', nAuto(g/453.6)], ['oz', nAuto(g/28.35)]];
  const V = [['ml', nAuto(ml)], ['L', nAuto(ml/1000)], [ml/250 > 1 ? 'tasses' : 'tasse', frac(ml/250)], ml <= 300 ? ['c. à soupe', frac(ml/15)] : null, ml <= 60 ? ['c. à thé', frac(ml/5)] : null].filter(Boolean);
  return `<div class="cvo">${M.concat(V).filter(([u]) => u!==U[1] && !(U[0]==='tasse' && u==='tasses')).map(([u, v]) => `<span><b>${v}</b> ${u}</span>`).join('')}</div>
    <p class="small">${U[3]==='m' ? 'Volumes' : 'Poids'} calculés pour : ${esc((CV_D.find(x => x[0]===cv.i) || CV_D[0])[1].toLowerCase())}. Tasse de 250 ml, c. à soupe de 15 ml, c. à thé de 5 ml.</p>`;
}
function convPrix(){
  const v = parseFloat(String(cv.pq).replace(',', '.')); if(!(v > 0)) return '';
  const o = cv.pu==='lb' ? [[v*2.2046,'$ / kg'],[v/4.536,'$ / 100 g']] : cv.pu==='kg' ? [[v/2.2046,'$ / lb'],[v/10,'$ / 100 g']] : [[v*10,'$ / kg'],[v*4.536,'$ / lb']];
  return o.map(([x,u]) => `<span><b>${nfr(x, 2)}</b> ${u}</span>`).join('');
}
function convCard(){
  const open = openPan.has('conv');
  return `<details class="card pick" data-pan="conv" ${open?'open':''}><summary>Convertisseur de mesures et de prix</summary>
    <div class="grid2"><label class="f">Quantité<input type="text" inputmode="decimal" id="cv_q" value="${esc(cv.q)}"></label>
      <label class="f">Unité<select id="cv_u">${CV_U.map(([v,t]) => `<option value="${v}" ${cv.u===v?'selected':''}>${t}</option>`).join('')}</select></label></div>
    <label class="f">Aliment (pour passer d'un volume à un poids)<select id="cv_i">${CV_D.map(([v,t]) => `<option value="${v}" ${cv.i===v?'selected':''}>${esc(t)}</option>`).join('')}</select></label>
    <div id="cv_out">${convOut()}</div>
    <p class="sgrp">Prix au poids</p>
    <div class="grid2"><label class="f">Montant ($)<input type="text" inputmode="decimal" id="cvp_q" value="${esc(cv.pq)}" placeholder="4,99"></label>
      <label class="f">Par<select id="cvp_u">${[['lb','livre (lb)'],['kg','kilo (kg)'],['100g','100 g']].map(([v,t]) => `<option value="${v}" ${cv.pu===v?'selected':''}>${t}</option>`).join('')}</select></label></div>
    <div class="cvo" id="cvp_out">${convPrix()}</div></details>`;
}
/* ---------- mise à jour des prix ----------
   Le site de Maxi ne peut pas être lu par l'application (il le bloque). On liste donc les articles qui comptent,
   avec un lien vers maxi.ca et le prix régulier vu dans les circulaires; on inscrit le prix du format, c'est tout. */
function prixArts(){
  const w = new Map(), add = (n, x) => { const b = baremeRaw(n); if(!b) return; const k = bxKey(b), o = w.get(k) || {b, n:plain(n), w:0}; o.w += x; w.set(k, o); };
  if(S.menu.date){ try{ buyList().rows.forEach(r => add(r.name, 20)); }catch(e){} }
  (S.ess||[]).concat(S.snacks||[]).forEach(o => add(o.name, 8));
  allRecipes().forEach(r => r.i.forEach(g => add(g[2], 1)));
  const q = norm(artF.q||'').trim();
  let L = [...w.values()].sort((a, c) => c.w - a.w);
  if(q) L = L.filter(o => norm(o.n).includes(q)); else L = L.slice(0, 40);
  return L;
}
function prixRow(o){
  const b = mergeBx(o.b), raw = o.b[1], ov = (S.bx||{})[bxKey(o.b)] || {}, k = esc(bxKey(o.b)), n = esc(o.n);
  const unitTxt = s => raw.u==='un' ? (s===1 ? "l'unité" : 'paquet de '+s) : fq(s, raw.u);
  const inp = (val, ph, extra) => `<input type="text" inputmode="decimal" class="num pm_in" data-k="${k}" ${extra} value="${val ? String(val).replace('.', ',') : ''}" placeholder="${String(ph).replace('.', ',')}" aria-label="Nouveau prix">`;
  const fields = raw.kg ? `<label class="f">Prix au kilo ($/kg)${inp(ov.kg, b[1].kg, 'data-kg="1"')}</label>`
    : raw.f.map(([s], i) => `<label class="f">${esc(cap(unitTxt(s)))} ($)${inp(ov.f && ov.f[i], b[1].f[i][1], `data-i="${i}"`)}</label>`).join('');
  const H = ((S.ph||{})[artB(o.n)] || []).filter(e => e.r).slice(0, 2);
  const vu = H.length ? `<small>Prix régulier vu dans les circulaires : ${H.map(e => `${esc(money(e.r))} chez ${esc(e.s)} (${esc(e.t)}, ${esc(dShort(e.d))})`).join(' · ')}</small>` : '';
  const quand = ov.d ? `<small class="ok">Mis à jour le ${esc(dShort(ov.d))}</small>` : '';
  return `<div class="item" style="display:block"><span class="t"><b>${esc(cap(o.n))}</b>${quand}${peTxt(o.b)}${vu}</span>
    <div class="grid2" style="margin-top:6px">${fields}</div>
    <p class="small"><a href="https://www.maxi.ca/fr/search?search-bar=${encodeURIComponent(o.n)}" target="_blank" rel="noopener">Voir le prix sur maxi.ca ↗</a>${Object.keys(ov).some(x => x!=='d') ? ` · <a href="#" data-a="pm_reset" data-k="${k}">Revenir au prix du fichier</a>` : ''}</p></div>`;
}
function prixView(){
  const L = prixArts(), p = pmaj();
  return peCard() + `<div class="card"><h3>Prix de référence Maxi (à la main)</h3>
    <p class="small">${peFrais() ? 'Le relevé automatique remplace ces prix pour les articles qu\'il trouve. Ceux-ci servent pour le reste, et pour estimer les épiceries sans relevé. ' : ''}Prix réguliers (pas les spéciaux) des articles qui comptent le plus dans ton épicerie, ${esc(PRIX_MAJ_TXT())}. Touche « Voir le prix sur maxi.ca », puis inscris le prix du même format. Un champ vide garde le prix actuel (en gris).</p>
    <label class="f">Ajuster tous les autres prix de (%)<input type="text" inputmode="decimal" class="num" id="pm_pct" value="${p.pct ? String(p.pct).replace('.', ',') : ''}" placeholder="0 (ex. 3 pour +3 %)"></label>
    <p class="small">Pratique pour suivre l'inflation sur tout ce que tu ne vérifies pas un par un.</p>
    <div class="acts"><button class="btn s p" data-a="pm_done">J'ai terminé la mise à jour</button></div>
    <p class="note" id="pm_msg" hidden></p></div>
    ${L.length ? `<div class="card list">${L.map(prixRow).join('')}</div>` : `<div class="empty"><b>Aucun article</b><span>Rien ne correspond à cette recherche.</span></div>`}
    ${!artF.q ? '<p class="small">Seuls les 40 articles les plus importants sont affichés : cherche un article plus haut pour en voir un autre.</p>' : ''}`;
}
let pbSec = 'budget';
const pbSeg = () => `<div class="seg" role="group" aria-label="Prix et budget">${[['budget','Budget'],['articles','Articles'],['prix','Prix des épiceries']].map(([v, t]) => `<button class="${pbSec===v?'on':''}" data-a="pb_sec" data-v="${v}" aria-pressed="${pbSec===v}">${t}</button>`).join('')}</div>`;
function renderArticles(){ renderView(); }
function artHtml(){
  const f = artF.f==='week' && !S.menu.date ? 'all' : artF.f;
  const L = artList(f), shown = L.slice(0, 150);
  let h = `<div class="card"><h2 style="font-size:1.25rem">Articles</h2><p class="small">Le spécial associé à chaque article. S'il n'est pas le bon, ouvre l'article : choisis le bon, exclus-le, ou change les mots, le rayon, le format ou le prix habituel. Ces réglages restent pour les prochaines semaines.</p>
    <input type="text" id="ar_q" value="${esc(artF.q)}" placeholder="Chercher un article" aria-label="Chercher un article" autocomplete="off">
    <div class="seg" role="group" aria-label="Articles à afficher">${[['week','Ma liste'],['all','Tous'],['mod','Modifiés']].map(([v,t]) => `<button class="${f===v?'on':''}" data-a="ar_f" data-v="${v}" ${v==='week' && !S.menu.date ? 'disabled' : ''}>${t}</button>`).join('')}</div></div>`;
  h += convCard();
  if(shown.length) h += `<div class="card list">${shown.map(artRow).join('')}</div>`;
  else h += `<div class="empty"><b>Aucun article</b><span>${f==='mod' ? "Aucun article modifié pour l'instant." : 'Rien ne correspond à cette recherche.'}</span></div>`;
  if(L.length > shown.length) h += `<p class="small">${L.length - shown.length} autres articles : précise la recherche.</p>`;
  return h;
}

/* Menu de la semaine — Profil de la famille, assistant de départ, réglages, Ma semaine.
   Les fichiers de js/ partagent les mêmes variables globales; ils sont chargés dans l'ordre de index.html. */
/* ---------- rendu : réglages ---------- */
function listEditor(id, arr){
  return `<div id="${id}">` + arr.map((s,i) => `<div class="grid4" style="margin-bottom:6px"><input type="text" data-l="${id}" data-i="${i}" data-f="name" value="${esc(s.name)}" aria-label="Nom"><input type="text" inputmode="decimal" class="num" data-l="${id}" data-i="${i}" data-f="q" value="${esc(s.q)}" aria-label="Quantité"><select data-l="${id}" data-i="${i}" data-f="u" aria-label="Unité"><option value="un" ${s.u==='un'?'selected':''}>un</option><option value="g" ${s.u==='g'?'selected':''}>g</option><option value="ml" ${s.u==='ml'?'selected':''}>ml</option></select><button class="btn s d" data-a="ldel" data-l="${id}" data-i="${i}" aria-label="Retirer">×</button></div><select data-l="${id}" data-i="${i}" data-f="r" aria-label="Rayon" style="margin-bottom:10px">${RAYONS.map(r=>`<option ${s.r===r?'selected':''}>${r}</option>`).join('')}</select>`).join('') + `<button class="btn s" data-a="ladd" data-l="${id}">Ajouter une ligne</button></div>`;
}
function histHtml(){
  if(!S.hist.length) return '<p class="small">Aucune semaine terminée pour l\'instant.</p>';
  const paid = S.hist.map(w => w.paid).filter(x => x>0), avg = paid.length ? paid.reduce((a,b) => a+b, 0)/paid.length : 0;
  return (avg ? `<p class="small">Moyenne payée : <b>${money(avg)}</b> sur ${paid.length} semaine${paid.length>1?'s':''}${S.p.budget ? `, pour un budget de ${money(S.p.budget)}` : ''}.</p>` : '')
    + S.hist.slice().reverse().slice(0,12).map(w => `<p class="small"><b>${esc(w.date)}</b>${w.paid ? ` (${money(w.paid)})` : ''} : ${histItems(w).map(x => esc(x.r)).join(', ')}</p>`).join('');
}
/* Prix de référence : date du relevé Maxi, comment les garder à jour */
function prixCard(){
  const nPerso = Object.values(S.prices||{}).filter(x => x && !x.sp).length, nVus = Object.keys(S.ph||{}).length;
  return `<div class="card"><h3>Prix de référence</h3>
    <p class="small">Les prix réguliers viennent de maxi.ca (${esc(PRIX_MAJ_TXT())}${+pmaj().pct ? `, ajustés de ${esc(String(pmaj().pct).replace('.', ','))} %` : ''}). Ils servent quand un article n'est pas en spécial.${prixVieux() ? ' <b class="over">Ce relevé date de plus de 4 mois : les prix ont probablement monté.</b>' : ''}</p>
    <p class="small">Ils se corrigent tout seuls avec tes données :</p>
    <ul class="todo small">
      <li><b>Prix payé</b> : dans Épicerie, touche le prix d'un article pour inscrire ce que tu as payé. Ce prix remplace celui de Maxi pour cet article. ${nPerso ? `(${nPerso} prix à toi)` : ''}</li>
      <li><b>Prix habituel</b> : dans Articles, inscris le prix régulier d'un article.</li>
      <li><b>Circulaires</b> : à chaque recherche, les spéciaux vus sont notés avec le prix habituel quand la circulaire indique le rabais. ${nVus ? `(${nVus} articles suivis)` : ''}</li>
    </ul>
    <div class="acts"><button class="btn s p" data-a="pm_go">Mettre à jour les prix</button></div>
    <label class="check"><input type="checkbox" id="pm_rappel" ${pmaj().rappel !== false ? 'checked' : ''}> Me le rappeler chaque mois</label></div>`;
}
function backupCard(){
  const L = readCopies(), fmt = d => { try{ return new Date(d).toLocaleString('fr-CA', {day:'numeric', month:'long', hour:'2-digit', minute:'2-digit'}); }catch(e){ return d; } };
  let res = ''; try{ res = localStorage.getItem(RESCUE) || ''; }catch(e){}
  const n = Object.keys(S.stock||{}).length, nr = (S.custom||[]).length, np = Object.keys(S.prices||{}).length;
  return `<div class="card" id="sauvegarde"><h3>Sauvegarde de mes données</h3>
    <p class="small">Tes données restent sur ce téléphone : ${n} article${n>1?'s':''} à la maison, ${nr} recette${nr>1?'s':''} à toi, ${np} prix noté${np>1?'s':''}, tes réglages et ton historique. Une mise à jour de l'application ne remplace que le code : tes données ne sont pas touchées.</p>
    ${res ? `<p class="note">Des données n'ont pas pu être lues et ont été mises de côté sans rien effacer. <button class="btn s" id="bk_rescue" data-armed="0">Essayer de les restaurer</button></p>` : ''}
    <p class="small"><b>Copies automatiques sur ce téléphone</b> : avant chaque mise à jour et une fois par jour, les 5 plus récentes. Elles protègent contre une erreur, mais pas si l'icône de l'application est supprimée.</p>
    ${L.length ? `<div class="list">${L.map((c,j) => `<div class="item"><span class="t"><b>${esc(c.label)}</b><small>${esc(fmt(c.d))}</small></span><button class="btn s" data-a="bk_restore" data-j="${j}" data-armed="0">Restaurer</button></div>`).join('')}</div>` : '<p class="small">Aucune copie pour l’instant.</p>'}
    ${IOS ? `<p class="small"><b>Copie dans Fichiers</b> : la seule qui survit si l'icône est supprimée ou si tu changes de téléphone. « Enregistrer dans Fichiers » ne remplace jamais l'ancienne copie : l'iPhone ajoute 2, 3, 4… au nom. Pour garder un seul fichier à jour, crée une fois le raccourci ci-dessous et choisis « Sauvegarde Menu » dans le partage. ${S.lastExport ? `Dernière copie : ${esc(fmtDate(S.lastExport))}.` : 'Aucune copie dans Fichiers pour l’instant.'}</p>`
    : `<p class="small"><b>Copie dans ${FICH}</b> : la seule qui survit si l'application est désinstallée, si les données ${ANDROID ? 'de Chrome' : 'du navigateur'} sont effacées ou si tu changes de ${ANDROID ? 'téléphone' : 'appareil'}. « Sauvegarder une copie » enregistre le fichier menu-semaine-sauvegarde.json dans ${FICH}. L'ancienne copie n'est pas remplacée : le nom reçoit (1), (2)… Pour restaurer, choisis la plus récente, ou plusieurs : l'application prend la plus récente.${canShareFiles() ? ` Pour la garder ailleurs que sur ${ANDROID ? 'le téléphone' : "l'appareil"}, touche « Envoyer une copie » et choisis Google Drive ou ton courriel.` : ''} ${S.lastExport ? `Dernière copie : ${esc(fmtDate(S.lastExport))}.` : `Aucune copie dans ${FICH} pour l’instant.`}</p>`}
    ${IOS ? `<details class="panel"><summary>Créer le raccourci « Sauvegarde Menu » (une seule fois)</summary>
      <ol class="small steps-l">
        <li>Ouvre l'app Raccourcis, touche + et nomme le raccourci « Sauvegarde Menu ».</li>
        <li>Touche ⓘ (Détails) et active « Afficher dans la feuille de partage ». Dans le bloc « Recevoir… » en haut, garde seulement « Fichiers ».</li>
        <li>Ajoute l'action « Enregistrer le fichier ». Elle enregistre ce que le partage lui envoie.</li>
        <li>Dans cette action, désactive « Demander où enregistrer », choisis le dossier (iCloud Drive, par exemple) et active l'option qui écrase le fichier s'il existe déjà.</li>
        <li>Touche OK. Ensuite : « Sauvegarder », puis « Sauvegarde Menu » dans la liste du partage. Le fichier menu-semaine-sauvegarde.json est remplacé, sans numéro.</li>
      </ol>
      <p class="small">Les copies numérotées déjà créées peuvent être supprimées dans Fichiers. Pour restaurer, tu peux aussi toutes les choisir : l'application prend la plus récente.</p>
    </details>` : ''}
    <label class="check"><input type="checkbox" data-pb="bkOpen" ${S.p.bkOpen!==false?'checked':''}> À chaque ouverture, proposer la sauvegarde s'il y a des changements</label>
    <div class="acts"><button class="btn s p" id="bk_file">Sauvegarder une copie</button>${!IOS && canShareFiles() ? '<button class="btn s" id="bk_send">Envoyer une copie</button>' : ''}<button class="btn s" id="bk_copy">Copier en texte</button></div>
    <label class="f">Restaurer une copie : choisis le fichier (ou plusieurs : la plus récente est prise), ou colle le texte<input type="file" id="bk_pick" multiple accept=".json,application/json,text/plain"></label>
    <textarea id="bk_txt" placeholder="Ou colle ici une copie en texte" aria-label="Sauvegarde"></textarea>
    <button class="btn s d" id="bk_imp" data-armed="0">Restaurer cette copie</button><div class="small" id="bk_msg"></div></div>`;
}
/* iPhone : le partage (« Enregistrer dans Fichiers »). Android et ordinateur : le fichier va dans Téléchargements.
   mode 'share' : toujours le partage (Google Drive, courriel…). Rend 'share', 'dl', ou '' si annulé. */
const canShareFiles = () => { try{ return !!(navigator.canShare && navigator.canShare({files:[new File(['{}'], 'x.json', {type:'application/json'})]})); }catch(e){ return false; } };
async function saveFile(txt, name, title, mode, type){
  const f = new File([txt], name, {type: type || 'application/json'});
  if(mode==='share' || (IOS && mode!=='dl')){
    try{ if(navigator.canShare && navigator.canShare({files:[f]})){ await navigator.share({files:[f], title}); return 'share'; } }
    catch(e){ if(e && e.name==='AbortError') return ''; }
  }
  const a = document.createElement('a'), u = URL.createObjectURL(f); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 60000);
  return 'dl';
}
async function exportFile(mode){
  const prev = S.lastExport; S.lastExport = isoToday();
  const txt = JSON.stringify(S), name = 'menu-semaine-sauvegarde.json';
  let how = '';
  try{ how = await saveFile(txt, name, 'Sauvegarde Menu de la semaine', mode); }catch(e){ S.lastExport = prev; copier(txt, '#bk_msg'); return; }
  if(!how){ S.lastExport = prev; return; }
  S.lastExport = isoToday(); save(); S.bkDirty = false; bkBar = false; try{ localStorage.setItem(KEY, JSON.stringify(S)); }catch(e){} render();
  const m = $('#bk_msg'); if(m) m.textContent = how==='dl' ? `Copie enregistrée dans ${FICH} : ${name}.` : IOS ? 'Copie créée. Avec le raccourci « Sauvegarde Menu », elle remplace la précédente.' : 'Copie envoyée.';
}
/* passage des données d'une version précédente à la 2.0 (au chargement et à chaque restauration) */
function migrer(){
  const m = S.menu, dow = iso => new Date(iso+'T12:00:00').getDay();
  /* un menu créé par l'ancienne version garde ses jours et sa date d'épicerie */
  if(m.date && !m.start) m.start = S.dates.shop || isoToday();
  if(m.date && !m.shop) m.shop = S.dates.shop || m.start;
  /* profil créé d'après les portions actuelles (sans les changer), à vérifier par l'utilisateur */
  if(S.setup && !isObj(S.profil)){
    const n = Math.max(1, Math.round(+S.p.souper || 4)), a = Math.min(2, n), ram = S.dates.shop ? dow(S.dates.shop) : m.shop ? dow(m.shop) : 6;
    S.profil = Object.assign(PROFIL0(), {membres: Array.from({length:n}, (_, i) => i < a ? {a:'adulte', ap:'normal', l:(S.p.restes||0) > i} : {a:'enfant', age:14, ap:'normal', l:(S.p.restes||0) > i}),
      jours:{plan:(ram + 5) % 7, cmd:(ram + 6) % 7, ram, cuis: m.start ? dow(m.start) : ram}, princ:S.p.main || S.stores[0] || '', verifier:true});
  }
}
function restoreFrom(raw, label){
  const o = JSON.parse(raw); if(!isObj(o) || !isObj(o.menu) || !isObj(o.stock)) throw new Error('invalide');
  const m = mergeState(o);   /* vérifie et complète AVANT de toucher aux données actuelles */
  if(!loadFailed && !snapshot('Avant la restauration', JSON.stringify(S))){ const e = $('#bk_msg'); if(e) e.textContent = "Espace plein : enregistre d'abord une sauvegarde dans " + FICH + ", puis réessaie."; throw Object.assign(new Error('espace'), {shown:true}); }
  const prev = S; S = m; S.appv = APPV; migrer();
  try{ render(); }catch(e){ S = prev; try{ save(); render(); }catch(_){} throw e; }   /* copie qui ne s'affiche pas : on revient aux données d'avant */
  loadFailed = false; save(); render();
  S.flash = label; const bm = $('#bk_msg'); if(bm) bm.textContent = label;
}
/* ---------- profil de la famille ----------
   Le profil décrit la famille, son horaire et ses épiceries. Il est gardé sur le téléphone (S.profil)
   et sert à calculer les portions, les lunchs, la semaine du menu et la date des spéciaux. */
const DOW = ['dimanche','lundi','mardi','mercredi','jeudi','vendredi','samedi'];
const APPETITS = [['petit','Petit appétit',.8],['normal','Appétit normal',1],['grand','Grand appétit',1.25]];
const PROFIL0 = () => ({membres:[{a:'adulte', ap:'normal', l:true},{a:'adulte', ap:'normal', l:true},{a:'enfant', age:10, ap:'normal', l:true},{a:'enfant', age:8, ap:'normal', l:true}],
  jours:{plan:4, cmd:5, ram:6, cuis:0}, princOnly:true, v:1});
const profil = () => { if(!isObj(S.profil)) S.profil = PROFIL0(); const p = S.profil; if(!Array.isArray(p.membres) || !p.membres.length) p.membres = PROFIL0().membres; if(!isObj(p.jours)) p.jours = PROFIL0().jours; return p; };
/* portion d'une personne : adulte 1; enfant selon l'âge (un ado mange comme un adulte), × appétit */
function portionDe(m){
  const base = m.a==='adulte' ? 1 : (+m.age||8) <= 5 ? .5 : (+m.age||8) <= 9 ? .7 : (+m.age||8) <= 12 ? .9 : 1.1;
  return base * ((APPETITS.find(x => x[0]===m.ap) || APPETITS[1])[2]);
}
const portionsFamille = () => profil().membres.reduce((t, m) => t + portionDe(m), 0);
const portionsLunch = () => profil().membres.filter(m => m.l).reduce((t, m) => t + portionDe(m), 0);
/* applique le profil aux réglages de portions déjà utilisés partout dans l'application */
function appliquerProfil(){
  /* seulement les portions du souper et des restes pour les lunchs : les autres réglages restent ceux de l'utilisateur */
  const P = profil(), f = Math.max(1, Math.round(portionsFamille())), l = Math.round(portionsLunch());
  S.p.souper = Math.min(12, f); S.p.restes = Math.min(10, l);
  if(S.p.nDin === undefined) S.p.nDin = l ? 5 : 0;
  if(P.princ){ S.p.main = P.princ; if(!S.stores.includes(P.princ)) S.stores = [P.princ].concat(S.stores); }
}
/* prochain jour de la semaine `dow` à partir de la date iso (le jour même compte) */
const nextDow = (iso, dow) => { const d = new Date(iso+'T12:00:00').getDay(); return addDays(iso, ((dow - d) + 7) % 7); };
const nextPickup = () => nextDow(isoToday(), profil().jours.ram);
/* premier jour de cuisine après le ramassage */
const startFrom = shop => S.profil ? nextDow(shop, profil().jours.cuis) : shop;
const famLine = () => { const M = profil().membres, a = M.filter(m => m.a==='adulte').length, e = M.filter(m => m.a!=='adulte');
  return `${a} adulte${a>1?'s':''}${e.length ? `, ${e.length} enfant${e.length>1?'s':''} (${e.map(m => (+m.age||'?')+' ans').join(', ')})` : ''}`; };

function familleCard(){
  const P = profil();
  const row = (m, i) => `<div class="item" style="display:block"><label class="f">Prénom (facultatif)<input type="text" data-pf="nom" data-i="${i}" value="${esc(m.nom||'')}" maxlength="30" autocomplete="off" placeholder="${esc(nomDe(i))}"></label><div class="grid2">
      <label class="f">${m.a==='adulte' ? 'Adulte' : 'Enfant'} ${P.membres.slice(0, i+1).filter(x => (x.a==='adulte')===(m.a==='adulte')).length}<select data-pf="a" data-i="${i}"><option value="adulte" ${m.a==='adulte'?'selected':''}>Adulte</option><option value="enfant" ${m.a!=='adulte'?'selected':''}>Enfant</option></select></label>
      ${m.a!=='adulte' ? `<label class="f">Âge<input type="text" inputmode="numeric" class="num" data-pf="age" data-i="${i}" value="${esc(m.age||'')}" placeholder="ans"></label>` : '<span></span>'}
      <label class="f">Appétit<select data-pf="ap" data-i="${i}">${APPETITS.map(([v,n]) => `<option value="${v}" ${m.ap===v?'selected':''}>${n}</option>`).join('')}</select></label>
      <label class="check" style="align-self:end"><input type="checkbox" data-pf="l" data-i="${i}" ${m.l?'checked':''}> Lunch (travail ou école)</label></div>
      ${goutsBlock(m, i)}
      ${P.membres.length > 1 ? `<button class="btn s d" data-a="pf_rm" data-i="${i}">Retirer</button>` : ''}</div>`;
  return `<div class="card"><h3>La famille</h3><p class="small">Les portions sont calculées d'après la famille : ${esc(famLine())}, soit environ <b>${nfr(portionsFamille(), 1)} portions</b> au souper et <b>${nfr(portionsLunch(), 1)}</b> en lunchs (restes).</p>
    <p class="small">Note les goûts de chacun : le menu favorise ce que chacun aime et répartit les coups de cœur dans la semaine.</p>
    <div class="list">${P.membres.map(row).join('')}</div>
    <div class="acts"><button class="btn s" data-a="pf_add" data-v="adulte">Ajouter un adulte</button><button class="btn s" data-a="pf_add" data-v="enfant">Ajouter un enfant</button></div></div>`;
}
const dowSel = (k, label) => `<label class="f">${label}<select data-pj="${k}">${[0,1,2,3,4,5,6].map(d => `<option value="${d}" ${profil().jours[k]===d?'selected':''}>${cap(DOW[d])}</option>`).join('')}</select></label>`;
function horaireCard(){
  return `<div class="card"><h3>Horaire de la semaine</h3><p class="small">Le menu commence le premier jour de cuisine après le ramassage. Les spéciaux sont choisis pour la date du ramassage, et l'accueil propose la bonne étape chaque jour.</p>
    <div class="grid2">${dowSel('plan','Je planifie le')}${dowSel('cmd','Je commande le')}${dowSel('ram','Je ramasse le')}${dowSel('cuis','On commence à cuisiner le')}</div>
    <label class="check"><input type="checkbox" data-pfb="princOnly" ${profil().princOnly!==false?'checked':''}> Faire la liste à l'épicerie principale; m'avertir quand une autre est nettement plus avantageuse</label></div>`;
}
function rayonsCard(){
  const o = rayOrder();
  return `<div class="card"><h3>Ordre des rayons</h3><p class="small">La liste suit cet ordre. Place-les comme ton parcours dans le magasin ou dans l'appli de commande.</p>
    <div class="list">${o.map((r, j) => `<div class="item"><span class="t">${j+1}. ${esc(cap(r))}</span>${j ? `<button class="btn s" data-a="rayup" data-j="${j}" aria-label="Monter ${esc(r)}">Monter</button>` : ''}</div>`).join('')}</div></div>`;
}
function testCard(){
  if(!TEST) return '';
  let has = false; try{ has = !!localStorage.getItem(REAL_KEY); }catch(e){}
  return `<div class="card call"><h3>Version de test</h3><p class="small">Cette version garde ses données à part. Tes vraies données (version familiale) ne sont jamais modifiées.</p>
    ${has ? `<button class="btn s p" id="test_copy" data-armed="0">Copier mes vraies données dans la version de test</button>` : `<p class="small">Aucune donnée de la version familiale sur ce téléphone. Pour partir des données d'un autre téléphone : sur celui-ci, Profil → Compte → « Enregistrer une copie », puis ici « Restaurer » avec ce fichier.</p>`}
    <p class="note" id="test_msg" hidden></p></div>`;
}
/* le profil seul (sans le menu ni l'historique), à garder ou à donner à un proche */
const PROFIL_KEYS = ['profil','cp','stores','storesx','ess','snacks','maison','bx','pmaj','art'];
/* Profil → Épiceries : le code de la famille, pour les spéciaux et les prix du robot */
function codeCard(){
  const c = familleCode();
  return `<div class="card" id="code_card"><h3>Code de la famille</h3>
    <p class="small">Les spéciaux de la semaine et les prix relevés par le robot sont réservés à la famille et aux amis. Ils sont chiffrés : seul un téléphone qui a le code peut les lire. Le code reste sur ce téléphone; il n'est pas dans les sauvegardes.</p>
    ${c ? `<p class="note">Ce téléphone a le code.${S.auto && S.auto.robot ? ` Spéciaux du robot lus le ${esc(fmtDate(S.auto.maj))}.` : ''}</p>
      <div class="acts"><button class="btn s" data-a="fc_test">Vérifier</button><button class="btn s d" data-a="fc_forget" data-armed="0">Oublier le code</button></div>`
    : `<div class="grid2" style="grid-template-columns:1fr auto;align-items:end"><label class="f">Code<input type="password" id="fc_in" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Le code reçu de la famille"></label><button class="btn s p" data-a="fc_save">Valider</button></div>`}
    <div class="small" id="fc_msg" hidden></div></div>`;
}
/* vérifie un code avec les fichiers du robot. 'ok' (avec la date), 'absent' (robot pas encore lancé) ou 'cle' */
async function codeTest(code){
  let d = null;
  try{ d = await lireChiffre(SP_ENC, code); }catch(e){ if(e.code === 'cle') return {r:'cle'}; throw e; }
  if(d) return {r:'ok', maj:d.maj};
  try{ d = await lireChiffre(PE_ENC, code); }catch(e){ if(e.code === 'cle') return {r:'cle'}; throw e; }
  return d ? {r:'ok', maj:d.maj} : {r:'absent'};
}
async function codeSave(test){
  const inp = $('#fc_in'), code = test ? familleCode() : (inp ? inp.value.trim() : ''), m = () => $('#fc_msg');
  if(!code){ say(m(), 'Entre le code reçu de la famille.'); return; }
  say(m(), 'Vérification du code…');
  let t; try{ t = await codeTest(code); }catch(e){ say(m(), e.code === 'vieux' ? 'Ce navigateur est trop ancien pour lire les fichiers chiffrés.' : 'Vérification impossible pour l\'instant (hors ligne ?). Réessaie plus tard.'); return; }
  if(t.r === 'cle'){ say(m(), test ? 'Le code de ce téléphone ne fonctionne plus : le code de la famille a changé. Oublie-le et entre le nouveau.' : 'Ce code ne fonctionne pas. Vérifie les mots (les majuscules et les accents ne comptent pas).'); return; }
  if(!test){ try{ localStorage.setItem(CODE_KEY, code); }catch(e){ say(m(), 'Impossible de garder le code sur ce téléphone.'); return; } _SPR = null; }
  const msg = t.r === 'ok' ? `Code accepté. Spéciaux et prix du robot du ${fmtDate(String(t.maj||'').slice(0,10))}.` : 'Code gardé. Le robot n\'a pas encore produit ses fichiers : ils seront lus dès qu\'ils seront prêts.';
  try{ await peFetch(true); }catch(e){}
  resetCaches(); save(); render(); say(m(), msg);
}
function profilFichierCard(){
  return `<div class="card"><h3>Mon profil</h3><p class="small">Famille, horaire, épiceries, achats réguliers et prix corrigés, sans le menu ni l'historique. Pratique pour réinstaller l'application ou la préparer pour un proche.</p>
    <div class="acts"><button class="btn s" id="pf_export">Enregistrer mon profil</button><label class="btn s" style="display:inline-flex;align-items:center">Charger un profil<input type="file" id="pf_file" accept=".json,application/json" hidden></label></div>
    <p class="note" id="pf_msg" hidden></p></div>`;
}
async function exportProfil(){
  const o = {type:'menu-profil', v:1, p:{}}; PROFIL_KEYS.forEach(k => { if(S[k] !== undefined) o.p[k] = S[k]; });
  o.p.reglages = Object.assign({}, S.p);
  const txt = JSON.stringify(o), name = 'profil-famille.json', msg = $('#pf_msg');
  const say = t => { if(msg){ msg.textContent = t; msg.hidden = false; } };
  try{ const how = await saveFile(txt, name, 'Profil Menu de la semaine'); if(how) say(how==='dl' ? `Profil enregistré dans ${FICH} : ${name}.` : 'Profil enregistré.'); }
  catch(e){ copier(txt, '#pf_msg'); }
}
function importProfil(txt){
  const o = JSON.parse(txt); if(!isObj(o) || o.type!=='menu-profil' || !isObj(o.p)) throw new Error('format');
  if(!snapshot('Avant le chargement d\'un profil', JSON.stringify(S))) throw new Error('espace');
  const keep = {}; PROFIL_KEYS.forEach(k => { if(o.p[k] !== undefined) keep[k] = o.p[k]; });   /* jamais le menu, l'historique ni les recettes */
  const m = mergeState(Object.assign(JSON.parse(JSON.stringify(S)), keep, {p: Object.assign({}, S.p, isObj(o.p.reglages) ? o.p.reglages : {})}));
  delete m.reglages; S = m; S.setup = true; profil(); appliquerProfil(); save(); render();
}
/* ---------- assistant de départ ---------- */
let wiz = 0, wizEss = false;
function renderWizard(){
  const steps = ['La famille','L\'horaire','Les épiceries','Les repas','Le budget'];
  const nav = `<div class="acts">${wiz > 0 ? '<button class="btn s" data-a="wiz" data-v="-1">← Retour</button>' : ''}${wiz < steps.length-1 ? '<button class="btn s p" data-a="wiz" data-v="1">Continuer →</button>' : '<button class="btn p" id="setup_done">Commencer</button>'}</div>`;
  const head = `<div class="card call"><h3>Bienvenue ! Préparons l'application pour ta famille</h3><p class="small">Étape ${wiz+1} sur ${steps.length} : <b>${steps[wiz]}</b>. Tout se change plus tard dans l'onglet Profil.</p></div>`;
  let body = '';
  if(wiz===0) body = familleCard();
  else if(wiz===1) body = horaireCard();
  else if(wiz===2) body = `<div class="card"><h3>Mes épiceries</h3><label class="f">Code postal<input type="text" data-cp="1" value="${esc(S.cp)}" autocapitalize="characters" placeholder="A1A 1A1"></label>
      <p class="small">Coche les épiceries où tu vas, ou touche le bouton pour voir celles qui ont une circulaire près de chez toi.</p>${storePicker()}
      <label class="f">Épicerie principale<select data-pf="princ"><option value="">Choisir…</option>${(S.stores.length ? S.stores : allStores()).map(s => `<option ${profil().princ===s?'selected':''}>${esc(s)}</option>`).join('')}</select></label></div>`;
  else if(wiz===3) body = `<div class="card"><h3>Les repas à planifier</h3><div class="grid2">${countSelects()}</div>
      <label class="check"><input type="checkbox" id="su_ess" ${S.ess.length ? 'checked disabled' : wizEss ? 'checked' : ''}> Ajouter une liste de départ pour les déjeuners, lunchs, collations et boissons</label></div>`;
  else body = `<div class="card"><h3>Le budget</h3><label class="f">Budget d'épicerie par semaine ($, 0 si aucun)<input type="text" inputmode="decimal" class="num" data-p="budget" value="${S.p.budget||0}"></label>
      <p class="small">Quand le menu dépasse ce montant, les soupers les plus chers sont remplacés par des plats moins chers.</p></div>`;
  return head + body + nav;
}

function renderReglages(){
  const p = S.p;
  let h = `<!--@apparence--><div class="card"><h3>Apparence</h3><div class="seg" role="group" aria-label="Apparence">${[['auto','Automatique'],['light','Claire'],['dark','Sombre']].map(([v,n]) => `<button class="${(p.theme||'auto')===v?'on':''}" data-a="theme" data-v="${v}">${n}</button>`).join('')}</div><p class="small">Automatique suit le téléphone : la carte crème le jour, l'ardoise le soir.</p></div>
<!--@menu-->    <div class="card"><h3>Repas habituels</h3><p class="small">Le questionnaire de chaque semaine part de ces nombres; change-les là pour une semaine différente.</p><div class="grid2">
    <label class="f">Déjeuners par semaine<select data-p="nDej">${[0,1,2,3,4,5,6,7].map(n=>`<option ${(p.nDej||0)===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Dîners par semaine<select data-p="nDin">${[0,1,2,3,4,5,6,7].map(n=>`<option ${(p.nDin||0)===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Soupers par semaine<select data-p="n">${[3,4,5,6,7].map(n=>`<option ${p.n===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Entrées par semaine<select data-p="nEnt">${[0,1,2,3,4,5,6,7].map(n=>`<option ${(p.nEnt||0)===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Soupes et potages par semaine<select data-p="nSou">${[0,1,2,3].map(n=>`<option ${(p.nSou||0)===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Desserts par semaine<select data-p="nDes">${[0,1,2,3,4,5,6,7].map(n=>`<option ${(p.nDes||0)===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Sans répéter (semaines)<select id="p_cool">${[1,2,3,4,5,6,8].map(n=>`<option ${p.cool===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Variantes<select id="p_var"><option value="alt" ${p.varMode==='alt'?'selected':''}>Alterner avec la base</option><option value="var" ${p.varMode==='var'?'selected':''}>Toujours une variante</option><option value="base" ${p.varMode==='base'?'selected':''}>Recette de base</option></select></label>
    <label class="f">Portions au souper<select id="p_sou">${[3,4,5,6,7,8].map(n=>`<option ${p.souper===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Portions de restes (dîner du lendemain)<select id="p_res">${[0,1,2,3,4,5].map(n=>`<option ${p.restes===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Portions au déjeuner<select data-p="pDej"><option value="0" ${!p.pDej?'selected':''}>Auto (${p.souper||4})</option>${[1,2,3,4,5,6,7,8,10].map(n=>`<option ${p.pDej===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Portions d'un dîner cuisiné<select data-p="pDin"><option value="0" ${!p.pDin?'selected':''}>Auto (${p.restes > 0 ? p.restes : (p.souper||4)})</option>${[1,2,3,4,5,6,7,8,10].map(n=>`<option ${p.pDin===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Préparation max. en semaine<select id="p_tm">${[20,30,35,45,60].map(n=>`<option value="${n}" ${p.maxTm===n?'selected':''}>${n} min</option>`).join('')}</select></label>
    <label class="f">Soupers plus longs (congé, fin de semaine)<select id="p_lg">${[0,1,2,3].map(n=>`<option ${p.nLong===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <label class="f">Jours de collations<select id="p_j">${[1,2,3,4,5,6,7].map(n=>`<option ${p.jours===n?'selected':''}>${n}</option>`).join('')}</select></label></div></div>
<!--@organisation-->    <div class="card"><h3>Organisation de la semaine</h3>
      <p class="small">Jours de congé : les soupers longs à préparer et le fumoir y sont placés. En semaine, seule la préparation compte : le four sans surveillance (jusqu'à 1 h 30) et la mijoteuse sont permis.</p>
      <div class="chips">${[1,2,3,4,5,6,0].map(d => `<label class="chip"><input type="checkbox" data-off="${d}" ${(p.off||[0,6]).includes(d)?'checked':''}>${cap(JOURS[d])}</label>`).join('')}</div>
      <p class="small">Déjeuners : les jours de congé, un déjeuner cuisiné; les jours de travail, un déjeuner de semaine (céréales, rôties, gruau, yogourt…). Pour en avoir tous les jours, mets 7 dans « Déjeuners par semaine ».</p>
      <label class="check"><input type="checkbox" data-pb="desSimple" ${p.desSimple?'checked':''}> Desserts : proposer aussi les simples (fruits, crème glacée, desserts du commerce). Sinon, seulement des desserts faits maison.</label>
      <label class="check"><input type="checkbox" data-pb="dinRestes" ${p.dinRestes!==false?'checked':''}> Dîners : manger d'abord les restes du souper de la veille. Les jours sans restes, un plat de la banque des soupers (différent de ceux de la semaine).</label>
      <label class="check"><input type="checkbox" data-pb="reste" ${p.reste!==false?'checked':''}> Cuisiner une fois, manger deux fois : jumeler les grosses pièces (épaule de jambon, poulet entier…) à un plat qui utilise les restes</label>
      <label class="f">Plats préparés (pizza, lasagne surgelées…)<select data-ps="pp">${[['spec','Les mettre au menu quand ils sont en spécial (1 par semaine)'],['sugg','Seulement les suggérer quand ils sont en spécial'],['all','Comme les autres plats'],['never','Jamais']].map(([v,n]) => `<option value="${v}" ${(p.pp||'spec')===v?'selected':''}>${n}</option>`).join('')}</select></label>
</div><!--@budget--><div class="card"><h3>Budget</h3>
      <label class="f">Budget d'épicerie par semaine ($, 0 si aucun)<input type="text" inputmode="decimal" class="num" data-p="budget" value="${p.budget||0}"></label>
      <p class="small">Quand le menu dépasse ce montant, les soupers les plus chers sont remplacés par des plats moins chers.</p></div>
<!--@epiceries-->    <div class="card"><h3>Mes épiceries</h3><p class="small">La recherche des spéciaux ne lit que les circulaires des épiceries cochées. Dans le questionnaire de la semaine, « Cette semaine, l'épicerie se fait… » permet de n'en garder qu'une, par exemple pour une commande en ligne.</p>
      <label class="f">Code postal<input type="text" data-cp="1" value="${esc(S.cp)}" autocapitalize="characters" placeholder="A1A 1A1"></label>
      ${storePicker()}
      <label class="f">Épicerie principale (pour la liste par magasin)<select data-ps="main"><option value="">La première cochée${S.stores[0] ? ' ('+esc(S.stores[0])+')' : ''}</option>${(S.stores.length ? S.stores : allStores()).map(s => `<option ${p.main===s?'selected':''}>${esc(s)}</option>`).join('')}</select></label></div>
<!--@collations-->    <div class="card"><h3>Mes collations, par jour</h3><p class="small">Multipliées par le nombre de jours, ajoutées à chaque liste.</p>${listEditor('snacks',S.snacks)}
      <label class="check"><input type="checkbox" data-pb="snk" ${S.p.snk!==false?'checked':''}> Suggérer des collations en spécial (carte « Collations en spécial » du Menu)</label></div>
<!--@ess-->    <div class="card"><h3>Achats réguliers : déjeuners, lunchs, collations et boissons</h3><p class="small">Tout ce que la famille achète chaque semaine, hors souper. Quantité pour la semaine : si un article dure plus longtemps (confiture, beurre d'arachide), baisse-le à 0 ou ajuste le stock dans Maison.</p>${listEditor('ess',S.ess)}${S.ess.length?'':'<button class="btn s" id="ess_preset">Ajouter la liste suggérée</button>'}</div>
<!--@toujours-->    <div class="card"><h3>Toujours à la maison</h3><p class="small">Séparés par des virgules. Ils ne vont pas dans la liste : ils s'affichent dans « Vérifier avant de partir ».</p><textarea id="maison">${esc(S.maison)}</textarea></div>
<!--@historique-->    <div class="card"><h3>Semaines passées</h3>${histHtml()}
    ${S.hist.length?'<button class="btn s d" id="hclr" data-armed="0">Effacer l\'historique</button>':''}</div>
<!--@prix-->    ${prixCard()}
<!--@sauvegarde-->    ${backupCard()}
<!--@version-->    <p class="small" style="text-align:center">Version de l'application : ${esc(APPV)}${TEST ? ' (version de test)' : ''}</p>
<!--@reset-->    <div class="card"><h3>Tout remettre à zéro</h3><p class="small">Efface le menu, le stock et l'historique.</p><button class="btn s d" id="reset" data-armed="0">Réinitialiser</button></div>`;
  /* la page Profil est découpée en sous-menus : chaque carte va dans sa section */
  const P = {}; h.split(/<!--@([a-z]+)-->/).forEach((x, i, a) => { if(i % 2) P[x] = a[i+1]; });
  const V = {famille:[familleCard(), horaireCard(), P.menu, P.organisation], epiceries:[P.epiceries, rayonsCard(), P.ess, P.collations, P.toujours],
    prixbudget:[pbSeg()].concat(pbSec==='articles' ? [artHtml()] : pbSec==='prix' ? [prixTabHtml()] : [P.budget, depensesCard(), P.prix]),
    compte:[codeCard(), geminiCard(), P.sauvegarde, profilFichierCard(), testCard(), P.apparence, P.version, P.reset],
    historique:[`<button class="btn" data-a="view" data-v="menu">← Retour au menu</button>`, P.historique]};
  const el = tab==='historique' ? $('#tab-historique') : $('#tab-profil');
  el.innerHTML = (V[tab] || V.famille).filter(Boolean).join('');
}

/* ---------- Ma semaine : l'accueil ----------
   Il montre l'étape utile selon le jour (préparer, commander, ramasser, cuisiner) et ce qu'on mange ce soir. */
/* fraîcheur d'un plat : poisson et viande hachée se mangent en début de semaine, le congelé et le garde-manger à la fin */
const _PER = new WeakMap();
function perishOf(r){
  if(!r) return 0; if(_PER.has(r)) return _PER.get(r);
  let p = 0;
  (r.i||[]).forEach(([q,u,n,ray]) => { const t = norm(n); if(/surgel|congel|boite|conserve|fume|seche/.test(t)) return;
    if(ray==='poissonnerie') p = Math.max(p, 3); else if(ray==='viandes'){ p = Math.max(p, /hache/.test(t) ? 2 : /poulet|dinde/.test(t) ? 1.5 : 1); }
    else if(/laitue|epinard|roquette|fraise|framboise|bleuet|champignon|avocat|asperge|coriandre|basilic|persil|germe/.test(t)) p = Math.max(p, 1); });
  _PER.set(r, p); return p;
}
/* pourquoi ce plat : les raisons qui ont pesé dans le choix, en mots simples */
function whyOf(it){
  const r = byName(it.r); if(!r) return [];
  const out = [];
  itemDeals(it, r).slice(0, 2).forEach(d => out.push(`${d.mot} en spécial${d.hit.p ? ' à ' + d.hit.p : ''}${d.hit.s ? ' chez ' + d.hit.s : ''}`));
  const st = stockOf(it); if(st.length) out.push('utilise ' + st.slice(0, 2).map(lowFirst).join(' et ') + ' de la maison');
  if(it.after) out.push('fait avec les restes de ' + lowFirst(it.after));
  const h = S.hist; let ago = -1; for(let k = h.length - 1; k >= 0; k--){ if(histItems(h[k]).some(x => x.r===r.n)){ ago = h.length - k; break; } }
  if(ago < 0 && h.length >= 2) out.push('jamais fait encore'); else if(ago >= 4) out.push(`pas fait depuis ${ago} semaines`);
  const rt = S.rate[r.n]; if(S.fav[r.n]) out.push('un favori'); else if(rt && rt.up > (rt.down||0)) out.push('aimé de la famille');
  if(mjOf(r)===1) out.push('à la mijoteuse'); else if(tpOf(r) <= 20) out.push('rapide à préparer');
  return out.slice(0, 4);
}
/* préparation du dimanche : les tâches regroupées pour toute la semaine */
function prepTasks(){
  const L = mlist('items').filter(x => x.d).slice().sort((a, b) => a.d.localeCompare(b.d)), out = [];
  if(!L.length) return out;
  const shop = S.menu.shop || shopISO(), jour = d => DOW[new Date(d+'T12:00:00').getDay()];
  const chop = {}, rice = [];
  L.forEach(it => { const r = byName(it.r); if(!r) return;
    const per = perishOf(r), gap = gapDays(shop, it.d);
    if(per >= 2 && gap >= 4) out.push({t:`Congeler la viande ou le poisson de « ${it.r} » dès le ramassage; le sortir au frigo ${jour(addDays(it.d, -1))} soir.`, d:addDays(it.d, -1)});
    if(/marin(er|ade)/i.test(r.s||'')) out.push({t:`Préparer la marinade de « ${it.r} » la veille (${jour(addDays(it.d, -1))}).`, d:addDays(it.d, -1)});
    if(mjOf(r)===1) out.push({t:`« ${it.r} » : remplir la mijoteuse le matin de ${jour(it.d)}.`, d:it.d});
    effective(r, it.v||0).forEach(g => { const t = norm(g.name);
      const k = /oignon(?! vert)/.test(t) ? 'oignons' : /\bail\b/.test(t) ? 'gousses d\'ail' : /poivron/.test(t) ? 'poivrons' : /celeri/.test(t) ? 'branches de céleri' : /carotte/.test(t) ? 'carottes' : '';
      if(k){ (chop[k] = chop[k] || {q:0, u:g.u, days:new Set()}); chop[k].days.add(jour(it.d)); if(g.u==='un') chop[k].q += g.q; }
      if(/\briz\b/.test(t) && !/vermicelle|galette|nouille/.test(t) && gap <= 4) rice.push(jour(it.d)); }); });
  Object.entries(chop).forEach(([k, o]) => { if(o.days.size >= 2) out.push({t:`Hacher d'avance ${o.q ? Math.ceil(o.q) + ' ' : 'les '}${k} pour ${[...o.days].join(', ')} (se gardent 4 jours au frigo).`}); });
  if(new Set(rice).size >= 2) out.push({t:`Cuire le riz en une fois pour ${[...new Set(rice)].join(' et ')} (se garde 4 jours au frigo).`});
  const long = L.find(it => isLong(byName(it.r)||{}) && isOff(it.d));
  if(long && S.p.restes > 0) out.push({t:`« ${long.r} » (${jour(long.d)}) : la recette est prévue avec les restes pour les lunchs; prévoir les plats pour les emporter.`});
  return out;
}
/* étape du jour d'après l'horaire du profil */
function etape(){
  const today = isoToday(), m = S.menu, P = profil(), np = nextPickup();
  const active = m.date && m.start && today <= addDays(m.start, 6);
  const futur = m.date && m.start && m.start > today;
  if(m.date && m.eb && !m.achete) return 'ebauche';
  if(!m.date || (!futur && (!active || gapDays(today, np) <= 3) && np > (m.shop || ''))) return 'preparer';
  if(!m.achete && today <= (m.shop || today)) return 'commander';
  if(!m.achete) return 'ramassage';
  if(m.achete && !(m.paid > 0)) return 'payer';
  return 'cuisiner';
}
function prepareCard(){
  const np = nextPickup(), start = startFrom(np), busy = S.menu.date && S.menu.start <= isoToday();
  return `<div class="card call"><h3>Préparer ma semaine</h3>
    <p class="small">Ramassage ${esc(fmtDate(np))}, menu du ${esc(dayLbl(start).toLowerCase())} au ${esc(dayLbl(addDays(start, 6)).toLowerCase())}. Un seul bouton : les spéciaux de tes épiceries, le menu varié, le budget et la liste.</p>
    ${busy ? `<p class="small">Les soupers qui restent cette semaine sont gardés jusqu'au ${esc(dayLbl(start).toLowerCase())}; la semaine en cours passe dans l'historique.</p>` : ''}
    <div class="acts"><button class="btn p" id="prep_week" data-armed="0" ${prepBusy ? 'disabled' : ''}>${prepBusy ? 'Préparation en cours…' : 'Préparer ma semaine'}</button></div>
    <p class="small">Quelques questions sur ta semaine, puis une ébauche du menu à ajuster avant la liste d'épicerie.</p>
    <p class="small" id="sp_status" aria-live="polite"></p></div>`;
}
/* où faire l'épicerie : la question posée avant de bâtir le menu (le menu suit les spéciaux de ces épiceries) */
const goPlan = () => { const v = S.p.goPlan || ''; if(v==='auto' || v==='*' || v==='main' || S.stores.includes(v)) return v; return profil().princOnly !== false && S.p.main ? 'main' : '*'; };
function goPlanSel(){
  if(S.stores.length < 2) return '';
  const v = goPlan(), main = S.p.main;
  const o = (val, txt) => `<option value="${esc(val)}" ${v===val ? 'selected' : ''}>${esc(txt)}</option>`;
  return `<label class="f">Cette semaine, l'épicerie se fait…<select data-a="goplan">${main ? o('main', `À mon épicerie principale (${main})`) : ''}${o('auto', "Où ce sera le moins cher (l'app choisit)")}${S.stores.filter(s => s !== main).map(s => o(s, `Chez ${s}`)).join('')}${o('*', 'Dans toutes mes épiceries')}</select></label>
    <p class="small">Le menu se bâtit avec les spéciaux de ${v==='auto' || v==='*' ? 'toutes tes épiceries' : `${esc(v==='main' ? main : v)} seulement`}.${v==='auto' ? " Ensuite, l'app compare le coût de la liste dans chaque épicerie et choisit la moins chère; tu verras aussi l'économie possible en allant à deux endroits ou plus." : ''}</p>`;
}
function commanderCardOu(){ try{ return ouAllerLigne(buyList().rows); }catch(e){ return ''; } }
function commanderCard(){
  const rows = buyList().rows, left = rows.filter(r => !S.menu.chk[r.k]).length, t = listTotals(rows), main = (goStores().length ? goStores() : [S.p.main || S.stores[0] || '']).filter(Boolean).join(' et ');
  return `<div class="card call"><h3>Commander l'épicerie</h3>
    <p class="small"><b>${left}</b> article${left>1?'s':''} à mettre au panier${main ? ' chez ' + esc(main) : ''}, ≈ <b>${money(t.cost)}</b>${S.p.budget ? ` pour un budget de ${money(S.p.budget)}` : ''}. Ramassage ${esc(fmtDate(S.menu.shop || shopISO()))}.</p>
    ${commanderCardOu()}
    <div class="acts"><button class="btn s p" data-a="view" data-v="epicerie">Ouvrir la liste de commande</button></div></div>`;
}
function payerCard(){
  return `<div class="card"><h3>Ramassage fait ?</h3><p class="small">Inscris le total de la facture : il sert à suivre le budget et à corriger les prix estimés.</p>${paidField(S.menu)}</div>`;
}
function prepDimancheCard(){
  const today = isoToday(), m = S.menu; if(!m.date || !m.start) return '';
  if(today < addDays(m.start, -2) || today > addDays(m.start, 1)) return '';
  const T = prepTasks(); if(!T.length) return '';
  const done = m.prep || {};
  return `<div class="card"><h3>Préparation du ${esc(dayLbl(m.start).toLowerCase())}</h3><p class="small">Ce qui se fait d'avance pour toute la semaine.</p>
    <ul class="todo">${T.map((x, j) => `<li><label class="check"><input type="checkbox" data-prep="${j}" ${done[j]?'checked':''}> ${esc(x.t)}</label></li>`).join('')}</ul></div>`;
}
/* calibrage : écart moyen entre l'estimation et le total payé (au moins 3 semaines), appliqué au total estimé */
function calF(){
  const R = S.hist.slice(-8).filter(w => w.paid > 0 && w.est > 0).map(w => w.paid / w.est).sort((a, b) => a - b);
  if(R.length < 3) return 1;
  const med = R[Math.floor(R.length / 2)]; return Math.max(.8, Math.min(1.35, med));
}
/* dépenses des 12 dernières semaines : payé (plein) ou estimé (pâle), et le budget */
function depensesCard(){
  const W = S.hist.slice(-12).map(w => ({d:w.start || '', lbl:w.date, v:w.paid > 0 ? w.paid : (w.est || 0), paid:w.paid > 0})).filter(w => w.v > 0);
  if(W.length < 2) return '';
  const b = +S.p.budget || 0, max = Math.max(b, ...W.map(w => w.v)) * 1.1, H = 120, bw = Math.min(36, Math.floor(300 / W.length) - 6), x0 = 34;
  const y = v => 10 + H - v / max * H;
  const bars = W.map((w, i) => `<rect x="${x0 + i * (bw + 6)}" y="${y(w.v).toFixed(1)}" width="${bw}" height="${(10 + H - y(w.v)).toFixed(1)}" rx="3" fill="var(--accent)" fill-opacity="${w.paid ? 1 : .35}"><title>${esc(w.lbl)} : ${money(w.v)}${w.paid ? '' : ' (estimé)'}</title></rect>`).join('');
  const bl = b ? `<line x1="${x0 - 4}" x2="${x0 + W.length * (bw + 6)}" y1="${y(b).toFixed(1)}" y2="${y(b).toFixed(1)}" stroke="var(--warn)" stroke-dasharray="4 3"/><text x="${x0 + W.length * (bw + 6) + 2}" y="${(y(b) + 4).toFixed(1)}" font-size="10" fill="var(--mute)">budget</text>` : '';
  const avg = W.reduce((t, w) => t + w.v, 0) / W.length;
  return `<div class="card"><h3>Dépenses des dernières semaines</h3><p class="small">Moyenne ${money(avg)} par semaine${b ? `, budget ${money(b)}` : ''}. Barres pâles : estimation (total payé non inscrit).</p>
    <svg viewBox="0 0 ${x0 + W.length * (bw + 6) + 44} ${H + 30}" width="100%" role="img" aria-label="Dépenses par semaine"><text x="0" y="${y(max / 1.1) + 4}" font-size="10" fill="var(--mute)">${Math.round(max / 1.1)} $</text><line x1="${x0 - 4}" x2="${x0 + W.length * (bw + 6)}" y1="${10 + H}" y2="${10 + H}" stroke="var(--line)"/>${bars}${bl}</svg></div>`;
}
function renderSemaine(){
  const el = $('#tab-semaine');
  if(!S.setup){ el.innerHTML = welcomeHero() + renderWizard(); return; }
  let h = `<p class="note" id="flash" ${S.flash ? '' : 'hidden'}>${esc(S.flash||'')}</p>`; S.flash = '';
  if(S.profil && S.profil.verifier) h += `<div class="card call"><h3>Nouveau : le profil de la famille</h3><p class="small">Les portions et les lunchs se calculent maintenant d'après la famille (adultes, enfants, appétit). Vérifie qu'il te ressemble : ${esc(famLine())}, ramassage le ${esc(DOW[profil().jours.ram])}, cuisine dès le ${esc(DOW[profil().jours.cuis])}.</p><div class="acts"><button class="btn s p" data-a="view" data-v="famille">Vérifier le profil</button><button class="btn s" data-a="pf_ok">C'est bon</button></div></div>`;
  const st = etape();
  if(instEvt && !isInstalled() && !S.instHide) h += `<div class="card call"><h3>Installer l'application</h3><p class="small">Une icône sur l'écran d'accueil : l'application s'ouvre sans la barre de ${esc(NAVI)}, comme une vraie app, et fonctionne sans Internet. Tes données restent les mêmes.</p><div class="acts">${instBtn()}<button class="btn s" data-a="inst_hide">Plus tard</button></div></div>`;
  h += renderToday();
  if(qzOpen) h += questionnaireCard();
  else if(st==='ebauche') h += ebaucheCard();
  else if(st==='preparer') h += prepareCard();
  else if(st==='commander') h += commanderCard();
  else if(st==='payer') h += payerCard();
  else if(st==='ramassage') h += `<div class="card call"><h3>Ramassage fait ?</h3><p class="small">Touche « Épicerie terminée » : les articles cochés entrent dans Maison. Inscris aussi le total de la facture pour suivre le budget.</p>${paidField(S.menu)}<div class="acts"><button class="btn s p" data-a="view" data-v="epicerie">Ouvrir la liste</button></div></div>`;
  h += prepDimancheCard();
  h += renderAvec();
  if(prixRappel()) h += `<div class="card"><h3>Mise à jour des prix</h3><p class="small">Les prix de référence ont été ${esc(PRIX_MAJ_TXT())}. Prends quelques minutes pour vérifier les principaux sur maxi.ca : le coût de l'épicerie et le budget seront plus justes.</p><div class="acts"><button class="btn s p" data-a="pm_go">Mettre à jour les prix</button><button class="btn s" data-a="pm_snooze">Dans une semaine</button></div></div>`;
  if(S.menu.date && !S.menu.eb && !renderToday()) h += `<div class="card"><h3>Rien de prévu aujourd'hui</h3><p class="small">La semaine du ${esc(dayLbl(weekStart()).toLowerCase())} est dans Menu.</p><div class="acts"><button class="btn s p" data-a="view" data-v="menu">Voir le menu</button></div></div>`;
  el.innerHTML = h;
}
/* Menu pour le frigo : une image de la semaine à enregistrer dans Photos, imprimer ou envoyer */
async function menuFrigo(){
  const W = 1080, rowH = 150, days = weekDates(), L = mlist('items'), D = mlist('dej'), P = dinPlan();
  const c = document.createElement('canvas'); c.width = W; c.height = 220 + rowH * 7 + 80; const g = c.getContext('2d');
  const font = (w, s) => `${w} ${s}px -apple-system, "Helvetica Neue", Arial, sans-serif`;
  g.fillStyle = '#fbf7ef'; g.fillRect(0, 0, W, c.height);
  g.fillStyle = '#2b2118'; g.font = font(700, 64); g.fillText('Menu de la semaine', 64, 110);
  g.fillStyle = '#7a6a58'; g.font = font(400, 34); g.fillText(`Du ${dayLbl(days[0]).toLowerCase()} au ${dayLbl(days[6]).toLowerCase()}`, 64, 165);
  const fit = (t, max, size, w) => { g.font = font(w, size); let s = String(t||''); while(g.measureText(s).width > max && s.length > 3) s = s.slice(0, -2); return s === String(t||'') ? s : s.trim() + '…'; };
  days.forEach((d, k) => { const y = 220 + k * rowH, it = L.find(x => x.d===d), dj = D.find(x => x.d===d), dn = P.find(p => p.d===d);
    g.fillStyle = k % 2 ? '#f3ecdf' : '#fbf7ef'; g.fillRect(40, y, W - 80, rowH - 8);
    g.fillStyle = '#b4532a'; g.font = font(700, 34); g.fillText(cap(DOW[new Date(d+'T12:00:00').getDay()]), 64, y + 52);
    g.fillStyle = '#2b2118'; g.fillText(fit(it ? it.r : '—', W - 380, 40, 600), 330, y + 56);
    const sub = [dj ? 'Déjeuner : ' + dj.r : '', dn ? 'Lunch : ' + (dn.rest ? 'restes de ' + lowFirst(dn.rest.r) : dn.it ? dn.it.r : '') : ''].filter(Boolean).join('   ·   ');
    if(sub){ g.fillStyle = '#7a6a58'; g.fillText(fit(sub, W - 380, 28, 400), 330, y + 104); } });
  g.fillStyle = '#7a6a58'; g.font = font(400, 24); g.fillText('Fait avec Menu de la semaine', 64, c.height - 36);
  const blob = await new Promise(r => c.toBlob(r, 'image/png')); if(!blob) return;
  frigoFile = new File([blob], 'menu-semaine.png', {type:'image/png'});
  /* l'image s'affiche : appui long pour l'enregistrer dans Photos, ou « Partager » (un nouveau toucher, exigé par l'iPhone) */
  const box = $('#frigo_box'); if(box){ box.innerHTML = `<img src="${URL.createObjectURL(blob)}" alt="Menu de la semaine" style="width:100%;border-radius:12px;margin-top:10px"><p class="small">${IOS ? "Appuie longuement sur l'image pour l'enregistrer dans Photos, ou :" : "Appuie longuement sur l'image, puis « Télécharger l'image », ou :"}</p><div class="acts"><button class="btn s p" id="frigo_share">Partager l'image</button></div>`; }
}
let frigoFile = null;
async function partagerFrigo(){
  if(!frigoFile) return;
  try{ await saveFile(frigoFile, 'menu-semaine.png', 'Menu de la semaine', 'share', 'image/png'); }catch(e){}
}
/* ---------- valeur nutritive (estimations) ----------
   Par 100 g : [motif du nom (sans accents), kcal, protéines g, glucides g, lipides g, fibres g, sodium mg, g par unité, densité g/ml, sorte].
   Sorte : L légume ou fruit, P protéine, C céréale ou féculent. Valeurs moyennes des tables de composition courantes (aliment cru,
   sauf indication). Le premier motif qui correspond l'emporte : les plus précis d'abord. Le sel ajouté « au goût » n'est pas compté. */
const NUT = [
  [/bouillon|consomme|fond de/,5,.5,.5,.2,0,300,0,1,''],[/sel nitrite|prague/,0,0,0,0,0,38000,0,1.2,''],[/^gros sel|^sel\b/,0,0,0,0,0,38700,0,1.2,''],
  [/flanc de porc/,518,9,0,53,0,32,0,1,'P'],[/semoule de mais/,370,7,79,1.8,7,35,0,.6,'C'],[/brochettes de bois|cure-dents/,0,0,0,0,0,0,0,1,''],[/epices a frotter/,300,5,55,5,10,5000,0,.6,''],[/planches? de cedre/,0,0,0,0,0,0,0,1,''],[/gingembre/,80,1.8,18,.8,2,13,0,1,''],
  [/cottage/,98,11,3.4,4.3,0,364,0,1.03,''],[/boursin/,400,6,3,40,0,600,150,1,''],[/pain au lait/,290,9,50,6,2,450,30,1,'C'],[/sauce tonkatsu/,130,1,30,.2,.5,2200,0,1.15,''],
  [/creme de pistache|pistaches?/,560,12,45,38,3,100,0,1,''],[/kataifi|phyllo/,300,8,60,3,2,450,0,1,'C'],[/chocolat au lait/,535,8,59,30,3,80,0,.6,''],[/biscoff|speculoos/,484,5,72,19,1.3,380,0,.5,''],
  [/pates? a won ?-?ton/,291,10,58,1.5,1.8,570,400,1,'C'],[/piments? (guajillo|ancho)/,320,11,60,6,26,40,6,1,''],
  [/sauce a l.ail|toum/,680,1,.6,75,0,630,0,.92,''],[/trempette/,350,1,15,30,0,700,125,1,''],[/poudre pour creme anglaise/,350,.5,88,.5,0,300,0,.6,''],
  // plats et produits préparés
  [/lasagne surgelee/,140,8,14,6,1.5,400,2500,1,''],[/pate chinois surgele/,110,5,14,4,1.5,300,1800,1,''],[/pates? au poulet surgele/,250,7,23,14,1,450,600,1,''],
  [/tourtieres? surgelee/,300,9,25,18,1,550,800,1,''],[/pizzas? surgelee/,260,11,30,11,2,600,800,1,''],[/egg rolls/,220,6,27,10,2,450,80,1,''],[/won-?tons/,200,8,26,7,1.5,500,20,1,''],
  [/ailes de poulet surgelee/,220,18,4,15,0,700,1000,1,'P'],[/pogo|corn dogs/,260,8,28,13,1,600,75,1,''],[/sushis/,150,5,30,1,1,450,600,1,''],
  [/doigts de poulet|filets de poulet panes|poitrines de poulet panees/,250,15,17,13,1,500,120,1,'P'],[/gateau au fromage surgele/,320,6,26,22,.5,350,700,1,''],
  [/tarte aux pommes surgelee/,240,2,34,11,1.6,300,900,1,''],[/melange a gateau/,430,5,77,10,2,800,430,1,''],[/creme glacee/,207,3.5,24,11,.7,80,600,1,''],[/sorbet/,130,.5,32,.2,1,20,700,1,''],
  [/soupe aux tomates/,40,1,8,.5,.5,450,540,1,''],[/creme de champignons/,55,1,6,3,.3,600,284,1,''],[/soupe miso/,40,2,5,1,.5,900,100,1,''],[/soupe a l.oignon/,340,7,60,3,4,7000,40,1,''],
  [/poulets? (bbq )?rotis?|poulets? bbq/,190,28,0,8,0,330,650,1,'P'],
  // volailles
  [/canard confit/,250,22,0,18,0,700,220,1,'P'],[/saucisses? de poulet/,170,16,3,10,0,650,100,1,'P'],[/poulet cuit|poulet effiloche|poulet rot/,190,28,0,8,0,330,650,1,'P'],
  [/poulets entiers/,160,15,0,11,0,70,1600,1,'P'],[/ailes de poulet/,200,18,0,14,0,80,90,1,'P'],[/pilons/,160,17,0,10,0,85,110,1,'P'],
  [/hauts? de cuisses? de poulet avec os|cuisses de poulet|pilons et cuisses/,165,15,0,11,0,70,150,1,'P'],[/hauts? de cuisses?/,145,18,0,8,0,85,120,1,'P'],
  [/poulet hache|dinde hachee/,145,17,0,8,0,60,0,1,'P'],[/dinde tranchee/,105,18,3,2,0,900,0,1,'P'],[/dinde/,120,22,0,3,0,60,0,1,'P'],
  [/poitrines? de poulet|poulet ou porc|poulet/,120,22.5,0,2.6,0,45,225,1,'P'],
  // boeuf, veau, agneau, gibier
  [/boeuf hache maigre|hache maigre/,200,20,0,13,0,70,0,1,'P'],[/boeuf hache|hache mi-maigre/,250,17,0,20,0,70,0,1,'P'],[/veau hache/,170,19,0,10,0,80,0,1,'P'],
  [/agneau/,280,17,0,23,0,60,80,1,'P'],[/orignal|chevreuil/,140,22,0,5,0,60,0,1,'P'],[/rosbif tranche/,120,20,2,4,0,800,0,1,'P'],
  [/boeuf fume|boeuf cuit/,230,26,0,14,0,500,0,1,'P'],[/brisket|pointe de poitrine|picanha|cote de boeuf|bouts de cotes/,260,17,0,21,0,60,0,1,'P'],
  [/tournedos/,220,20,0,15,0,250,170,1,'P'],[/steaks? minute/,150,22,0,6,0,60,0,1,'P'],
  [/steak|surlonge|bavette|faux-filet|contre-filet|filet mignon|filets mignons|interieur de ronde|filet de boeuf/,190,21,0,11,0,55,225,1,'P'],
  [/boeuf|ragout|palette/,180,20,0,11,0,60,0,1,'P'],
  // porc et charcuteries
  [/bacon cuit/,540,37,1.4,42,0,1700,0,1,'P'],[/bacon/,400,12,1.3,38,0,750,0,1,'P'],[/lardons/,380,13,1,36,0,900,0,1,'P'],[/lard sale/,750,3,0,80,0,1400,0,1,''],
  [/jarret de porc fume/,200,18,0,14,0,900,400,1,'P'],[/viande fumee|smoked meat|pastrami/,220,24,1,13,0,1100,0,1,'P'],[/jambon fume|epaule de jambon/,180,17,1,12,0,1100,0,1,'P'],[/jambon/,145,18,1.5,7,0,1200,0,1,'P'],
  [/saucisses? a hot-dog/,290,11,3,26,0,1000,45,1,'P'],[/mini-saucisses/,300,11,3,27,0,1000,10,1,'P'],[/merguez/,300,15,1,26,0,800,60,1,'P'],[/saucisses? fumee/,300,12,2,27,0,1000,60,1,'P'],
  [/saucisses?/,300,14,2,26,0,750,100,1,'P'],[/chorizo/,450,24,2,38,0,1200,0,1,'P'],[/pepperoni/,500,20,1,45,0,1600,0,1,'P'],[/salami/,400,22,1,34,0,1700,0,1,'P'],
  [/prosciutto/,250,26,0,16,0,2400,0,1,'P'],[/mortadelle/,310,15,1,27,0,1200,0,1,'P'],[/bologne/,300,11,3,27,0,1000,0,1,'P'],[/cretons/,300,14,4,26,0,800,0,1,'P'],
  [/porc effiloche/,230,25,2,13,0,450,0,1,'P'],[/cotes levees/,280,16,0,24,0,80,0,1,'P'],[/filets? de porc/,120,21,0,3.5,0,50,0,1,'P'],
  [/cotelettes de porc desossees/,165,21,0,8,0,55,170,1,'P'],[/cotelettes/,200,19,0,13,0,55,200,1,'P'],[/epaule de porc|pattes de porc/,230,17,0,18,0,70,0,1,'P'],
  [/porc hache/,260,17,0,21,0,60,0,1,'P'],[/porc/,180,20,0,11,0,60,0,1,'P'],
  // poissons et fruits de mer
  [/saumon fume/,120,18,0,4.5,0,1000,0,1,'P'],[/boites? de saumon/,140,20,0,6,0,450,190,1,'P'],[/saumon/,200,20,0,13,0,60,150,1,'P'],[/truite/,140,20,0,6,0,50,150,1,'P'],
  [/boites? de thon|thon/,115,26,0,1,0,330,120,1,'P'],[/morue|aiglefin|tilapia|sole|goberge|poisson blanc|filets de poisson/,85,18,0,1,0,70,150,1,'P'],
  [/crevettes? (cuites|nordiques)/,100,21,0,1,0,600,0,1,'P'],[/crevettes?/,85,20,0,.5,0,300,0,1,'P'],[/petoncles/,70,12,3,.5,0,400,0,1,'P'],
  [/moules/,30,4,1.2,.7,0,90,0,1,'P'],[/homard/,90,19,0,1,0,400,0,1,'P'],[/sauce de poisson/,35,5,3.6,0,0,7800,0,1.2,''],[/poisson/,85,18,0,1,0,70,150,1,'P'],
  // végé
  [/tofu/,145,16,3,9,2,15,450,1,'P'],[/edamames?/,120,11,9,5,5,6,500,1,'P'],[/lentilles (vertes|corail|seches)/,350,25,60,1,11,6,0,.85,'P'],
  [/lentilles/,115,9,20,.4,7,230,400,1,'P'],[/pois (jaunes|verts) (casses|secs)/,340,24,60,1,25,15,0,.85,'P'],[/pois chiches/,140,7,21,2.5,6,250,400,1,'P'],
  [/feves au lard/,120,5,22,1,5,450,398,1,'P'],[/haricots (noirs|rouges|blancs)|boites? de haricots/,110,7,20,.5,7,250,400,1,'P'],
  [/nouilles aux oeufs/,380,14,71,4.4,3,20,0,1,'C'],[/oeufs?/,143,12.6,.7,9.5,0,140,50,1,'P'],
  // produits laitiers
  [/beurre d.arachide/,590,25,20,50,6,430,0,1.05,''],[/lait de coco/,200,2,3,21,0,15,0,1,''],[/lait concentre/,320,8,54,9,0,130,400,1.3,''],
  [/babeurre/,40,3.3,4.8,1,0,105,0,1.03,''],[/\blait\b/,50,3.4,4.9,2,0,45,0,1.03,''],[/fromage a la creme/,340,6,4,34,0,320,0,1,''],
  [/creme sure/,200,2.5,4,19,0,50,0,1,''],[/^creme 35|^creme a fouetter/,340,2,3,36,0,30,0,1,''],[/^creme/,160,3,4,15,0,40,0,1,''],
  [/yogourt grec/,75,10,4,2,0,40,0,1.05,''],[/yogourt a la vanille/,95,4,15,2,0,50,0,1.05,''],[/yogourt/,65,4.5,6,2,0,50,0,1.05,''],[/tzatziki/,100,4,4,7,0,300,0,1.05,''],
  [/beurre/,717,.9,.1,81,0,550,0,.95,''],[/parmesan/,420,36,3,28,0,1500,0,.4,''],[/feta/,265,14,4,21,0,1100,0,1,''],[/ricotta/,175,11,3,13,0,85,0,1,''],
  [/mascarpone/,430,5,4,44,0,50,0,1,''],[/velveeta|fromage blanc fondu/,300,16,9,22,0,1500,0,1,''],[/fromage bleu|\bbleu\b/,350,21,2,29,0,1100,0,1,''],[/chevre/,300,19,1,24,0,450,0,1,''],
  [/brie/,330,21,.5,28,0,630,0,1,''],[/batonnets de fromage|fromage ficelle/,300,24,2,21,0,600,21,1,''],[/mozzarella fraiche|bocconcini/,250,18,2,19,0,300,0,1,''],
  [/tranches? de (cheddar|provolone|fromage suisse)/,380,25,1.5,30,0,650,22,1,''],[/tranches de fromage|fromage tranche/,330,18,7,26,0,1300,20,1,''],
  [/mozzarella/,280,22,2.2,20,0,600,0,1,''],[/provolone/,350,26,2,27,0,870,0,1,''],[/gruyere|emmental|suisse/,400,28,1,31,0,300,0,1,''],[/fromage en grains/,360,24,1.5,28,0,700,0,1,''],
  [/gouda/,350,25,2,27,0,800,0,1,''],[/cheddar|fromage/,400,25,1.3,33,0,650,0,1,''],
  // céréales, pains, pâtes
  [/riz cuit/,130,2.7,28,.3,.4,1,0,1,'C'],[/nouilles de riz|vermicelles de riz/,360,6,82,.6,1.6,180,0,1,'C'],[/feuilles de riz/,330,6,81,.6,1,50,10,1,'C'],
  [/vinaigre/,18,0,.5,0,0,2,0,1,''],[/cereales de riz souffle/,380,6,85,1,1,650,0,.15,''],[/riz/,360,7,79,.6,1.3,5,0,.85,'C'],[/udon/,130,3.5,27,.5,1.2,250,0,1,'C'],[/ramen/,440,9,63,17,2.4,600,85,1,'C'],
  [/nouilles/,300,10,60,2,2,20,0,1,'C'],[/gnocchi/,160,4,33,.5,1.5,450,0,1,'C'],[/tortellini/,290,12,43,8,2,450,0,1,'C'],
  [/feuilles de lasagne/,360,13,73,1.5,3,6,20,1,'C'],[/^(spaghetti|pennes?|rotinis?|macaronis?|linguine|fettuccine|tagliatelles?|petites pates|orzo|pates courtes|pates (rotini|courtes))|^pates$/,360,13,73,1.5,3,6,0,1,'C'],
  [/couscous/,375,13,77,.6,5,10,0,.75,'C'],[/quinoa/,370,14,64,6,7,5,0,.8,'C'],[/orge/,350,10,78,1.2,15,9,0,.8,'C'],[/flocons d.avoine|granola/,390,12,66,8,9,15,0,.4,'C'],
  [/farine de sarrasin/,335,13,71,3.4,10,11,0,.55,'C'],[/farine grillee|farine/,364,10,76,1,2.7,2,0,.53,''],[/fecule de mais/,380,.3,91,0,1,9,0,.6,''],
  [/panko/,370,12,76,2,3,400,0,.25,''],[/chapelure/,395,13,72,5,4.5,730,0,.45,''],[/cereales/,380,8,84,2,6,500,200,.3,'C'],
  [/croutons/,410,12,74,6.6,5,700,0,.3,''],[/biscuits soda/,420,9,72,10,3,950,150,1,'C'],[/croustilles|chips/,500,7,58,27,5,450,220,1,''],
  [/pain a l.ail/,350,8,42,16,2,550,400,1,'C'],[/tranches de pain/,265,9,49,3.2,2.7,490,30,1,'C'],[/pains? (a hamburger|brioches a hamburger|a hot-dog|kaiser)|petits pains|sliders/,280,9,50,4.5,2,480,55,1,'C'],
  [/pains? sous-marin/,270,9,51,3,2.5,500,120,1,'C'],[/baguettes?/,270,9,55,1.5,2.4,600,250,1,'C'],[/ciabatta/,265,9,51,3,2.5,550,280,1,'C'],[/pain croute/,265,9,52,2,3,550,450,1,'C'],
  [/naan/,290,9,50,5.5,2,450,90,1,'C'],[/pitas?/,275,9,56,1.2,2,535,60,1,'C'],[/grandes tortillas/,300,8,50,7.5,3,750,60,1,'C'],[/tortillas|coquilles a tacos/,300,8,50,7.5,3,750,30,1,'C'],
  [/croissants?/,406,8,46,21,2.6,470,60,1,'C'],[/muffins anglais/,230,8,44,1.8,3,400,57,1,'C'],[/bagels?/,260,10,50,1.5,2.3,450,100,1,'C'],[/pain brioche/,340,9,50,11,2,400,400,1,'C'],
  [/pates? a pizza/,250,8,48,3,2,500,450,1,'C'],[/abaisses? de pate|pate feuilletee/,450,5,45,28,1.5,420,200,1,'C'],[/fonds de tartelettes/,480,5,55,26,1.5,350,20,1,''],
  [/rondelles a empanadas/,350,7,48,15,2,500,40,1,'C'],[/pain/,265,9,50,3,2.7,500,30,1,'C'],
  // légumes et fruits
  [/pommes de terre rissolees/,180,2.5,22,9,2,350,0,1,'L'],[/frites/,160,2.5,25,5.5,2.5,300,0,1,'L'],[/patates? douces?/,86,1.6,20,.1,3,55,300,1,'L'],
  [/grosses pommes de terre/,77,2,17,.1,2.2,6,300,1,'L'],[/pommes? de terre|patates|grelots/,77,2,17,.1,2.2,6,200,1,'L'],
  [/compote de pommes/,70,.2,18,.1,1.2,2,113,1,'L'],[/jus de pomme/,46,.1,11,.1,.2,4,0,1.04,''],[/jus d.orange/,45,.7,10,.2,.2,1,0,1.04,''],[/jus de (lime|citron)/,25,.4,8,.1,.4,2,0,1.03,''],
  [/oignons verts|ciboulette/,32,1.8,7,.2,2.6,16,15,1,'L'],[/poudre d.oignon|poudre d.ail/,340,10,75,1,10,60,0,.5,''],[/oignons espagnols/,40,1.1,9,.1,1.7,4,300,1,'L'],
  [/echalotes?/,72,2.5,17,.1,3,12,30,1,'L'],[/oignons?/,40,1.1,9,.1,1.7,4,150,1,'L'],[/poireaux?/,61,1.5,14,.3,1.8,20,150,1,'L'],[/^(gousses? d.ail|ail)\b/,150,6,33,.5,2,17,5,1,''],
  [/carottes mini|carottes?/,41,.9,10,.2,2.8,70,75,1,'L'],[/celeri/,16,.7,3,.2,1.6,80,40,1,'L'],[/poivrons rotis/,30,1,5,.3,1.5,300,0,1,'L'],[/poivre/,250,10,64,3,25,20,0,.5,''],
  [/poivrons?/,26,1,6,.3,2,4,170,1,'L'],[/courgettes?/,17,1.2,3,.3,1,8,250,1,'L'],[/brocolis?/,34,2.8,7,.4,2.6,33,450,1,'L'],[/chou-fleur/,25,2,5,.3,2,30,800,1,'L'],
  [/haricots verts/,31,1.8,7,.2,2.7,6,0,1,'L'],[/champignons|pleurotes/,22,3,3.3,.3,1,5,0,1,'L'],[/epinards/,23,2.9,3.6,.4,2.2,79,0,1,'L'],[/kale|chou frise/,49,4.3,9,.9,3.6,38,200,1,'L'],
  [/choucroute/,19,.9,4.3,.1,2.9,650,0,1,'L'],[/chou|salade de chou/,25,1.3,6,.1,2.5,18,400,1,'L'],[/salade cesar/,140,3,7,12,1.5,300,300,1,'L'],
  [/coeurs de romaine/,17,1.2,3.3,.3,2.1,8,200,1,'L'],[/laitue boston/,13,1.4,2.2,.2,1.1,5,150,1,'L'],[/laitue melangee|jeunes pousses|roquette/,20,2,3,.5,1.5,25,142,1,'L'],
  [/feuilles de laitue/,15,1.2,3,.2,1.3,10,15,1,'L'],[/laitues?|romaine/,17,1.2,3.3,.3,2.1,8,400,1,'L'],
  [/sauce a pizza/,55,2,9,1.5,2,400,0,1.05,''],[/sauce tomate|sauce marinara/,60,1.8,9,2,2,450,0,1.05,'L'],[/pate de tomates/,82,4.3,19,.5,4,60,0,1.1,'L'],
  [/puree de tomates/,38,1.6,9,.2,1.9,150,0,1.05,'L'],[/tomates sechees/,210,5,23,14,6,270,0,.9,'L'],[/tomates (en des|broyees)|boites de tomates/,27,1.3,5.5,.2,1.7,190,0,1.05,'L'],
  [/tomates?/,18,.9,3.9,.2,1.2,5,120,1,'L'],[/salsa/,30,1.5,6.5,.2,1.5,600,0,1.05,'L'],
  [/mais en creme/,72,1.7,18,.4,1.2,260,400,1,'L'],[/boites? de mais|mais en grains$/,80,2.5,18,1,2,200,250,1,'L'],[/\bmais\b/,86,3.2,19,1.2,2.4,2,0,1,'L'],
  [/pois et carottes|petits pois|pois verts/,70,4,12,.4,4,70,0,1,'L'],[/legumes melanges|melange de legumes/,60,3,12,.3,3.5,40,0,1,'L'],
  [/feves germees|pousses de soya/,30,3,6,.2,1.8,6,0,1,'L'],[/pois mange-tout/,42,2.8,7.5,.2,2.6,4,0,1,'L'],[/bok choy|pak-choi/,13,1.5,2.2,.2,1,65,200,1,'L'],
  [/fenouil/,31,1.2,7,.2,3.1,52,250,1,'L'],[/panais/,75,1.2,18,.3,4.9,10,150,1,'L'],[/courge/,45,1,12,.1,2,4,0,1,'L'],[/betteraves/,65,.8,16,.1,1.5,300,500,1,'L'],
  [/cornichons sucres/,90,.3,21,.2,1,450,30,1,''],[/cornichons/,12,.3,2.4,.2,1,900,30,1,''],[/artichauts/,45,3,9,.2,5,300,250,1,'L'],[/jalapenos?/,29,.9,6.5,.4,2.8,3,15,1,'L'],
  [/avocats?/,160,2,8.5,14.7,6.7,7,140,1,'L'],[/concombre anglais/,15,.7,3.6,.1,.5,2,400,1,'L'],[/concombres?/,15,.7,3.6,.1,.5,2,300,1,'L'],
  [/olives/,145,1,4,15,3,1500,0,1,''],[/capres/,23,2.4,5,.9,3.2,2350,0,1,''],[/basilic|persil|coriandre|aneth|menthe|herbes fraiches/,30,3,5,.6,3,40,40,.1,''],
  [/graines de citrouille/,560,30,11,49,6,7,0,.55,''],[/citrons?/,29,1.1,9,.3,2.8,2,50,1,''],[/limes?/,30,.7,11,.2,2.8,2,35,1,''],[/oranges?/,47,.9,12,.1,2.4,0,150,1,'L'],
  [/pommes/,52,.3,14,.2,2.4,1,180,1,'L'],[/bananes?/,89,1.1,23,.3,2.6,1,120,1,'L'],[/ananas en (conserve|rondelles)|boites? d.ananas/,60,.4,15.5,.1,.8,1,400,1,'L'],
  [/ananas/,50,.5,13,.1,1.4,1,500,1,'L'],[/mangues?/,60,.8,15,.4,1.6,1,200,1,'L'],[/petits fruits|fraises|framboises|bleuets|barquette de fruits/,50,.8,12,.4,3.5,1,450,1,'L'],
  [/peches/,39,.9,10,.3,1.5,0,150,1,'L'],[/poires/,57,.4,15,.1,3.1,1,180,1,'L'],[/raisins secs/,300,3,79,.5,3.7,11,0,1,''],[/raisins/,69,.7,18,.2,.9,2,0,1,'L'],
  [/dattes/,280,2.5,75,.4,8,2,0,1,''],[/canneberges sechees/,325,.1,82,1.4,5.7,3,0,1,''],[/sauce aux canneberges/,150,.2,38,.1,1,30,0,1.1,''],[/rhubarbe/,21,.9,4.5,.2,1.8,4,0,1,'L'],
  [/cerises au marasquin/,165,.2,42,.2,3,4,300,1,''],[/cerises/,60,1,15,.2,1.6,3,350,1,'L'],
  // gras, sauces, condiments
  [/huile (pour la |a )?friture/,88,0,0,10,0,0,0,.92,''],[/huile/,884,0,0,100,0,0,0,.92,''],[/mayonnaise/,680,1,.6,75,0,630,0,.92,''],[/\branch\b/,450,1,6,46,0,900,125,1,''],
  [/vinaigrette|sauce cesar/,350,.5,8,35,0,900,0,1,''],[/ketchup/,100,1.2,26,.1,.3,900,0,1.15,''],[/moutarde au miel/,230,1,30,11,1,600,125,1.1,''],
  [/moutarde/,66,4,6,3.3,3,1100,0,1.05,''],[/relish/,130,.5,35,.5,1,800,0,1.1,''],[/raifort/,48,1.2,11,.7,3.3,420,0,1,''],
  [/sauce soya|soya/,53,8,5,.6,.8,5500,0,1.15,''],[/teriyaki/,90,6,16,0,.1,3800,0,1.1,''],[/hoisin/,220,3.3,44,3.4,2.8,1600,0,1.15,''],[/huitres/,51,1.4,11,.3,.3,2700,0,1.2,''],
  [/sauce aux prunes/,180,.9,43,1,.7,540,125,1.15,''],[/bbq/,170,.8,41,.6,.9,1000,125,1.15,''],[/sriracha|sambal|sauce piquante|buffalo|chipotle|pate de chili/,90,1.5,15,1,1,2500,0,1.05,''],
  [/worcestershire/,78,0,19,0,0,1000,0,1.1,''],[/sauce brune/,40,1,6,1.5,.3,500,250,1,''],[/alfredo/,150,2.5,4,14,0,500,0,1,''],[/sauce blanche/,100,3,8,6,0,300,0,1,''],
  [/aigre-douce|general tao|pad thai/,170,1.5,38,1.5,.4,1300,0,1.15,''],[/sauce cocktail/,100,1.5,22,.5,1.5,1200,0,1.1,''],[/sauce tartare/,300,.5,8,30,0,600,125,1,''],
  [/sloppy joe/,70,1.5,15,.3,1.5,700,0,1.1,''],[/salsa verde/,30,1,6,.5,1.5,500,0,1.05,''],[/pesto/,450,5,6,45,1.5,750,0,1,''],
  [/tahini/,600,17,21,54,9,115,0,1,''],[/tartinade chocolat/,540,6,57,31,3.4,40,0,1.2,''],[/miso/,200,12,26,6,5.4,3700,0,1.15,''],[/gochujang/,220,4,45,2,2,3000,0,1.2,''],
  [/pate de (cari|tikka|chili)|pate de cari/,150,2,10,11,3,3000,0,1.1,''],
  // assaisonnements, sucres, pâtisserie
  [/assaisonnement|epices a (tacos|steak)|sachets? (d.epices|d.assaisonnement)/,300,5,55,5,10,5000,25,.6,''],
  [/bicarbonate/,0,0,0,0,0,27000,0,1.1,''],[/poudre a pate/,53,0,28,0,0,10600,0,.9,''],[/levure/,325,40,41,7.6,27,50,0,.6,''],
  [/sucre a glacer/,390,0,100,0,0,2,0,.5,''],[/cassonade/,380,.1,98,0,0,28,0,.9,''],[/sucre/,387,0,100,0,0,1,0,.85,''],[/miel/,304,.3,82,0,.2,4,0,1.42,''],
  [/sirop d.erable/,260,0,67,.1,0,12,0,1.33,''],[/melasse/,290,0,75,.1,0,37,0,1.4,''],[/vanille/,288,0,13,0,0,9,0,.88,''],
  [/cacao/,230,20,58,14,33,20,0,.4,''],[/chocolat|pepites/,530,5,60,31,6,20,0,.6,''],[/guimauves/,318,1.8,81,.2,.1,80,0,.2,''],[/bonbons/,380,0,95,0,0,30,0,1,''],
  [/biscuits graham/,430,7,77,10,3,500,14,.4,''],[/oreo/,480,5,70,20,3,400,11,1,''],[/doigts de dame/,365,10,75,4,1,150,10,1,''],[/brownies/,420,5,60,18,2,300,50,1,''],
  [/arachides/,590,25,21,50,8,400,0,.55,''],[/noix de coco/,650,7,24,65,16,37,0,.35,''],[/sesame/,573,18,23,50,12,11,0,.6,''],[/noix|pacanes|amandes|pignons/,620,17,15,58,8,5,0,.45,''],
  [/sauce au (caramel|chocolat)|caramel/,300,1.5,65,4,.5,300,0,1.3,''],[/tapioca/,358,.2,89,0,1,1,0,.75,''],
  [/confiture|ketchup aux fruits/,250,.4,65,.1,1,30,250,1.3,''],
  [/canettes? de biere/,43,.5,3.6,0,0,4,355,1,''],[/biere/,43,.5,3.6,0,0,4,0,1,''],[/vin/,85,.1,2.6,0,0,5,0,1,''],[/cognac|bourbon|rhum/,230,0,0,0,0,1,0,.95,''],
  [/cafe/,1,.1,0,0,0,2,0,1,''],[/cola/,42,0,10.6,0,0,4,0,1.04,''],
  // épices et herbes séchées (petites quantités)
  [/paprika|cumin|origan|thym|cannelle|cari|poudre de chili|herbes de provence|muscade|sauge|laurier|garam masala|clous? de girofle|cayenne|flocons de piment|romarin|seche/,300,12,55,8,30,50,1,.5,'']];
let _NUTC = new Map();
function nutRow(name){ const n = norm(name); if(_NUTC.has(n)) return _NUTC.get(n); const r = NUT.find(x => x[0].test(n)) || null; _NUTC.set(n, r); return r; }
/* grammes d'un ingrédient (quantité de la liste) */
function nutGrams(row, name, q, u){ return u==='g' ? q : u==='ml' ? q * (row ? row[8] || 1 : 1) : q * ((row && row[7]) || gpuOf(norm(name)) || 100); }
/* valeur nutritive d'une liste d'ingrédients, divisée par le nombre de portions */
function nutSomme(ings, np){
  const t = {kcal:0, p:0, gl:0, l:0, fi:0, na:0, leg:0, g:0, inc:0};
  ings.forEach(g => { if(g.x || g.rest) return; const row = nutRow(g.name), gr = nutGrams(row, g.name, g.q, g.u); t.g += gr;
    if(!row){ t.inc += gr; return; } const f = gr / 100; t.kcal += row[1]*f; t.p += row[2]*f; t.gl += row[3]*f; t.l += row[4]*f; t.fi += row[5]*f; t.na += row[6]*f; if(row[9]==='L') t.leg += gr; });
  const d = Math.max(1, np || 1); Object.keys(t).forEach(k => { if(k !== 'g' && k !== 'inc') t[k] /= d; });
  t.fiable = t.g ? 1 - t.inc / t.g : 0; return t;
}
/* par portion d'un plat du menu (accompagnements, sauce et 2e protéine compris) */
function nutPlat(it){
  const r = byName(it.r); if(!r || r.nonut) return null; const kd = kindOf(r);
  const np = kd==='souper' || it.sr ? portionsOf(it) : kd==='dejeuner' ? (it.pt || pDej()) : (it.pt || 6);
  return nutSomme(fullIngs(it), np);
}
/* par portion de la recette telle qu'écrite (6 portions), sans accompagnements */
function nutRecette(r, v){ return nutSomme(effective(r, v||0).map(g => ({name:g.name, q:g.q, u:g.u})), 6); }
const nfr0 = x => Math.round(x).toLocaleString('fr-CA');
/* repères : ce qui ressort pour une portion de repas */
function nutReperes(t, repas){
  if(!t || t.fiable < .6) return [];
  const R = [];
  if(t.p >= 30) R.push(['Riche en protéines','a']);
  if(t.fi >= 6) R.push(['Riche en fibres','a']); else if(t.fi >= 4) R.push(['Source de fibres','a']);
  if(t.leg >= 150) R.push([`${nfr(t.leg / 80, 1).replace(/,0$/, '')} portions de légumes`,'a']);
  if(repas && t.kcal < 450) R.push(['Léger','a']); if(repas && t.kcal > 900) R.push(['Copieux','k']);
  if(t.na > 1500) R.push(['Très salé','w']); else if(t.na > 1100) R.push(['Salé','w']);
  return R;
}
function nutLigne(t, repas){
  if(!t || t.fiable < .6) return '';
  const rp = nutReperes(t, repas);
  return `<details class="panel nut"><summary>Par portion : ≈ ${nfr0(t.kcal)} kcal · protéines ${nfr0(t.p)} g · fibres ${nfr0(t.fi)} g${rp.length ? `<span class="flags">${rp.map(([x, c]) => `<span class="flag ${c}">${esc(x)}</span>`).join('')}</span>` : ''}</summary>
    <table class="nutt"><tbody><tr><td>Énergie</td><td>${nfr0(t.kcal)} kcal</td></tr><tr><td>Protéines</td><td>${nfr0(t.p)} g</td></tr><tr><td>Glucides</td><td>${nfr0(t.gl)} g</td></tr>
    <tr><td>Lipides</td><td>${nfr0(t.l)} g</td></tr><tr><td>Fibres</td><td>${nfr0(t.fi)} g</td></tr><tr><td>Sodium</td><td>${nfr0(t.na)} mg</td></tr><tr><td>Légumes et fruits</td><td>${nfr0(t.leg)} g</td></tr></tbody></table>
    <p class="small">Estimation à partir des ingrédients${t.fiable < .95 ? ' (quelques ingrédients inconnus ne sont pas comptés)' : ''}, sans le sel ajouté au goût. Repères : un souper équilibré donne environ 25 à 40 g de protéines, 6 g de fibres ou plus, moins de 1 000 mg de sodium et 2 portions de légumes (une portion ≈ 80 g).</p></details>`;
}
/* bilan des soupers de la semaine (pour l'ébauche) */
function nutSemaine(){
  const L = mlist('items').map(it => nutPlat(it)).filter(t => t && t.fiable >= .6); if(L.length < 2) return '';
  const moy = k => L.reduce((a, t) => a + t[k], 0) / L.length, poisson = mlist('items').filter(it => { const r = byName(it.r); return r && mainProts(r, it.v).some(x => x==='poisson' || x==='mer'); }).length;
  const veg = moy('leg') / 80, na = moy('na'), fi = moy('fi');
  const notes = [veg < 1.5 ? 'Peu de légumes : ajoute une salade ou un légume à quelques soupers.' : '', na > 1100 ? 'Assez salé : préfère les versions maison des sauces, ou du bouillon réduit en sel.' : '', fi < 4 ? 'Peu de fibres : un plat de légumineuses ou des grains entiers aideraient.' : '', poisson === 0 ? 'Pas de poisson cette semaine (le Guide alimentaire en suggère au moins une fois).' : ''].filter(Boolean);
  return `<div class="nutw"><p class="qz-h">La semaine dans l'assiette <small>soupers, par portion</small></p>
    <p class="small">≈ ${nfr0(moy('kcal'))} kcal · protéines ${nfr0(moy('p'))} g · fibres ${nfr(fi, 1)} g · sodium ${nfr0(na)} mg · légumes ${nfr(veg, 1)} portion${veg >= 2 ? 's' : ''} · ${poisson} souper${poisson>1?'s':''} de poisson</p>
    ${notes.length ? `<p class="small">${esc(notes.join(' '))}</p>` : '<p class="small">Une semaine bien équilibrée.</p>'}</div>`;
}
/* ---------- le questionnaire de la semaine ----------
   « Préparer ma semaine » ouvre quelques questions déjà remplies (combien, le temps, les protéines, les envies).
   L'app bâtit ensuite une ébauche avec ses questions par repas; « Bâtir le menu final » la confirme. */
let qzOpen = false, qz = null, qzMode = 'preparer';
const QZ_N = [['n','Soupers',[3,4,5,6,7]],['nSr','Dont soupes-repas',[0,1,2]],['nCm','Dont repas plaisir',[0,1,2]],['nSou','Soupes à côté',[0,1,2,3]],['nEnt','Entrées',[0,1,2,3,4,5,6,7]],
  ['nDes','Desserts',[0,1,2,3,4,5,6,7]],['nDej','Déjeuners',[0,1,2,3,4,5,6,7]],['nDin','Dîners',[0,1,2,3,4,5,6,7]]];
const QZ_ENV = [['poulet','Poulet'],['boeuf','Boeuf'],['porc','Porc'],['poisson','Poisson'],['vege','Végé'],['bbq','BBQ et grillades'],['mijote','Mijoteuse'],['pates','Pâtes'],
  ['mex','Mexicain'],['asia','Asiatique'],['pub','Pub'],['poutine','Poutine'],['sandwich','Burgers et sandwichs'],['fumoir','Fumoir'],['soupe','Soupes']];
const QZ_PAS = [['poulet','Poulet'],['boeuf','Boeuf'],['porc','Porc'],['poisson','Poisson et fruits de mer'],['vege','Végé']];
function qzInit(){
  const p = S.p, q = (S.menu && S.menu.eb && S.menu.q) || {};
  qz = {n:Object.fromEntries(QZ_N.map(([k]) => [k, +p[k] || 0])), temps:q.temps || 'normale', mix:q.mix || (S.qLast && S.qLast.mix) || 'p2',
    env:(q.env || []).slice(), pas:(q.pas || []).slice(), budget:+p.budget || 0};
  if(!qz.n.n) qz.n.n = 5;
}
function questionnaireCard(){
  if(!qz) qzInit();
  const garder = qzMode==='refaire' || !!(S.menu && S.menu.eb), np = garder && S.menu.shop ? S.menu.shop : nextPickup(), start = garder && S.menu.start ? S.menu.start : startFrom(np), q = qz;
  const R = membresG().map((m, i) => ({i, k:Object.keys(m.g||{}).filter(k => GOUT_PROT.includes(k) && m.g[k]===1)})).filter(x => x.k.length);
  const seg = (k, opts, lab) => `<div class="seg qz-seg" role="group" aria-label="${esc(lab)}">${opts.map(([v, t]) => `<button class="${q[k]===v?'on':''}" data-a="qz_set" data-k="${k}" data-v="${v}" aria-pressed="${q[k]===v}">${esc(t)}</button>`).join('')}</div>`;
  const chips = (k, L, lab) => `<div class="chips" role="group" aria-label="${esc(lab)}">${L.map(([v, t]) => `<button type="button" class="chip${q[k].includes(v)?' on':''}" data-a="qz_tog" data-k="${k}" data-v="${v}" aria-pressed="${q[k].includes(v)}">${esc(t)}</button>`).join('')}</div>`;
  const tps = q.temps==='vite' ? 'Des plats rapides les soirs de semaine (25 min de préparation au plus) et pas de longue cuisson.'
    : q.temps==='temps' ? `Des plats plus élaborés permis, et jusqu'à ${Math.max(2, (S.p.nLong ?? 1) + 1)} longues cuissons les jours de congé.` : `Comme d'habitude : ${S.p.maxTm||35} min de préparation au plus un soir de semaine.`;
  const mix = q.mix==='p2' ? 'Quand un plat contient une protéine que quelqu\'un refuse, une 2e protéine est prévue pour lui, cuite à part.'
    : q.mix==='eviter' ? 'Cette semaine, seulement des plats que tout le monde mange.' : 'Pas de 2e protéine : chacun s\'arrange.';
  return `<div class="card call" id="qz_card"><h3>${qzMode==='refaire' && S.menu.date && !S.menu.eb ? 'Refaire le menu' : 'Ta semaine'}</h3>
    <p class="small">Ramassage ${esc(fmtDate(np))}, menu du ${esc(dayLbl(start).toLowerCase())} au ${esc(dayLbl(addDays(start, 6)).toLowerCase())}. Les réponses sont déjà remplies : change seulement ce qui est différent cette semaine.${garder && S.menu.date ? ' Les plats gardés restent; les autres sont choisis de nouveau.' : ''}</p>
    <p class="qz-h">Combien cette semaine</p>
    <div class="grid4c">${QZ_N.map(([k, lab, opts]) => `<label class="f">${lab}<select data-qn="${k}">${opts.concat([q.n[k]]).filter((v, j, a) => a.indexOf(v)===j).sort((a, b) => a-b).map(v => `<option ${q.n[k]===v?'selected':''}>${v}</option>`).join('')}</select></label>`).join('')}</div>
    <p class="qz-h">Le temps pour cuisiner</p>${seg('temps', [['vite','Semaine chargée'],['normale','Normale'],['temps',"J'ai du temps"]], 'Le temps pour cuisiner')}<p class="small">${esc(tps)}</p>
    ${R.length ? `<p class="qz-h">Les protéines</p><p class="small">${esc(R.map(x => `${nomDe(x.i)} refuse : ${refusTxt(x.k)}`).join('. '))}.</p>
      ${seg('mix', [['p2','2e protéine au besoin'],['eviter','Éviter ces plats'],['pareil','Même plat pour tous']], 'Les protéines')}<p class="small">${esc(mix)}</p>`
    : `<p class="small">Quelqu'un ne mange pas de poisson, de porc ou de champignons ? Note les goûts de chacun dans <button class="lnk" data-a="view" data-v="famille">Profil → Famille</button> : le menu en tiendra compte.</p>`}
    <p class="qz-h">Envies de la semaine <small>facultatif</small></p>${chips('env', QZ_ENV, 'Envies de la semaine')}
    <p class="qz-h">Pas cette semaine <small>facultatif</small></p>${chips('pas', QZ_PAS, 'Pas cette semaine')}
    ${goPlanSel()}
    <label class="f">Budget de la semaine (facultatif)<input type="text" inputmode="decimal" class="num" data-qb="1" value="${q.budget ? String(q.budget).replace('.', ',') : ''}" placeholder="Aucun"></label>
    <div class="acts"><button class="btn p" id="prep_go" ${prepBusy ? 'disabled' : ''}>${prepBusy ? 'Préparation en cours…' : "Voir l'ébauche du menu"}</button><button class="btn s" data-a="qz_close">Annuler</button></div>
    <p class="small" id="sp_status" aria-live="polite"></p></div>`;
}
/* rôle d'une entrée ou d'une soupe (menu déroulant seul, pour l'ébauche) */
function roSel(it, i, l){
  const ro = it.ro || (l==='sou' ? 'lunch' : 'libre');
  const R = l==='sou' ? [['avec','À côté du souper'],['lunch','Pour les lunchs'],['repas','Comme repas (soupe-repas)']] : [['entree','En entrée'],['avec','Avec le repas'],['libre','Au choix, sans jour']];
  return `<select data-a="xro" data-ml="${l}" data-i="${i}" aria-label="Servie">${R.map(([v, t]) => `<option value="${v}" ${ro===v?'selected':''}>${esc(t)}</option>`).join('')}</select>`;
}
/* accompagnements d'une soupe-repas (deux menus déroulants) */
function sideMini(it, i){
  const r = byName(it.r); if(!r) return ''; const rr = soupR(r);
  return `<div class="eb-sides">${['f','v'].map(slot => { const key = slot==='f'?'sf':'sv', cur = it[key]||'';
    const ok = sidesOf(slot).filter(x => (compat(x, rr) && !(slot==='f' && clash(x, rr))) || x.id===cur);
    return `<select data-a="sidesel" data-ml="items" data-i="${i}" data-s="${slot}" aria-label="${slot==='f' ? 'Avec la soupe' : 'Salade ou légume'}"><option value="">${slot==='f' ? 'Rien avec' : 'Pas de salade'}</option>${ok.map(x => `<option value="${esc(x.id)}" ${cur===x.id?'selected':''}>${esc(x.n)}</option>`).join('')}</select>`; }).join('')}</div>`;
}
/* l'ébauche : chaque jour, son souper et ses questions; puis le reste de la semaine */
function ebaucheCard(){
  const m = S.menu, I = mlist('items'), rows = buyList().rows, t = listTotals(rows), nDeal = rows.filter(r => dealFor(r.name)).length;
  let nq = 0;
  const day = d => {
    const i = I.findIndex(x => x.d===d), it = I[i], r = it && byName(it.r);
    if(!it || !r) return `<div class="eb-day"><span class="eb-d">${esc(dayLbl(d))}</span><span class="eb-m"><small>Pas de souper prévu</small></span></div>`;
    const qs = [], R = refusDe(it, 'items');
    if(R && R.prot.length){ const sel = p2Sel(it, 'items', i); qs.push(`<p class="eb-q">${esc(p2Txt(it, 'items'))}</p>${sel ? `<label class="f">2e protéine${sel}</label>` : ''}`); nq++; }
    const at = autreTxt(it, 'items'); if(at){ qs.push(`<p class="eb-q">${esc(at)}</p>`); nq++; }
    if(it.sr){ qs.push(`<p class="eb-q">Soupe-repas : avec quoi ?</p>${sideMini(it, i)}`); nq++; }
    const pp = x => pasPour(x) ? `<small>${esc(pasPour(x))}</small>` : '';
    mlist('ent').forEach((x, j) => { if(x.d===d && (x.ro==='entree' || x.ro==='avec')){ qs.push(`<div class="eb-x"><span>${esc(x.r)}${pp(x)}</span>${roSel(x, j, 'ent')}</div>`); nq++; } });
    mlist('sou').forEach((x, j) => { if(x.d===d && x.ro==='avec'){ qs.push(`<div class="eb-x"><span>Soupe : ${esc(x.r)}${pp(x)}</span>${roSel(x, j, 'sou')}</div>`); nq++; } });
    const k = cmEff(it, r), fl = [fmtMin(tpM(r, k)), it.sr ? 'soupe-repas' : '', it.cm ? 'repas plaisir' : '', itemDeals(it, r).length ? 'spécial' : '', it.after ? 'avec des restes' : '', k ? CM_L[k].toLowerCase() : '', p2Info(it, 'items') ? '2e protéine' : ''].filter(Boolean);
    return `<div class="eb-day${isOff(d) ? ' off' : ''}"><span class="eb-d">${esc(dayLbl(d))}</span><span class="eb-m"><b>${esc(r.n)}</b><small>${esc(fl.join(' · '))}</small></span><button class="btn s" data-a="mswap" data-ml="items" data-i="${i}" aria-label="Changer ${esc(r.n)}">Changer</button>${qs.length ? `<div class="eb-qs">${qs.join('')}</div>` : ''}</div>`;
  };
  const jours = weekDates().map(day).join('');
  const libres = [['sou', x => !x.ro || x.ro==='lunch', 'Soupes pour les lunchs'], ['ent', x => !x.ro || x.ro==='libre', 'Entrées au choix']]
    .map(([l, f, lab]) => { const L = mlist(l).map((x, j) => [x, j]).filter(([x]) => f(x)); return L.length ? `<p class="qz-h">${esc(lab)}</p>${L.map(([x, j]) => `<div class="eb-x"><span>${esc(x.r)}</span>${roSel(x, j, l)}</div>`).join('')}` : ''; }).join('');
  const autres = [['dej','Déjeuners'],['des','Desserts']].map(([l, lab]) => { const L = mlist(l); return L.length ? `<p class="small"><b>${lab} :</b> ${esc(L.map(x => x.r).join(', '))}</p>` : ''; }).join('')
    + (P => P.length ? `<p class="small"><b>Dîners :</b> ${esc(P.map(p => p.rest ? 'restes de ' + lowFirst(p.rest.r) : p.it ? p.it.r : '').filter(Boolean).join(', '))}</p>` : '')(dinPlan().filter(p => p.it || p.rest));
  return `<div class="card call" id="eb_card"><h3>Ébauche du menu</h3>
    <p class="small">Du ${esc(dayLbl(m.start).toLowerCase())} au ${esc(dayLbl(addDays(m.start, 6)).toLowerCase())} · ≈ ${money(t.cost)}${S.p.budget ? ' (budget ' + money(+S.p.budget) + ')' : ''}${nDeal ? ` · ${nDeal} article${nDeal>1?'s':''} en spécial` : ''}. ${nq ? 'Réponds aux questions, change' : 'Change'} ce qui ne te plaît pas, puis bâtis le menu final.</p>
    <div class="eb-list">${jours}</div>${libres}${autres}${nutSemaine()}
    <p class="small">Pour tout voir (versions, portions, recettes) : <button class="lnk" data-a="view" data-v="menu">Menu</button>.</p>
    <div class="acts"><button class="btn p" id="eb_ok">Bâtir le menu final et la liste</button><button class="btn s" id="eb_redo" data-armed="0">Refaire l'ébauche</button><button class="btn s" data-a="qz_open">Revoir mes réponses</button></div></div>`;
}
/* « Préparer ma semaine » : spéciaux → menu → budget, en une fois */
let prepBusy = false;
async function preparerSemaine(eb, garder){
  if(prepBusy) return; prepBusy = true;
  try{ await preparerSemaine0(eb, garder); } catch(e){ prepBusy = false; render(); throw e; } finally { prepBusy = false; }
}
async function preparerSemaine0(eb, garder){
  const say = t => { const s = $('#sp_status'); if(s) s.textContent = t; };
  const today = isoToday();
  /* les soupers qui restent cette semaine (déjà achetés) restent au menu jusqu'au début de la nouvelle;
     « Refaire le menu » (garder) refait plutôt la semaine en cours, mêmes dates, plats gardés compris */
  let prev = garder ? (S.menu.prev || []) : [];
  if(!garder && S.menu.date && S.menu.start <= today){ prev = mlist('items').filter(x => x.d && x.d >= today).map(x => Object.assign({}, x, {lock:true})); terminerSemaine(); }
  tab = 'semaine';
  if(!garder && !(S.dates.man && S.dates.shop && S.dates.shop >= today)){ S.dates.shop = nextPickup(); S.dates.man = false; }
  const gp = goPlan();
  if(S.stores.length > 1){ const one = gp==='main' ? S.p.main : S.stores.includes(gp) ? gp : '';
    S.skip = one ? S.stores.filter(s => s !== one) : []; S.goSome = false; S.goAuto = gp==='auto'; }
  save(); render();
  if(familleCode() && S.stores.length && !(S.auto && S.auto.shop === S.dates.shop && S.auto.maj === isoToday())){ say('Recherche des spéciaux…'); try{ await chercherSpeciaux(false); }catch(e){} }
  const sp = (S.auto && S.auto.shop === S.dates.shop) ? autoItems().length : 0;
  genMenu();
  if(eb) S.menu.eb = true;
  S.menu.prev = garder ? prev : prev.filter(x => x.d < S.menu.start);
  /* « l'app choisit » : la liste va à l'épicerie la moins chère; les combinaisons restent proposées dans Épicerie */
  let ouTxt = '';
  if(S.goAuto && S.stores.length > 1){ resetCaches(); const C = comparer(buyList().rows), b = C.best, m = C.multi[0];
    choisirEpiceries(b.stores); S.p.grp = 'rayon'; resetCaches();
    ouTxt = ` Le moins cher cette semaine : ${b.stores[0]}.` + (m ? ` En allant aussi chez ${m.stores.filter(s => s !== b.stores[0]).join(' et ')} : ≈ ${money((b.total - m.total)*calF())} de moins (voir Épicerie).` : ''); }
  const rows = buyList().rows, t = listTotals(rows), aub = aubaines().length;
  S.flash = `${eb ? 'Ébauche prête' : 'Menu prêt'} : ${mlist('items').length} soupers du ${dayLbl(S.menu.start).toLowerCase()} au ${dayLbl(addDays(S.menu.start, 6)).toLowerCase()}, ≈ ${money(t.cost)}${S.p.budget ? ' (budget ' + money(S.p.budget) + ')' : ''}${t.save >= 1 ? ', ≈ ' + money(t.save) + ' économisés en spéciaux' : ''}.`
    + (sp ? '' : !familleCode() ? ' Sans le code de la famille (Profil → Compte), le menu est fait sans les spéciaux.' : ' Les circulaires de cette semaine ne sont pas encore lues : relance « Chercher les spéciaux » jeudi pour un menu qui en profite.')
    + (aub ? ` ${aub} vraie${aub>1?'s':''} aubaine${aub>1?'s':''} à considérer pour faire des réserves.` : '') + ouTxt;
  tab = 'semaine'; prepBusy = false; save(); render(); window.scrollTo(0, 0);
}
/* l'ébauche devient le menu de la semaine; la liste d'épicerie suit */
function ebaucheOk(){
  const m = S.menu; if(!m.eb) return; delete m.eb;
  const rows = buyList().rows, t = listTotals(rows);
  S.flash = `Menu final prêt : ${mlist('items').length} soupers. La liste d'épicerie est bâtie : ${rows.length} article${rows.length>1?'s':''}, ≈ ${money(t.cost)}.`;
  tab = 'semaine'; save(); render(); window.scrollTo(0, 0);
}

/* Menu de la semaine — Navigation, actions et démarrage (chargé en dernier).
   Les fichiers de js/ partagent les mêmes variables globales; ils sont chargés dans l'ordre de index.html. */
/* ---------- navigation et rendu global ----------
   5 onglets en bas (groupes), chacun avec ses sous-menus en haut (vues). `tab` = la vue affichée. */
let tab = 'semaine', aideFrom = 'semaine';
const GROUPS = {semaine:['semaine'], menu:['menu','historique'], epicerie:['epicerie','maison'], recettes:['recettes'], profil:['famille','epiceries','prixbudget','compte','aide']};
/* sous-menus visibles en haut : Historique s'ouvre par « Semaines passées » (Menu), l'Aide par son bouton */
const SUBNAV = {epicerie:['epicerie','maison'], profil:['famille','epiceries','prixbudget','compte']};
const VLBL = {epicerie:'Liste', maison:'Maison', famille:'Famille', epiceries:'Épiceries', prixbudget:'Prix et budget', compte:'Compte'};
/* anciennes adresses (liens d'avant, données d'une ancienne version) : elles mènent à la nouvelle place */
const OLDV = {horaire:'famille', budget:'prixbudget', articles:'prixbudget', prix:'prixbudget', sauvegarde:'compte', apparence:'compte'};
const SECTIONS = ['semaine','menu','historique','epicerie','maison','recettes','profil'];
const groupOf = v => Object.keys(GROUPS).find(g => GROUPS[g].includes(v));
const secOf = v => GROUPS.profil.includes(v) ? 'profil' : v;
const lastView = {};
const RENDER = {semaine:() => renderSemaine(), menu:() => renderMenu(), historique:() => renderReglages(), epicerie:() => renderEpicerie(), maison:() => renderMaison(), recettes:() => renderRecettes(), aide:() => renderAide()};
GROUPS.profil.filter(v => v!=='aide').forEach(v => RENDER[v] = () => renderReglages());
function renderView(){ (RENDER[tab] || renderSemaine)(); const nav = subNav(groupOf(tab)); if(nav) $('#tab-'+secOf(tab)).insertAdjacentHTML('afterbegin', nav); }
function subNav(g){ const L = SUBNAV[g]; if(!L || !L.includes(tab)) return '';
  return `<div class="seg subnav" role="tablist" aria-label="Sous-menus">${L.map(v => `<button role="tab" class="${v===tab?'on':''}" data-a="view" data-v="${v}" aria-selected="${v===tab}">${esc(VLBL[v])}</button>`).join('')}</div>`; }
function prixTabHtml(){ return `<div class="card"><input type="text" id="ar_q" value="${esc(artF.q)}" placeholder="Chercher un article" aria-label="Chercher un article" autocomplete="off"></div>` + prixView(); }
/* Apparence : claire par défaut, sombre ou comme le téléphone au choix (Profil). */
function applyTheme(){
  const t = (S.p && S.p.theme) || 'auto', root = document.documentElement;
  if(t==='auto') delete root.dataset.theme; else root.dataset.theme = t;
  const dark = t==='dark' || (t==='auto' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
  const m = document.getElementById('mtc'); if(m) m.content = dark ? '#1c1917' : '#f6eee0';
}
/* plats supprimés ou versions retirées : on nettoie les références au lieu de planter l'affichage */
function fixRefs(){
  let ch = false;
  const ok = it => { if(!it || typeof it.r!=='string') return false; const r = byName(it.r); if(!r) return false; if(it.v && !(vars(r)[it.v-1])){ it.v = 0; ch = true; } return true; };
  LISTS.forEach(l => { const L = S.menu[l]; if(Array.isArray(L)){ const K = L.filter(ok); if(K.length !== L.length){ S.menu[l] = K; ch = true; } } });
  if(S.occ && Array.isArray(S.occ.items)){ const K = S.occ.items.filter(ok); if(K.length !== S.occ.items.length){ S.occ.items = K; ch = true; } }
  return ch;
}
function render(){
  applyTheme();
  _AR = _ND = _BL = _AS = _PN = null; _DF = new Map(); _ASA = null; _ECO = new Map(); _CMP = new Map();
  if(fixRefs() | syncMeals()) save();
  if(OLDV[tab]){ if(tab==='articles' || tab==='prix') pbSec = tab; tab = OLDV[tab]; }
  if(!groupOf(tab)) tab = 'semaine';
  if(plusK==='frigo' && tab==='maison') plusK = '';
  const g = groupOf(tab); lastView[g] = tab;
  (RENDER[tab] || renderSemaine)();
  const sec = secOf(tab);
  SECTIONS.forEach(t => { const el = $('#tab-'+t); if(el) el.hidden = t!==sec; });
  const nav = subNav(g); if(nav) $('#tab-'+sec).insertAdjacentHTML('afterbegin', nav);
  document.querySelectorAll('#tabs button').forEach(b => b.setAttribute('aria-selected', b.dataset.t===g));
  { const tb = $('#testbar'); if(tb) tb.hidden = !TEST; document.body.classList.toggle('test', TEST); }
  const n = S.menu.date ? buyList().rows.filter(r => !S.menu.chk[r.k]).length : 0;
  const bg = $('#bgl'); bg.hidden = !n; bg.textContent = n;
  if(cook) renderCook();
  renderPlus();
  navSync();
}
$('#tabs').addEventListener('click', e => { const b = e.target.closest('button'); if(!b) return; const g = b.dataset.t; plusK = ''; tab = groupOf(tab)===g ? GROUPS[g][0] : (lastView[g] && lastView[g]!=='aide' ? lastView[g] : GROUPS[g][0]); render(); window.scrollTo(0,0); });

/* ---------- actions ---------- */
function arm(btn, label, fn){
  if(btn.dataset.armed==='1'){ fn(); return; }
  btn.dataset.armed='1'; const old = btn.textContent; btn.textContent = label;
  setTimeout(() => { if(btn.isConnected){ btn.dataset.armed='0'; btn.textContent = old; } }, 3500);
}
function terminerSemaine(){
  /* articles cochés au magasin sans avoir touché « Épicerie terminée » : on les compte quand même dans Maison */
  if(!S.menu.achete && Object.values(S.menu.chk||{}).some(Boolean)) epicerieFaite();
  needs().forEach(n => {
    if(isMaison(n.name)) return;
    const sk = stockKey(n); const st = sk ? S.stock[sk] : null; if(!st) return;
    st.q = Math.max(0, st.q - n.q); if(st.q <= 0.001) delete S.stock[sk];
  });
  S.hist.push({start:S.menu.start||'', est:S.menu.est||0, date:S.menu.date, items:S.menu.items.map(x => ({r:x.r, v:x.v, sf:x.sf||'', sv:x.sv||''})), din:mlist('din').map(x => ({r:x.r, v:x.v, sf:x.sf||'', sv:x.sv||''})), dej:mlist('dej').map(x => ({r:x.r, v:x.v})), ent:mlist('ent').map(x => ({r:x.r, v:x.v})), sou:mlist('sou').map(x => ({r:x.r, v:x.v})), des:mlist('des').map(x => ({r:x.r, v:x.v})), paid:S.menu.paid||0});
  S.hist = S.hist.slice(-26);
  S.menu = {date:'', items:(S.report||[]).map(x => Object.assign({}, x, {lock:true, rep:true})), din:[], dej:[], dinCook:{}, dinNo:{}, dsel:{}, ent:[], sou:[], des:[], chk:{}, extra:{}, achete:false, snap:null, useup:{}};
  S.report = [];
  S.spec = [];
  S.dates.shop = ''; S.dates.man = false;   /* la prochaine semaine repart du prochain jour de ramassage */
  save(); tab = 'menu'; render(); window.scrollTo(0,0);
}
function epicerieFaite(){
  const {rows} = buyList();
  rows.forEach(r => {
    if(!S.menu.chk[r.k]) return;
    const q = Math.max(r.buy, r.def||0), o = S.stock[r.k]; if(o) o.q += q; else S.stock[r.k] = {name:r.name, u:r.u, q, rayon:r.rayon};
  });
  S.menu.snap = (S.menu.snap||[]).filter(x => x.ok).concat(rows.map(r => ({name:r.name, u:r.u, buy:r.buy, ok:!!S.menu.chk[r.k]})));
  S.menu.est = Math.round(((S.menu.achete ? (S.menu.est || 0) : 0) + listTotals(rows.filter(r => S.menu.chk[r.k])).raw) * 100) / 100;
  S.menu.chk = {}; S.menu.extra = {}; S.menu.achete = true; storeMode = false; save(); render();
}
function ajouterSpeciaux(){
  const store = $('#spstore').value; const lines = $('#sptxt').value.split(/\n+/).map(x => x.trim()).filter(x => x.length>=4 && x.length<=140);
  const mots = new Set(allRecipes().flatMap(r => (r.m||[]).map(norm)));
  const keep = lines.filter(l => { const n = norm(l); return [...mots].some(m => m.length>=4 && n.includes(m)); });
  const known = new Set(S.spec.map(s => s.s+'|'+norm(s.t)));
  let added = 0;
  keep.forEach(l => { const k = store+'|'+norm(l); if(!known.has(k)){ S.spec.push({s:store, t:l}); added++; } });
  S.spec = S.spec.slice(-120);
  save(); render();
  const msg = $('#spmsg'); if(msg) msg.textContent = `${added} spéciaux retenus sur ${lines.length} lignes.`;
}

document.addEventListener('click', e => {
  const t = e.target.closest('[id],[data-a]'); if(!t) return;
  /* un menu déroulant ou un champ texte se gère à « change » : redessiner au toucher fermerait le menu sur iPhone */
  if(t.tagName==='SELECT' || t.tagName==='OPTION' || t.tagName==='TEXTAREA' || (t.tagName==='INPUT' && !/^(checkbox|radio|button|submit)$/.test(t.type))) return;
  const a = t.dataset.a, id = t.id;
  if(id==='cook' && !a) return;   /* un toucher dans le mode Cuisiner, hors bouton */
  if(a==='cook'){ e.preventDefault(); if(t.dataset.r) openCook({r:t.dataset.r, pt:+t.dataset.pt||0, ms:t.dataset.ms==='1', cm:t.dataset.cm||''}); else openCook({l:t.dataset.ml||'items', i:+t.dataset.i}); return; }
  if(a==='ck_close'){ closeCook(); return; }
  if(a==='inst_go'){ installApp(); return; }
  if(a==='rb_check'){ const ty = t.dataset.t, j = robotJobs[ty]; if(j){ j.etat = 'attente'; j.t = Date.now() - 60e3; jobsSave(); render(); robotSuivre(ty, ty==='recette' ? 'reel' : 'inv'); } return; }
  if(a==='rb_drop'){ delete robotJobs[t.dataset.t]; jobsSave(); render(); return; }
  if(a==='fam_pub'){ const r = byName(t.dataset.r); if(!r) return; t.disabled = true; recFlash = `Ajout de ${r.n} à la banque commune…`; render();
    famPublier(r).then(() => { recFlash = `${r.n} est dans la banque commune.`; render(); }).catch(e => { recFlash = `La banque commune n'a pas pu être mise à jour (${e.message}).`; render(); }); return; }
  if(a==='fam_rm'){ const n = t.dataset.r; arm(t, 'Confirmer : retirer pour toute la famille', () => { recFlash = `Retrait de ${n}…`; render();
    famRetirer(n).then(() => { recFlash = `${n} est retirée de la banque commune.`; render(); }).catch(e => { recFlash = `La banque commune n'a pas pu être mise à jour (${e.message}).`; render(); }); }); return; }
  if(a==='fc_save' || a==='fc_test'){ codeSave(a==='fc_test'); return; }
  if(a==='qz_set'){ if(qz){ qz[t.dataset.k] = t.dataset.v; render(); } return; }
  if(a==='qz_tog'){ if(qz){ const L = qz[t.dataset.k], v = t.dataset.v, j = L.indexOf(v); if(j >= 0) L.splice(j, 1); else L.push(v);
    const o = t.dataset.k==='env' ? qz.pas : qz.env, k2 = o.indexOf(v); if(j < 0 && k2 >= 0) o.splice(k2, 1); render(); } return; }
  if(a==='qz_close'){ qzOpen = false; qz = null; qzMode = 'preparer'; render(); return; }
  if(a==='qz_open'){ qzMode = 'refaire'; qzOpen = true; qzInit(); tab = 'semaine'; render(); const qc = $('#qz_card'); if(qc) qc.scrollIntoView({block:'start'}); return; }
  if(a==='gm_save' || a==='gm_test'){ geminiSave(a==='gm_test'); return; }
  if(a==='gm_forget'){ arm(t, 'Confirmer : oublier la clé', () => { try{ localStorage.removeItem(GEM_KEY); }catch(e){} _GEMM = null; render(); }); return; }
  if(a==='fc_forget'){ arm(t, 'Confirmer : oublier le code', () => { try{ localStorage.removeItem(CODE_KEY); }catch(e){} _SPR = null; _CLES.clear(); render(); }); return; }
  if(a==='inst_hide'){ S.instHide = true; save(); render(); return; }
  if(a==='ck_cm'){ if(cook){ const k = t.dataset.k || 'b';
      if(cook.l){ const it = mlist(cook.l)[cook.i]; if(it){ it.cm = k; save(); render(); } } else cook.cm = k==='b' ? '' : k;
      renderCook(); const el = $('#cook'); if(el) el.scrollTop = 0; } return; }
  if(a==='resto'){ const td = isoToday(), w = t.dataset.m; let msg = '';
    if(w==='soir'){ const i = mlist('items').findIndex(x => x.d===td); if(i>=0) msg = reportTomorrow(i); }
    else if(w==='matin'){ const i = mlist('dej').findIndex(x => x.d===td); if(i>=0) msg = reportDej(i); }
    else msg = restoMidi(td);
    if(msg){ S.flash = msg; save(); render(); const fm = $('#flash'); if(fm){ fm.textContent = msg; fm.hidden = false; } window.scrollTo(0, 0); } return; }
  if(a==='ck_reset'){ if(cook){ const o = ckRead(); delete o[cook.ck||cook.key]; ckWrite(o); renderCook(); } return; }
  if(id==='pf_export'){ exportProfil(); return; }
  if(id==='frigo_share'){ partagerFrigo(); return; }
  if(id==='frigo'){ menuFrigo().catch(() => setSync("L'image n'a pas pu être créée.")); return; }
  if(id==='prep_week'){ if(prepBusy) return; if(S.menu.date && S.menu.start <= isoToday() && t.dataset.armed!=='1'){ arm(t, 'Confirmer : préparer la prochaine semaine', () => {}); return; } qzMode = 'preparer'; qzOpen = true; qzInit(); tab = 'semaine'; plusK = ''; render(); const qc = $('#qz_card'); if(qc) qc.scrollIntoView({block:'start'}); return; }
  if(id==='refaire'){ if(prepBusy) return; qzMode = 'refaire'; qzOpen = true; qz = null; qzInit(); tab = 'semaine'; plusK = ''; render(); const qc = $('#qz_card'); if(qc) qc.scrollIntoView({block:'start'}); return; }
  if(id==='prep_go'){ if(prepBusy || !qz) return;
    Object.assign(S.p, qz.n); S.p.nSr = Math.min(S.p.nSr||0, S.p.n||0); S.p.nCm = Math.min(S.p.nCm||0, Math.max(0, (S.p.n||0) - S.p.nSr)); S.p.budget = qz.budget || 0; S.qLast = {mix:qz.mix};
    QW = {temps:qz.temps, mix:qz.mix, env:qz.env.slice(), pas:qz.pas.slice()}; qzOpen = false; t.disabled = true;
    const garder = (qzMode==='refaire' || !!S.menu.eb) && !!S.menu.date; qzMode = 'preparer';
    preparerSemaine(true, garder).catch(e => setSync('Petit problème : ' + (e.message||'erreur'))).finally(() => { QW = null; qz = null; render(); }); return; }
  if(id==='eb_ok'){ ebaucheOk(); return; }
  if(id==='eb_redo'){ if(t.dataset.armed!=='1'){ arm(t, 'Confirmer : refaire (les plats gardés restent)', () => {}); return; } genMenu(); S.flash = 'Nouvelle ébauche.'; save(); render(); return; }
  if(id==='test_copy'){ arm(t, 'Confirmer : remplacer les données de test', () => { const msg = $('#test_msg'); try{ restoreFrom(localStorage.getItem(REAL_KEY), 'Vraies données copiées dans la version de test.'); profil(); appliquerProfil(); save(); render(); }catch(e){ if(msg){ msg.textContent = 'La copie a échoué : ' + (e.message||'erreur') + '. Rien n\'a été changé.'; msg.hidden = false; } } }); return; }
  if(id==='setup_done'){ profil(); appliquerProfil(); wiz = 0; S.setup = true; if(wizEss && !S.ess.length) S.ess = ESS_START(); save(); render(); window.scrollTo(0,0); return; }
  if(id==='ess_preset'){ S.ess = ESS_START(); save(); render(); return; }
  if(id==='gen'){ if(S.menu.date && t.dataset.armed!=='1'){ arm(t,'Confirmer', ()=>{}); return; } genMenu(); return; }
  if(id==='fab'){ plusK = 'menu'; plusFromMenu = false; render(); return; }
  if(id==='addbtn'){ const r = byName($('#addsel').value); if(r){ addToMenu(r); save(); render(); } return; }
  if(id==='fin'){ if(S.menu.start && S.menu.start > isoToday()) return; arm(t,'Confirmer : terminer la semaine', terminerSemaine); return; }
  if(id==='achete'){ arm(t, Object.values(S.menu.chk||{}).some(Boolean) ? 'Confirmer : épicerie terminée' : 'Rien de coché : confirmer quand même ?', epicerieFaite); return; }
  if(id==='spadd'){ ajouterSpeciaux(); return; }
  if(id==='spclr'){ S.spec = []; save(); render(); return; }
  if(id==='hclr'){ arm(t,'Confirmer', () => { S.hist = []; save(); render(); }); return; }
  if(id==='reset'){ arm(t,'Confirmer : tout effacer', () => { if(!snapshot('Avant la remise à zéro', JSON.stringify(S))){ setSync("Espace plein : enregistre d'abord une sauvegarde dans " + FICH + " (Profil)."); return; } S = DEFAULT(); S.appv = APPV; loadFailed = false; rescued = false; save(); render(); }); return; }
  if(id==='help_btn'||id==='help_open'){ if(tab!=='aide') aideFrom = tab; plusK = ''; tab='aide'; S.help=true; save(); render(); window.scrollTo(0,0); return; }
  if(id==='help_hide'){ S.help=true; save(); render(); return; }
  if(id==='help_back'){ tab = aideFrom && aideFrom!=='aide' ? aideFrom : 'semaine'; render(); window.scrollTo(0,0); return; }
  if(id==='sp_go'){ chercherSpeciaux(false); return; }
  if(id==='bfit'){ const n = budgetFit(); S.flash = n ? `${n} souper${n>1?'s':''} remplacé${n>1?'s':''} par ${n>1?'des plats moins chers':'un plat moins cher'}.` + (listTotals(buyList().rows).cost > (+S.p.budget||0) ? ' Le budget est encore dépassé : verrouille moins de plats, baisse les portions ou retire des articles.' : '') : "Aucun plat moins cher ne convient (plats verrouillés, déjà faits récemment ou exclus). Essaie de baisser les portions ou de retirer des articles."; save(); render(); const fm = $('#flash'); if(fm){ fm.textContent = S.flash; fm.hidden = false; } else setSync(S.flash); return; }
  if(id==='st_find'){ trouverEpiceries(); return; }
  if(id==='stx_add'){ const n = String(($('#stx_n')||{}).value||'').trim().replace(/\s+/g,' '); if(!n) { say($('#st_msg'), "Écris le nom de l'épicerie."); return; }
    const known = marchand(n) && STORES.includes(marchand(n)) ? marchand(n) : '';
    if(known){ if(!S.stores.includes(known)) S.stores.push(known); }
    else { S.storesx = S.storesx||[]; if(!S.storesx.some(s => norm(s)===norm(n))) S.storesx.push(n); if(!S.stores.includes(n)) S.stores.push(n); }
    save(); render(); say($('#st_msg'), known ? `${known} est déjà dans la liste : elle est maintenant cochée.` : `${n} ajoutée et cochée. Ses spéciaux seront lus si Flipp a sa circulaire pour ton code postal.`); return; }
  if(id==='nr_save'){ saveRecette(); return; }
  const mx = id.match(/^(x[mep]_)([lmd])_copy$/);
  if(mx){ copier(({l:texteListe,m:texteMenu,d:texteDetail})[mx[2]](), '#'+mx[1]+'msg'); return; }
  if(id==='ns_save'){ saveSide(); return; }
  if(id==='store_on'){ storeMode = true; lockScreen(true); render(); window.scrollTo(0,0); return; }
  if(id==='store_off'){ storeMode = false; lockScreen(false); render(); window.scrollTo(0,0); return; }
  if(id==='reel_go' || id==='inv_go'){ if(t.disabled) return;
    const type = id==='reel_go' ? 'recette' : 'inventaire', box = $(type==='recette' ? '#reel_msg' : '#inv_msg'), inp = $(type==='recette' ? '#reel_img' : '#inv_img');
    const extra = type==='recette' ? {lien:String(($('#reel_lien')||{}).value || '').trim().slice(0, 300), note:String(($('#reel_note')||{}).value || '').trim().slice(0, 300)} : {};
    t.disabled = true; if(box) box.textContent = 'Préparation des images…';
    robotEnvoyer(type, inp ? inp.files : [], extra).then(() => { render(); robotSuivre(type, type==='recette' ? 'reel' : 'inv'); })
      .catch(e => { t.disabled = false; const b2 = $(type==='recette' ? '#reel_msg' : '#inv_msg'); if(b2) b2.textContent = e.code ? e.message : 'L\'envoi a échoué (' + e.message + '). Vérifie la connexion et réessaie.'; });
    return; }
  if(id==='inv_add'){ let n = 0;
    (invRes || []).forEach(x => { if(!x.on || !(x.q > 0)) return; const k = keyOf(x.name, x.u), o = S.stock[k]; if(o) o.q = x.q; else S.stock[k] = {name:x.name, u:x.u, q:x.q, rayon:x.rayon, cat:''}; n++; });
    invRes = null; openPan.delete('inv'); save(); render(); const m = $('#inv_msg'); if(m) m.textContent = `${n} article${n>1?'s':''} mis à jour dans Maison.`; return; }
  if(id==='inv_copy'){ copier((invRes || []).filter(x => x.on).map(x => `${String(x.q).replace('.', ',')} ${x.u} ${x.name}`).join('\n'), '#inv_msg'); return; }
  if(id==='inv_clear'){ invRes = null; render(); return; }
  if(id==='imp_go'){ const txt = $('#imp_txt').value, res = importRecipes(txt);
    if(res.added || res.skipped){ if(res.added) save(); render(); const mm = $('#imp_msg');
      if(mm) mm.textContent = res.added ? `${res.added} recette${res.added>1?'s':''} importée${res.added>1?'s':''} : ${res.names.join(', ')}.` : 'Ces recettes sont déjà dans ta banque.'; return; }
    const w = parseWebRecipe(txt);
    if(!w){ const mm = $('#imp_msg'); if(mm) mm.textContent = "Aucune recette trouvée dans ce texte. Copie la recette au complet, avec la liste des ingrédients (un par ligne) et la préparation."; return; }
    webToDraft(w); plusK = 'nouvelle'; plusFromMenu = false; render();
    const box = document.querySelector('details[data-rec="__new"]'); if(box) box.scrollIntoView({block:'start'});
    drafts.new.note = `Recette lue : ${w.rows.length} ingrédient${w.rows.length>1?'s':''}${w.portions && w.k==='souper' ? `, ajustés de ${w.portions} à 6 portions` : ''}${w.unsure.length ? `. Quantité à vérifier : ${w.unsure.join(', ')}` : ''}. Vérifie les noms, les quantités, le genre et le temps, puis touche « Enregistrer la recette » en bas.`; render(); const box2 = document.querySelector('details[data-rec="__new"]'); if(box2) box2.scrollIntoView({block:'start'}); return; }
  if(id==='go_liste'){ tab='epicerie'; render(); window.scrollTo(0,0); return; }
  if(id==='bk_copy'){ copier(JSON.stringify(S), '#bk_msg').then(ok => { if(ok){ S.lastExport = isoToday(); save(); } }); return; }
  if(id==='bk_file'){ exportFile(); return; }
  if(id==='bk_send'){ exportFile('share'); return; }
  if(id==='bk_imp'){ arm(t,'Confirmer : remplacer mes données', () => {
      try{ restoreFrom($('#bk_txt').value, 'Copie restaurée. Tes données d\'avant sont gardées dans les copies automatiques.'); }
      catch(e){ const m = $('#bk_msg'); if(m && !e.shown) m.textContent = "Cette copie n'est pas valide. Rien n'a été changé."; t.dataset.armed='0'; t.textContent='Restaurer cette copie'; } }); return; }
  if(id==='bk_rescue'){ arm(t,'Confirmer : restaurer', () => { try{ restoreFrom(localStorage.getItem(RESCUE), 'Données restaurées.'); localStorage.removeItem(RESCUE); }catch(e){ const m = $('#bk_msg'); if(m) m.textContent = "Ces données n'ont pas pu être lues. Elles restent gardées."; } }); return; }
  if(id==='aadd'){
    const name = plain($('#an').value), am0 = $('#amsg'); let q = parseFloat(String($('#aq').value).replace(',','.')), u = $('#au').value;
    if(!name){ if(am0) am0.textContent = 'Choisis ou tape un aliment.'; return; }
    if(!(q>0)){ if(am0) am0.textContent = 'Indique une quantité plus grande que 0.'; return; }
    if((u==='g' || u==='ml') && q < 20 && t.dataset.sure!==String(q)+u){ t.dataset.sure = String(q)+u; if(am0) am0.textContent = `${String(q).replace('.',',')} ${u}, c'est très peu. Si tu voulais dire ${String(q).replace('.',',')} ${u==='g'?'kg':'L'} ou ${String(q).replace('.',',')} paquets, change l'unité. Sinon, touche encore « Ajouter à la maison ».`; return; }
    [q,u] = toBase(q,u); [q,u] = normQU(name,q,u);
    const k = keyOf(name,u); const o = S.stock[k];
    const cat = $('#acat').value; if(o){ o.q += q; if(cat) o.cat = cat; } else S.stock[k] = {name, u, q, rayon:$('#ar').value, cat};
    save(); render(); const am = $('#amsg'); if(am) am.textContent = name+' ajouté. La prochaine planification en tient compte.'; return;
  }
  if(!a) return;
  const i = +t.dataset.i;
  const ml = t.dataset.ml;
  if(ml){
    const L = mlist(ml), it = L[i]; if(!it) return;
    const r = byName(it.r);
    if(a==='mexing') e.preventDefault();
    if(a==='mcopy'){ copier(texteRecette(it,i,true), '#rmsg_'+ml+'_'+i); return; }
    if(a==='rep1' || a==='repw'){ const msg = a==='rep1' ? reportTomorrow(i) : reportWeek(i); S.flash = msg; save(); render(); const fm = $('#flash'); if(fm){ fm.textContent = msg; fm.hidden = !msg; } return; }
    if(a==='dinrest' || a==='dinno'){ const d = it.d; L.splice(i, 1); if(d){ if(a==='dinrest') delete (S.menu.dinCook||{})[d]; else (S.menu.dinNo = S.menu.dinNo||{})[d] = true; } save(); render(); return; }
    if(a==='malts'){ altKey = altKey===ml+'|'+i ? '' : ml+'|'+i; render(); return; }
    if(a==='mpick'){ const nr = byName(t.dataset.r); if(!nr) return; const others = L.filter((_,j) => j!==i); others.forEach(x => { if(x.after===it.r) delete x.after; });
      const ni = it.sr && kindOf(nr)==='soupe' ? mkSoupe(nr, usedSides(others)) : it.cm ? Object.assign(mkItem(nr, usedSides(others), pickVar(nr)), {cm:1}) : (ml==='items' || ml==='din') ? mkItem(nr, usedSides(others), pickVar(nr)) : Object.assign({r:nr.n, v:pickVar(nr)}, it.ro ? {ro:it.ro} : {}); if(it.d) ni.d = it.d; if(it.dfix) ni.dfix = true; if(it.pt) ni.pt = it.pt;
      L[i] = ni; altKey = ''; save(); render(); return; }
    if(a==='srback'){ S.flash = soupeACote(i); save(); render(); return; }
    if(a==='mlock') it.lock = !it.lock;
    else if(a==='mrm'){ L.splice(i,1); L.forEach(x => { if(x.after===it.r) delete x.after; }); }
    else if(a==='mswap' || a==='mdis'){
      if(a==='mdis') S.dis[it.r] = true;
      const d0 = it.d, keep = L.filter((_,j) => j!==i); keep.forEach(x => { if(x.after===it.r) delete x.after; });
      const nl = fill(L.length, keep, ml, new Set([it.r])); if(nl.length > keep.length && d0) nl[nl.length-1].d = d0; S.menu[ml] = nl; }
    else if(a==='mup' || a==='mdown'){ const v = a==='mup' ? 'up' : 'down', rt = S.rate[it.r] = S.rate[it.r] || {up:0, down:0};
      if(it.rt) rt[it.rt] = Math.max(0, rt[it.rt]-1); it.rt = it.rt===v ? '' : v; if(it.rt) rt[it.rt]++; }
    else if(a==='msetcm'){ it.cm = t.dataset.k || 'b'; }
    else if(a==='mexing'){ it.ex = it.ex||[]; const k = t.dataset.k, p = it.ex.indexOf(k); if(p>=0) it.ex.splice(p,1); else it.ex.push(k); }
    else if(a==='msetv'){
      const nv = +t.dataset.v; it.v = nv;
      if((ml==='items' || ml==='din') && r){ const old = it.ovr||{}, ov = variantSides(r,nv), used = usedSides(L.filter((_,j) => j!==i));
        ['f','v'].forEach(sl => { const key = sl==='f'?'sf':'sv'; if(sl in ov) it[key] = ov[sl]; else if(old[sl]) it[key] = chooseSide(r,sl,used); });
        it.ovr = {f:'f' in ov, v:'v' in ov}; }
    }
    else if(a==='mreroll' && r){ const used = usedSides(L.filter((_,j) => j!==i)), ov = it.sr ? {} : variantSides(r,it.v), rr = it.sr ? soupR(r) : r; delete it.man;
      it.sf = 'f' in ov ? ov.f : chooseSide(rr,'f',used); used.add(it.sf); it.sv = 'v' in ov ? ov.v : chooseSide(rr,'v',used); }
    if(ml==='items') assignDays(false);
    save(); render(); return;
  }
  if(a==='radd'){ pick = {q:'', r:t.dataset.r, v:+t.dataset.v||0}; openPan.add('pick'); plusK = 'plat'; plusFromMenu = false; render(); return; }
  if(a==='pk_pick'){ pick = {q:pick.q, r:t.dataset.r, v:+t.dataset.v||0, meal:pick.meal, d:pick.d}; render(); const pc = document.querySelector('details.pick'); if(pc) pc.scrollIntoView({block:'start'}); return; }
  if(a==='pk_cancel'){ pick = {q:'', r:'', v:0}; render(); return; }
  if(a==='pk_add'){ addPicked(); return; }
  if(a==='unrep'){ const x = (S.report||[]).splice(+t.dataset.j, 1)[0]; if(x){ const it = Object.assign({}, x, {lock:true}); mlist('items').push(it); assignDays(false); S.flash = `${x.r} est remis au menu de cette semaine.`; } save(); render(); return; }
  if(a==='oc_add'){ const r = byName(t.dataset.r); if(r){ const x = {r:r.n, v:+t.dataset.v||0}; if(kindOf(r)==='souper'){ const it = mkItem(r, new Set(), x.v); x.sf = it.sf; x.sv = it.sv; } occ().items.push(x); openPan.add('occ'); save(); render(); const oc = document.querySelector('details[data-pan=occ]'); if(oc) oc.scrollIntoView({block:'start'}); } return; }
  if(a==='occ_rm'){ occ().items.splice(+t.dataset.j, 1); save(); render(); return; }
  if(a==='occ_clear'){ occ().items = []; save(); render(); return; }
  if(a==='occ_copy'){ copier(occText(), '#occ_msg'); return; }
  if(a==='occ_menu'){ occToMenu(); save(); render(); window.scrollTo(0,0); return; }
  if(a==='sdis'){ S.sdis = S.sdis||{}; if(S.sdis[t.dataset.id]) delete S.sdis[t.dataset.id]; else S.sdis[t.dataset.id] = true; openRec.add('side|'+t.dataset.id); save(); render(); return; }
  if(a==='sdel2'){ arm(t, 'Confirmer', () => { S.sidesx = (S.sidesx||[]).filter(x => x.id!==t.dataset.id); save(); render(); }); return; }
  if(a==='bk_restore'){ const c = readCopies()[+t.dataset.j]; if(c) arm(t, 'Confirmer', () => { try{ restoreFrom(c.data, `Copie du ${new Date(c.d).toLocaleDateString('fr-CA', {day:'numeric', month:'long'})} restaurée.`); }catch(e){ const m = $('#bk_msg'); if(m && !e.shown) m.textContent = "Cette copie n'a pas pu être lue. Rien n'a été changé."; } }); return; }
  if(a==='bk_go'){ tab = 'compte'; render(); const c = document.getElementById('sauvegarde'); if(c) c.scrollIntoView({block:'start'}); return; }
  if(a==='bk_hide'){ bkBar = false; render(); return; }
  if(a==='bk_later'){ S.bkSnooze = addDays(isoToday(), 14); save(); render(); return; }
  if(a==='theme'){ S.p.theme = t.dataset.v; save(); render(); return; }
  if(a==='stx_rm'){ e.preventDefault(); const s = t.dataset.s; S.storesx = (S.storesx||[]).filter(x => x!==s); S.stores = S.stores.filter(x => x!==s); save(); render(); return; }
  if(a==='ar_go'){ e.preventDefault(); const b = t.dataset.b; tab = 'prixbudget'; pbSec = 'articles'; artF = {q:'', f:'week'}; openPan.add('art|'+b); render(); const d = document.querySelector(`details.art[data-b="${CSS.escape(b)}"]`); if(d) d.scrollIntoView({block:'start'}); return; }
  if(a==='plus_open'){ plusFromMenu = plusK==='menu' || (plusFromMenu && t.dataset.k!=='menu'); plusK = t.dataset.k; if(plusK==='menu') plusFromMenu = false; render(); const el = $('#plus'); if(el) el.scrollTop = 0; return; }
  if(a==='plus_close'){ plusK = ''; render(); return; }
  if(a==='view'){ if(t.dataset.pb) pbSec = t.dataset.pb; plusK = ''; tab = t.dataset.v; render(); window.scrollTo(0,0); return; }
  if(a==='pf_ok'){ if(S.profil) delete S.profil.verifier; save(); render(); return; }
  if(a==='pf_add'){ profil().membres.push(t.dataset.v==='adulte' ? {a:'adulte', ap:'normal', l:true} : {a:'enfant', age:10, ap:'normal', l:true}); appliquerProfil(); ajuster(); save(); render(); return; }
  if(a==='pf_rm'){ const P = profil(); if(P.membres.length > 1) P.membres.splice(+t.dataset.i, 1); appliquerProfil(); ajuster(); save(); render(); return; }
  if(a==='wiz'){ wiz = Math.max(0, Math.min(4, wiz + (+t.dataset.v||0))); if(wiz===3) appliquerProfil(); save(); render(); window.scrollTo(0,0); return; }
  if(a==='ar_f'){ artF.f = t.dataset.v; render(); return; }
  if(a==='ou_pick'){ e.preventDefault(); choisirEpiceries(String(t.dataset.v||'').split('|')); save(); render(); return; }
  if(a==='pe_maj'){ e.preventDefault(); t.disabled = true; const msg = $('#pe_msg'); if(msg){ msg.hidden = false; msg.textContent = 'Recherche du dernier relevé…'; }
    peFetch(true).then(() => { S.flash = ''; save(); render(); const m2 = $('#pe_msg'); if(m2){ m2.hidden = false; m2.textContent = peDate() ? `Prix à jour : relevé du ${fmtDate(peDate())}.` : 'Relevé reçu.'; } })
      .catch(() => { t.disabled = false; if(msg) msg.textContent = 'Le relevé n\'a pas pu être lu (connexion ?). Les prix déjà sur le téléphone restent.'; }); return; }
  if(a==='pm_go'){ e.preventDefault(); tab = 'prixbudget'; pbSec = 'prix'; artF.q = ''; render(); window.scrollTo(0,0); return; }
  if(a==='pb_sec'){ pbSec = t.dataset.v; render(); window.scrollTo(0,0); return; }
  if(a==='rf_k'){ rf.k = t.dataset.v; grpAll.clear(); render(); return; }
  if(a==='rf_more'){ grpAll.add(t.dataset.g); render(); return; }
  if(a==='rf_reset'){ Object.assign(rf, {pr:'', st:'', g:'pr', fast:false, mij:false, af:false, spec:false, aime:false, fav:false, dis:false}); render(); return; }
  if(a==='pm_snooze'){ pmaj().snooze = addDays(isoToday(), 7); save(); render(); return; }
  if(a==='pm_done'){ const p = pmaj(); p.d = isoToday(); delete p.snooze; save(); render(); const mm = $('#pm_msg'); if(mm){ mm.textContent = 'Prix à jour. Prochain rappel dans un mois.'; mm.hidden = false; } return; }
  if(a==='pm_reset'){ e.preventDefault(); if(S.bx) delete S.bx[t.dataset.k]; save(); render(); return; }
  if(a==='ar_unex'){ const b = t.dataset.b, A = (S.art||{})[b]; if(A) delete A.ex; openPan.add('art|'+b); save(); render(); return; }
  if(a==='ar_ex'){ const b = t.dataset.b, s = allSpec().find(x => spId(x)===t.dataset.id); if(s){ const A = (S.art||{})[b] || {}; artSet(b, {n:t.dataset.n, ex:[...new Set((A.ex||[]).concat(norm(s.t)))].slice(-60)}); if(S.menu.dsel && S.menu.dsel[b]===t.dataset.id) delete S.menu.dsel[b]; } openPan.add('art|'+b); save(); render(); return; }
  if(a==='ar_pick' || a==='ar_none' || a==='ar_auto' || a==='ar_spick'){ const b = t.dataset.b; S.menu.dsel = S.menu.dsel || {};
    if(a==='ar_none') S.menu.dsel[b] = 'none'; else if(a==='ar_auto') delete S.menu.dsel[b];
    else { S.menu.dsel[b] = t.dataset.id;
      if(a==='ar_spick' && t.dataset.v==='a'){ const s = allSpec().find(x => spId(x)===t.dataset.id); if(s){ const tk = toks(s.t, true).slice(0, 6), A = (S.art||{})[b] || {}; if(tk.length && !(A.learn||[]).some(x => x.join(' ')===tk.join(' '))) artSet(b, {n:t.dataset.n, learn:(A.learn||[]).concat([tk])}); } }
      delete artSq[b]; }
    openPan.add('art|'+b); save(); render(); return; }
  if(a==='ar_unlearn'){ e.preventDefault(); artSet(t.dataset.b, {learn:[]}); save(); render(); return; }
  if(a==='ar_reset'){ const b = t.dataset.b; delete (S.art||{})[b]; if(S.menu.dsel) delete S.menu.dsel[b]; delete (S.prices||{})[keyOf(t.dataset.n, t.dataset.u)]; save(); render(); return; }
  if(a==='goadd'){ const s = t.dataset.s; S.skip = (S.skip||[]).filter(x => x!==s); S.goSome = false; save(); render(); return; }
  if(a==='dincook'){ const d = t.dataset.d; S.menu.dinCook = Object.assign(S.menu.dinCook||{}, {[d]:true}); save(); render(); return; }
  if(a==='pk_meal'){ pick.meal = t.dataset.v; render(); return; }
  if(a==='avec_occ'){ avec.n = occ().n; avec.k = 'souper'; avec.all = false; openPan.add('avec'); plusK = ''; tab = 'semaine'; render(); const el = document.querySelector('details[data-pan=avec]'); if(el) el.scrollIntoView({block:'start'}); return; }
  if(a==='avec_cm'){ avec.cm = t.dataset.k || ''; render(); return; }
  if(a==='avec_pick'){ avec.r = t.dataset.r; avec.cm = ''; openPan.add('avec'); render(); const el = document.querySelector('details[data-pan=avec] .pk_sel'); if(el) el.scrollIntoView({block:'start'}); return; }
  if(a==='avec_clear'){ avec.r = ''; render(); const q = $('#avec_q'); if(q) q.focus(); return; }
  if(a==='avec_pair'){ avecPairToMenu([avec.r, t.dataset.r]); save(); render(); window.scrollTo(0, 0); return; }
  if(a==='avec_all'){ avec.all = !avec.all; render(); return; }
  if(a==='avec_menu'){ avecToMenu(t.dataset.r); save(); render(); window.scrollTo(0, 0); return; }
  if(a==='avec_sem'){ if(S.menu.date && t.dataset.armed!=='1'){ arm(t, 'Confirmer : remplacer le menu de la semaine', () => {}); return; } genMenuMaison(); window.scrollTo(0, 0); return; }
  if(a==='din_add'){ pick = {q:'', r:'', v:0, meal:'din', d:t.dataset.d}; openPan.add('pick'); plusK = 'plat'; plusFromMenu = false; render(); const pc = document.querySelector('#plus details.pick'); if(pc){ pc.scrollIntoView({block:'start'}); const q = $('#pk_q'); if(q) q.focus(); } return; }
  if(a==='aubadd'){ const s = allSpecAll().find(x => x.t===t.dataset.t); if(s){ S.menu.sn = S.menu.sn||[]; S.menu.sn.push({t:s.t, p:s.p, s:s.s, name:s.t, q:1, u:'un', r:guessRayon(s.t), src:'Réserves (aubaine)'}); save(); render(); } return; }
  if(a==='pr_edit'){ e.preventDefault(); prEdit = t.dataset.k; render(); const inp = document.querySelector('input.prin'); if(inp) inp.focus(); return; }
  if(a==='snadd'){ const s = allSpec().find(x => x.t===t.dataset.t); if(s){ S.menu.sn = S.menu.sn||[]; S.menu.sn.push({t:s.t, p:s.p, s:s.s, name:s.t, q:1, u:'un', r:guessRayon(s.t)}); save(); render(); } return; }
  if(a==='snrm'){ (S.menu.sn||[]).splice(+t.dataset.i, 1); save(); render(); return; }
  if(a==='ib_add' || a==='ib_rm'){ const d = drafts[t.dataset.ib]; if(d){ if(a==='ib_add') d.rows.push({n:'', q:'', u:'un', ray:''}); else { d.rows.splice(+t.dataset.j,1); if(!d.rows.length) d.rows.push({n:'', q:'', u:'un', ray:''}); } render(); } return; }
  if(a==='ib_pick'){ const d = drafts[t.dataset.ib], x = d && d.rows[+t.dataset.j], c = catFind(t.dataset.c); if(x && c){ x.n = c.n; x.u = c.u; x.ray = c.ray; const w = t.closest('.ibw'); w.querySelector('.ib_n').value = c.n; w.querySelector('.ib_u').value = c.u; w.querySelector('.sugg').innerHTML = ''; w.querySelector('.ib_rw').innerHTML = ''; w.querySelector('.ib_q').focus(); } return; }
  if(a==='an_pick'){ anFill(catFind(t.dataset.c)); const q = $('#aq'); if(q){ q.focus(); q.select(); } return; }
  if(a==='an_ray'){ anRay = anRay===t.dataset.r ? '' : t.dataset.r; openPan.add('an_browse'); renderMaison(); return; }
  if(a==='grp'){ S.p.grp = t.dataset.v; save(); render(); return; }
  if(a==='cmdmode'){ S.p.cmd = t.dataset.v==='1'; save(); render(); return; }
  if(a==='rayup'){ const o = rayOrder(), j = +t.dataset.j; if(j > 0){ [o[j-1], o[j]] = [o[j], o[j-1]]; profil().rayons = o; save(); render(); } return; }
  if(a==='rdis'){ const n = t.dataset.r; if(S.dis[n]) delete S.dis[n]; else S.dis[n] = true; save(); render(); return; }
  if(a==='vsave' || a==='vrm' || a==='vadd' || a==='vrestore' || a==='rsave' || a==='rreset'){
    const n = t.dataset.r, r = byName(n); if(!r) return;
    const before = varRows(r).map(x => x.v);   /* pour garder la bonne version aux plats déjà au menu */
    if(a==='vrestore'){ e.preventDefault(); delete S.vared[n]; delete S.vardel[n]; Object.keys(drafts).forEach(k => { if(k.startsWith('va|'+n+'|')) delete drafts[k]; }); }
    else if(a==='rsave'){ saveRecEdit(t); return; }
    else if(a==='rreset'){ delete S.redit[n]; delete drafts['edit|'+n]; }
    else if(a==='vrm'){ if(t.dataset.armed!=='1'){ arm(t,'Confirmer', ()=>{}); return; }
      const ix = +t.dataset.i; if(t.dataset.s==='b') (S.vardel[n] = S.vardel[n]||[]).push(ix); else S.varx[n].splice(ix,1); Object.keys(drafts).forEach(k => { if(k.startsWith('va|'+n+'|')) delete drafts[k]; }); }
    else { const key = t.dataset.key, res = varFromDraft(key); if(res.err){ say(t.closest('.vbox').querySelector('.ve_msg'), res.err); return; }
      const val = res.val;
      if(a==='vadd') (S.varx[n] = S.varx[n]||[]).push(val);
      else if(t.dataset.s==='b') (S.vared[n] = S.vared[n]||{})[+t.dataset.i] = val;
      else S.varx[n][+t.dataset.i] = val;
      delete drafts[key]; openPan.delete(key); }
    remapV(n, before, a); openRec.add(n); save(); render(); return;
  }
  if(a==='gorec'){ e.preventDefault(); plusK = 'nouvelle'; plusFromMenu = false; render(); }
  else if(a==='rshare2'){ const r = byName(t.dataset.r); const fx = x => x==='auto' ? '' : (x||''); copier(texteRecette({r:r.n, v:0, sf:fx(r.sf), sv:fx(r.sv)}, 0, true), '#rm2_'+t.dataset.x); }
  else if(a==='eat'){ const k = t.dataset.k; if(S.menu.useup[k]) delete S.menu.useup[k]; else S.menu.useup[k] = true; save(); render(); }
  else if(a==='addrec'){ const r = byName(t.dataset.r); if(r){ addToMenu(r); save(); render(); } }
  else if(a==='keepside'){ const o = S.stock[t.dataset.k]; if(o && !(S.sidesx||[]).some(s => norm(s.n)===norm(o.name))){ (S.sidesx = S.sidesx||[]).push({id:'x'+Date.now().toString(36), n:o.name, sl:o.cat, ty:['all'], i:[[Math.max(1,o.q), o.u, o.name, o.rayon||'épicerie']]}); save(); render(); const am = $('#amsg'); if(am) am.textContent = o.name+' est maintenant un accompagnement permanent (voir Recettes).'; } }
  else if(a==='fav'){ if(S.fav[t.dataset.r]) delete S.fav[t.dataset.r]; else S.fav[t.dataset.r] = true; openRec.add(t.dataset.r); save(); render(); }
  else if(a==='sdel'){ e.preventDefault(); arm(t, 'confirmer ?', () => { S.sidesx = (S.sidesx||[]).filter(x => x.id!==t.dataset.id); save(); render(); }); }
  else if(a==='rdel'){ arm(t,'Confirmer', () => { S.custom = S.custom.filter(r => r.n!==t.dataset.r); delete S.varx[t.dataset.r]; openRec.delete(t.dataset.r); save(); render(); }); }
  else if(a==='spdel'){ e.preventDefault(); S.spec.splice(i,1); save(); render(); }
  else if(a==='manque'){ const k = t.dataset.k; if(S.menu.extra[k]) delete S.menu.extra[k]; else S.menu.extra[k] = true; save(); render(); }
  else if(a==='stp' || a==='stm'){ const o = S.stock[t.dataset.k]; if(!o) return; o.q += (a==='stp'?1:-1)*stepOf(o.u); if(o.q<=0) delete S.stock[t.dataset.k]; save(); render(); }
  else if(a==='ladd'){ S[t.dataset.l].push({name:'', q:1, u:'un', r:'épicerie'}); save(); renderReglages(); }
  else if(a==='ldel'){ arm(t, 'Confirmer', () => { S[t.dataset.l].splice(i,1); save(); renderReglages(); }); }
});
document.addEventListener('change', e => {
  if(e.target && e.target.dataset && e.target.dataset.a==='goplan'){ S.p.goPlan = e.target.value; save(); render(); return; }
  if(e.target && e.target.dataset && e.target.dataset.a==='pe_mag'){ const t = e.target; S.pe = Object.assign(peSel(), {[t.dataset.ch]: t.value}); resetCaches(); save(); render(); return; }
  { const t0 = e.target; if(t0 && t0.dataset && t0.dataset.ib !== undefined && t0.dataset.j !== undefined){ const d0 = drafts[t0.dataset.ib], x0 = d0 && d0.rows && d0.rows[+t0.dataset.j]; if(x0 && x0.doute){ x0.doute = ''; const w0 = t0.closest('.ibw'); if(w0){ w0.classList.remove('doute'); const s0 = w0.querySelector('.dt'); if(s0) s0.remove(); } } } }
  const t = e.target;
  if(t.dataset.ck && cook){ const ck = cook.ck||cook.key, o = ckRead(), x = o[ck] = o[ck] || {c:{}}; x.ts = Date.now(); x.c = x.c || {};
    if(t.checked) x.c[t.dataset.ck] = 1; else delete x.c[t.dataset.ck]; ckWrite(o); ckProgress(); return; }
  if(bindDraft(t)) return;
  if(t.classList.contains('ib_u') || t.classList.contains('ib_ray')){ const d = drafts[t.dataset.ib], x = d && d.rows[+t.dataset.j]; if(x){ if(t.classList.contains('ib_u')) x.u = t.value; else x.ray = t.value; } return; }
  if(t.classList.contains('ib_n')){ const d = drafts[t.dataset.ib], x = d && d.rows[+t.dataset.j]; if(x){ x.n = t.value.trim(); const c = catFind(x.n), w = t.closest('.ibw');
      if(c){ x.ray = c.ray; if(!x.q){ x.u = c.u; w.querySelector('.ib_u').value = c.u; } w.querySelector('.ib_rw').innerHTML = ''; } else w.querySelector('.ib_rw').innerHTML = x.n ? rayPick(t.dataset.ib, +t.dataset.j, x) : ''; } return; }
  if(t.id==='an'){ anFill(catFind(t.value), true); return; }
  if(t.dataset.p){ S.p[t.dataset.p] = numIn(t.value); ajuster(); save(); render(); return; }
  if(t.dataset.ps){ S.p[t.dataset.ps] = t.value; if(t.dataset.ps==='main' && S.profil) profil().princ = t.value; save(); render(); return; }
  if(t.dataset.pg){   /* goût d'un membre : 1 à 5, ou rien */
    const m = profil().membres[+t.dataset.i]; if(!m) return; m.g = isObj(m.g) ? m.g : {};
    const v = +t.value; if(v >= 1 && v <= 5) m.g[t.dataset.pg] = v; else delete m.g[t.dataset.pg];
    save(); render(); return; }
  if(t.dataset.pf){   /* profil : membre de la famille ou épicerie principale */
    const P = profil(), f = t.dataset.pf;
    if(f==='princ'){ P.princ = t.value; S.p.main = t.value; }
    else { const m = P.membres[+t.dataset.i]; if(!m) return;
      if(f==='a') m.a = t.value==='adulte' ? 'adulte' : 'enfant';
      else if(f==='age'){ const v = parseInt(t.value, 10); m.age = v >= 0 && v < 25 ? v : m.age; }
      else if(f==='ap') m.ap = t.value;
      else if(f==='l') m.l = t.checked;
      else if(f==='nom'){ m.nom = String(t.value).trim().slice(0, 30); if(!m.nom) delete m.nom; }
      else if(f==='rx'){ m.rx = String(t.value).slice(0, 200); if(!m.rx.trim()) delete m.rx; } }
    appliquerProfil(); ajuster(); save(); render(); return; }
  if(t.dataset.pj){ profil().jours[t.dataset.pj] = Math.max(0, Math.min(6, +t.value || 0)); save(); render(); return; }
  if(t.dataset.pfb){ profil()[t.dataset.pfb] = t.checked; save(); render(); return; }
  if(t.id==='pf_file' && t.files && t.files.length){ const fr = new FileReader(); fr.onload = () => { const msg = $('#pf_msg'); try{ importProfil(String(fr.result)); const m2 = $('#pf_msg'); if(m2){ m2.textContent = 'Profil chargé. Tes données d\'avant sont gardées dans les copies automatiques.'; m2.hidden = false; } }catch(e){ if(msg){ msg.textContent = e.message==='espace' ? "Espace plein : enregistre d'abord une sauvegarde." : "Ce fichier n'est pas un profil valide. Rien n'a été changé."; msg.hidden = false; } } }; fr.readAsText(t.files[0]); t.value = ''; return; }
  if(t.dataset.pb){ S.p[t.dataset.pb] = t.checked; save(); render(); return; }
  if(t.dataset.off!==undefined){ const d = +t.dataset.off, o = new Set(S.p.off||[0,6]); if(t.checked) o.add(d); else o.delete(d); S.p.off = [...o]; save(); return; }
  if(t.id==='bk_pick' && t.files && t.files.length){
    const fs = [...t.files], read = f => new Promise(res => { const fr = new FileReader(); fr.onload = () => res(String(fr.result||'')); fr.onerror = () => res(''); fr.readAsText(f); });
    Promise.all(fs.map(read)).then(txts => {
      let best = null; txts.forEach((x, j) => { try{ const o = JSON.parse(x); if(o && o.menu && o.stock){ const ts = +o.maj || 0; if(!best || ts > best.ts) best = {x, ts, n:fs[j].name}; } }catch(e){} });
      const ta = $('#bk_txt'), m = $('#bk_msg');
      if(!best){ if(m) m.textContent = fs.length > 1 ? "Aucun de ces fichiers n'est une copie valide." : "Ce fichier n'est pas une copie valide."; return; }
      if(ta) ta.value = best.x;
      const quand = best.ts ? ` (enregistrée le ${new Date(best.ts).toLocaleString('fr-CA', {day:'numeric', month:'long', hour:'2-digit', minute:'2-digit'})})` : '';
      if(m) m.textContent = (fs.length > 1 ? `${fs.length} fichiers lus. La plus récente : ${best.n}${quand}.` : `Fichier lu${quand}.`) + ' Touche « Restaurer cette copie » pour confirmer.';
    }); return; }
  if(t.dataset.a==='pr_in'){ const v = parseFloat(String(t.value).replace(',','.').replace(/[^0-9.]/g,'')), r = buyList().rows.find(x => x.k===t.dataset.k);
    if(r && v > 0){ S.prices = S.prices||{}; S.prices[r.k] = {pu: v/r.buy, d: isoToday(), s: storeOf(r), sp: !!dealFor(r.name)}; }
    prEdit = ''; save(); render(); return; }
  if(t.dataset.a==='pk_v'){ pick.v = +t.value; return; }
  if(t.dataset.a==='occ_n'){ occ().n = +t.value; save(); render(); return; }
  if(t.dataset.inv !== undefined && invRes){ const x = invRes[+t.dataset.inv]; if(x){ x.on = t.checked; const b = $('#inv_add'); if(b) b.textContent = `Mettre à jour Maison (${invRes.filter(y => y.on).length})`; } return; }
  if(t.dataset.invq !== undefined && invRes){ const x = invRes[+t.dataset.invq], v = parseFloat(String(t.value).replace(',', '.')); if(x && v >= 0) x.q = v; return; }
  if(t.dataset.invu !== undefined && invRes){ const x = invRes[+t.dataset.invu]; if(x) x.u = t.value; return; }
  if(t.dataset.a==='avec_n'){ avec.n = +t.value; openPan.add('avec'); render(); return; }
  if(t.dataset.a==='avec_k'){ avec.k = t.value; avec.all = false; openPan.add('avec'); render(); return; }
  if(t.dataset.a==='occ_home'){ occ().home = t.checked; save(); render(); return; }
  if(t.dataset.a==='xro' || t.dataset.a==='xday'){ const l = t.dataset.ml, L = mlist(l), it = L[+t.dataset.i]; if(!it) return;
    if(t.dataset.a==='xday'){ const o = L.find(x => x!==it && x.d===t.value); if(o){ if(it.d) o.d = it.d; else delete o.d; } if(t.value){ it.d = t.value; it.dfix = true; } else { delete it.d; delete it.dfix; } }
    else if(t.value==='repas'){ S.flash = soupeEnRepas(l, +t.dataset.i); }
    else { it.ro = t.value; delete it.dfix; if(it.ro==='lunch' || it.ro==='libre') delete it.d; assignExtras(false); }
    save(); render(); return; }
  if(t.dataset.qn){ if(qz){ qz.n[t.dataset.qn] = +t.value || 0; if(qz.n.nSr > qz.n.n) qz.n.nSr = qz.n.n; if(qz.n.nCm > qz.n.n - qz.n.nSr) qz.n.nCm = Math.max(0, qz.n.n - qz.n.nSr); } return; }
  if(t.dataset.qb){ if(qz) qz.budget = numIn(t.value); return; }
  if(t.dataset.a==='p2sel'){ const it = mlist(t.dataset.ml)[+t.dataset.i]; if(it){ it.p2 = t.value; save(); render(); } return; }
  if(t.dataset.a==='msauce'){ const it = mlist(t.dataset.ml)[+t.dataset.i]; if(it){ if(t.value) it.sc = t.value; else delete it.sc; save(); render(); } return; }
  if(t.dataset.a==='rside'){ setRecSide(t.dataset.r, t.dataset.s, t.value); return; }
  if(t.dataset.a==='mday'){ const L = mlist(t.dataset.ml||'items'), it = L[+t.dataset.i]; if(it){ const nd = t.value, other = L.find(x => x!==it && x.d===nd); if(other){ if(it.d) other.d = it.d; else delete other.d; } if(nd){ it.d = nd; it.dfix = true; } else delete it.d; save(); render(); } return; }
  if(t.dataset.prep !== undefined){ S.menu.prep = Object.assign({}, S.menu.prep, {[t.dataset.prep]: t.checked}); save(); return; }
  if(t.id==='paid'){ S.menu.paid = parseFloat(String(t.value).replace(',','.')) || 0; save(); return; }
  if(t.classList.contains('ar_in')){ const b = t.dataset.b, k = t.dataset.k, n = t.dataset.n, u = t.dataset.u, v = String(t.value).trim();
    if(k==='kw' || k==='no' || k==='ray') artSet(b, {n, [k]: v});
    else if(k==='pkq' || k==='pku'){ const box = t.closest('.rbody'), q = parseFloat(String(box.querySelector('[data-k=pkq]').value).replace(',', '.')), pu = box.querySelector('[data-k=pku]').value; artSet(b, {n, pk: q > 0 ? {q: pu==='un' ? Math.round(q) : q, u: pu} : null}); }
    else if(k==='pu'){ const x = parseFloat(v.replace(',', '.').replace(/[^0-9.]/g, '')), key = keyOf(n, u); S.prices = S.prices || {};
      if(x > 0) S.prices[key] = {pu: u==='un' ? x : x/1000, d: isoToday(), s:'', sp:false}; else delete S.prices[key]; }
    openPan.add('art|'+b); save(); render(); return; }
  if(t.dataset.a==='gomode'){ const v = t.value;
    if(v==='+') S.goSome = true;
    else { S.goSome = false; S.skip = v==='*' ? [] : S.stores.filter(s => s!==v);
      if(S.menu.date && !S.menu.achete) S.flash = v==='*' ? "Cette semaine : toutes tes épiceries. La liste et les prix sont à jour; touche « Refaire le menu » pour profiter de tous leurs spéciaux (les plats gardés restent)."
        : `Cette semaine : seulement ${v}. La liste, les prix et les aubaines viennent maintenant de ${v}. Touche « Refaire le menu » pour choisir les plats selon ses spéciaux (les plats gardés restent).`; }
    save(); render(); return; }
  if(t.dataset.go){ const s = t.dataset.go, sk = new Set(S.skip||[]); if(t.checked) sk.delete(s); else sk.add(s); S.skip = [...sk]; save(); render(); return; }
  if(t.dataset.store){ const s = t.dataset.store; S.stores = t.checked ? [...new Set(S.stores.concat(s))] : S.stores.filter(x => x!==s);
    if(t.checked && !STORES.includes(s)){ S.storesx = S.storesx||[]; if(!S.storesx.includes(s)) S.storesx.push(s); } save(); return; }
  if(t.dataset.cp){ S.cp = t.value.trim().toUpperCase(); save(); return; }
  if(t.dataset.rf){ rf[t.dataset.rf] = t.type==='checkbox' ? t.checked : t.value; renderRecettes(); return; }
  if(t.dataset.a==='chk'){
    if(t.checked) S.menu.chk[t.dataset.k]=true; else delete S.menu.chk[t.dataset.k];
    const it = t.closest('.item'); if(it) it.classList.toggle('done', t.checked);
    const rows = buyList().rows, done = rows.filter(r => S.menu.chk[r.k]).length;
    const pt = $('#pg-t'), pb = $('#pg-b'); if(pt) pt.textContent = `${done} sur ${rows.length} dans le panier`; if(pb) pb.style.width = (rows.length?done/rows.length*100:0)+'%';
    const bg = $('#bgl'); const n = rows.length-done; bg.hidden = !n; bg.textContent = n;
    save();
    if(storeMode){ const y = window.scrollY; renderEpicerie(); window.scrollTo(0, y); }
    return;
  }
  if(t.dataset.a==='sidesel'){ const it = mlist(t.dataset.ml||'items')[+t.dataset.i]; if(!it) return; it[t.dataset.s==='f'?'sf':'sv'] = t.value; it.ovr = Object.assign({}, it.ovr, {[t.dataset.s]:false}); it.man = Object.assign({}, it.man, {[t.dataset.s]:1}); save(); render(); return; }
  if(t.dataset.a==='stcat'){ const o = S.stock[t.dataset.k]; if(o){ o.cat = t.value; save(); render(); } return; }
  if(t.dataset.a==='tmsel'){ S.tmx[t.dataset.r] = +t.value; openRec.add(t.dataset.r); save(); render(); return; }
  if(t.dataset.a==='tpsel'){ (S.tpx = S.tpx||{})[t.dataset.r] = +t.value; openRec.add(t.dataset.r); save(); render(); return; }
  if(t.dataset.a==='sideq'){ const it = mlist(t.dataset.ml||'items')[+t.dataset.i]; if(it) it[t.dataset.s==='f'?'fm':'vm'] = parseFloat(t.value); save(); render(); return; }
  if(t.dataset.a==='portions'){ const it = mlist(t.dataset.ml||'items')[+t.dataset.i]; if(it){ if(+t.value) it.pt = +t.value; else delete it.pt; } save(); render(); return; }
  if(t.dataset.a==='stq'){ const o = S.stock[t.dataset.k]; const raw = String(t.value).trim(), v = parseFloat(raw.replace(/\s/g,'').replace(',','.')); if(o){ if(raw!=='' && isNaN(v)){ render(); return; } if(v>0) o.q = v; else delete S.stock[t.dataset.k]; save(); render(); } return; }
  if(t.dataset.l){ const row = S[t.dataset.l][+t.dataset.i]; if(!row) return; const f = t.dataset.f; row[f] = f==='q' ? numIn(t.value) : t.value; save(); return; }
  if(t.id==='d_plan'){ S.dates.plan = t.value; save(); return; }
  if(t.id==='d_shop'){ S.dates.shop = t.value; S.dates.man = !!t.value; save(); render(); return; }
  if(t.id==='relay_in'){ S.relay = t.value.trim(); save(); return; }
  if(t.id==='p_cool'){ S.p.cool = +t.value; save(); }
  if(t.classList && t.classList.contains('pm_in')){   /* prix inscrit dans « Mise à jour des prix » */
    const k = t.dataset.k, raw = String(t.value).trim(), v = parseFloat(raw.replace(/[\s$]/g,'').replace(',','.'));
    if(raw && !(v > 0 && v < 1000)){ t.value = ''; return; }
    S.bx = isObj(S.bx) ? S.bx : {}; const o = S.bx[k] = Object.assign({}, S.bx[k]);
    if(t.dataset.kg) { if(raw) o.kg = v; else delete o.kg; }
    else { o.f = Array.isArray(o.f) ? o.f : []; o.f[+t.dataset.i] = raw ? v : null; if(!o.f.some(x => x > 0)) delete o.f; }
    if(o.f || o.kg) o.d = isoToday(); else delete S.bx[k];
    save(); return; }
  if(t.id==='pm_pct'){ const v = parseFloat(String(t.value).replace(/[\s%]/g,'').replace(',','.')); pmaj().pct = isFinite(v) ? Math.max(-50, Math.min(100, v)) : 0; save(); render(); return; }
  if(t.id==='su_ess'){ wizEss = t.checked; return; }
  if(t.id==='pm_rappel'){ pmaj().rappel = t.checked; save(); return; }
  else if(t.id==='p_var'){ S.p.varMode = t.value; save(); }
  else if(t.id==='p_sou'){ S.p.souper = +t.value; save(); render(); }
  else if(t.id==='p_res'){ S.p.restes = +t.value; save(); render(); }
  else if(t.id==='p_tm'){ S.p.maxTm = +t.value; save(); }
  else if(t.id==='p_lg'){ S.p.nLong = +t.value; save(); }
  else if(t.id==='p_j'){ S.p.jours = +t.value; save(); }
  else if(t.id==='maison'){ S.maison = t.value; save(); }
});
document.addEventListener('toggle', e => { const d = e.target;
  if(d.dataset && d.dataset.ray !== undefined){ if(d.open) rayFerme.delete(d.dataset.ray); else rayFerme.add(d.dataset.ray); return; }
  if(d.dataset && d.dataset.pan){ const k = d.dataset.pan, was = openPan.has(k); if(d.open){ openPan.add(k); if(!was && /^art\|/.test(k) && !d.querySelector('.rbody')){ renderArticles(); return; } if(!was && !d.querySelector('.vbox,.rbox') && /^(va|vn|edit)\|/.test(k)) renderRecettes(); } else openPan.delete(k); return; }
  if(d.dataset && d.dataset.rec){ if(d.open){ const lazy = d.dataset.lazy && !openRec.has(d.dataset.rec); openRec.add(d.dataset.rec); if(lazy) renderRecettes(); } else openRec.delete(d.dataset.rec); } }, true);
document.addEventListener('input', e => {
  const t = e.target;
  if(bindDraft(t)) return;
  if(t.classList.contains('ib_q')){ const d = drafts[t.dataset.ib], x = d && d.rows[+t.dataset.j]; if(x) x.q = t.value; return; }
  if(t.classList.contains('ib_n')){ const d = drafts[t.dataset.ib], x = d && d.rows[+t.dataset.j]; if(!x) return; x.n = t.value;
    t.closest('.ibw').querySelector('.sugg').innerHTML = sugBtns(catSearch(t.value), `data-a="ib_pick" data-ib="${esc(t.dataset.ib)}" data-j="${t.dataset.j}"`); return; }
  if(t.id==='avec_q'){ const box = $('#avec_res'); if(box) box.innerHTML = pickSearch(t.value).filter(x => kindOf(x.r)!=='sauce').slice(0, 6).map(x => `<div class="item"><span class="t"><b>${esc(x.r.n)}</b><small>${esc([KIND1[kindOf(x.r)] || '', methods(x.r).length ? 'aussi : '+methods(x.r).slice(1).map(m => m.l.toLowerCase()).join(', ') : ''].filter(Boolean).join(' · '))}</small></span><button class="btn s" data-a="avec_pick" data-r="${esc(x.r.n)}">Choisir</button></div>`).join(''); return; }
  if(t.id==='oc_q'){ const box = $('#oc_res'); if(box) box.innerHTML = pickSearch(t.value).filter(x => kindOf(x.r)!=='sauce').map(x => { const vs = vars(x.r); return `<div class="item"><span class="t"><b>${esc(x.r.n)}</b><small>${esc([KIND1[kindOf(x.r)], x.v ? 'version '+vname(vs[x.v-1][0]).toLowerCase() : ''].filter(Boolean).join(' · '))}</small></span><button class="btn s" data-a="oc_add" data-r="${esc(x.r.n)}" data-v="${x.v}">Ajouter</button></div>`; }).join(''); return; }
  if(t.classList.contains('ar_sq')){ const b = t.dataset.b; artSq[b] = t.value; const box = document.querySelector(`.ar_sr[data-b="${CSS.escape(b)}"]`); if(box) box.innerHTML = artSearchRows(b, t.value); return; }
  if(['cv_q','cv_u','cv_i'].includes(t.id)){ cv[t.id.slice(3)] = t.value; const o = $('#cv_out'); if(o) o.innerHTML = convOut(); return; }
  if(t.id==='cvp_q' || t.id==='cvp_u'){ cv[t.id==='cvp_q' ? 'pq' : 'pu'] = t.value; const o = $('#cvp_out'); if(o) o.innerHTML = convPrix(); return; }
  if(t.id==='ar_q'){ artF.q = t.value; const pos = t.selectionStart; renderView(); const f = $('#ar_q'); if(f){ f.focus(); f.setSelectionRange(pos, pos); } return; }
  if(t.id==='pk_q'){ pick.q = t.value; pick.msg = ''; const box = $('#pk_res'); if(box) box.innerHTML = pickRows(t.value); return; }
  if(t.id==='an'){ const box = $('#an_sugg'); if(box) box.innerHTML = sugBtns(catSearch(t.value, 8), 'data-a="an_pick"'); return; }
});
document.addEventListener('input', e => { if(e.target.id!=='aide_q') return; const q = norm(e.target.value).trim(); let n = 0;
  document.querySelectorAll('#tab-profil details.help').forEach(d => { const hit = !q || norm(d.textContent).includes(q); d.hidden = !hit; if(q) d.open = hit; if(hit) n++; });
  const none = $('#aide_none'); if(none) none.hidden = !q || n > 0; });
document.addEventListener('keydown', e => { if(e.key==='Escape' && plusK){ plusK = ''; render(); } });
document.addEventListener('input', e => { if(e.target.id==='rfilt'){ rf.q = e.target.value; const pos = e.target.selectionStart; renderRecettes(); const f = $('#rfilt'); f.focus(); f.setSelectionRange(pos,pos); return; } });
document.addEventListener('input', e => { if(e.target.id==='filt'){ filtre = e.target.value; const pos = e.target.selectionStart; renderMaison(); const f = $('#filt'); f.focus(); f.setSelectionRange(pos,pos); } });


/* ---------- aide ---------- */
function renderAide(){
  const go = (lbl, v, x) => `<button class="btn s p" data-a="view" data-v="${v}" ${x||''}>${lbl}</button>`, gp = (lbl, k) => `<button class="btn s p" data-a="plus_open" data-k="${k}">${lbl}</button>`;
  const GO = {'Première configuration':go('Ouvrir Profil → Famille','famille'), 'Ta semaine en 4 étapes':go("Ouvrir Aujourd'hui",'semaine'),
    'Faire le menu de la semaine':go('Ouvrir le menu','menu') + gp('Ajouter un plat','plat'), "Les jours de la semaine et l'onglet Aujourd'hui":go('Ouvrir Profil → Famille','famille'),
    'Déjeuners, dîners et restes':go('Ouvrir le menu','menu'), 'Plats préparés, collations, entrées et desserts':go('Ouvrir le menu','menu'), 'Après le repas : on a aimé ou pas':go('Ouvrir le menu','menu'),
    "L'inventaire : ce qu'il y a à la maison":go('Ouvrir Maison','maison') + gp('Photo du frigo','frigo'), "Faire l'épicerie une seule fois":go('Ouvrir la liste','epicerie'),
    'Terminer la semaine':go('Ouvrir le menu','menu'), 'Partager, envoyer et importer':gp('Partager','partager') + gp('Coller une recette','coller'),
    'La banque de recettes':go('Ouvrir Recettes','recettes'), 'Reels et photos du frigo, avec ton Gemini':gp('Importer un reel','reel') + go('Ma clé Gemini','compte'),
    'Les goûts de chacun':go('Ouvrir Profil → Famille','famille'), 'Si la recherche des spéciaux ne fonctionne pas':go('Code de la famille','compte') + go('Ouvrir le menu','menu'),
    'Sauvegarder':go('Ouvrir Profil → Compte','compte'), 'Articles : corriger un spécial, convertir une mesure':go('Ouvrir les articles','prixbudget','data-pb="articles"')};
  let k = 0;
  const D = (t, body, open) => `<details class="card help" ${open?'open':''}><summary>${++k}. ${t}</summary>${body}${GO[t] ? `<div class="acts">${GO[t]}</div>` : ''}</details>`;
  $('#tab-profil').innerHTML = `<button class="btn" id="help_back">← Retour</button>
  <div class="card"><input type="search" id="aide_q" placeholder="Comment faire… (reel, budget, sauvegarde)" aria-label="Chercher dans l'aide" autocomplete="off"><p class="small" id="aide_none" hidden>Rien trouvé. Essaie un autre mot : liste, menu, recette, prix…</p></div>
  <div class="card"><h3>À quoi sert cette application</h3><p>Elle planifie les déjeuners, les dîners, les soupers, les entrées, les soupes et les desserts de la semaine, tient compte des spéciaux de tes épiceries et de ce qu'il y a déjà à la maison, et produit <b>une seule liste d'épicerie complète</b>. Tes données restent sur ton téléphone.</p></div>`
  + D("Installer l'application", (() => {
    const ios = `<p><b>Sur iPhone</b></p><ol><li>Ouvre l'adresse de l'application dans <b>Safari</b> (pas dans Messenger ni une autre application).</li>
    <li>Touche <b>Partager</b> (le carré avec une flèche vers le haut), fais défiler la liste d'actions jusqu'à <b>Sur l'écran d'accueil</b>, puis touche <b>Ajouter</b>.</li>
    <li>Ouvre toujours l'application par <b>son icône</b>.</li></ol>
    <div class="warn"><b>Sur iPhone, installe avant d'entrer quoi que ce soit.</b> Safari et l'icône de l'écran d'accueil ne partagent pas leurs données.</div>`;
    const and = `<p><b>Sur Android</b></p><ol><li>Ouvre l'adresse de l'application dans <b>Chrome</b> (pas dans Messenger ni une autre application).</li>
    <li>Touche le menu <b>⋮</b> en haut à droite, puis <b>Installer l'application</b> (ou <b>Ajouter à l'écran d'accueil</b>, puis <b>Installer</b>).</li>
    <li>Ouvre ensuite l'application par <b>son icône</b>. Ce que tu as déjà entré dans Chrome s'y retrouve.</li></ol>
    <p class="small">Avec un autre navigateur (Samsung Internet, Firefox), cherche « Ajouter à l'écran d'accueil » dans son menu, et ouvre toujours l'application par le même chemin : chaque navigateur garde ses propres données.</p>`;
    const now = isInstalled() ? '<p class="note">L\'application est installée sur ce téléphone.</p>' : instBtn() ? `<div class="acts">${instBtn()}</div>` : '';
    return now + (ANDROID ? and + ios : ios + and); })() + `
    <div class="tip">Chaque personne installe l'application sur son téléphone. Les données ne sont pas partagées entre téléphones (voir « Partager, envoyer et importer »).</div>`, true)
  + D('Première configuration', `<p>Au premier lancement, un assistant en 5 étapes décrit ta famille :</p>
    <ul><li><b>La famille</b> : adultes et enfants (avec leur âge), l'appétit de chacun et qui apporte un lunch. Les portions et les restes pour les lunchs en découlent.</li>
    <li><b>L'horaire</b> : le jour où tu planifies, où tu commandes, où tu ramasses l'épicerie et où vous commencez à cuisiner.</li>
    <li><b>Les épiceries</b> : ton code postal, celles où tu vas et ta principale. Avant chaque semaine, tu choisis où faire l'épicerie : à la principale, dans une autre, ou « où ce sera le moins cher » (l'application choisit).</li>
    <li><b>Les repas</b> à planifier et, si tu veux, une liste de départ pour les déjeuners, lunchs, collations et boissons.</li>
    <li><b>Le budget</b> de la semaine.</li></ul>
    <p>Tout se change ensuite dans l'onglet <b>Profil</b>. Le profil peut être enregistré dans ${FICH} (Profil → Compte) pour le réinstaller ou le donner à un proche.</p>`)
  + D('Ta semaine en 4 étapes', `<ol><li><b>Planifier</b> (mercredi soir ou jeudi) : dans <b>Aujourd'hui</b>, touche <b>Préparer ma semaine</b>. Quelques questions déjà remplies (combien de soupers, de soupes et d'entrées, le temps pour cuisiner, les envies, les protéines), puis <b>Voir l'ébauche du menu</b>. L'application lit les circulaires pour la date du ramassage et propose une ébauche variée qui en profite. Réponds à ses questions (2e protéine, accompagnement de la soupe-repas, rôle des entrées), touche <b>Changer</b> pour un plat qui ne te plaît pas, puis <b>Bâtir le menu final et la liste</b>.</li>
    <li><b>Commander</b> : Épicerie → <b>Commande en ligne</b>. Chaque article a un lien vers le site de l'épicerie et le format à commander. Ouvre-le, ajoute au panier, reviens et coche.</li>
    <li><b>Ramasser</b> : touche « Épicerie terminée », puis inscris le total de la facture. Après quelques semaines, l'estimation du coût se corrige d'elle-même.</li>
    <li><b>Cuisiner</b> : la carte <b>Préparation</b> regroupe ce qui se fait d'avance (hacher, cuire le riz, mariner, congeler). Chaque soir, la carte <b>Aujourd'hui</b> montre le repas et le bouton Cuisiner.</li></ol>
    <div class="tip">Les poissons et la viande hachée sont placés en début de semaine, les plats du congélateur et du garde-manger à la fin.</div>`)
  + D('Faire le menu de la semaine', `<ol>
    <li>Les dates (<b>Je planifie le</b>, <b>J'achète le</b>) sont dans Menu → <b>Spéciaux et dates</b>. Les spéciaux retenus sont ceux valides le jour de l'épicerie.</li>
    <li><b>Où faire l'épicerie</b> : dans le questionnaire de la semaine, choisis <b>Cette semaine, l'épicerie se fait…</b>. Le menu se bâtit avec les spéciaux de cette épicerie seulement. Avec <b>Où ce sera le moins cher</b>, le menu profite des spéciaux de toutes tes épiceries, puis l'application compare le coût de la liste partout et choisit la moins chère. Après coup, Épicerie → <b>Où faire l'épicerie</b> → « Choisir » change ce choix. La liste complète de tes épiceries se change dans Profil → Épiceries.</li>
    <li>Une envie précise ? Bouton <b>+</b> → <b>Ajouter un plat au menu</b> : cherche un plat, une version ou un ingrédient (burger Nashville, saumon, potage), puis choisis le jour. Le plat reste au menu quand tu le refais. Tu peux le faire avant de créer le menu : l'application complète le reste. Dans Recettes, le bouton <b>Ajouter au menu de la semaine</b> fait la même chose.</li>
    <li><b>Reporter un souper</b> : resto ou changement de plan ? Ouvre le plat, touche <b>Reporter</b> : « À demain » fait glisser les soupers suivants d'un jour jusqu'au prochain soir libre; « À la semaine prochaine » le met de côté, il sera déjà au menu de la semaine suivante et ses ingrédients restent dans Maison. La carte Aujourd'hui a aussi « On mange au resto : reporter à demain ».</li>
    <li><b>Portions</b> : ouvre un plat et choisis le nombre de portions (2 pour un souper à deux, 12 quand on reçoit). La liste d'épicerie s'ajuste.</li>
    <li>Bouton <b>+</b> → <b>Je reçois ou repas à deux</b> : choisis des plats et le nombre de personnes. L'application fait une liste d'épicerie juste pour ce repas, que tu peux copier pour une course de dernière minute, ou mettre au menu un soir de la semaine.</li>
    <li><b>Préparer ma semaine</b> cherche les spéciaux et bâtit le menu. Les plats sont choisis selon les spéciaux, ce qui est déjà à la maison, tes favoris et le temps de préparation, sans répéter les plats récents ni ceux mis de côté.</li>
    <li>Le nombre de déjeuners, dîners, soupers, entrées, soupes et desserts se choisit dans le questionnaire. Menu → <b>Refaire le menu</b> le rouvre avec tes réponses : les plats gardés restent.</li>
    <li>Sur chaque souper, ouvre <b>Accompagnements</b> pour choisir le féculent et le légume ou salade, leur quantité (Aucun, Moins, Normal, Plus, Double) et les portions du repas.</li>
    <li>Les pastilles <b>Normale, Épicée…</b> changent la version. Le détail de la version (ingrédients ajoutés ou retirés, préparation) s'affiche dessous.</li>
    <li><b>Garder</b> verrouille un plat, <b>Autre plat</b> le remplace. Le bouton <b>Plus</b> contient <b>Copier la recette</b>, <b>Je n'aime pas</b> (le plat est mis de côté pour de bon et remplacé) et <b>Retirer du menu</b>. Dans « Recette et ingrédients », « retirer » enlève un ingrédient de la liste.</li>
    <li>Les étiquettes jaunes montrent les spéciaux trouvés dans tes circulaires : produit, prix et magasin.</li>
    <li>Chaque souper a un <b>jour</b> (en haut de sa carte). Touche-le pour déplacer le plat; l'autre plat prévu ce jour-là prend sa place.</li></ol>`)
  + D("Les jours de la semaine et l'onglet Aujourd'hui", `<ul><li>Dans Profil → Famille, coche tes <b>jours de congé</b>. Les soupers plus longs y sont placés; les jours de travail reçoivent les plats rapides (<b>Temps max. en semaine</b>, 35 min par défaut).</li>
    <li>Les plats « à la mijoteuse » se préparent le matin en 15 minutes : ils vont bien un jour de travail.</li>
    <li>L'onglet <b>Aujourd'hui</b> montre le déjeuner, le dîner et le souper du jour, celui de demain, avec les rappels : sortir la viande du congélateur la veille, partir la mijoteuse le matin, garder des restes.</li>
    <li><b>Cuisiner</b> ouvre la recette en grand : ingrédients pour tes portions (avec la sauce et les accompagnements) et étapes à cocher. L'écran reste allumé. Sur chaque plat du menu, <b>Recette</b> ouvre la même vue pour y jeter un coup d'œil pendant la planification.</li></ul>`)
  + D('Déjeuners, dîners et restes', `<ul><li><b>Déjeuners</b> : ils ont leur section dans Recettes (crêpes, galettes de sarrasin, pain doré, déjeuner de cabane, gruau de nuit…). Les plus longs vont aux jours de congé. Les céréales, rôties et cafés de tous les jours restent dans la liste « Déjeuners, lunchs » de Profil.</li>
    <li><b>Dîners</b> : chaque souper est cuisiné avec des portions de plus (Profil → Famille, « Portions de restes »). Le midi suivant, le dîner, ce sont ces restes : rien à acheter. Les jours sans restes, l'application choisit une recette de la banque des soupers, différente de celles de la semaine, pour les portions d'un dîner.</li>
    <li>Sur un jour de restes, <b>Préparer un dîner à la place</b> ajoute une recette. Sur un dîner cuisiné, <b>Manger plutôt les restes de…</b> fait l'inverse, et <b>Pas de dîner ce jour-là</b> (sous Plus) le retire.</li>
    <li>Bouton <b>+</b> → <b>Ajouter un plat au menu</b> : pour une recette de souper, choisis <b>Au souper</b> ou <b>Au dîner</b>, puis le jour.</li>
    <li>La carte <b>Aujourd'hui</b> rappelle de garder les restes du souper pour le dîner du lendemain.</li><li>Quand une grosse pièce est au menu (épaule de jambon, poulet entier, rôti de porc…), un deuxième plat qui utilise ses restes est ajouté plus tard dans la semaine : sandwichs au jambon haché, croque-monsieur, pâtes au jambon, pâté au poulet…</li>
    <li>La carte de la grosse pièce indique <b>Restes prévus pour</b> : la quantité achetée est augmentée en conséquence. Celle du deuxième plat indique <b>Avec les restes de</b> : cet ingrédient n'est pas racheté.</li>
    <li>Le deuxième plat est toujours placé après le premier. Pour ne plus jumeler les plats, décoche l'option dans Profil → Famille, carte « Organisation de la semaine ».</li></ul>`)
  + D('Plats préparés, collations, entrées et desserts', `<ul><li>Les <b>entrées</b> et les <b>desserts</b> choisis dans le questionnaire ont leur section sous les soupers, et leurs ingrédients sont dans la liste d'épicerie.</li>
    <li>Chaque <b>entrée</b> est servie <b>en entrée</b> ou <b>avec le repas</b> (en complément), avec le souper d'un jour (la fin de semaine d'abord), ou au choix. Le souper l'indique : « + entrée : bruschettas ». Change son rôle et son jour dans sa carte.</li>
    <li>La carte <b>Collations en spécial</b> (Menu) propose des fruits, yogourts, fromages, craquelins, barres et autres collations annoncés dans tes circulaires. « Ajouter » en met un paquet dans la liste pour cette semaine seulement. Pour ne plus la voir : Profil, carte « Mes collations ».</li>
    <li>Les <b>plats préparés</b> (pizza, lasagne ou pâté surgelés, poulet rôti ou sushis du comptoir…) portent l'étiquette <b>Prêt à servir</b>, et <b>En spécial</b> quand une de tes circulaires les annonce.</li>
    <li>Dans Profil → Famille, choisis : les mettre au menu quand ils sont en spécial (1 par semaine au plus), seulement les suggérer (carte « Plats préparés en spécial » du Menu), les traiter comme les autres plats, ou jamais.</li></ul>`)
  + D('Après le repas : on a aimé ou pas', `<p>Le jour même ou après, touche <b>On a aimé</b> ou <b>Pas aimé</b> sur la carte du souper. Un plat aimé revient plus souvent; un plat peu aimé revient moins souvent, et après deux « Pas aimé » il n'est plus proposé automatiquement (tu peux toujours l'ajouter toi-même). Pour l'écarter pour de bon, utilise <b>Je n'aime pas</b>.</p>`)
  + D("L'inventaire : ce qu'il y a à la maison", `<ul><li>L'onglet <b>Maison</b> garde ce que tu as. Tout ce qui s'y trouve est déduit de la liste et favorise les plats qui l'utilisent.</li>
    <li><b>Ajouter un article</b> : tape quelques lettres (« fromage », « poulet ») et touche l'aliment proposé. L'unité, le rayon et la catégorie se remplissent tout seuls; il reste à vérifier la quantité. Tu peux aussi <b>choisir par rayon</b>.</li>
    <li>Un aliment que l'application ne connaît pas est accepté : vérifie alors son rayon et sa catégorie. « Féculent » ou « Légume ou salade » en fait un accompagnement possible (un sac de rouleaux de printemps, par exemple).</li>
    <li>Une quantité très petite en grammes (3 g, par exemple) demande une confirmation : c'était peut-être 3 kg ou 3 paquets.</li>
    <li>Tape une quantité exacte ou utilise − et +. À 0, l'article disparaît. « À utiliser cette semaine » (Menu) propose d'utiliser ce qui dort à la maison.</li></ul>`)
  + D("Faire l'épicerie une seule fois", `<ol><li>L'onglet <b>Épicerie</b> classe tout <b>par rayon</b> ou <b>par magasin</b>. Par magasin, chaque article va à l'épicerie de la semaine où il coûte nettement moins; le reste va à ton épicerie principale.</li>
    <li><b>Où faire l'épicerie</b> : en haut de la liste (touche pour l'ouvrir), le coût de toute la liste dans chacune de tes épiceries, spéciaux et prix réguliers compris, puis l'économie possible en allant à 2, 3 ou 4 endroits. L'application ne compte pas l'essence ni le temps : c'est à toi de voir si l'économie vaut le déplacement. Touche <b>Choisir</b> : la liste se sépare par épicerie.</li>
    <li><b>Mode magasin</b> : gros texte, écran qui reste allumé quand le téléphone le permet, et les articles cochés descendent dans « Dans le panier ». Touche <b>Quitter</b> pour revenir.</li>
    <li>« Vérifier avant de partir » rappelle les articles toujours à la maison : touche <b>Il manque</b> au besoin.</li>
    <li>Avec un <b>budget</b> (Profil → Prix et budget), l'onglet montre ton budget et le coût estimé des articles en spécial. Au retour, inscris le <b>total payé</b> à la caisse : la moyenne payée s'affiche dans Menu → Semaines passées.</li>
    <li><b>Prix et budget</b> : chaque article montre le prix de l'épicerie où il va. Un prix sans « ≈ » est un vrai prix : un spécial de la circulaire, une promotion ou un prix relevé sur le site de l'épicerie, ou le prix que tu as payé. « ≈ » veut dire un prix estimé. Touche un prix pour noter ce que tu as payé : l'application le retient pour cette épicerie. Le total estimé se compare à ton budget.</li>
    <li><b>Prix des épiceries</b> (Profil → Prix et budget) : chaque jeudi matin, un robot relève sur les sites de Maxi et d'IGA les prix réguliers et les promotions de près de 150 articles de base, pour les magasins de Saint-Georges. L'application va chercher ce relevé toute seule une fois par jour; « Mettre à jour les prix maintenant » le fait tout de suite. Walmart, Marché Ami, Inter-Marché et les autres n'ont pas de prix en ligne lisibles : le robot note aussi, à part, le prix des marques connues (Québon, Heinz, Kraft…) chez Maxi et IGA, qui est à peu près le même partout : c'est ce prix qui compte pour ces épiceries, sinon une estimation d'après leur écart habituel avec Maxi. Leurs circulaires et les prix que tu inscris passent en premier.</li>
    <li><b>Moins cher ailleurs</b> : sous un article, l'application indique s'il coûte nettement moins dans une autre de tes épiceries (d'après un vrai prix seulement).</li>
    <li><b>Vraies aubaines</b> : un rabais d'au moins 35 % sur un produit qui se garde (viande et poisson à congeler, surgelés, garde-manger, beurre, fromage) apparaît dans « Vraies aubaines : fais des réserves », avec un conseil de conservation et « En ajouter ».</li>
    <li>Coche les articles dans le panier, puis touche <b>Épicerie terminée</b> au retour : ils entrent dans Maison.</li></ol>`)
  + D('Terminer la semaine', `<p><b>Terminer la semaine</b> (Menu) retire de Maison ce qui a été utilisé, garde les restes et range les plats dans l'historique. Exemple : 12 oeufs achetés, 8 utilisés, il en reste 4 pour la semaine suivante.</p>`)
  + D('Partager, envoyer et importer', `<ul><li>Rien n'est partagé automatiquement. Le bouton <b>Partager</b> (Menu ou Épicerie) copie la liste d'épicerie, le menu de la semaine ou le menu détaillé, ou crée une image du menu pour le frigo. Colle le texte dans un message ou dans Notes.</li>
    <li>Chaque recette a son bouton <b>Copier cette recette</b>. Le message se termine par un code qui contient toute la recette, versions comprises.</li>
    <li>Pour la recevoir sur un autre téléphone : bouton <b>+</b> → <b>Coller une recette</b>, colle le message, touche <b>Importer</b>. Plusieurs recettes peuvent être collées d'un coup.</li>
    <li><b>Recette d'un site Internet</b> (Ricardo, 5-15, Pratico-pratiques…) : dans ${esc(NAVI)}, sélectionne le titre, les ingrédients et la préparation, touche Copier, puis colle dans « Coller une recette » (bouton +). L'application comprend les mesures (c. à soupe, tasse, lb, boîte de 796 ml), les fractions et les mots de préparation (haché, en dés, au goût), relie chaque ingrédient à un aliment connu et ajuste la recette à 6 portions. Le formulaire « Nouvelle recette » se remplit : vérifie, puis enregistre. Astuce : le bouton Partager → Copier ne copie que le lien; la version « Imprimer » du site rend la sélection plus facile.</li></ul>`)
  + D('La banque de recettes', `<ul><li>L'onglet <b>Recettes</b> regroupe les plats par <b>protéine</b>, par <b>style</b> ou par <b>genre</b> (soupers, entrées, desserts). En haut, la recherche et les catégories (Soupers, Repas plaisir, TikTok, Desserts…); la protéine, le style, « 30 min ou moins » et les favoris sont sous <b>Filtres</b>. Chaque groupe montre 6 recettes : « Voir les … » montre les autres.</li>
    <li><b>Je n'aime pas</b> met une recette de côté : elle n'est plus jamais proposée. Coche « Mis de côté » (sous Filtres) pour les revoir et <b>Remettre dans la banque</b>.</li>
    <li><b>Accompagnements</b> : chaque souper montre son féculent et son légume. « Varié » laisse l'application choisir chaque semaine parmi ceux qui vont avec le plat; choisis-en un pour l'avoir à tout coup, ou « Aucun ». La section <b>Accompagnements</b> (catégorie Accompagnements) montre tous les féculents et légumes avec leurs ingrédients; « Ne plus le proposer » le retire des choix automatiques.</li>
    <li><b>Tendances TikTok</b> : Recettes → catégorie TikTok. La plupart sont des versions de plats que tu connais déjà (poulet « marry me », escalope géante, feta au four, zuppa toscana, tiramisu au yogourt, brownies Dubaï…) : ouvre le plat et choisis la version marquée (TikTok), ou tape son nom dans bouton + → « Ajouter un plat au menu » : la bonne version est choisie d'office. Les tacos birria et la lasagne aux dumplings sont des plats à part.</li>
    <li><b>Repas plaisir et soirs de match</b> : Recettes → catégorie Repas plaisir : les poutines gastronomiques, la fondue chinoise et les recettes de soirs de match (bouchées, frites chargées, bombe de bacon, bacon maison…). Ces recettes « À l'occasion » ne sont jamais choisies comme souper ordinaire. Dans le questionnaire de la semaine, « Dont repas plaisir » (0, 1 ou 2) en met au menu, le vendredi ou le samedi d'abord, jamais deux soirs de suite. Les bouchées s'ajoutent à la main (Ajouter au menu de la semaine), ou dans une liste à part : bouton + → « Je reçois ou repas à deux ».</li>
    <li><b>Soupes et potages</b> : une soupe sert de trois façons. <b>Soupe-repas</b> : elle remplace un souper et vient avec son accompagnement (grilled cheese, pain croûté et cheddar, sandwichs, salade). <b>À côté du souper</b> : elle accompagne le souper d'un jour de semaine. <b>Pour les lunchs</b>. Choisis combien de chaque sorte dans le questionnaire de la semaine; dans la carte d'une soupe, « Servie » change son rôle.</li>
    <li><b>Sauces</b> : des compléments, pas des repas. Ouvre un souper du menu et choisis une « Sauce en complément » (sauce au poivre avec un steak, par exemple), ou touche <b>Ajouter à un plat du menu</b> dans la recette de la sauce. Ses ingrédients vont dans la liste d'épicerie.</li>
    <li><b>Nouvelle recette</b> (bouton +), <b>Modifier la recette</b> et les versions utilisent le même formulaire guidé : pour chaque ingrédient, tape quelques lettres, touche l'aliment proposé, puis indique la quantité et l'unité dans les menus. Le rayon se remplit tout seul; pour un aliment nouveau, l'application demande dans quel rayon il se trouve.</li>
    <li><b>Ajouter une version</b> ou <b>Modifier cette version</b> : coche les ingrédients à retirer, ajoute ceux qui changent, choisis l'accompagnement et écris la préparation propre à cette version. « Retirer cette version » la cache, « Rétablir les variantes d'origine » annule tes changements.</li>
    <li>Ce que tu tapes dans un formulaire reste là même si tu changes d'onglet. Un message sous le formulaire indique ce qui manque (un nom, une quantité…).</li>
    <li>Les soupers sont écrits pour 6 portions et ajustés à tes portions; les entrées et desserts donnent environ 6 à 8 portions.</li></ul>`)
  + D('Reels et photos du frigo, avec ton Gemini', `<ul><li>Il faut <b>ta clé Gemini</b>, gratuite : Profil → Compte → « Ta clé Gemini ». Ouvre aistudio.google.com avec ton compte Google (18 ans et plus), touche « Create API key », copie la clé et colle-la. Elle reste sur ce téléphone, hors des sauvegardes.</li>
    <li><b>Un reel en recette</b> : bouton + → Importer un reel. Envoie 1 à 4 captures d'écran (la description ouverte au complet, les écrans de la recette) et le lien. En quelques secondes, le formulaire « Nouvelle recette » est rempli : vérifie, puis « Enregistrer la recette ». Avec le code de la famille, coche « Ajouter à la banque commune » pour que toute la famille l'ait.</li>
    <li><b>Photo du frigo</b> : bouton + → Photo du frigo (aussi dans Épicerie → Maison). Photographie le frigo, le congélateur ou le garde-manger; Gemini liste ce qu'il voit. Corrige, décoche, puis « Mettre à jour Maison ».</li>
    <li>Chacun utilise sa propre limite gratuite de Gemini. Les images vont seulement à Google, qui les lit; avec la version gratuite, Google peut s'en servir pour améliorer ses produits.</li></ul>`)
  + D('Les goûts de chacun', `<ul><li>Profil → Famille : chaque personne a un prénom (facultatif) et ses <b>goûts</b>, notés <b>J'adore</b>, <b>J'aime</b>, <b>Je tolère</b>, <b>Je n'aime pas</b> ou <b>Refuse d'en manger</b> : les protéines, les sortes de plats et quelques aliments (champignons, poivrons, oignons…). « Refuse aussi » ajoute d'autres aliments.</li>
    <li>Le menu favorise ce que chacun aime et répartit les coups de cœur : chacun a les siens dans la semaine. « Je n'aime pas » fait passer un plat après les autres.</li>
    <li><b>Refuse d'en manger</b> : un plat que personne ne mange n'est jamais proposé. Si seulement certains refusent la protéine principale (le poisson, par exemple), une <b>2e protéine</b> est prévue pour eux, cuite à part avec le même assaisonnement : la quantité de poisson diminue et le poulet s'ajoute à la liste. Dans la carte du plat ou dans l'ébauche, choisis une autre 2e protéine, ou « Aucune ».</li>
    <li>Chaque semaine, le questionnaire demande quoi faire : 2e protéine au besoin, éviter ces plats, ou même plat pour tous.</li></ul>`)
  + D('Si la recherche des spéciaux ne fonctionne pas', `<ul><li>Les spéciaux sont réservés à la famille et aux amis : il faut le <b>code de la famille</b> (Profil → Compte). Le robot lit les circulaires le mercredi soir et le jeudi matin; le téléphone les reçoit chiffrées, sans interroger Flipp.</li>
    <li>« Le code ne fonctionne plus » : le code de la famille a changé. Oublie l'ancien et entre le nouveau.</li>
    <li>Vérifie tes épiceries et ton code postal dans Profil → Épiceries.</li>
    <li>Si le navigateur bloque la requête, copie le texte d'une circulaire (<a href="https://flipp.com/fr-ca" target="_blank" rel="noopener">Flipp</a>) et colle-le dans Menu → Spéciaux et dates → « Si la recherche ne fonctionne pas ».</li>
    <li>Sans spéciaux, tout fonctionne : le menu est simplement choisi sans les rabais.</li></ul>`)
  + D('Sauvegarder', `<ul><li>Les données sont enregistrées sur ce téléphone à chaque action. <b>Une mise à jour de l'application ne les touche pas</b> : elle remplace seulement le code, et chaque nouvelle version lit les données de l'ancienne.</li>
    <li>Par sécurité, l'application garde une <b>copie automatique</b> avant chaque mise à jour et une fois par jour (les 5 dernières, dans Profil → Compte). Si une version n'arrive pas à lire tes données, elle les met de côté au lieu de les effacer.</li>
    <li>Ce qui peut effacer les données : ${IOS ? "supprimer l'icône de l'écran d'accueil, effacer les données des sites dans les réglages de l'iPhone" : "désinstaller l'application, effacer les données de Chrome (ou du site) dans les réglages d'Android"}, ou ouvrir l'application à une autre adresse. Garde la même adresse et ne supprime pas l'application.</li>
    <li>Pour être protégé même dans ces cas : Profil → Compte → <b>Sauvegarder une copie</b>${IOS ? ', puis « Enregistrer dans Fichiers »' : ' : le fichier va dans Téléchargements'}. Fais-le après avoir rempli ton garde-manger, puis une fois par mois. Pour revenir en arrière : « Restaurer une copie » et choisis le fichier.</li></ul>`)
  + D("Articles : corriger un spécial, convertir une mesure", `<ul><li>Profil → Prix et budget → <b>Articles</b> montre le spécial associé à chaque article de ta liste (« Ma liste »), de tous les articles connus (« Tous ») ou de ceux que tu as modifiés.</li>
    <li>Un spécial n'est pas le bon ? Touche « Pas le bon ? » sous l'étiquette jaune dans la liste, ou ouvre l'article. Choisis un autre spécial, « Aucun spécial cette semaine », ou cherche le bon dans les circulaires : « Cette semaine » l'associe jusqu'à la fin de la semaine, « Toujours » retient ce produit pour les prochaines semaines.</li>
    <li>Tu peux aussi changer les <b>mots recherchés</b> (une virgule sépare deux façons de le nommer), ajouter des <b>mots à exclure</b> (pané, assaisonné…), choisir le <b>rayon</b>, le <b>format du paquet</b> et le <b>prix habituel</b>.</li>
    <li>À chaque recherche des spéciaux, le prix trouvé est noté. Quand un article n'est pas en spécial, la liste dit à quel prix il l'est souvent.</li>
    <li>Le <b>convertisseur</b> passe des g aux lb, des ml aux tasses et cuillères (avec la densité de la farine, du sucre, du beurre…), et des prix à la livre aux prix au kilo.</li></ul>`)
  + D("Partager l'application", `<p>Pour l'installer sur un autre téléphone, ouvre ce lien dans Safari (iPhone) ou Chrome (Android), ou montre ce code à scanner avec l'appareil photo :</p>
    <p><a href="https://mdulac86.github.io/Menu/">mdulac86.github.io/Menu</a></p><p><img src="qr-menu.png" width="160" height="160" alt="Code QR vers l'application"></p>
    <p class="small">Chaque personne a ses propres données : rien n'est partagé entre les téléphones.</p>`)
  + D('Vie privée', `<ul><li>Tes données (famille, menus, liste, prix) restent <b>sur ton téléphone</b>. Aucun compte, aucune collecte.</li>
    <li>Avec le code de la famille, les spéciaux et les prix viennent du robot : le téléphone n'envoie rien à Flipp. Ton <b>code postal</b> est envoyé à Flipp seulement si le fichier du robot manque, ou pour trouver les épiceries près de chez toi sans le code.</li>
    <li>Le code de la famille et ta clé Gemini restent sur ton téléphone. Ils ne sont ni dans les sauvegardes ni dans le code de l'application.</li>
    <li>Les liens vers les sites des épiceries ouvrent leur page de recherche dans ${esc(NAVI)}.</li></ul>`)
  + D("Droits d'auteur", `<p>© 2026 mdulac86. Tous droits réservés.</p>
    <p>Tu peux utiliser l'application et partager son lien. Le code, les recettes, les prix et les textes ne peuvent pas être copiés, modifiés ou publiés ailleurs sans permission. Les recettes envoyées avec « Copier cette recette » peuvent être échangées entre utilisateurs, pour un usage personnel.</p>`)
  + (self.APP_CONTACT ? D('Signaler un problème ou une idée', `<p><a class="btn s p" href="mailto:${esc(self.APP_CONTACT)}?subject=${encodeURIComponent('Menu de la semaine ' + APPV)}&body=${encodeURIComponent('Appareil : ' + navigator.userAgent + '\n\n')}">Écrire un courriel</a></p><p class="small">La version de l'application et le modèle du téléphone sont ajoutés; aucune de tes données.</p>`) : '')
  + D('Questions fréquentes', `<p><b>Le menu ne change pas quand je le refais.</b> Les plats « Gardé » restent; une fois l'épicerie terminée, le menu est verrouillé jusqu'à « Terminer la semaine ».</p>
    <p><b>Un article est en double.</b> Deux recettes le nomment différemment; additionne-les en magasin.</p>
    <p><b>Les quantités ne conviennent pas.</b> Ajuste les portions (Profil ou repas par repas), les quantités d'accompagnements, ou modifie la recette. Les quantités des recettes sont des estimations : corrige celles qui ne conviennent pas à ta famille.</p>
    <p><b>Un spécial ne correspond pas à l'article</b> (ex. des oeufs Kinder pour des oeufs). Profil → Prix et budget → Articles → l'article → « Pas ce produit » : il ne sera plus jamais associé. Les friandises, plats préparés et produits « à la » ou « aux » (nouilles aux oeufs, poulet au beurre) sont déjà écartés automatiquement.</p>
    <p><b>Tout recommencer.</b> Profil → Compte → « Tout remettre à zéro ».</p>`);
}


/* ---------- démarrage ---------- */
/* un brouillon de recette réellement commencé (pas seulement un formulaire vide ouvert) */
const draftsDirty = () => { try{ return Object.values(drafts).some(d => d && ((typeof d.n==='string' && d.n.trim()) || (typeof d.s==='string' && d.s.trim()) || (Array.isArray(d.rows) && d.rows.some(r => r && typeof r.n==='string' && r.n.trim())))); }catch(e){ return false; } };
const missingFiles = () => [typeof RECIPES==='undefined' && 'recettes.js', typeof BAREME==='undefined' && 'prix-maxi.js', typeof recipePhoto==='undefined' && 'photos.js'].filter(Boolean);
(function init(){
  try{ if('serviceWorker' in navigator && /^https?:/.test(location.protocol)){
    const had = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.register(TEST_PAGE ? 'sw-test.js' : 'sw.js', TEST_PAGE ? {updateViaCache: 'none', scope: './test'} : {updateViaCache: 'none'}).then(reg => { document.addEventListener('visibilitychange', () => { if(document.visibilityState==='visible') reg.update().catch(()=>{}); }); }).catch(()=>{});
    navigator.serviceWorker.addEventListener('controllerchange', () => { if(draftsDirty()){ setSync('Nouvelle version prête : elle s\'appliquera à la prochaine ouverture.'); return; } if(had && !sessionStorage.getItem(PFX+'maj')){ try{ sessionStorage.setItem(PFX+'maj', '1'); }catch(e){} location.reload(); } });
  } }catch(e){}
  loadLocal();
  migrer();
  peLoad(); peSel();
  /* le dernier relevé des prix, une fois par jour : l'application fonctionne sans, avec l'estimation */
  /* on redessine seulement si personne n'est en train de toucher l'écran (sinon, au prochain affichage) */
  let lastTouch = 0; ['pointerdown','keydown','change','input'].forEach(ev => document.addEventListener(ev, () => { lastTouch = Date.now(); }, true));
  setTimeout(() => { famFetch(false).then(ch => { if(ch && S.setup && Date.now() - lastTouch > 3000 && !draftsDirty()) render(); }).catch(() => {});
    ['recette', 'inventaire'].forEach(ty => { const j = robotJobs[ty];
      if(j && j.direct && j.etat === 'attente'){ j.etat = 'erreur'; j.rep = {erreur:'La lecture a été interrompue (application fermée).'}; jobsSave(); render(); }
      else if(j && j.etat === 'pret' && robotFini(ty)) render(); else if(j && j.etat === 'attente') robotSuivre(ty, ty==='recette' ? 'reel' : 'inv'); }); }, 900);
  setTimeout(() => { peFetch(false).then(ch => { if(!ch) return; save(); const ae = document.activeElement;
    if(S.setup && Date.now() - lastTouch > 3000 && !draftsDirty() && !(ae && /INPUT|TEXTAREA|SELECT/.test(ae.tagName))) render(); }).catch(() => {}); }, 400);
  try{ if(navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(()=>{}); }catch(e){}
  try{ matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme); }catch(e){}
  try{ render(); }
  catch(err){
    /* un fichier de l'application n'a pas été chargé (connexion) : ce ne sont pas les données, on ne touche à rien */
    if(missingFiles().length){ setSync("Un fichier de l'application n'a pas pu être chargé (" + missingFiles().join(', ') + "). Vérifie la connexion et recharge la page. Tes données sont intactes."); return; }
    /* données qui empêchent l'affichage : on les met de côté et on n'enregistre plus rien par-dessus */
    try{ const j = localStorage.getItem(KEY); if(j && !localStorage.getItem(RESCUE)) localStorage.setItem(RESCUE, j); }catch(_){}
    loadFailed = true; rescued = false; S = DEFAULT(); S.appv = APPV;
    S.flash = "Tes données ont causé une erreur d'affichage. Elles sont gardées telles quelles, rien n'est effacé ni remplacé : Profil → Compte → « Essayer de les restaurer », ou « Tout remettre à zéro » pour repartir.";
    try{ render(); }catch(_){}
  }
  setSync(loadFailed ? 'Mode secours : tes données sont gardées de côté' : 'Enregistré sur cet appareil');
  /* dernière protection : une erreur imprévue s'affiche au lieu de bloquer l'application en silence */
  window.addEventListener('error', e => { setSync('Petit problème : ' + (e.message || 'erreur') + '. Tes données sont intactes.'); });
  window.addEventListener('unhandledrejection', e => { setSync('Petit problème : ' + ((e.reason && e.reason.message) || 'erreur') + '. Tes données sont intactes.'); });
})();

